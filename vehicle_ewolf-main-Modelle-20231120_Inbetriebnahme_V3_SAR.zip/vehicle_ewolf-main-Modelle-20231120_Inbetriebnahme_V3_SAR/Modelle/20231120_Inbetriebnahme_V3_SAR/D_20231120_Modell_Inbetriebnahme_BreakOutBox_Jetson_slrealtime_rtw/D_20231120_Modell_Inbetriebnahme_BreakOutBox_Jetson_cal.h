#ifndef RTW_HEADER_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal_h_
#define RTW_HEADER_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal_h_
#include "rtwtypes.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"
#include "PathFollowingControlSystem_cal.h"

/* Storage class 'PageSwitching', for system '<S81>/Enabled Subsystem' */
struct D_202_EnabledSubsystem_cal_type {
  real_T Out1_Y0;                      /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S82>/Out1'
                                        */
};

/* Storage class 'PageSwitching', for system '<Root>' */
struct D_20231120_Modell_Inbe_cal_type {
  real_T PIDController_InitialConditionF;
                              /* Mask Parameter: PIDController_InitialConditionF
                               * Referenced by: '<S119>/Integrator'
                               */
  real_T PIDController_LowerSaturationLi;
                              /* Mask Parameter: PIDController_LowerSaturationLi
                               * Referenced by: '<S126>/Saturation'
                               */
  real_T PIDController_UpperSaturationLi;
                              /* Mask Parameter: PIDController_UpperSaturationLi
                               * Referenced by: '<S126>/Saturation'
                               */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S44>/Constant'
                                       */
  real_T CompareToConstant_const_a; /* Mask Parameter: CompareToConstant_const_a
                                     * Referenced by: '<S64>/Constant'
                                     */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S65>/Constant'
                                      */
  real_T CompareToConstant3_const;   /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S67>/Constant'
                                      */
  real_T CompareToConstant_const_k; /* Mask Parameter: CompareToConstant_const_k
                                     * Referenced by: '<S58>/Constant'
                                     */
  real_T CompareToConstant1_const_f;
                                   /* Mask Parameter: CompareToConstant1_const_f
                                    * Referenced by: '<S59>/Constant'
                                    */
  real_T CompareToConstant4_const;   /* Mask Parameter: CompareToConstant4_const
                                      * Referenced by: '<S62>/Constant'
                                      */
  real_T CompareToConstant6_const;   /* Mask Parameter: CompareToConstant6_const
                                      * Referenced by: '<S23>/Constant'
                                      */
  real_T CompareToConstant1_const_o;
                                   /* Mask Parameter: CompareToConstant1_const_o
                                    * Referenced by: '<S19>/Constant'
                                    */
  real_T CompareToConstant5_const;   /* Mask Parameter: CompareToConstant5_const
                                      * Referenced by: '<S33>/Constant'
                                      */
  real_T CompareToConstant7_const;   /* Mask Parameter: CompareToConstant7_const
                                      * Referenced by: '<S24>/Constant'
                                      */
  real_T CompareToConstant3_const_k;
                                   /* Mask Parameter: CompareToConstant3_const_k
                                    * Referenced by: '<S21>/Constant'
                                    */
  real_T CompareToConstant4_const_k;
                                   /* Mask Parameter: CompareToConstant4_const_k
                                    * Referenced by: '<S22>/Constant'
                                    */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S66>/Constant'
                                      */
  real_T CompareToConstant_const_j; /* Mask Parameter: CompareToConstant_const_j
                                     * Referenced by: '<S63>/Constant'
                                     */
  real_T CompareToConstant_const_kb;
                                   /* Mask Parameter: CompareToConstant_const_kb
                                    * Referenced by: '<S204>/Constant'
                                    */
  real_T CompareToConstant1_const_k;
                                   /* Mask Parameter: CompareToConstant1_const_k
                                    * Referenced by: '<S205>/Constant'
                                    */
  real_T EdgeDetector_model;           /* Mask Parameter: EdgeDetector_model
                                        * Referenced by: '<S36>/Constant1'
                                        */
  real_T TappedDelay1_vinit;           /* Mask Parameter: TappedDelay1_vinit
                                        * Referenced by: '<S42>/Tapped Delay1'
                                        */
  real_T TappedDelay_vinit;            /* Mask Parameter: TappedDelay_vinit
                                        * Referenced by: '<S60>/Tapped Delay'
                                        */
  real_T TappedDelay_vinit_h;          /* Mask Parameter: TappedDelay_vinit_h
                                        * Referenced by: '<S61>/Tapped Delay'
                                        */
  real_T TappedDelay_vinit_hn;         /* Mask Parameter: TappedDelay_vinit_hn
                                        * Referenced by: '<S14>/Tapped Delay'
                                        */
  real_T TappedDelay_vinit_c;          /* Mask Parameter: TappedDelay_vinit_c
                                        * Referenced by: '<S15>/Tapped Delay'
                                        */
  real_T TappedDelay1_vinit_e;         /* Mask Parameter: TappedDelay1_vinit_e
                                        * Referenced by: '<S54>/Tapped Delay1'
                                        */
  boolean_T CompareToConstant2_const_a;
                                   /* Mask Parameter: CompareToConstant2_const_a
                                    * Referenced by: '<S20>/Constant'
                                    */
  boolean_T EdgeDetector_ic;           /* Mask Parameter: EdgeDetector_ic
                                        * Referenced by: '<S36>/Memory'
                                        */
  boolean_T SRFlipFlop_initial_condition;
                                 /* Mask Parameter: SRFlipFlop_initial_condition
                                  * Referenced by: '<S55>/Memory'
                                  */
  boolean_T DetectIncrease_vinit;      /* Mask Parameter: DetectIncrease_vinit
                                        * Referenced by: '<S30>/Delay Input1'
                                        */
  boolean_T DetectIncrease_vinit_h;    /* Mask Parameter: DetectIncrease_vinit_h
                                        * Referenced by: '<S32>/Delay Input1'
                                        */
  boolean_T DetectIncrease_vinit_e;    /* Mask Parameter: DetectIncrease_vinit_e
                                        * Referenced by: '<S57>/Delay Input1'
                                        */
  struct_6wJYULTF6Ls8uk5VTDhG3G CAN_Out_Y0;/* Computed Parameter: CAN_Out_Y0
                                            * Referenced by: '<S68>/CAN_Out'
                                            */
  struct_6CClcx4Z7WqHzsyX3vL1wG CAN_Out_Y0_n;/* Computed Parameter: CAN_Out_Y0_n
                                              * Referenced by: '<S69>/CAN_Out'
                                              */
  real_T Constant3_Value;              /* Expression: 0
                                        * Referenced by: '<S26>/Constant3'
                                        */
  real_T Out1_Y0;                      /* Expression: -1e6
                                        * Referenced by: '<S40>/Out1'
                                        */
  real_T posedge_Value[2];             /* Expression: [1 0]
                                        * Referenced by: '<S36>/pos. edge'
                                        */
  real_T negedge_Value[2];             /* Expression: [0 1]
                                        * Referenced by: '<S36>/neg. edge'
                                        */
  real_T eitheredge_Value[2];          /* Expression: [1 1]
                                        * Referenced by: '<S36>/either edge'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S2>/Constant5'
                                        */
  real_T Constant2_Value;              /* Expression: -45
                                        * Referenced by: '<S2>/Constant2'
                                        */
  real_T Constant1_Value;              /* Expression: -90
                                        * Referenced by: '<S2>/Constant1'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: -45
                                        * Referenced by: '<S2>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -135
                                        * Referenced by: '<S2>/Saturation1'
                                        */
  real_T Saturation2_UpperSat;         /* Expression: 1
                                        * Referenced by: '<S2>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: -1
                                        * Referenced by: '<S2>/Saturation2'
                                        */
  real_T Constant_Value;               /* Expression: 0.5
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T Constant6_Value;              /* Expression: 0.5
                                        * Referenced by: '<S43>/Constant6'
                                        */
  real_T Constant7_Value;              /* Expression: 3
                                        * Referenced by: '<S43>/Constant7'
                                        */
  real_T Constant4_Value;              /* Expression: 45
                                        * Referenced by: '<S2>/Constant4'
                                        */
  real_T Constant3_Value_j;            /* Expression: 0
                                        * Referenced by: '<S2>/Constant3'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 45
                                        * Referenced by: '<S2>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -45
                                        * Referenced by: '<S2>/Saturation'
                                        */
  real_T Multiply_Gain;                /* Expression: 0.5
                                        * Referenced by: '<S43>/Multiply'
                                        */
  real_T Saturation3_UpperSat;         /* Expression: 1
                                        * Referenced by: '<S2>/Saturation3'
                                        */
  real_T Saturation3_LowerSat;         /* Expression: -1
                                        * Referenced by: '<S2>/Saturation3'
                                        */
  real_T Constant1_Value_p;            /* Expression: 0
                                        * Referenced by: '<S50>/Constant1'
                                        */
  real_T Constant_Value_e;             /* Expression: 1
                                        * Referenced by: '<S50>/Constant'
                                        */
  real_T Saturation_UpperSat_a;        /* Expression: 1
                                        * Referenced by: '<S50>/Saturation'
                                        */
  real_T Saturation_LowerSat_o;        /* Expression: 0
                                        * Referenced by: '<S50>/Saturation'
                                        */
  real_T CANRead1_P1_Size[2];          /* Computed Parameter: CANRead1_P1_Size
                                        * Referenced by: '<S68>/CAN Read1'
                                        */
  real_T CANRead1_P1[7];
            /* Expression: [initValues(1:4) messageType initValues(6) BusOutput]
             * Referenced by: '<S68>/CAN Read1'
             */
  real_T Gain_Gain;                    /* Expression: 1
                                        * Referenced by: '<S68>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain1'
                                        */
  real_T Gain10_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain10'
                                        */
  real_T Gain11_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain11'
                                        */
  real_T Gain12_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain12'
                                        */
  real_T Gain13_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain13'
                                        */
  real_T Gain14_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain14'
                                        */
  real_T Gain15_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain15'
                                        */
  real_T Gain16_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain16'
                                        */
  real_T Gain17_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain17'
                                        */
  real_T Gain18_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain18'
                                        */
  real_T Gain19_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain19'
                                        */
  real_T Gain2_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain2'
                                        */
  real_T Gain20_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain20'
                                        */
  real_T Gain21_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain21'
                                        */
  real_T Gain22_Gain;                  /* Expression: 1
                                        * Referenced by: '<S68>/Gain22'
                                        */
  real_T Gain3_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain3'
                                        */
  real_T Gain4_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain4'
                                        */
  real_T Gain5_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain5'
                                        */
  real_T Gain6_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain6'
                                        */
  real_T Gain7_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain7'
                                        */
  real_T Gain8_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain8'
                                        */
  real_T Gain9_Gain;                   /* Expression: 1
                                        * Referenced by: '<S68>/Gain9'
                                        */
  real_T CANRead1_P1_Size_n[2];        /* Computed Parameter: CANRead1_P1_Size_n
                                        * Referenced by: '<S69>/CAN Read1'
                                        */
  real_T CANRead1_P1_l[7];
            /* Expression: [initValues(1:4) messageType initValues(6) BusOutput]
             * Referenced by: '<S69>/CAN Read1'
             */
  real_T Gain_Gain_i;                  /* Expression: 1
                                        * Referenced by: '<S69>/Gain'
                                        */
  real_T Gain1_Gain_f;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain1'
                                        */
  real_T Gain10_Gain_l;                /* Expression: 1
                                        * Referenced by: '<S69>/Gain10'
                                        */
  real_T Gain11_Gain_e;                /* Expression: 1
                                        * Referenced by: '<S69>/Gain11'
                                        */
  real_T Gain12_Gain_f;                /* Expression: 1
                                        * Referenced by: '<S69>/Gain12'
                                        */
  real_T Gain13_Gain_k;                /* Expression: 1
                                        * Referenced by: '<S69>/Gain13'
                                        */
  real_T Gain14_Gain_n;                /* Expression: 1
                                        * Referenced by: '<S69>/Gain14'
                                        */
  real_T Gain2_Gain_m;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain2'
                                        */
  real_T Gain3_Gain_p;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain3'
                                        */
  real_T Gain4_Gain_n;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain4'
                                        */
  real_T Gain5_Gain_m;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain5'
                                        */
  real_T Gain6_Gain_p;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain6'
                                        */
  real_T Gain7_Gain_h;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain7'
                                        */
  real_T Gain8_Gain_l;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain8'
                                        */
  real_T Gain9_Gain_e;                 /* Expression: 1
                                        * Referenced by: '<S69>/Gain9'
                                        */
  real_T RatioLenkradwinkelLenkwinkel_Va;/* Expression: 20.3
                                          * Referenced by: '<S70>/Ratio Lenkradwinkel Lenkwinkel'
                                          */
  real_T Saturation1_UpperSat_i;       /* Expression: 1
                                        * Referenced by: '<S75>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_h;       /* Expression: 0
                                        * Referenced by: '<S75>/Saturation1'
                                        */
  real_T InitialVelocity_Value;        /* Expression: 0.1
                                        * Referenced by: '<S138>/Initial Velocity'
                                        */
  real_T Constant1_Value_n;            /* Expression: 50
                                        * Referenced by: '<S12>/Constant1'
                                        */
  real_T Constant_Value_p;             /* Expression: 50
                                        * Referenced by: '<S12>/Constant'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S29>/Constant'
                                        */
  real_T Constant_Value_h;             /* Expression: 0
                                        * Referenced by: '<S31>/Constant'
                                        */
  real_T Constant_Value_d;             /* Expression: 0
                                        * Referenced by: '<S25>/Constant'
                                        */
  real_T Constant_Value_a;             /* Expression: 0
                                        * Referenced by: '<S34>/Constant'
                                        */
  real_T Constant_Value_n;             /* Expression: 0
                                        * Referenced by: '<S35>/Constant'
                                        */
  real_T Constant_Value_g;             /* Expression: 0
                                        * Referenced by: '<S56>/Constant'
                                        */
  real_T Constant_Value_j;             /* Expression: 0
                                        * Referenced by: '<S51>/Constant'
                                        */
  real_T Setup_P1_Size[2];             /* Computed Parameter: Setup_P1_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P1;                     /* Expression: parPciSlot
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P2_Size[2];             /* Computed Parameter: Setup_P2_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P2;                     /* Expression: parModuleId
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P3_Size[2];             /* Computed Parameter: Setup_P3_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P3;                     /* Expression: parTriggerSignal
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P4_Size[2];             /* Computed Parameter: Setup_P4_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P4[4];                  /* Expression: parAdcChannels
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P5_Size[2];             /* Computed Parameter: Setup_P5_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P5;                     /* Expression: parAdcMode
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P6_Size[2];             /* Computed Parameter: Setup_P6_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P6[4];                  /* Expression: parAdcRanges
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P7_Size[2];             /* Computed Parameter: Setup_P7_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P7[4];                  /* Expression: parDacChannels
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P8_Size[2];             /* Computed Parameter: Setup_P8_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P8[4];                  /* Expression: parDacRanges
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P9_Size[2];             /* Computed Parameter: Setup_P9_Size
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Setup_P9;                     /* Expression: parDioFirstControl
                                        * Referenced by: '<S6>/Setup '
                                        */
  real_T Analoginput_P1_Size[2];      /* Computed Parameter: Analoginput_P1_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P1;               /* Expression: parModuleId
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P2_Size[2];      /* Computed Parameter: Analoginput_P2_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P2;               /* Expression: parSampleTime
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P3_Size[2];      /* Computed Parameter: Analoginput_P3_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P3;               /* Expression: parPciSlot
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P4_Size[2];      /* Computed Parameter: Analoginput_P4_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P4[4];            /* Expression: parAdcChannels
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P5_Size[2];      /* Computed Parameter: Analoginput_P5_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P5;               /* Expression: parAdcMode
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P6_Size[2];      /* Computed Parameter: Analoginput_P6_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P6;               /* Expression: parAdcRate
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P7_Size[2];      /* Computed Parameter: Analoginput_P7_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P7[4];            /* Expression: parAdcRanges
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P8_Size[2];      /* Computed Parameter: Analoginput_P8_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P8[2];            /* Expression: parAdcInitValues
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Analoginput_P9_Size[2];      /* Computed Parameter: Analoginput_P9_Size
                                       * Referenced by: '<S6>/Analog input '
                                       */
  real_T Analoginput_P9[2];            /* Expression: parAdcResets
                                        * Referenced by: '<S6>/Analog input '
                                        */
  real_T Digitalinput_P1_Size[2];    /* Computed Parameter: Digitalinput_P1_Size
                                      * Referenced by: '<S6>/Digital input '
                                      */
  real_T Digitalinput_P1;              /* Expression: parModuleId
                                        * Referenced by: '<S6>/Digital input '
                                        */
  real_T Digitalinput_P2_Size[2];    /* Computed Parameter: Digitalinput_P2_Size
                                      * Referenced by: '<S6>/Digital input '
                                      */
  real_T Digitalinput_P2;              /* Expression: parSampleTime
                                        * Referenced by: '<S6>/Digital input '
                                        */
  real_T Digitalinput_P3_Size[2];    /* Computed Parameter: Digitalinput_P3_Size
                                      * Referenced by: '<S6>/Digital input '
                                      */
  real_T Digitalinput_P3;              /* Expression: parPciSlot
                                        * Referenced by: '<S6>/Digital input '
                                        */
  real_T Digitalinput_P4_Size[2];    /* Computed Parameter: Digitalinput_P4_Size
                                      * Referenced by: '<S6>/Digital input '
                                      */
  real_T Digitalinput_P4[8];           /* Expression: parDiChannels
                                        * Referenced by: '<S6>/Digital input '
                                        */
  real_T Gain1_Gain_b;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain1'
                                        */
  real_T Gain10_Gain_e;                /* Expression: 1
                                        * Referenced by: '<S6>/Gain10'
                                        */
  real_T Gain11_Gain_g;                /* Expression: 1
                                        * Referenced by: '<S6>/Gain11'
                                        */
  real_T Gain12_Gain_h;                /* Expression: 1
                                        * Referenced by: '<S6>/Gain12'
                                        */
  real_T Gain2_Gain_n;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain2'
                                        */
  real_T Gain3_Gain_m;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain3'
                                        */
  real_T Gain4_Gain_c;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain4'
                                        */
  real_T Gain5_Gain_c;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain5'
                                        */
  real_T Gain6_Gain_i;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain6'
                                        */
  real_T Gain7_Gain_a;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain7'
                                        */
  real_T Gain8_Gain_i;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain8'
                                        */
  real_T Gain9_Gain_n;                 /* Expression: 1
                                        * Referenced by: '<S6>/Gain9'
                                        */
  real_T TmpRTBAtSwitchInport1_InitialCo;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Autonom_ON_Value;             /* Expression: 0
                                        * Referenced by: '<Root>/Autonom_ON'
                                        */
  real_T IC1_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC1'
                                        */
  real_T Android_ON_Value;             /* Expression: 0
                                        * Referenced by: '<Root>/Android_ON'
                                        */
  real_T TransferFcn_A;                /* Computed Parameter: TransferFcn_A
                                        * Referenced by: '<S12>/Transfer Fcn'
                                        */
  real_T TransferFcn_C;                /* Computed Parameter: TransferFcn_C
                                        * Referenced by: '<S12>/Transfer Fcn'
                                        */
  real_T IC_Value;                     /* Expression: 0
                                        * Referenced by: '<S12>/IC'
                                        */
  real_T Switch_Threshold;             /* Expression: 0.5
                                        * Referenced by: '<Root>/Switch'
                                        */
  real_T Switch_Threshold_m;           /* Expression: 0.5
                                        * Referenced by: '<S3>/Switch'
                                        */
  real_T Saturation3_UpperSat_m;       /* Expression: 1
                                        * Referenced by: '<S3>/Saturation3'
                                        */
  real_T Saturation3_LowerSat_e;       /* Expression: 0
                                        * Referenced by: '<S3>/Saturation3'
                                        */
  real_T uDLookupTable_tableData[2];   /* Expression: [0.8 4.8]
                                        * Referenced by: '<S3>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[2];    /* Expression: [0:1]
                                        * Referenced by: '<S3>/1-D Lookup Table'
                                        */
  real_T IC2_Value;                    /* Expression: 0.8
                                        * Referenced by: '<S3>/IC2'
                                        */
  real_T Bias1_Bias;                   /* Expression: 0
                                        * Referenced by: '<S3>/Bias1'
                                        */
  real_T uDLookupTable1_tableData[2];  /* Expression: [0.4 2.4]
                                        * Referenced by: '<S3>/1-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp01Data[2];   /* Expression: [0:1]
                                        * Referenced by: '<S3>/1-D Lookup Table1'
                                        */
  real_T IC3_Value;                    /* Expression: 0.4
                                        * Referenced by: '<S3>/IC3'
                                        */
  real_T Bias2_Bias;                   /* Expression: 0
                                        * Referenced by: '<S3>/Bias2'
                                        */
  real_T TmpRTBAtSwitchInport1_Initial_j;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Constant_Value_o;             /* Expression: 0
                                        * Referenced by: '<S10>/Constant'
                                        */
  real_T Constant2_Value_o;            /* Expression: 0.5
                                        * Referenced by: '<S10>/Constant2'
                                        */
  real_T Constant1_Value_c;            /* Expression: 0
                                        * Referenced by: '<S10>/Constant1'
                                        */
  real_T IC_Value_j;                   /* Expression: 0.5
                                        * Referenced by: '<S2>/IC'
                                        */
  real_T TransferFcn1_A;               /* Computed Parameter: TransferFcn1_A
                                        * Referenced by: '<S12>/Transfer Fcn1'
                                        */
  real_T TransferFcn1_C;               /* Computed Parameter: TransferFcn1_C
                                        * Referenced by: '<S12>/Transfer Fcn1'
                                        */
  real_T IC1_Value_g;                  /* Expression: 0.5
                                        * Referenced by: '<S12>/IC1'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<Root>/Switch1'
                                        */
  real_T Saturation_UpperSat_o;        /* Expression: 1
                                        * Referenced by: '<S76>/Saturation'
                                        */
  real_T Saturation_LowerSat_e;        /* Expression: 0
                                        * Referenced by: '<S76>/Saturation'
                                        */
  real_T uDLookupTable1_tableData_b[5];/* Expression: [0,0.40,0.5,0.60 ,1]
                                        * Referenced by: '<S76>/1-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp01Data_k[5]; /* Expression: [0, 0.25,0.5,0.75 ,1]
                                        * Referenced by: '<S76>/1-D Lookup Table1'
                                        */
  real_T TmpRTBAtIndexVector1Inport3_Ini;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Constant3_Value_f;            /* Expression: 1
                                        * Referenced by: '<S72>/Constant3'
                                        */
  real_T uDLookupTable_tableData_n[2]; /* Expression: [1 0]
                                        * Referenced by: '<S72>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data_g[2];
                                   /* Expression:  [min_steer_car max_steer_car]
                                    * Referenced by: '<S72>/1-D Lookup Table'
                                    */
  real_T Saturation_UpperSat_e;        /* Expression: 1
                                        * Referenced by: '<S72>/Saturation'
                                        */
  real_T Saturation_LowerSat_j;        /* Expression: 0
                                        * Referenced by: '<S72>/Saturation'
                                        */
  real_T TmpRTBAtSwitch1Inport1_InitialC;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Switch1_Threshold_l;          /* Expression: 0.5
                                        * Referenced by: '<S10>/Switch1'
                                        */
  real_T TmpRTBAtSumInport2_InitialCondi;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Constant2_Value_e;            /* Expression: 1
                                        * Referenced by: '<S49>/Constant2'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S49>/Integrator'
                                        */
  real_T Constant1_Value_ns;           /* Expression: 0
                                        * Referenced by: '<S49>/Constant1'
                                        */
  real_T DiscreteTimeIntegrator2_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator2_gainval
                           * Referenced by: '<S53>/Discrete-Time Integrator2'
                           */
  real_T DiscreteTimeIntegrator2_IC;   /* Expression: 0
                                        * Referenced by: '<S53>/Discrete-Time Integrator2'
                                        */
  real_T Delta_Time1_Value;            /* Expression: 0.2
                                        * Referenced by: '<S53>/Delta_Time1'
                                        */
  real_T Isolateddigitalinput_P1_Size[2];
                             /* Computed Parameter: Isolateddigitalinput_P1_Size
                              * Referenced by: '<S7>/Isolated digital input '
                              */
  real_T Isolateddigitalinput_P1;      /* Expression: parModuleType
                                        * Referenced by: '<S7>/Isolated digital input '
                                        */
  real_T Isolateddigitalinput_P2_Size[2];
                             /* Computed Parameter: Isolateddigitalinput_P2_Size
                              * Referenced by: '<S7>/Isolated digital input '
                              */
  real_T Isolateddigitalinput_P2;      /* Expression: parModuleId
                                        * Referenced by: '<S7>/Isolated digital input '
                                        */
  real_T Isolateddigitalinput_P3_Size[2];
                             /* Computed Parameter: Isolateddigitalinput_P3_Size
                              * Referenced by: '<S7>/Isolated digital input '
                              */
  real_T Isolateddigitalinput_P3;      /* Expression: parSampleTime
                                        * Referenced by: '<S7>/Isolated digital input '
                                        */
  real_T Isolateddigitalinput_P4_Size[2];
                             /* Computed Parameter: Isolateddigitalinput_P4_Size
                              * Referenced by: '<S7>/Isolated digital input '
                              */
  real_T Isolateddigitalinput_P4;      /* Expression: parPciSlot
                                        * Referenced by: '<S7>/Isolated digital input '
                                        */
  real_T Isolateddigitalinput_P5_Size[2];
                             /* Computed Parameter: Isolateddigitalinput_P5_Size
                              * Referenced by: '<S7>/Isolated digital input '
                              */
  real_T Isolateddigitalinput_P5[3];   /* Expression: parIsolDiChannels
                                        * Referenced by: '<S7>/Isolated digital input '
                                        */
  real_T Isolateddigitalinput_P6_Size[2];
                             /* Computed Parameter: Isolateddigitalinput_P6_Size
                              * Referenced by: '<S7>/Isolated digital input '
                              */
  real_T Isolateddigitalinput_P6;      /* Expression: parInternalModuleId
                                        * Referenced by: '<S7>/Isolated digital input '
                                        */
  real_T Gain_Gain_c;                  /* Expression: 1
                                        * Referenced by: '<S7>/Gain'
                                        */
  real_T Gain1_Gain_j;                 /* Expression: 1
                                        * Referenced by: '<S7>/Gain1'
                                        */
  real_T Constant_Value_go;            /* Expression: 1
                                        * Referenced by: '<S48>/Constant'
                                        */
  real_T Gain5_Gain_cp;                /* Expression: 1
                                        * Referenced by: '<S5>/Gain5'
                                        */
  real_T Constant6_Value_c;            /* Expression: 0
                                        * Referenced by: '<S75>/Constant6'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S75>/Switch2'
                                        */
  real_T Constant1_Value_i;            /* Expression: 2.5
                                        * Referenced by: '<S75>/Constant1'
                                        */
  real_T uDLookupTable4_tableData[4];  /* Expression: [-1.13 -0.13 0.13 1.13]
                                        * Referenced by: '<S75>/1-D Lookup Table4'
                                        */
  real_T uDLookupTable4_bp01Data[4];   /* Expression:  [-1 -0.0001 0.0001 1]
                                        * Referenced by: '<S75>/1-D Lookup Table4'
                                        */
  real_T Constant_Value_pv;            /* Expression: 0.5
                                        * Referenced by: '<S75>/Constant'
                                        */
  real_T Saturation3_UpperSat_e;       /* Expression: 1
                                        * Referenced by: '<S75>/Saturation3'
                                        */
  real_T Saturation3_LowerSat_k;       /* Expression: 0
                                        * Referenced by: '<S75>/Saturation3'
                                        */
  real_T Switch_Threshold_j;           /* Expression: 0.5
                                        * Referenced by: '<S10>/Switch'
                                        */
  real_T Constant_Value_f;             /* Expression: 0.5
                                        * Referenced by: '<S81>/Constant'
                                        */
  real_T Constant1_Value_j;            /* Expression: 0.5
                                        * Referenced by: '<S78>/Constant1'
                                        */
  real_T IC1_Value_a;                  /* Expression: 0.5
                                        * Referenced by: '<S78>/IC1'
                                        */
  real_T Saturation1_UpperSat_j;       /* Expression: 1
                                        * Referenced by: '<S77>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_o;       /* Expression: 0
                                        * Referenced by: '<S77>/Saturation1'
                                        */
  real_T Constant5_Value_o;            /* Expression: 0.027
                                        * Referenced by: '<S10>/Constant5'
                                        */
  real_T uDLookupTable_tableData_d[2]; /* Expression: [1.6 3.4]
                                        * Referenced by: '<S10>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data_m[2];  /* Expression: [0:1]
                                        * Referenced by: '<S10>/1-D Lookup Table'
                                        */
  real_T IC2_Value_j;                  /* Expression: 2.5
                                        * Referenced by: '<S10>/IC2'
                                        */
  real_T Bias_Bias;                    /* Expression: 0.25
                                        * Referenced by: '<S10>/Bias'
                                        */
  real_T uDLookupTable1_tableData_c[2];/* Expression: [3.4 1.6]
                                        * Referenced by: '<S10>/1-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp01Data_c[2]; /* Expression: [0:1]
                                        * Referenced by: '<S10>/1-D Lookup Table1'
                                        */
  real_T IC3_Value_h;                  /* Expression: 2.5
                                        * Referenced by: '<S10>/IC3'
                                        */
  real_T Bias1_Bias_f;                 /* Expression: 0.25
                                        * Referenced by: '<S10>/Bias1'
                                        */
  real_T Analogoutput_P1_Size[2];    /* Computed Parameter: Analogoutput_P1_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P1;              /* Expression: parModuleId
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Analogoutput_P2_Size[2];    /* Computed Parameter: Analogoutput_P2_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P2;              /* Expression: parSampleTime
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Analogoutput_P3_Size[2];    /* Computed Parameter: Analogoutput_P3_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P3;              /* Expression: parPciSlot
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Analogoutput_P4_Size[2];    /* Computed Parameter: Analogoutput_P4_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P4[4];           /* Expression: parDacChannels
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Analogoutput_P5_Size[2];    /* Computed Parameter: Analogoutput_P5_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P5[4];           /* Expression: parDacRanges
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Analogoutput_P6_Size[2];    /* Computed Parameter: Analogoutput_P6_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P6[4];           /* Expression: parDacInitValues
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Analogoutput_P7_Size[2];    /* Computed Parameter: Analogoutput_P7_Size
                                      * Referenced by: '<S6>/Analog output '
                                      */
  real_T Analogoutput_P7[4];           /* Expression: parDacResets
                                        * Referenced by: '<S6>/Analog output '
                                        */
  real_T Gain6_Gain_f;                 /* Expression: 1
                                        * Referenced by: '<S5>/Gain6'
                                        */
  real_T Gain7_Gain_b;                 /* Expression: 1
                                        * Referenced by: '<S5>/Gain7'
                                        */
  real_T Gain8_Gain_f;                 /* Expression: 1
                                        * Referenced by: '<S5>/Gain8'
                                        */
  real_T Gain9_Gain_m;                 /* Expression: 1
                                        * Referenced by: '<S5>/Gain9'
                                        */
  real_T Constant8_Value;              /* Expression: 0
                                        * Referenced by: '<S5>/Constant8'
                                        */
  real_T Constant_Value_hc;            /* Expression: 0
                                        * Referenced by: '<S6>/Constant'
                                        */
  real_T Digitaloutput_P1_Size[2];  /* Computed Parameter: Digitaloutput_P1_Size
                                     * Referenced by: '<S6>/Digital output '
                                     */
  real_T Digitaloutput_P1;             /* Expression: parModuleId
                                        * Referenced by: '<S6>/Digital output '
                                        */
  real_T Digitaloutput_P2_Size[2];  /* Computed Parameter: Digitaloutput_P2_Size
                                     * Referenced by: '<S6>/Digital output '
                                     */
  real_T Digitaloutput_P2;             /* Expression: parSampleTime
                                        * Referenced by: '<S6>/Digital output '
                                        */
  real_T Digitaloutput_P3_Size[2];  /* Computed Parameter: Digitaloutput_P3_Size
                                     * Referenced by: '<S6>/Digital output '
                                     */
  real_T Digitaloutput_P3;             /* Expression: parPciSlot
                                        * Referenced by: '<S6>/Digital output '
                                        */
  real_T Digitaloutput_P4_Size[2];  /* Computed Parameter: Digitaloutput_P4_Size
                                     * Referenced by: '<S6>/Digital output '
                                     */
  real_T Digitaloutput_P4[8];          /* Expression: parDoChannels
                                        * Referenced by: '<S6>/Digital output '
                                        */
  real_T Digitaloutput_P5_Size[2];  /* Computed Parameter: Digitaloutput_P5_Size
                                     * Referenced by: '<S6>/Digital output '
                                     */
  real_T Digitaloutput_P5[8];          /* Expression: parDoInitValues
                                        * Referenced by: '<S6>/Digital output '
                                        */
  real_T Digitaloutput_P6_Size[2];  /* Computed Parameter: Digitaloutput_P6_Size
                                     * Referenced by: '<S6>/Digital output '
                                     */
  real_T Digitaloutput_P6[8];          /* Expression: parDoResets
                                        * Referenced by: '<S6>/Digital output '
                                        */
  real_T Setup_P1_Size_k[2];           /* Computed Parameter: Setup_P1_Size_k
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P1_p;                   /* Expression: parModuleType
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P2_Size_a[2];           /* Computed Parameter: Setup_P2_Size_a
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P2_p;                   /* Expression: parPciSlot
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P3_Size_j[2];           /* Computed Parameter: Setup_P3_Size_j
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P3_m;                   /* Expression: parModuleId
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P4_Size_g[2];           /* Computed Parameter: Setup_P4_Size_g
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P5_Size_e[2];           /* Computed Parameter: Setup_P5_Size_e
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Setup_P5_l;                   /* Expression: parInternalModuleId
                                        * Referenced by: '<S7>/Setup '
                                        */
  real_T Alive_Value;                  /* Expression: 0
                                        * Referenced by: '<S7>/Alive'
                                        */
  real_T Gain2_Gain_a;                 /* Expression: 1
                                        * Referenced by: '<S7>/Gain2'
                                        */
  real_T TmpRTBAtSwitchInport1_Initia_jx;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Switch_Threshold_o;           /* Expression: 0.5
                                        * Referenced by: '<S1>/Switch'
                                        */
  real_T Saturation3_UpperSat_i;       /* Expression: 0
                                        * Referenced by: '<S1>/Saturation3'
                                        */
  real_T Saturation3_LowerSat_j;       /* Expression: -1
                                        * Referenced by: '<S1>/Saturation3'
                                        */
  real_T Gain1_Gain_h;                 /* Expression: -1
                                        * Referenced by: '<S1>/Gain -1'
                                        */
  real_T uDLookupTable_tableData_e[5]; /* Expression: [0, 10, 20, 30, 80]
                                        * Referenced by: '<S16>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data_n[5];  /* Expression: [0, 0.25, 0.5, 0.75, 1]
                                        * Referenced by: '<S16>/1-D Lookup Table'
                                        */
  real_T Constant2_Value_l;            /* Expression: 1
                                        * Referenced by: '<S26>/Constant2'
                                        */
  real_T Digitalinput_P1_Size_h[2];/* Computed Parameter: Digitalinput_P1_Size_h
                                    * Referenced by: '<S8>/Digital input'
                                    */
  real_T Digitalinput_P1_i;            /* Expression: boardType
                                        * Referenced by: '<S8>/Digital input'
                                        */
  real_T Digitalinput_P2_Size_g[2];/* Computed Parameter: Digitalinput_P2_Size_g
                                    * Referenced by: '<S8>/Digital input'
                                    */
  real_T Digitalinput_P2_g;            /* Expression: id
                                        * Referenced by: '<S8>/Digital input'
                                        */
  real_T Digitalinput_P3_Size_n[2];/* Computed Parameter: Digitalinput_P3_Size_n
                                    * Referenced by: '<S8>/Digital input'
                                    */
  real_T Digitalinput_P3_b[2];         /* Expression: chan
                                        * Referenced by: '<S8>/Digital input'
                                        */
  real_T Digitalinput_P4_Size_m[2];/* Computed Parameter: Digitalinput_P4_Size_m
                                    * Referenced by: '<S8>/Digital input'
                                    */
  real_T Digitalinput_P4_p;            /* Expression: vectorizeOutput
                                        * Referenced by: '<S8>/Digital input'
                                        */
  real_T Digitalinput_P5_Size[2];    /* Computed Parameter: Digitalinput_P5_Size
                                      * Referenced by: '<S8>/Digital input'
                                      */
  real_T Digitalinput_P5;              /* Expression: ts
                                        * Referenced by: '<S8>/Digital input'
                                        */
  real_T Digitalinput_P6_Size[2];    /* Computed Parameter: Digitalinput_P6_Size
                                      * Referenced by: '<S8>/Digital input'
                                      */
  real_T Digitalinput_P6;              /* Expression: pciSlot
                                        * Referenced by: '<S8>/Digital input'
                                        */
  real_T Gain_Gain_g;                  /* Expression: 1
                                        * Referenced by: '<S8>/Gain'
                                        */
  real_T Gain1_Gain_c;                 /* Expression: 1
                                        * Referenced by: '<S8>/Gain1'
                                        */
  real_T Constant_Value_eq;            /* Expression: 0
                                        * Referenced by: '<S16>/Constant'
                                        */
  real_T Constant_Value_ai;            /* Expression: -1
                                        * Referenced by: '<S26>/Constant'
                                        */
  real_T Constant1_Value_f;            /* Expression: 0
                                        * Referenced by: '<S26>/Constant1'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S26>/Unit Delay'
                                        */
  real_T Delay1_InitialCondition;      /* Expression: 0.0
                                        * Referenced by: '<S17>/Delay1'
                                        */
  real_T Constant1_Value_m;            /* Expression: 0
                                        * Referenced by: '<S17>/Constant1'
                                        */
  real_T IC1_Value_m;                  /* Expression: 0
                                        * Referenced by: '<S16>/IC1'
                                        */
  real_T Delay1_InitialCondition_i;    /* Expression: 0.0
                                        * Referenced by: '<S18>/Delay1'
                                        */
  real_T Constant1_Value_pm;           /* Expression: 0
                                        * Referenced by: '<S18>/Constant1'
                                        */
  real_T IC2_Value_n;                  /* Expression: 0
                                        * Referenced by: '<S16>/IC2'
                                        */
  real_T Constant13_Value;             /* Expression: 1
                                        * Referenced by: '<S5>/Constant13'
                                        */
  real_T Constant_Value_ph;            /* Expression: 1
                                        * Referenced by: '<S49>/Constant'
                                        */
  real_T PulseGenerator_Amp;           /* Expression: 1
                                        * Referenced by: '<S49>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;     /* Computed Parameter: PulseGenerator_Period
                                     * Referenced by: '<S49>/Pulse Generator'
                                     */
  real_T PulseGenerator_Duty;         /* Computed Parameter: PulseGenerator_Duty
                                       * Referenced by: '<S49>/Pulse Generator'
                                       */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<S49>/Pulse Generator'
                                        */
  real_T Gain4_Gain_i;                 /* Expression: 1
                                        * Referenced by: '<S5>/Gain4'
                                        */
  real_T FETdigitaloutput_P1_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P1_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P1;          /* Expression: parModuleType
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P2_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P2_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P2;          /* Expression: parModuleId
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P3_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P3_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P3;          /* Expression: parSampleTime
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P4_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P4_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P4;          /* Expression: parPciSlot
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P5_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P5_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P5[5];       /* Expression: parFetDoChannels
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P6_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P6_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P6[5];       /* Expression: parFetDoInitValues
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P7_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P7_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P7[5];       /* Expression: parFetDoReset
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T FETdigitaloutput_P8_Size[2];
                                 /* Computed Parameter: FETdigitaloutput_P8_Size
                                  * Referenced by: '<S7>/FET digital output '
                                  */
  real_T FETdigitaloutput_P8;          /* Expression: parInternalModuleId
                                        * Referenced by: '<S7>/FET digital output '
                                        */
  real_T LVTTLdigitalinput_P1_Size[2];
                                /* Computed Parameter: LVTTLdigitalinput_P1_Size
                                 * Referenced by: '<S7>/LVTTL digital input '
                                 */
  real_T LVTTLdigitalinput_P1;         /* Expression: parModuleType
                                        * Referenced by: '<S7>/LVTTL digital input '
                                        */
  real_T LVTTLdigitalinput_P2_Size[2];
                                /* Computed Parameter: LVTTLdigitalinput_P2_Size
                                 * Referenced by: '<S7>/LVTTL digital input '
                                 */
  real_T LVTTLdigitalinput_P2;         /* Expression: parModuleId
                                        * Referenced by: '<S7>/LVTTL digital input '
                                        */
  real_T LVTTLdigitalinput_P3_Size[2];
                                /* Computed Parameter: LVTTLdigitalinput_P3_Size
                                 * Referenced by: '<S7>/LVTTL digital input '
                                 */
  real_T LVTTLdigitalinput_P3;         /* Expression: parSampleTime
                                        * Referenced by: '<S7>/LVTTL digital input '
                                        */
  real_T LVTTLdigitalinput_P4_Size[2];
                                /* Computed Parameter: LVTTLdigitalinput_P4_Size
                                 * Referenced by: '<S7>/LVTTL digital input '
                                 */
  real_T LVTTLdigitalinput_P4;         /* Expression: parPciSlot
                                        * Referenced by: '<S7>/LVTTL digital input '
                                        */
  real_T LVTTLdigitalinput_P5_Size[2];
                                /* Computed Parameter: LVTTLdigitalinput_P5_Size
                                 * Referenced by: '<S7>/LVTTL digital input '
                                 */
  real_T LVTTLdigitalinput_P6_Size[2];
                                /* Computed Parameter: LVTTLdigitalinput_P6_Size
                                 * Referenced by: '<S7>/LVTTL digital input '
                                 */
  real_T LVTTLdigitalinput_P6;         /* Expression: parInternalModuleId
                                        * Referenced by: '<S7>/LVTTL digital input '
                                        */
  real_T LVTTLdigitaloutput_P1_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P1_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P1;        /* Expression: parModuleType
                                        * Referenced by: '<S7>/LVTTL digital output '
                                        */
  real_T LVTTLdigitaloutput_P2_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P2_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P2;        /* Expression: parModuleId
                                        * Referenced by: '<S7>/LVTTL digital output '
                                        */
  real_T LVTTLdigitaloutput_P3_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P3_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P3;        /* Expression: parSampleTime
                                        * Referenced by: '<S7>/LVTTL digital output '
                                        */
  real_T LVTTLdigitaloutput_P4_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P4_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P4;        /* Expression: parPciSlot
                                        * Referenced by: '<S7>/LVTTL digital output '
                                        */
  real_T LVTTLdigitaloutput_P5_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P5_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P6_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P6_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P7_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P7_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P8_Size[2];
                               /* Computed Parameter: LVTTLdigitaloutput_P8_Size
                                * Referenced by: '<S7>/LVTTL digital output '
                                */
  real_T LVTTLdigitaloutput_P8;        /* Expression: parInternalModuleId
                                        * Referenced by: '<S7>/LVTTL digital output '
                                        */
  real_T CANSetup_P1_Size[2];          /* Computed Parameter: CANSetup_P1_Size
                                        * Referenced by: '<S9>/CAN Setup '
                                        */
  real_T CANSetup_P1[40];
  /* Expression: [moduleInitValues, chn1, ArbitrationManbdrChn1, FdManbdrChn1, chn2, ArbitrationManbdrChn2, FdManbdrChn2, chn3, ArbitrationManbdrChn3, FdManbdrChn3, chn4, ArbitrationManbdrChn4, FdManbdrChn4]
   * Referenced by: '<S9>/CAN Setup '
   */
  real_T CANSetup_P2_Size[2];          /* Computed Parameter: CANSetup_P2_Size
                                        * Referenced by: '<S9>/CAN Setup '
                                        */
  real_T CANSetup_P2;                  /* Expression: initStruct
                                        * Referenced by: '<S9>/CAN Setup '
                                        */
  real_T CANSetup_P3_Size[2];          /* Computed Parameter: CANSetup_P3_Size
                                        * Referenced by: '<S9>/CAN Setup '
                                        */
  real_T CANSetup_P3;                  /* Expression: termStruct
                                        * Referenced by: '<S9>/CAN Setup '
                                        */
  real_T Constant_Value_kc;            /* Expression: 0.01
                                        * Referenced by: '<S17>/Constant'
                                        */
  real_T Saturation_UpperSat_j;        /* Expression: 0.2
                                        * Referenced by: '<S17>/Saturation'
                                        */
  real_T Saturation_LowerSat_j3;       /* Expression: 0
                                        * Referenced by: '<S17>/Saturation'
                                        */
  real_T Constant_Value_f3;            /* Expression: 0.01
                                        * Referenced by: '<S18>/Constant'
                                        */
  real_T Saturation_UpperSat_k;        /* Expression: 0.2
                                        * Referenced by: '<S18>/Saturation'
                                        */
  real_T Saturation_LowerSat_n;        /* Expression: 0
                                        * Referenced by: '<S18>/Saturation'
                                        */
  real_T Constant_Value_l;             /* Expression: eps
                                        * Referenced by: '<S37>/Constant'
                                        */
  real_T TmpRTBAtLenkradwinkelgeschwindi;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T TmpRTBAtDerivativeInport1_Initi;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Delay1_InitialCondition_e;    /* Expression: 0.0
                                        * Referenced by: '<S50>/Delay1'
                                        */
  real_T Constant_Value_ov;            /* Expression: 0
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T Constant1_Value_g;            /* Expression: 0
                                        * Referenced by: '<S8>/Constant1'
                                        */
  real_T Constant2_Value_k;            /* Expression: 0
                                        * Referenced by: '<S8>/Constant2'
                                        */
  real_T GearRatio_Value;              /* Expression: 17.5
                                        * Referenced by: '<S8>/Gear Ratio'
                                        */
  real_T Gain4_Gain_cp;                /* Expression: 1
                                        * Referenced by: '<S8>/Gain4'
                                        */
  real_T Gain5_Gain_o;                 /* Expression: 1
                                        * Referenced by: '<S8>/Gain5'
                                        */
  real_T Gain6_Gain_e;                 /* Expression: 1
                                        * Referenced by: '<S8>/Gain6'
                                        */
  real_T TmpRTBAtDerivativeInport1_Ini_j;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T TmpRTBAtMATLABFunction1Inport2_;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Saturation_UpperSat_p;        /* Expression: 1
                                        * Referenced by: '<S77>/Saturation'
                                        */
  real_T Saturation_LowerSat_m;        /* Expression: 0
                                        * Referenced by: '<S77>/Saturation'
                                        */
  real_T Constant_Value_h3;            /* Expression: 0
                                        * Referenced by: '<S77>/Constant'
                                        */
  real_T Constant5_Value_b;            /* Expression: 1
                                        * Referenced by: '<S75>/Constant5'
                                        */
  real_T TmpRTBAtTransferFcn1Inport1_Ini;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T TmpRTBAtTransferFcnInport1_Init;/* Expression: 0
                                          * Referenced by:
                                          */
  real_T Constant_Value_b;             /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T RXSampleTime_Value;           /* Expression: 1
                                        * Referenced by: '<S9>/RX Sample Time'
                                        */
  real_T Constant3_Value_d;            /* Expression: 10
                                        * Referenced by: '<S4>/Constant3'
                                        */
  real_T uDLookupTable_tableData_l[2]; /* Expression: [1 0]
                                        * Referenced by: '<S74>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data_mj[2];
                                   /* Expression:  [min_steer_car max_steer_car]
                                    * Referenced by: '<S74>/1-D Lookup Table'
                                    */
  real_T Saturation_UpperSat_jd;       /* Expression: 1
                                        * Referenced by: '<S74>/Saturation'
                                        */
  real_T Saturation_LowerSat_nj;       /* Expression: 0
                                        * Referenced by: '<S74>/Saturation'
                                        */
  real_T Constant_Value_ow;            /* Expression: 1
                                        * Referenced by: '<S78>/Constant'
                                        */
  real_T Constant_Value_lk;            /* Expression: 10
                                        * Referenced by: '<S79>/Constant'
                                        */
  real_T Saturation2_UpperSat_b;       /* Expression: 1
                                        * Referenced by: '<S75>/Saturation2'
                                        */
  real_T Saturation2_LowerSat_b;       /* Expression: 0
                                        * Referenced by: '<S75>/Saturation2'
                                        */
  real_T RateTransition1_InitialConditio;/* Expression: 0
                                          * Referenced by: '<S11>/Rate Transition1'
                                          */
  real_T Odometer_InitialCondition;    /* Expression: 0
                                        * Referenced by:
                                        */
  real_T Saturation_UpperSat_i;        /* Expression: 100
                                        * Referenced by: '<S12>/Saturation'
                                        */
  real_T Saturation_LowerSat_k;        /* Expression: 0
                                        * Referenced by: '<S12>/Saturation'
                                        */
  real_T uDLookupTable_tableData_m[3]; /* Expression: [-1 0 1]
                                        * Referenced by: '<S12>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data_b[3];  /* Expression: [0 50 100]
                                        * Referenced by: '<S12>/1-D Lookup Table'
                                        */
  real_T Constant2_Value_a;            /* Expression: 100
                                        * Referenced by: '<S12>/Constant2'
                                        */
  real_T Saturation1_UpperSat_a;       /* Expression: 100
                                        * Referenced by: '<S12>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_o4;      /* Expression: 0
                                        * Referenced by: '<S12>/Saturation1'
                                        */
  real_T SoC_InitialCondition;         /* Expression: 0
                                        * Referenced by:
                                        */
  real_T Switch_Threshold_c;           /* Expression: 0.1
                                        * Referenced by: '<S138>/Switch'
                                        */
  real_T Saturation2_UpperSat_c;       /* Expression: 0.15
                                        * Referenced by: '<S144>/Saturation2'
                                        */
  real_T Saturation2_LowerSat_d;       /* Expression: -0.15
                                        * Referenced by: '<S144>/Saturation2'
                                        */
  real_T Saturation3_UpperSat_p;       /* Expression: 0.06
                                        * Referenced by: '<S144>/Saturation3'
                                        */
  real_T Saturation3_LowerSat_h;       /* Expression: -0.06
                                        * Referenced by: '<S144>/Saturation3'
                                        */
  real_T Gain_Gain_f[21];          /* Expression: [0:0.1:PredictionHorizon*0.1]'
                                    * Referenced by: '<S144>/Gain'
                                    */
  real_T Saturation_UpperSat_l;        /* Expression: 0.5
                                        * Referenced by: '<S144>/Saturation'
                                        */
  real_T Saturation_LowerSat_d;        /* Expression: -0.5
                                        * Referenced by: '<S144>/Saturation'
                                        */
  real_T Saturation1_UpperSat_d;       /* Expression: 0.6
                                        * Referenced by: '<S144>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_n;       /* Expression: -0.6
                                        * Referenced by: '<S144>/Saturation1'
                                        */
  real_T uDLookupTable2_tableData[2];  /* Expression: [-1 1]
                                        * Referenced by: '<S1>/1-D Lookup Table2'
                                        */
  real_T uDLookupTable2_bp01Data[2];   /* Expression: [min_ac max_ac]
                                        * Referenced by: '<S1>/1-D Lookup Table2'
                                        */
  real_T uDLookupTable2_tableData_j[2];/* Expression: [-1 1]
                                        * Referenced by: '<S3>/1-D Lookup Table2'
                                        */
  real_T uDLookupTable2_bp01Data_l[2]; /* Expression: [min_ac max_ac]
                                        * Referenced by: '<S3>/1-D Lookup Table2'
                                        */
  real_T Lenkungumdrehen_Gain;         /* Expression: -1
                                        * Referenced by: '<S73>/Lenkung umdrehen'
                                        */
  real_T Umrechnenvonradingrad_Gain;   /* Expression: 180/pi
                                        * Referenced by: '<S73>/Umrechnen von rad in grad'
                                        */
  real_T uDLookupTable2_tableData_c[2];/* Expression: [0 1]
                                        * Referenced by: '<S73>/1-D Lookup Table2'
                                        */
  real_T uDLookupTable2_bp01Data_d[2];
                                   /* Expression:  [min_steer_car max_steer_car]
                                    * Referenced by: '<S73>/1-D Lookup Table2'
                                    */
  real_T Saturation1_UpperSat_o;       /* Expression: 1
                                        * Referenced by: '<S73>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_g;       /* Expression: 0
                                        * Referenced by: '<S73>/Saturation1'
                                        */
  real32_T Gain_Gain_ii;               /* Computed Parameter: Gain_Gain_ii
                                        * Referenced by: '<S139>/Gain'
                                        */
  real32_T Gain1_Gain_cq;              /* Computed Parameter: Gain1_Gain_cq
                                        * Referenced by: '<S139>/Gain1'
                                        */
  real32_T Gain2_Gain_o;               /* Computed Parameter: Gain2_Gain_o
                                        * Referenced by: '<S139>/Gain2'
                                        */
  real32_T Gain3_Gain_d;               /* Computed Parameter: Gain3_Gain_d
                                        * Referenced by: '<S139>/Gain3'
                                        */
  real32_T Constant_Value_jd;          /* Computed Parameter: Constant_Value_jd
                                        * Referenced by: '<S140>/Constant'
                                        */
  real32_T HalfLaneWidthEstimate_Value;
                              /* Computed Parameter: HalfLaneWidthEstimate_Value
                               * Referenced by: '<S140>/Half Lane Width Estimate'
                               */
  real32_T HalfLaneWidthEstimate1_Value;
                             /* Computed Parameter: HalfLaneWidthEstimate1_Value
                              * Referenced by: '<S140>/Half Lane Width Estimate1'
                              */
  real32_T Constant_Value_pa;          /* Computed Parameter: Constant_Value_pa
                                        * Referenced by: '<S142>/Constant'
                                        */
  real32_T HalfLaneWidthEstimate_Value_f;
                            /* Computed Parameter: HalfLaneWidthEstimate_Value_f
                             * Referenced by: '<S142>/Half Lane Width Estimate'
                             */
  real32_T HalfLaneWidthEstimate1_Value_h;
                           /* Computed Parameter: HalfLaneWidthEstimate1_Value_h
                            * Referenced by: '<S142>/Half Lane Width Estimate1'
                            */
  real32_T SetVelocity_Value;          /* Computed Parameter: SetVelocity_Value
                                        * Referenced by: '<S11>/Set Velocity'
                                        */
  real32_T Delay1_4_InitialCondition;
                                /* Computed Parameter: Delay1_4_InitialCondition
                                 * Referenced by: '<S137>/Delay1'
                                 */
  real32_T Delay1_3_InitialCondition;
                                /* Computed Parameter: Delay1_3_InitialCondition
                                 * Referenced by: '<S137>/Delay1'
                                 */
  real32_T Delay1_2_InitialCondition;
                                /* Computed Parameter: Delay1_2_InitialCondition
                                 * Referenced by: '<S137>/Delay1'
                                 */
  real32_T Delay1_1_InitialCondition;
                                /* Computed Parameter: Delay1_1_InitialCondition
                                 * Referenced by: '<S137>/Delay1'
                                 */
  real32_T Merge1_1_InitialOutput; /* Computed Parameter: Merge1_1_InitialOutput
                                    * Referenced by: '<S137>/Merge1'
                                    */
  real32_T Merge1_2_InitialOutput; /* Computed Parameter: Merge1_2_InitialOutput
                                    * Referenced by: '<S137>/Merge1'
                                    */
  real32_T Merge1_4_InitialOutput; /* Computed Parameter: Merge1_4_InitialOutput
                                    * Referenced by: '<S137>/Merge1'
                                    */
  real32_T Merge1_3_InitialOutput; /* Computed Parameter: Merge1_3_InitialOutput
                                    * Referenced by: '<S137>/Merge1'
                                    */
  uint16_T UDPSend_toPort;             /* Computed Parameter: UDPSend_toPort
                                        * Referenced by: '<S2>/UDP Send'
                                        */
  boolean_T OUT_Y0;                    /* Computed Parameter: OUT_Y0
                                        * Referenced by: '<S38>/OUT'
                                        */
  boolean_T OUT_Y0_l;                  /* Computed Parameter: OUT_Y0_l
                                        * Referenced by: '<S39>/OUT'
                                        */
  boolean_T UnitDelay_InitialCondition_j;
                             /* Computed Parameter: UnitDelay_InitialCondition_j
                              * Referenced by: '<S48>/Unit Delay'
                              */
  boolean_T Memory_InitialCondition;
                                  /* Computed Parameter: Memory_InitialCondition
                                   * Referenced by: '<S48>/Memory'
                                   */
  boolean_T RT_InitialCondition;      /* Computed Parameter: RT_InitialCondition
                                       * Referenced by: '<S78>/RT'
                                       */
  boolean_T TmpRTBAtSwitchInport2_InitialCo;
                          /* Computed Parameter: TmpRTBAtSwitchInport2_InitialCo
                           * Referenced by:
                           */
  boolean_T UnitDelay_InitialCondition_p;
                             /* Computed Parameter: UnitDelay_InitialCondition_p
                              * Referenced by: '<S16>/Unit Delay'
                              */
  boolean_T UnitDelay1_InitialCondition;
                              /* Computed Parameter: UnitDelay1_InitialCondition
                               * Referenced by: '<S26>/Unit Delay1'
                               */
  boolean_T TmpRTBAtLenkradwinkelOutport1_I;
                          /* Computed Parameter: TmpRTBAtLenkradwinkelOutport1_I
                           * Referenced by:
                           */
  boolean_T TmpRTBAtFahrzeuggeschwindigkeit;
                          /* Computed Parameter: TmpRTBAtFahrzeuggeschwindigkeit
                           * Referenced by:
                           */
  boolean_T IC2_Value_e;               /* Computed Parameter: IC2_Value_e
                                        * Referenced by: '<S4>/IC2'
                                        */
  boolean_T Memory1_InitialCondition;
                                 /* Computed Parameter: Memory1_InitialCondition
                                  * Referenced by: '<S48>/Memory1'
                                  */
  boolean_T Logic_table[16];           /* Computed Parameter: Logic_table
                                        * Referenced by: '<S55>/Logic'
                                        */
  uint8_T UDPReceive1_fmAddress[4]; /* Computed Parameter: UDPReceive1_fmAddress
                                     * Referenced by: '<S2>/UDP Receive1'
                                     */
  uint8_T TmpRTBAtBytePackingOutport1_Ini;
                          /* Computed Parameter: TmpRTBAtBytePackingOutport1_Ini
                           * Referenced by:
                           */
  uint8_T FromJetson_fmAddress[4];   /* Computed Parameter: FromJetson_fmAddress
                                      * Referenced by: '<S11>/From Jetson'
                                      */
  uint8_T UDPSend_toAddress[4];        /* Computed Parameter: UDPSend_toAddress
                                        * Referenced by: '<S2>/UDP Send'
                                        */
  PathFollowingControlSy_cal_type PathFollowingControlSystem_cal;
                                    /* '<S138>/Path Following Control System' */
  D_202_EnabledSubsystem_cal_type D_2023112_EnabledSubsystem1_cal;/* '<S81>/Enabled Subsystem1' */
  D_202_EnabledSubsystem_cal_type D_20231120_EnabledSubsystem_cal;/* '<S81>/Enabled Subsystem' */
};

/* Storage class 'PageSwitching' */
extern D_20231120_Modell_Inbe_cal_type D_20231120_Modell_Inbe_cal_impl;
extern D_20231120_Modell_Inbe_cal_type *D_20231120_Modell_Inbetrieb_cal;

#endif
     /* RTW_HEADER_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal_h_ */

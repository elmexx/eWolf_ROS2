/*
 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
 * Model version              : 4.141
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C++ source code generated on : Fri May 24 11:08:49 2024
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_h_
#define RTW_HEADER_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_h_
#include <cstring>
#include <logsrv.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "verify/verifyIntrf.h"
#include "slrealtime/libsrc/IP/udp.hpp"
#include "slrealtime/libsrc/IP/ip.hpp"
#include "slrealtime/libsrc/IP/socketFactory.hpp"
#include "sg_fpga_io30x_setup_util.h"
#include "sg_fpga_io31x_io32x_setup_util.h"
#include "sg_fpga_io33x_setup_util.h"
#include "sg_fpga_io39x_setup_util.h"
#include "sg_common.h"
#include "sg_printf.h"
#include "Monitorausgabe_sfun_cgen_wrapper.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"
#include "can_message.h"
#include "PathFollowingControlSystem.h"
#include <cmath>
#include <stddef.h>

extern "C"
{

#include "rt_nonfinite.h"

}

extern "C"
{

#include "rtGetInf.h"

}

#include "rt_zcfcn.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal.h"
#include "zero_crossing_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetSampleHitArray
#define rtmGetSampleHitArray(rtm)      ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmGetStepSize
#define rtmGetStepSize(rtm)            ((rtm)->Timing.stepSize)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
#define rtmGet_TimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmCounterLimit
#define rtmCounterLimit(rtm, idx)      ((rtm)->Timing.TaskCounters.cLimit[(idx)])
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#ifndef rtmGetTimeOfLastOutput
#define rtmGetTimeOfLastOutput(rtm)    ((rtm)->Timing.timeOfLastOutput)
#endif

/* Block signals for system '<S81>/Enabled Subsystem' */
struct B_EnabledSubsystem_D_20231120_T {
  real_T Drehmomentsvorgabenormiert;   /* '<S82>/Drehmomentsvorgabe normiert' */
};

/* Block states (default storage) for system '<S81>/Enabled Subsystem' */
struct DW_EnabledSubsystem_D_2023112_T {
  int8_T EnabledSubsystem_SubsysRanBC; /* '<S81>/Enabled Subsystem' */
  boolean_T EnabledSubsystem_MODE;     /* '<S81>/Enabled Subsystem' */
};

/* Block signals (default storage) */
struct B_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  LaneSensor PackLaneBus;              /* '<S11>/PackLaneBus' */
  CAN_DATATYPE CANRead1_o2;            /* '<S69>/CAN Read1' */
  CAN_DATATYPE CANRead1_o2_e;          /* '<S68>/CAN Read1' */
  real_T IO191_AI_CH1;                 /* '<S6>/Analog input ' */
  real_T IO191_AI_CH2;                 /* '<S6>/Analog input ' */
  real_T IO191_AI_CH3;                 /* '<S6>/Analog input ' */
  real_T IO191_AI_CH4;                 /* '<S6>/Analog input ' */
  real_T Digitalinput_o1;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o2;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o3;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o4;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o5;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o6;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o7;              /* '<S6>/Digital input ' */
  real_T Digitalinput_o8;              /* '<S6>/Digital input ' */
  real_T IO191_DI_CH9_Bremspedal_1;    /* '<S6>/Gain1' */
  real_T IO191_AI_CH2_FP_2_G;          /* '<S6>/Gain10' */
  real_T IO191_AI_CH3_LG_1_G;          /* '<S6>/Gain11' */
  real_T IO191_AI_CH4_LG_2_G;          /* '<S6>/Gain12' */
  real_T IO191_DI_CH10_Bremspedal_2;   /* '<S6>/Gain2' */
  real_T IO191_DI_CH11_BR_Licht;       /* '<S6>/Gain3' */
  real_T IO191_DI_CH12_Totmann_Taster_1;/* '<S6>/Gain4' */
  real_T IO191_DI_CH13_Totmann_Taster_2;/* '<S6>/Gain5' */
  real_T IO191_DI_CH14_Freigabe_Taster;/* '<S6>/Gain6' */
  real_T IO191_DI_CH15;                /* '<S6>/Gain7' */
  real_T IO191_DI_CH16;                /* '<S6>/Gain8' */
  real_T IO191_AI_CH1_FP_1_G;          /* '<S6>/Gain9' */
  real_T TmpRTBAtSwitchInport1;        /* '<S3>/1-D Lookup Table2' */
  real_T UDPReceive1_o2;               /* '<S2>/UDP Receive1' */
  real_T VectorConcatenate[200];       /* '<S42>/Vector Concatenate' */
  real_T SumofElements;                /* '<S42>/Sum of Elements' */
  real_T Divide;                       /* '<S42>/Divide' */
  real_T DataTypeConversion1;          /* '<S2>/Data Type Conversion1' */
  real_T Switch1;                      /* '<S2>/Switch1' */
  real_T IC1;                          /* '<S2>/IC1' */
  real_T TransferFcn;                  /* '<S12>/Transfer Fcn' */
  real_T IC;                           /* '<S12>/IC' */
  real_T Fahrpedal;                    /* '<Root>/Switch' */
  real_T Switch;                       /* '<S3>/Switch' */
  real_T Saturation3;                  /* '<S3>/Saturation3' */
  real_T uDLookupTable;                /* '<S3>/1-D Lookup Table' */
  real_T IC2;                          /* '<S3>/IC2' */
  real_T Ausgabe_Gaspedal_FP_1_G;      /* '<S3>/Bias1' */
  real_T uDLookupTable1;               /* '<S3>/1-D Lookup Table1' */
  real_T IC3;                          /* '<S3>/IC3' */
  real_T Ausgabe_Gaspedal_FP_2_G;      /* '<S3>/Bias2' */
  real_T TmpRTBAtSwitchInport1_i; /* '<S10>/Linearisierung Lenkmoment Jetson' */
  real_T DataTypeConversion;           /* '<S2>/Data Type Conversion' */
  real_T Switch_j;                     /* '<S2>/Switch' */
  real_T IC_p;                         /* '<S2>/IC' */
  real_T TransferFcn1;                 /* '<S12>/Transfer Fcn1' */
  real_T IC1_h;                        /* '<S12>/IC1' */
  real_T Lenkung;                      /* '<Root>/Switch1' */
  real_T RC_LenkwinkelEingang;         /* '<S76>/Saturation' */
  real_T RC_LenkwinkelVorgabe;         /* '<S76>/1-D Lookup Table1' */
  real_T RT_g;                         /* '<S10>/RT' */
  real_T TmpRTBAtIndexVector1Inport3;
                                  /* '<S10>/Linearisierung Lenkmoment Jetson' */
  real_T LenkwinkelVorgabeMessungJetson;/* '<S72>/From File' */
  real_T FromWs[5];                    /* '<S86>/FromWs' */
  real_T IndexVector2;                 /* '<S72>/Index Vector2' */
  real_T uDLookupTable_l;              /* '<S72>/1-D Lookup Table' */
  real_T Saturation;                   /* '<S72>/Saturation' */
  real_T IndexVector1;                 /* '<S10>/Index Vector1' */
  real_T TmpRTBAtSwitch1Inport1;  /* '<S10>/Linearisierung Lenkmoment Jetson' */
  real_T SollLenkwinkel;               /* '<S10>/Switch1' */
  real_T SollgrevorRegler;             /* '<S75>/Saturation2' */
  real_T Integrator;                   /* '<S49>/Integrator' */
  real_T Switch2;                      /* '<S49>/Switch2' */
  real_T VectorConcatenate_b[5];       /* '<S60>/Vector Concatenate' */
  real_T SumofElements_i;              /* '<S60>/Sum of Elements' */
  real_T Divide_d;                     /* '<S60>/Divide' */
  real_T VectorConcatenate_g[5];       /* '<S61>/Vector Concatenate' */
  real_T SumofElements_d;              /* '<S61>/Sum of Elements' */
  real_T Divide_p;                     /* '<S61>/Divide' */
  real_T Subtract2;                    /* '<S53>/Subtract2' */
  real_T Abs2;                         /* '<S53>/Abs2' */
  real_T DataTypeConversion2;          /* '<S53>/Data Type Conversion2' */
  real_T DiscreteTimeIntegrator2;      /* '<S53>/Discrete-Time Integrator2' */
  real_T Isolateddigitalinput_o1;      /* '<S7>/Isolated digital input ' */
  real_T Isolateddigitalinput_o2;      /* '<S7>/Isolated digital input ' */
  real_T Isolateddigitalinput_o3;      /* '<S7>/Isolated digital input ' */
  real_T IO291_DI_CH1_NotAus_1;        /* '<S7>/Gain' */
  real_T IO291_DI_CH2_NotAus_2;        /* '<S7>/Gain1' */
  real_T DataTypeConversion_p;         /* '<S48>/Data Type Conversion' */
  real_T Taster_Freigabe;              /* '<S5>/Gain5' */
  real_T Regelabweichung;              /* '<S75>/Switch2' */
  real_T PProdOut;                     /* '<S124>/PProd Out' */
  real_T Integrator_a;                 /* '<S119>/Integrator' */
  real_T Sum;                          /* '<S128>/Sum' */
  real_T Saturation_i;                 /* '<S126>/Saturation' */
  real_T StellgrenachOffset;           /* '<S75>/1-D Lookup Table4' */
  real_T Sum1;                         /* '<S75>/Sum1' */
  real_T Saturation3_e;                /* '<S75>/Saturation3' */
  real_T Switch_o;                     /* '<S10>/Switch' */
  real_T Switch2_d;                    /* '<S78>/Switch2' */
  real_T IC1_d;                        /* '<S78>/IC1' */
  real_T Saturation1;                  /* '<S77>/Saturation1' */
  real_T Sum_m;                        /* '<S10>/Sum' */
  real_T uDLookupTable_a;              /* '<S10>/1-D Lookup Table' */
  real_T IC2_g;                        /* '<S10>/IC2' */
  real_T LG_1_G;                       /* '<S10>/Bias' */
  real_T uDLookupTable1_i;             /* '<S10>/1-D Lookup Table1' */
  real_T IC3_l;                        /* '<S10>/IC3' */
  real_T LG_2_G;                       /* '<S10>/Bias1' */
  real_T FP_FET_1_On;                  /* '<S5>/Gain6' */
  real_T FP_FET_2_On;                  /* '<S5>/Gain7' */
  real_T LG_FET_1_On;                  /* '<S5>/Gain8' */
  real_T LG_FET_2_On;                  /* '<S5>/Gain9' */
  real_T Br_Licht_On;                  /* '<S5>/Constant8' */
  real_T Constant;                     /* '<S6>/Constant' */
  real_T Alive;                        /* '<S7>/Alive' */
  real_T IO291_DI_CH3_Brmslcht;        /* '<S7>/Gain2' */
  real_T TmpRTBAtSwitchInport1_iu;     /* '<S1>/1-D Lookup Table2' */
  real_T Switch_p;                     /* '<S1>/Switch' */
  real_T Saturation3_j;                /* '<S1>/Saturation3' */
  real_T Bremssignal;                  /* '<S1>/Gain -1' */
  real_T uDLookupTable_j;              /* '<S16>/1-D Lookup Table' */
  real_T Digitalinput_o1_p;            /* '<S8>/Digital input' */
  real_T Digitalinput_o2_b;            /* '<S8>/Digital input' */
  real_T IO397_DI_Ch8_Bremsaktuator_Hall;/* '<S8>/Gain' */
  real_T VectorConcatenate_n[5];       /* '<S14>/Vector Concatenate' */
  real_T SumofElements_f;              /* '<S14>/Sum of Elements' */
  real_T Divide_l;                     /* '<S14>/Divide' */
  real_T Round;                        /* '<S14>/Round' */
  real_T DataTypeConversion_e;         /* '<S28>/Data Type Conversion' */
  real_T IO397_DI_Ch9_Bremsaktuator_Hall;/* '<S8>/Gain1' */
  real_T VectorConcatenate_a[5];       /* '<S15>/Vector Concatenate' */
  real_T SumofElements_g;              /* '<S15>/Sum of Elements' */
  real_T Divide_e;                     /* '<S15>/Divide' */
  real_T Round_m;                      /* '<S15>/Round' */
  real_T DataTypeConversion1_m;        /* '<S28>/Data Type Conversion1' */
  real_T Switch_f;                     /* '<S16>/Switch' */
  real_T Switch1_c;                    /* '<S26>/Switch1' */
  real_T UnitDelay;                    /* '<S26>/Unit Delay' */
  real_T Switch2_f;                    /* '<S26>/Switch2' */
  real_T Add;                          /* '<S26>/Add' */
  real_T Add_a;                        /* '<S16>/Add' */
  real_T Delay1;                       /* '<S17>/Delay1' */
  real_T Switch1_h;                    /* '<S17>/Switch1' */
  real_T IC1_di;                       /* '<S16>/IC1' */
  real_T DataTypeConversion_g;         /* '<S7>/Data Type Conversion' */
  real_T Delay1_n;                     /* '<S18>/Delay1' */
  real_T Switch1_j;                    /* '<S18>/Switch1' */
  real_T IC2_e;                        /* '<S16>/IC2' */
  real_T DataTypeConversion1_c;        /* '<S7>/Data Type Conversion1' */
  real_T USS_Reverse;                  /* '<S5>/Constant13' */
  real_T PulseGenerator;               /* '<S49>/Pulse Generator' */
  real_T Switch1_m;                    /* '<S49>/Switch1' */
  real_T LED_Totmann;                  /* '<S5>/Gain4' */
  real_T Bias;                         /* '<S17>/Bias' */
  real_T Saturation_io;                /* '<S17>/Saturation' */
  real_T Switch_oz;                    /* '<S17>/Switch' */
  real_T Bias_n;                       /* '<S18>/Bias' */
  real_T Saturation_g;                 /* '<S18>/Saturation' */
  real_T Switch_g;                     /* '<S18>/Switch' */
  real_T Clock;                        /* '<S37>/Clock' */
  real_T MultiportSwitch[2];           /* '<S36>/Multiport Switch' */
  real_T Sum_j;                        /* '<S37>/Sum' */
  real_T TmpRTBAtLenkradwinkelgeschwindi;/* '<S4>/Product' */
  real_T Lenkradwinkel;
  real_T Derivative;                   /* '<S4>/Derivative' */
  real_T Delay1_a;                     /* '<S50>/Delay1' */
  real_T VectorConcatenate_j[5];       /* '<S54>/Vector Concatenate' */
  real_T SumofElements_fw;             /* '<S54>/Sum of Elements' */
  real_T Divide_g;                     /* '<S54>/Divide' */
  real_T Switch_k;                     /* '<S50>/Switch' */
  real_T Switch1_cc;                   /* '<S50>/Switch1' */
  real_T Divide_h;                     /* '<S8>/Divide' */
  real_T Divide1;                      /* '<S8>/Divide1' */
  real_T IO397_QAD_Position;           /* '<S8>/Gain4' */
  real_T IO397_QAD_Turns;              /* '<S8>/Gain5' */
  real_T IO397_QAD_rpm;                /* '<S8>/Gain6' */
  real_T TmpRTBAtDerivativeInport1;
  real_T LenkradwinkelGeschwindigkeit; /* '<S79>/Derivative' */
  real_T TmpRTBAtMATLABFunction1Inport2;/* '<S79>/Product' */
  real_T Saturation_i2;                /* '<S77>/Saturation' */
  real_T Switch_d;                     /* '<S80>/Switch' */
  real_T Switch2_g;                    /* '<S80>/Switch2' */
  real_T IProdOut;                     /* '<S116>/IProd Out' */
  real_T Lenkwinkel;                   /* '<S11>/Rate Transition2' */
  real_T TmpRTBAtTransferFcn1Inport1;  /* '<S12>/Divide' */
  real_T TmpRTBAtTransferFcnInport1;   /* '<S12>/1-D Lookup Table' */
  real_T RXSampleTime;                 /* '<S9>/RX Sample Time' */
  real_T TmpSignalConversionAtBytePackin[3];
  real_T Product;                      /* '<S4>/Product' */
  real_T uDLookupTable_o;              /* '<S74>/1-D Lookup Table' */
  real_T Saturation_m;                 /* '<S74>/Saturation' */
  real_T Product_o;                    /* '<S79>/Product' */
  real_T Sum_p;                        /* '<S78>/Sum' */
  real_T SollgrevorRegler_h;           /* '<S75>/Saturation2' */
  real_T Radar_Data;                   /* '<S11>/Data Type Conversion' */
  real_T Switch_l;                     /* '<S12>/Switch' */
  real_T Saturation_k;                 /* '<S12>/Saturation' */
  real_T uDLookupTable_p;              /* '<S12>/1-D Lookup Table' */
  real_T Switch1_l;                    /* '<S12>/Switch1' */
  real_T Saturation1_n;                /* '<S12>/Saturation1' */
  real_T Divide_c;                     /* '<S12>/Divide' */
  real_T Longitudinal_Velocity;        /* '<S11>/Rate Transition1' */
  real_T Switch_gp;                    /* '<S138>/Switch' */
  real_T FromJetson_o2;                /* '<S11>/From Jetson' */
  real_T DataTypeConversion3;          /* '<S144>/Data Type Conversion3' */
  real_T Saturation2;                  /* '<S144>/Saturation2' */
  real_T DataTypeConversion2_a;        /* '<S144>/Data Type Conversion2' */
  real_T Saturation3_b;                /* '<S144>/Saturation3' */
  real_T Product_oh;                   /* '<S144>/Product' */
  real_T Gain[21];                     /* '<S144>/Gain' */
  real_T Sum_a[21];                    /* '<S144>/Sum' */
  real_T DataTypeConversion1_f;        /* '<S144>/Data Type Conversion1' */
  real_T UnaryMinus1;                  /* '<S144>/Unary Minus1' */
  real_T Saturation_f;                 /* '<S144>/Saturation' */
  real_T DataTypeConversion_gl;        /* '<S144>/Data Type Conversion' */
  real_T UnaryMinus;                   /* '<S144>/Unary Minus' */
  real_T Saturation1_l;                /* '<S144>/Saturation1' */
  real_T uDLookupTable2;               /* '<S1>/1-D Lookup Table2' */
  real_T uDLookupTable2_i;             /* '<S3>/1-D Lookup Table2' */
  real_T JetsonWinkelRad;              /* '<S73>/Lenkung umdrehen' */
  real_T JetsonWinkelGrad;             /* '<S73>/Umrechnen von rad in grad' */
  real_T JetsonWinkelGradNormiert;     /* '<S73>/1-D Lookup Table2' */
  real_T Saturation1_d;                /* '<S73>/Saturation1' */
  real_T Odometer;
  real_T SoC;
  real_T SFunctionBuilder;             /* '<Root>/S-Function Builder' */
  real_T IndexVector;                  /* '<S10>/Index Vector' */
  real_T Saturation1_a;                /* '<S75>/Saturation1' */
  real_T Sum_k;                        /* '<S75>/Sum' */
  real_T LenkDrehmomentMaxNomiert;     /* '<S79>/MATLAB Function1' */
  real_T lenkradwinkelMaxNomiert;      /* '<S79>/MATLAB Function' */
  real_T Switch_fo;                    /* '<S78>/Switch' */
  real_T Switch1_cq;                   /* '<S78>/Switch1' */
  real_T CANUnpack;                    /* '<S69>/CAN Unpack' */
  real_T CANUnpack1_o1;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o2;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o3;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o4;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o5;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o6;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o7;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack1_o8;                /* '<S69>/CAN Unpack1' */
  real_T CANUnpack2_o1;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o2;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o3;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o4;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o5;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o6;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o7;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack2_o8;                /* '<S69>/CAN Unpack2' */
  real_T CANUnpack4_o1;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o2;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o3;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o4;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o5;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o6;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o7;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack4_o8;                /* '<S69>/CAN Unpack4' */
  real_T CANUnpack5_o1;                /* '<S69>/CAN Unpack5' */
  real_T CANUnpack5_o2;                /* '<S69>/CAN Unpack5' */
  real_T Lenkradwinkel_m;              /* '<S69>/Gain' */
  real_T AY;                           /* '<S69>/Gain1' */
  real_T USS_Sensor_VLM;               /* '<S69>/Gain10' */
  real_T USS_Sensor_VRA;               /* '<S69>/Gain11' */
  real_T USS_Sensor_VRM;               /* '<S69>/Gain12' */
  real_T RC_Fahrpedal;                 /* '<S69>/Gain13' */
  real_T RC_Lenkung;                   /* '<S69>/Gain14' */
  real_T Gierrate;                     /* '<S69>/Gain2' */
  real_T AX;                           /* '<S69>/Gain3' */
  real_T Gierbeschleunigung;           /* '<S69>/Gain4' */
  real_T USS_Sensor_HLA;               /* '<S69>/Gain5' */
  real_T USS_Sensor_HLM;               /* '<S69>/Gain6' */
  real_T USS_Sensor_HRA;               /* '<S69>/Gain7' */
  real_T USS_Sensor_HRM;               /* '<S69>/Gain8' */
  real_T USS_Sensor_VLA;               /* '<S69>/Gain9' */
  real_T Divide_b;                     /* '<S70>/Divide' */
  real_T isvalid;
  real_T radardatalength1788;
  real_T Radar_Punkt;
  real_T Radar_Mode;
  real_T Radar_2;
  real_T CANUnpack_o1;                 /* '<S68>/CAN Unpack' */
  real_T CANUnpack_o2;                 /* '<S68>/CAN Unpack' */
  real_T CANUnpack_o3;                 /* '<S68>/CAN Unpack' */
  real_T CANUnpack_o4;                 /* '<S68>/CAN Unpack' */
  real_T CANUnpack1_o1_k;              /* '<S68>/CAN Unpack1' */
  real_T CANUnpack1_o2_m;              /* '<S68>/CAN Unpack1' */
  real_T CANUnpack1_o3_h;              /* '<S68>/CAN Unpack1' */
  real_T CANUnpack1_o4_f;              /* '<S68>/CAN Unpack1' */
  real_T CANUnpack2_o1_f;              /* '<S68>/CAN Unpack2' */
  real_T CANUnpack2_o2_a;              /* '<S68>/CAN Unpack2' */
  real_T CANUnpack2_o3_m;              /* '<S68>/CAN Unpack2' */
  real_T CANUnpack3_o1;                /* '<S68>/CAN Unpack3' */
  real_T CANUnpack3_o2;                /* '<S68>/CAN Unpack3' */
  real_T CANUnpack4_o1_n;              /* '<S68>/CAN Unpack4' */
  real_T CANUnpack4_o2_n;              /* '<S68>/CAN Unpack4' */
  real_T CANUnpack5;                   /* '<S68>/CAN Unpack5' */
  real_T CANUnpack6_o1;                /* '<S68>/CAN Unpack6' */
  real_T CANUnpack6_o2;                /* '<S68>/CAN Unpack6' */
  real_T CANUnpack6_o3;                /* '<S68>/CAN Unpack6' */
  real_T CANUnpack6_o4;                /* '<S68>/CAN Unpack6' */
  real_T CANUnpack6_o5;                /* '<S68>/CAN Unpack6' */
  real_T CANUnpack7_o1;                /* '<S68>/CAN Unpack7' */
  real_T CANUnpack7_o2;                /* '<S68>/CAN Unpack7' */
  real_T CANUnpack8_o1;                /* '<S68>/CAN Unpack8' */
  real_T CANUnpack8_o2;                /* '<S68>/CAN Unpack8' */
  real_T ChargeRequest;                /* '<S68>/Gain' */
  real_T IBatt;                        /* '<S68>/Gain1' */
  real_T Range;                        /* '<S68>/Gain10' */
  real_T CarSpeed;                     /* '<S68>/Gain11' */
  real_T SoC_b;                        /* '<S68>/Gain12' */
  real_T BrakePedal;                   /* '<S68>/Gain13' */
  real_T DriveMode;                    /* '<S68>/Gain14' */
  real_T DistanceToral_24Bit;          /* '<S68>/Gain15' */
  real_T VehicleSpeedFromABS;          /* '<S68>/Gain16' */
  real_T Wheel_Speed_FL;               /* '<S68>/Gain17' */
  real_T Wheel_Speed_FR;               /* '<S68>/Gain18' */
  real_T Wheel_Speed_RL;               /* '<S68>/Gain19' */
  real_T V_KL15;                       /* '<S68>/Gain2' */
  real_T Wheel_Speed_RR;               /* '<S68>/Gain20' */
  real_T Handbremse;                   /* '<S68>/Gain21' */
  real_T Odometer_e;                   /* '<S68>/Gain22' */
  real_T V_KL30;                       /* '<S68>/Gain3' */
  real_T BMSStatus;                    /* '<S68>/Gain4' */
  real_T InverterStatus;               /* '<S68>/Gain5' */
  real_T eMotorSpeed;                  /* '<S68>/Gain6' */
  real_T eMotorTorque;                 /* '<S68>/Gain7' */
  real_T Distance;                     /* '<S68>/Gain8' */
  real_T DistanceTotal;                /* '<S68>/Gain9' */
  real_T Switch_jr;                    /* '<S49>/Switch' */
  real_T Bias_nf;                      /* '<S50>/Bias' */
  real_T Saturation_gz;                /* '<S50>/Saturation' */
  real_T Saturation_c;                 /* '<S2>/Saturation' */
  real_T Add1;                         /* '<S2>/Add1' */
  real_T Divide1_o;                    /* '<S2>/Divide1' */
  real_T Power;                        /* '<S43>/Power' */
  real_T Multiply;                     /* '<S43>/Multiply' */
  real_T Add2;                         /* '<S43>/Add2' */
  real_T Saturation3_m;                /* '<S2>/Saturation3' */
  real_T Saturation1_p;                /* '<S2>/Saturation1' */
  real_T Add_n;                        /* '<S2>/Add' */
  real_T Divide_cy;                    /* '<S2>/Divide' */
  real_T Saturation2_j;                /* '<S2>/Saturation2' */
  real_T count_enable;                 /* '<S28>/State Transition Table' */
  real_T count_dir;                    /* '<S28>/State Transition Table' */
  real_T In1;                          /* '<S40>/In1' */
  real_T Switch_oi;                    /* '<S26>/Switch' */
  real32_T ByteUnpacking[3];           /* '<S2>/Byte Unpacking' */
  real32_T LateralOffset;              /* '<S137>/Delay1' */
  real32_T HeadingAngle;               /* '<S137>/Delay1' */
  real32_T CurvatureDerivative;        /* '<S137>/Delay1' */
  real32_T Curvature;                  /* '<S137>/Delay1' */
  real32_T Curvature_a;                /* '<S137>/Merge1' */
  real32_T UnaryMinus_i;               /* '<S145>/Unary Minus' */
  real32_T CurvatureDerivative_m;      /* '<S137>/Merge1' */
  real32_T UnaryMinus1_k;              /* '<S145>/Unary Minus1' */
  real32_T LateralOffset_f;            /* '<S137>/Merge1' */
  real32_T UnaryMinus3;                /* '<S145>/Unary Minus3' */
  real32_T HeadingAngle_l;             /* '<S137>/Merge1' */
  real32_T UnaryMinus2;                /* '<S145>/Unary Minus2' */
  real32_T Product_g;                  /* '<S142>/Product' */
  real32_T Subtract;                   /* '<S142>/Subtract' */
  real32_T Product1;                   /* '<S142>/Product1' */
  real32_T Product_l;                  /* '<S140>/Product' */
  real32_T Subtract_l;                 /* '<S140>/Subtract' */
  real32_T Product1_k;                 /* '<S140>/Product1' */
  real32_T Add_nc;                     /* '<S139>/Add' */
  real32_T Add1_e;                     /* '<S139>/Add1' */
  real32_T Add2_e;                     /* '<S139>/Add2' */
  real32_T Add3;                       /* '<S139>/Add3' */
  uint8_T UDPReceive1_o1[12];          /* '<S2>/UDP Receive1' */
  uint8_T BytePacking[24];             /* '<S2>/Byte Packing' */
  uint8_T FromJetson_o1[48];           /* '<S11>/From Jetson' */
  uint8_T TmpRTBAtBytePackingOutport1[24];/* '<S2>/Byte Packing' */
  boolean_T Compare;                   /* '<S44>/Compare' */
  boolean_T Compare_n;                 /* '<S64>/Compare' */
  boolean_T Compare_m;                 /* '<S65>/Compare' */
  boolean_T AND;                       /* '<S49>/AND' */
  boolean_T Compare_p;                 /* '<S67>/Compare' */
  boolean_T Compare_pz;                /* '<S58>/Compare' */
  boolean_T Compare_h;                 /* '<S59>/Compare' */
  boolean_T AND_m;                     /* '<S52>/AND' */
  boolean_T Compare_j;                 /* '<S62>/Compare' */
  boolean_T RelationalOperator2;       /* '<S53>/Relational Operator2' */
  boolean_T UnitDelay_f;               /* '<S48>/Unit Delay' */
  boolean_T LogicalOperator;           /* '<S48>/Logical Operator' */
  boolean_T LogicalOperator1;          /* '<S48>/Logical Operator1' */
  boolean_T AND2;                      /* '<S48>/AND2' */
  boolean_T Memory;                    /* '<S48>/Memory' */
  boolean_T AND3;                      /* '<S48>/AND3' */
  boolean_T RelationalOperator;        /* '<S81>/Relational Operator' */
  boolean_T HiddenBuf_InsertedFor_EnabledSu;/* '<S81>/Relational Operator' */
  boolean_T RT_i;                      /* '<S78>/RT' */
  boolean_T LogicalOperator_b;         /* '<S81>/Logical Operator' */
  boolean_T HiddenBuf_InsertedFor_Enabled_m;/* '<S81>/Logical Operator' */
  boolean_T TmpRTBAtSwitchInport2;     /* '<S78>/Relational Operator' */
  boolean_T Compare_d;                 /* '<S23>/Compare' */
  boolean_T Compare_f;                 /* '<S35>/Compare' */
  boolean_T Compare_i;                 /* '<S19>/Compare' */
  boolean_T UnitDelay_c;               /* '<S16>/Unit Delay' */
  boolean_T Compare_ig;                /* '<S20>/Compare' */
  boolean_T OR;                        /* '<S16>/OR' */
  boolean_T Compare_fa;                /* '<S34>/Compare' */
  boolean_T AND6;                      /* '<S26>/AND6' */
  boolean_T Compare_o;                 /* '<S33>/Compare' */
  boolean_T UnitDelay1;                /* '<S26>/Unit Delay1' */
  boolean_T Compare_fx;                /* '<S24>/Compare' */
  boolean_T AND7;                      /* '<S16>/AND7' */
  boolean_T Compare_hi;                /* '<S29>/Compare' */
  boolean_T Bremsaktuator_1;           /* '<S1>/AND3' */
  boolean_T Compare_c;                 /* '<S21>/Compare' */
  boolean_T Compare_co;                /* '<S25>/Compare' */
  boolean_T AND8;                      /* '<S16>/AND8' */
  boolean_T Compare_cr;                /* '<S22>/Compare' */
  boolean_T AND1;                      /* '<S16>/AND1' */
  boolean_T AND2_m;                    /* '<S16>/AND2' */
  boolean_T Compare_dk;                /* '<S31>/Compare' */
  boolean_T Bremsaktuator_2;           /* '<S1>/AND4' */
  boolean_T Uk1;                       /* '<S30>/Delay Input1' */
  boolean_T FixPtRelationalOperator;   /* '<S30>/FixPt Relational Operator' */
  boolean_T Uk1_e;                     /* '<S32>/Delay Input1' */
  boolean_T FixPtRelationalOperator_p; /* '<S32>/FixPt Relational Operator' */
  boolean_T DataTypeConversion2_i;     /* '<S36>/Data Type Conversion2' */
  boolean_T Memory_p;                  /* '<S36>/Memory' */
  boolean_T LogicalOperator1_h;        /* '<S36>/Logical Operator1' */
  boolean_T RelationalOperator_a;      /* '<S37>/Relational Operator' */
  boolean_T TmpRTBAtLenkradwinkelOutport1;/* '<S4>/Lenkradwinkel' */
  boolean_T TmpRTBAtFahrzeuggeschwindigkeit;/* '<S4>/Fahrzeuggeschwindigkeit' */
  boolean_T AND_i;                     /* '<S4>/AND' */
  boolean_T IC2_j;                     /* '<S4>/IC2' */
  boolean_T Compare_j5;                /* '<S56>/Compare' */
  boolean_T Uk1_k;                     /* '<S57>/Delay Input1' */
  boolean_T Compare_on;                /* '<S63>/Compare' */
  boolean_T FixPtRelationalOperator_c; /* '<S57>/FixPt Relational Operator' */
  boolean_T NOT;                       /* '<S48>/NOT' */
  boolean_T OR_j;                      /* '<S48>/OR' */
  boolean_T AND_n;                     /* '<S48>/AND' */
  boolean_T Memory1;                   /* '<S48>/Memory1' */
  boolean_T AND1_a;                    /* '<S48>/AND1' */
  boolean_T Memory_b;                  /* '<S55>/Memory' */
  boolean_T Logic[2];                  /* '<S55>/Logic' */
  boolean_T LowerRelop1;               /* '<S80>/LowerRelop1' */
  boolean_T UpperRelop;                /* '<S80>/UpperRelop' */
  boolean_T OR_k;                      /* '<Root>/OR' */
  boolean_T Compare_e;                 /* '<S51>/Compare' */
  boolean_T RelationalOperator1;       /* '<S78>/Relational Operator1' */
  boolean_T RelationalOperator_j;      /* '<S78>/Relational Operator' */
  boolean_T Compare_nw;                /* '<S204>/Compare' */
  boolean_T Compare_if;                /* '<S205>/Compare' */
  boolean_T CANRead1_o1;               /* '<S69>/CAN Read1' */
  boolean_T CANRead1_o1_f;             /* '<S68>/CAN Read1' */
  boolean_T Compare_hy;                /* '<S66>/Compare' */
  boolean_T geschwindigkeitLenkradwinkel_OK;/* '<S4>/Lenkradwinkelgeschwindigkeit' */
  boolean_T lenkradwinkel_OK;          /* '<S4>/Lenkradwinkel' */
  boolean_T geschwindigkeitFahrzeug_OK;/* '<S4>/Fahrzeuggeschwindigkeit' */
  boolean_T RelationalOperator1_g;     /* '<S39>/Relational Operator1' */
  boolean_T RelationalOperator1_c;     /* '<S38>/Relational Operator1' */
  boolean_T AND5;                      /* '<S26>/AND5' */
  B_PathFollowingControlSystem__T PathFollowingControlSystem_i;
                                    /* '<S138>/Path Following Control System' */
  B_EnabledSubsystem_D_20231120_T EnabledSubsystem1;/* '<S81>/Enabled Subsystem1' */
  B_EnabledSubsystem_D_20231120_T EnabledSubsystem;/* '<S81>/Enabled Subsystem' */
};

/* Block states (default storage) for system '<Root>' */
struct DW_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  packLaneMarkerBus_D_20231120__T obj; /* '<S11>/PackLaneBus' */
  real_T TappedDelay1_X[199];          /* '<S42>/Tapped Delay1' */
  real_T TappedDelay_X[4];             /* '<S60>/Tapped Delay' */
  real_T TappedDelay_X_m[4];           /* '<S61>/Tapped Delay' */
  real_T DiscreteTimeIntegrator2_DSTATE;/* '<S53>/Discrete-Time Integrator2' */
  real_T TappedDelay_X_b[4];           /* '<S14>/Tapped Delay' */
  real_T TappedDelay_X_d[4];           /* '<S15>/Tapped Delay' */
  real_T UnitDelay_DSTATE;             /* '<S26>/Unit Delay' */
  real_T Delay1_DSTATE;                /* '<S17>/Delay1' */
  real_T Delay1_DSTATE_o;              /* '<S18>/Delay1' */
  real_T Delay1_DSTATE_p;              /* '<S50>/Delay1' */
  real_T TappedDelay1_X_c[4];          /* '<S54>/Tapped Delay1' */
  real_T TmpRTBAtSwitchInport1_Buf[2]; /* synthesized block */
  real_T IC_FirstOutputTime;           /* '<S12>/IC' */
  real_T IC2_FirstOutputTime;          /* '<S3>/IC2' */
  real_T IC3_FirstOutputTime;          /* '<S3>/IC3' */
  real_T TmpRTBAtSwitchInport1_Buf_e[2];/* synthesized block */
  real_T IC1_FirstOutputTime;          /* '<S12>/IC1' */
  real_T TmpRTBAtIndexVector1Inport3_Buf[2];/* synthesized block */
  real_T TmpRTBAtSwitch1Inport1_Buf[2];/* synthesized block */
  real_T TmpRTBAtSumInport2_Buf[2];    /* synthesized block */
  real_T IC1_FirstOutputTime_n;        /* '<S78>/IC1' */
  real_T IC2_FirstOutputTime_n;        /* '<S10>/IC2' */
  real_T IC3_FirstOutputTime_f;        /* '<S10>/IC3' */
  real_T TmpRTBAtSwitchInport1_Buf_eu[2];/* synthesized block */
  real_T IC1_FirstOutputTime_d;        /* '<S16>/IC1' */
  real_T IC2_FirstOutputTime_c;        /* '<S16>/IC2' */
  real_T TmpRTBAtLenkradwinkelgeschwindi[2];/* synthesized block */
  real_T TmpRTBAtDerivativeInport1_Buf[2];/* synthesized block */
  real_T TimeStampA;                   /* '<S4>/Derivative' */
  real_T LastUAtTimeA;                 /* '<S4>/Derivative' */
  real_T TimeStampB;                   /* '<S4>/Derivative' */
  real_T LastUAtTimeB;                 /* '<S4>/Derivative' */
  real_T IC2_FirstOutputTime_ny;       /* '<S4>/IC2' */
  real_T TmpRTBAtDerivativeInport1_Buf_a[2];/* synthesized block */
  real_T TimeStampA_a;                 /* '<S79>/Derivative' */
  real_T LastUAtTimeA_a;               /* '<S79>/Derivative' */
  real_T TimeStampB_g;                 /* '<S79>/Derivative' */
  real_T LastUAtTimeB_o;               /* '<S79>/Derivative' */
  real_T TmpRTBAtMATLABFunction1Inport2_[2];/* synthesized block */
  real_T TmpRTBAtTransferFcn1Inport1_Buf[2];/* synthesized block */
  real_T TmpRTBAtTransferFcnInport1_Buf[2];/* synthesized block */
  real_T RateTransition1_Buf[2];       /* '<S11>/Rate Transition1' */
  real_T Odometer_Buf[2];              /* synthesized block */
  real_T SoC_Buf[2];                   /* synthesized block */
  real_T Setup_RWORK[2];               /* '<S6>/Setup ' */
  void *Setup_PWORK;                   /* '<S6>/Setup ' */
  void *Analoginput_PWORK;             /* '<S6>/Analog input ' */
  void *Digitalinput_PWORK;            /* '<S6>/Digital input ' */
  void* UDPReceive1_DWORK1;            /* '<S2>/UDP Receive1' */
  void *UDPReceive1_PWORK[2];          /* '<S2>/UDP Receive1' */
  struct {
    void *PrevTimePtr;
  } FromFile_PWORK;                    /* '<S72>/From File' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK;                      /* '<S86>/FromWs' */

  void *Isolateddigitalinput_PWORK[2]; /* '<S7>/Isolated digital input ' */
  void *Analogoutput_PWORK;            /* '<S6>/Analog output ' */
  void *Digitaloutput_PWORK;           /* '<S6>/Digital output ' */
  void *Digitalinput_PWORK_i[2];       /* '<S8>/Digital input' */
  void *FETdigitaloutput_PWORK[2];     /* '<S7>/FET digital output ' */
  void *LVTTLdigitalinput_PWORK[2];    /* '<S7>/LVTTL digital input ' */
  void *LVTTLdigitaloutput_PWORK[2];   /* '<S7>/LVTTL digital output ' */
  void *CANSetup_PWORK;                /* '<S9>/CAN Setup ' */
  struct {
    void *LoggedData[4];
  } Scope2_PWORK;                      /* '<S13>/Scope2' */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Gain1;   /* synthesized block */

  struct {
    void *LoggedData[4];
  } Scope1_PWORK;                      /* '<S16>/Scope1' */

  struct {
    void *LoggedData[2];
  } Scope_PWORK;                       /* '<S2>/Scope' */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Freig;   /* synthesized block */

  struct {
    void *USERIO_P_IND;
    void *PROG_SPACE_P_IND;
    void *CONFIG_REGISTER_P_IND;
    void *CONDITIONING_MODULE_IO3xx_2x_P_IND;
    void *DEVICENAME_P_IND;
  } Setup_PWORK_f;                     /* '<S8>/Setup' */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Lenkm;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Regle;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Switc;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Lenkw;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Drehm;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_LenkD;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Satur;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Deriv;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MATLA;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_1DLoo;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_PIDCo;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Swi_o;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_1DL_b;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Sat_b;   /* synthesized block */

  struct {
    void *LoggedData[3];
  } Scope_PWORK_h;                     /* '<S13>/Scope' */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_BusSe;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Linea;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Gesch;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Len_i;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MAT_h;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Produ;   /* synthesized block */

  void* FromJetson_DWORK1;             /* '<S11>/From Jetson' */
  void *FromJetson_PWORK[2];           /* '<S11>/From Jetson' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Bus_n;   /* synthesized block */

  void* UDPSend_DWORK1;                /* '<S2>/UDP Send' */
  void *UDPSend_PWORK;                 /* '<S2>/UDP Send' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Lin_l;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Estim;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Est_i;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Est_m;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MPCCo;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_MPC_a;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Previ;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Pre_g;   /* synthesized block */

  void *CANRead1_PWORK;                /* '<S69>/CAN Read1' */
  void *CANRead1_PWORK_o;              /* '<S68>/CAN Read1' */
  real32_T Delay1_4_DSTATE;            /* '<S137>/Delay1' */
  real32_T Delay1_3_DSTATE;            /* '<S137>/Delay1' */
  real32_T Delay1_2_DSTATE;            /* '<S137>/Delay1' */
  real32_T Delay1_1_DSTATE;            /* '<S137>/Delay1' */
  int32_T clockTickCounter;            /* '<S49>/Pulse Generator' */
  int32_T sfEvent;                     /* '<S28>/State Transition Table' */
  uint32_T is_c4_D_20231120_Modell_Inbetri;/* '<S28>/State Transition Table' */
  int_T Analoginput_IWORK[2];          /* '<S6>/Analog input ' */
  int_T UDPReceive1_IWORK[3];          /* '<S2>/UDP Receive1' */
  int_T ByteUnpacking_IWORK[2];        /* '<S2>/Byte Unpacking' */
  struct {
    int_T PrevIndex;
  } FromWs_IWORK;                      /* '<S86>/FromWs' */

  struct {
    int_T MODULEARCHITECTURE_I_IND;
  } Setup_IWORK;                       /* '<S8>/Setup' */

  int_T BytePacking_IWORK[2];          /* '<S2>/Byte Packing' */
  int_T FromJetson_IWORK[3];           /* '<S11>/From Jetson' */
  int_T UDPSend_IWORK[2];              /* '<S2>/UDP Send' */
  int_T CANUnpack_ModeSignalID;        /* '<S69>/CAN Unpack' */
  int_T CANUnpack_StatusPortID;        /* '<S69>/CAN Unpack' */
  int_T CANUnpack1_ModeSignalID;       /* '<S69>/CAN Unpack1' */
  int_T CANUnpack1_StatusPortID;       /* '<S69>/CAN Unpack1' */
  int_T CANUnpack2_ModeSignalID;       /* '<S69>/CAN Unpack2' */
  int_T CANUnpack2_StatusPortID;       /* '<S69>/CAN Unpack2' */
  int_T CANUnpack4_ModeSignalID;       /* '<S69>/CAN Unpack4' */
  int_T CANUnpack4_StatusPortID;       /* '<S69>/CAN Unpack4' */
  int_T CANUnpack5_ModeSignalID;       /* '<S69>/CAN Unpack5' */
  int_T CANUnpack5_StatusPortID;       /* '<S69>/CAN Unpack5' */
  int_T CANUnpack_ModeSignalID_d;      /* '<S68>/CAN Unpack' */
  int_T CANUnpack_StatusPortID_j;      /* '<S68>/CAN Unpack' */
  int_T CANUnpack1_ModeSignalID_f;     /* '<S68>/CAN Unpack1' */
  int_T CANUnpack1_StatusPortID_o;     /* '<S68>/CAN Unpack1' */
  int_T CANUnpack2_ModeSignalID_i;     /* '<S68>/CAN Unpack2' */
  int_T CANUnpack2_StatusPortID_d;     /* '<S68>/CAN Unpack2' */
  int_T CANUnpack3_ModeSignalID;       /* '<S68>/CAN Unpack3' */
  int_T CANUnpack3_StatusPortID;       /* '<S68>/CAN Unpack3' */
  int_T CANUnpack4_ModeSignalID_k;     /* '<S68>/CAN Unpack4' */
  int_T CANUnpack4_StatusPortID_m;     /* '<S68>/CAN Unpack4' */
  int_T CANUnpack5_ModeSignalID_a;     /* '<S68>/CAN Unpack5' */
  int_T CANUnpack5_StatusPortID_d;     /* '<S68>/CAN Unpack5' */
  int_T CANUnpack6_ModeSignalID;       /* '<S68>/CAN Unpack6' */
  int_T CANUnpack6_StatusPortID;       /* '<S68>/CAN Unpack6' */
  int_T CANUnpack7_ModeSignalID;       /* '<S68>/CAN Unpack7' */
  int_T CANUnpack7_StatusPortID;       /* '<S68>/CAN Unpack7' */
  int_T CANUnpack8_ModeSignalID;       /* '<S68>/CAN Unpack8' */
  int_T CANUnpack8_StatusPortID;       /* '<S68>/CAN Unpack8' */
  uint16_T UDPSend_DWORK2;             /* '<S2>/UDP Send' */
  boolean_T UnitDelay_DSTATE_e;        /* '<S48>/Unit Delay' */
  boolean_T UnitDelay_DSTATE_c;        /* '<S16>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE;         /* '<S26>/Unit Delay1' */
  boolean_T DelayInput1_DSTATE;        /* '<S30>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_b;      /* '<S32>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_j;      /* '<S57>/Delay Input1' */
  int8_T TmpRTBAtSwitchInport1_RdBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_WrBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_RdBufId_g;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_WrBufId_g;/* synthesized block */
  int8_T TmpRTBAtIndexVector1Inport3_RdB;/* synthesized block */
  int8_T TmpRTBAtIndexVector1Inport3_WrB;/* synthesized block */
  int8_T TmpRTBAtSwitch1Inport1_RdBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitch1Inport1_WrBufIdx;/* synthesized block */
  int8_T TmpRTBAtSumInport2_RdBufIdx;  /* synthesized block */
  int8_T TmpRTBAtSumInport2_WrBufIdx;  /* synthesized block */
  int8_T DiscreteTimeIntegrator2_PrevRes;/* '<S53>/Discrete-Time Integrator2' */
  int8_T RT_RdBufIdx;                  /* '<S78>/RT' */
  int8_T RT_WrBufIdx;                  /* '<S78>/RT' */
  int8_T TmpRTBAtSwitchInport2_RdBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitchInport2_WrBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_RdBufI_gy;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_WrBufI_gp;/* synthesized block */
  int8_T TmpRTBAtLenkradwinkelOutport1_R;/* synthesized block */
  int8_T TmpRTBAtLenkradwinkelOutport1_W;/* synthesized block */
  int8_T TmpRTBAtLenkradwinkelgeschwin_p;/* synthesized block */
  int8_T TmpRTBAtLenkradwinkelgeschwin_k;/* synthesized block */
  int8_T TmpRTBAtDerivativeInport1_RdBuf;/* synthesized block */
  int8_T TmpRTBAtDerivativeInport1_WrBuf;/* synthesized block */
  int8_T TmpRTBAtFahrzeuggeschwindigkeit;/* synthesized block */
  int8_T TmpRTBAtFahrzeuggeschwindigke_b;/* synthesized block */
  int8_T TmpRTBAtDerivativeInport1_RdB_e;/* synthesized block */
  int8_T TmpRTBAtDerivativeInport1_WrB_j;/* synthesized block */
  int8_T TmpRTBAtMATLABFunction1Inport_p;/* synthesized block */
  int8_T TmpRTBAtMATLABFunction1Inport_m;/* synthesized block */
  int8_T TmpRTBAtTransferFcn1Inport1_RdB;/* synthesized block */
  int8_T TmpRTBAtTransferFcn1Inport1_WrB;/* synthesized block */
  int8_T TmpRTBAtTransferFcnInport1_RdBu;/* synthesized block */
  int8_T TmpRTBAtTransferFcnInport1_WrBu;/* synthesized block */
  int8_T TmpRTBAtBytePackingOutport1_RdB;/* synthesized block */
  int8_T TmpRTBAtBytePackingOutport1_WrB;/* synthesized block */
  int8_T RateTransition1_RdBufIdx;     /* '<S11>/Rate Transition1' */
  int8_T RateTransition1_WrBufIdx;     /* '<S11>/Rate Transition1' */
  int8_T Odometer_RdBufIdx;            /* synthesized block */
  int8_T Odometer_WrBufIdx;            /* synthesized block */
  int8_T SoC_RdBufIdx;                 /* synthesized block */
  int8_T SoC_WrBufIdx;                 /* synthesized block */
  int8_T CenterfromNone1_SubsysRanBC;  /* '<S137>/Center from None1' */
  int8_T CenterfromRight1_SubsysRanBC; /* '<S137>/Center from Right1' */
  int8_T CenterfromLeft1_SubsysRanBC;  /* '<S137>/Center from Left1' */
  int8_T CenterfromLeftandRight1_SubsysR;
                                      /* '<S137>/Center from Left and Right1' */
  int8_T POSITIVEEdge_SubsysRanBC;     /* '<S36>/POSITIVE Edge' */
  int8_T NEGATIVEEdge_SubsysRanBC;     /* '<S36>/NEGATIVE Edge' */
  int8_T TriggeredSubsystem_SubsysRanBC;/* '<S37>/Triggered Subsystem' */
  uint8_T TmpRTBAtBytePackingOutport1_Buf[48];/* synthesized block */
  uint8_T is_active_c4_D_20231120_Modell_;/* '<S28>/State Transition Table' */
  boolean_T IC1_FirstOutputTime_b;     /* '<S2>/IC1' */
  boolean_T IC_FirstOutputTime_j;      /* '<S2>/IC' */
  boolean_T Memory_PreviousInput;      /* '<S48>/Memory' */
  boolean_T RT_Buf[2];                 /* '<S78>/RT' */
  boolean_T TmpRTBAtSwitchInport2_Buf[2];/* synthesized block */
  boolean_T Memory_PreviousInput_o;    /* '<S36>/Memory' */
  boolean_T TmpRTBAtLenkradwinkelOutport1_B[2];/* synthesized block */
  boolean_T TmpRTBAtFahrzeuggeschwindigke_k[2];/* synthesized block */
  boolean_T Memory1_PreviousInput;     /* '<S48>/Memory1' */
  boolean_T Memory_PreviousInput_d;    /* '<S55>/Memory' */
  boolean_T objisempty;                /* '<S11>/PackLaneBus' */
  boolean_T POSITIVEEdge_MODE;         /* '<S36>/POSITIVE Edge' */
  boolean_T NEGATIVEEdge_MODE;         /* '<S36>/NEGATIVE Edge' */
  DW_PathFollowingControlSystem_T PathFollowingControlSystem_i;
                                    /* '<S138>/Path Following Control System' */
  DW_EnabledSubsystem_D_2023112_T EnabledSubsystem1;/* '<S81>/Enabled Subsystem1' */
  DW_EnabledSubsystem_D_2023112_T EnabledSubsystem;/* '<S81>/Enabled Subsystem' */
};

/* Continuous states (default storage) */
struct X_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  real_T TransferFcn_CSTATE;           /* '<S12>/Transfer Fcn' */
  real_T TransferFcn1_CSTATE;          /* '<S12>/Transfer Fcn1' */
  real_T Integrator_CSTATE;            /* '<S49>/Integrator' */
  real_T Integrator_CSTATE_k;          /* '<S119>/Integrator' */
};

/* State derivatives (default storage) */
struct XDot_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  real_T TransferFcn_CSTATE;           /* '<S12>/Transfer Fcn' */
  real_T TransferFcn1_CSTATE;          /* '<S12>/Transfer Fcn1' */
  real_T Integrator_CSTATE;            /* '<S49>/Integrator' */
  real_T Integrator_CSTATE_k;          /* '<S119>/Integrator' */
};

/* State disabled  */
struct XDis_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  boolean_T TransferFcn_CSTATE;        /* '<S12>/Transfer Fcn' */
  boolean_T TransferFcn1_CSTATE;       /* '<S12>/Transfer Fcn1' */
  boolean_T Integrator_CSTATE;         /* '<S49>/Integrator' */
  boolean_T Integrator_CSTATE_k;       /* '<S119>/Integrator' */
};

/* Zero-crossing (trigger) state */
struct PrevZCX_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  ZCSigState Integrator_Reset_ZCE;     /* '<S49>/Integrator' */
  ZCSigState Integrator_Reset_ZCE_p;   /* '<S119>/Integrator' */
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S37>/Triggered Subsystem' */
};

/* Invariant block signals (default storage) */
struct ConstB_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  real_T Width;                        /* '<S14>/Width' */
  real_T Width_d;                      /* '<S15>/Width' */
  real_T Width_g;                      /* '<S42>/Width' */
  real_T Width_f;                      /* '<S2>/Width' */
  real_T Width_gx;                     /* '<S60>/Width' */
  real_T Width_gf;                     /* '<S61>/Width' */
  real_T Width_m;                      /* '<S54>/Width' */
};

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
struct ODE1_IntgData {
  real_T *f[1];                        /* derivatives */
};

#endif

/* Real-time Model Data Structure */
struct tag_RTM_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[5];
    SimStruct childSFunctions[14];
    SimStruct *childSFunctionPtrs[14];
    struct _ssBlkInfo2 blkInfo2[14];
    struct _ssSFcnModelMethods2 methods2[14];
    struct _ssSFcnModelMethods3 methods3[14];
    struct _ssSFcnModelMethods4 methods4[14];
    struct _ssStatesInfo2 statesInfo2[14];
    ssPeriodicStatesInfo periodicStatesInfo[14];
    struct _ssPortInfo2 inputOutputPortInfo2[14];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[4];
      struct _ssOutPortUnit outputPortUnits[4];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[4];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn3;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      uint_T attribs[4];
      mxArray *params[4];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn4;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[3];
      struct _ssOutPortUnit outputPortUnits[3];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[3];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn5;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[4];
      struct _ssInPortUnit inputPortUnits[4];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[4];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn6;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[8];
      struct _ssInPortUnit inputPortUnits[8];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[8];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn7;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[5];
      mxArray *params[5];
    } Sfcn8;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn9;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[5];
      struct _ssInPortUnit inputPortUnits[5];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[5];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn10;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn11;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn12;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[3];
      mxArray *params[3];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn13;
  } NonInlinedSFcns;

  X_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][4];
  ODE1_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    uint32_T clockTick3;
    uint32_T clockTickH3;
    uint32_T clockTick4;
    uint32_T clockTickH4;
    struct {
      uint16_T TID[5];
      uint16_T cLimit[5];
    } TaskCounters;

    struct {
      uint16_T TID1_2;
      uint16_T TID1_3;
      uint16_T TID2_3;
      uint16_T TID2_4;
    } RateInteraction;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[5];
    time_T offsetTimesArray[5];
    int_T sampleTimeTaskIDArray[5];
    int_T sampleHitArray[5];
    int_T perTaskSampleHitsArray[25];
    time_T tArray[5];
  } Timing;
};

extern CAN_DATATYPE CAN_DATATYPE_GROUND;

/* Block signals (default storage) */
#ifdef __cplusplus

extern "C"
{

#endif

  extern struct B_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B;

#ifdef __cplusplus

}

#endif

/* Continuous states (default storage) */
extern X_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X;

/* Block states (default storage) */
extern struct DW_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX;
extern const ConstB_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB;/* constant block i/o */

#ifdef __cplusplus

extern "C"
{

#endif

  /* Model entry point functions */
  extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_initialize
    (void);
  extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step0(void);
  extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step2(void);
  extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step3(void);
  extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step4(void);
  extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_terminate(void);

#ifdef __cplusplus

}

#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C"
{

#endif

  extern RT_MODEL_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *const
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M;

#ifdef __cplusplus

}

#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson'
 * '<S1>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung'
 * '<S2>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android'
 * '<S3>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Fahrpedal Steuerung'
 * '<S4>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Fahrzeugbeobachter'
 * '<S5>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe'
 * '<S6>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191'
 * '<S7>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS'
 * '<S8>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO397'
 * '<S9>'   : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691'
 * '<S10>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung'
 * '<S11>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson'
 * '<S12>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Read RC Control'
 * '<S13>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Scope'
 * '<S14>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/Moving Average'
 * '<S15>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/Moving Average1'
 * '<S16>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1'
 * '<S17>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen'
 * '<S18>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen1'
 * '<S19>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant1'
 * '<S20>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant2'
 * '<S21>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant3'
 * '<S22>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant4'
 * '<S23>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant6'
 * '<S24>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant7'
 * '<S25>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Zero1'
 * '<S26>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter'
 * '<S27>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector'
 * '<S28>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/QAD1'
 * '<S29>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen/Compare To Zero'
 * '<S30>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen/Detect Increase'
 * '<S31>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen1/Compare To Zero'
 * '<S32>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen1/Detect Increase'
 * '<S33>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter/Compare To Constant5'
 * '<S34>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter/Compare To Zero'
 * '<S35>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter/Compare To Zero1'
 * '<S36>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model'
 * '<S37>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/Internal dirac generator'
 * '<S38>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/NEGATIVE Edge'
 * '<S39>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/POSITIVE Edge'
 * '<S40>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/Internal dirac generator/Triggered Subsystem'
 * '<S41>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/QAD1/State Transition Table'
 * '<S42>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android/Detektion_kein_Signal'
 * '<S43>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android/Kurvenanpassung'
 * '<S44>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android/Detektion_kein_Signal/Compare To Constant'
 * '<S45>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Fahrzeugbeobachter/Fahrzeuggeschwindigkeit'
 * '<S46>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Fahrzeugbeobachter/Lenkradwinkel'
 * '<S47>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Fahrzeugbeobachter/Lenkradwinkelgeschwindigkeit'
 * '<S48>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe'
 * '<S49>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann'
 * '<S50>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/1s Tastersperre'
 * '<S51>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Compare To Zero'
 * '<S52>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal'
 * '<S53>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Lenkung'
 * '<S54>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/EMV Filter'
 * '<S55>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/S-R Flip-Flop'
 * '<S56>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/1s Tastersperre/Compare To Zero'
 * '<S57>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/1s Tastersperre/Detect Increase'
 * '<S58>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Compare To Constant'
 * '<S59>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Compare To Constant1'
 * '<S60>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Moving Average'
 * '<S61>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Moving Average1'
 * '<S62>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Lenkung/Compare To Constant4'
 * '<S63>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/EMV Filter/Compare To Constant'
 * '<S64>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant'
 * '<S65>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant1'
 * '<S66>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant2'
 * '<S67>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant3'
 * '<S68>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 1'
 * '<S69>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 3'
 * '<S70>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 3/Linearisierung Lenkwinkel IST'
 * '<S71>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer'
 * '<S72>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Lenkmomentsimulationssignalgeber'
 * '<S73>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Linearisierung Lenkmoment Jetson'
 * '<S74>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Linearisierung Lenkwinkel IST'
 * '<S75>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler'
 * '<S76>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Subsystem1'
 * '<S77>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Lenkwingelgeschwindigkeitsbegrenzer'
 * '<S78>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Lenkwinkelbegrenzer'
 * '<S79>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Subsystem1'
 * '<S80>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Lenkwingelgeschwindigkeitsbegrenzer/Saturation Dynamic'
 * '<S81>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Lenkwinkelbegrenzer/Split pos. and neg. Drehmoment'
 * '<S82>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Lenkwinkelbegrenzer/Split pos. and neg. Drehmoment/Enabled Subsystem'
 * '<S83>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Lenkwinkelbegrenzer/Split pos. and neg. Drehmoment/Enabled Subsystem1'
 * '<S84>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Subsystem1/MATLAB Function'
 * '<S85>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Beobachter und Begrenzer/Subsystem1/MATLAB Function1'
 * '<S86>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Lenkmomentsimulationssignalgeber/Signal Builder'
 * '<S87>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller'
 * '<S88>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Anti-windup'
 * '<S89>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/D Gain'
 * '<S90>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Filter'
 * '<S91>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Filter ICs'
 * '<S92>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/I Gain'
 * '<S93>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Ideal P Gain'
 * '<S94>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Ideal P Gain Fdbk'
 * '<S95>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Integrator'
 * '<S96>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Integrator ICs'
 * '<S97>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/N Copy'
 * '<S98>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/N Gain'
 * '<S99>'  : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/P Copy'
 * '<S100>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Parallel P Gain'
 * '<S101>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Reset Signal'
 * '<S102>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Saturation'
 * '<S103>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Saturation Fdbk'
 * '<S104>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Sum'
 * '<S105>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Sum Fdbk'
 * '<S106>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tracking Mode'
 * '<S107>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tracking Mode Sum'
 * '<S108>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tsamp - Integral'
 * '<S109>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tsamp - Ngain'
 * '<S110>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/postSat Signal'
 * '<S111>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/preSat Signal'
 * '<S112>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Anti-windup/Passthrough'
 * '<S113>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/D Gain/Disabled'
 * '<S114>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Filter/Disabled'
 * '<S115>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Filter ICs/Disabled'
 * '<S116>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/I Gain/External Parameters'
 * '<S117>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Ideal P Gain/Passthrough'
 * '<S118>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S119>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Integrator/Continuous'
 * '<S120>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Integrator ICs/Internal IC'
 * '<S121>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/N Copy/Disabled wSignal Specification'
 * '<S122>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/N Gain/Disabled'
 * '<S123>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/P Copy/Disabled'
 * '<S124>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Parallel P Gain/External Parameters'
 * '<S125>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Reset Signal/External Reset'
 * '<S126>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Saturation/Enabled'
 * '<S127>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Saturation Fdbk/Disabled'
 * '<S128>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Sum/Sum_PI'
 * '<S129>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Sum Fdbk/Disabled'
 * '<S130>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tracking Mode/Disabled'
 * '<S131>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S132>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tsamp - Integral/Passthrough'
 * '<S133>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/Tsamp - Ngain/Passthrough'
 * '<S134>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/postSat Signal/Forward_Path'
 * '<S135>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/Regler/PID Controller/preSat Signal/Forward_Path'
 * '<S136>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl'
 * '<S137>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1'
 * '<S138>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller'
 * '<S139>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from Left and Right1'
 * '<S140>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from Left1'
 * '<S141>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from None1'
 * '<S142>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from Right1'
 * '<S143>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/MATLAB Function1'
 * '<S144>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Preview Curvature'
 * '<S145>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Preview Curvature/ISO 8855 to SAE J670E'
 * '<S146>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System'
 * '<S147>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller'
 * '<S148>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/DataTypeConversion_Ts'
 * '<S149>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/DataTypeConversion_spacing'
 * '<S150>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/DataTypeConversion_tlag'
 * '<S151>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Longitudinal velocity must be positive'
 * '<S152>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers'
 * '<S153>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Models'
 * '<S154>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models'
 * '<S155>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/CurvatureConversion'
 * '<S156>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_Vx'
 * '<S157>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_amax'
 * '<S158>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_amin'
 * '<S159>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_e1'
 * '<S160>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_e2'
 * '<S161>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_extmv'
 * '<S162>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_optsgn'
 * '<S163>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_umax'
 * '<S164>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_umin'
 * '<S165>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_vset'
 * '<S166>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller'
 * '<S167>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller'
 * '<S168>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC'
 * '<S169>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check'
 * '<S170>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check A'
 * '<S171>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check B'
 * '<S172>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check C'
 * '<S173>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check D'
 * '<S174>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check DX'
 * '<S175>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check U'
 * '<S176>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check X'
 * '<S177>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check Y'
 * '<S178>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check1'
 * '<S179>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check2'
 * '<S180>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check'
 * '<S181>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check1'
 * '<S182>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check2'
 * '<S183>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check3'
 * '<S184>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check4'
 * '<S185>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check5'
 * '<S186>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check6'
 * '<S187>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check7'
 * '<S188>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check8'
 * '<S189>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Scalar Signal Check'
 * '<S190>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Scalar Signal Check1'
 * '<S191>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Scalar Signal Check2'
 * '<S192>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Vector Signal Check'
 * '<S193>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Vector Signal Check1'
 * '<S194>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Vector Signal Check6'
 * '<S195>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/moorx'
 * '<S196>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/optimizer'
 * '<S197>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/optimizer/FixedHorizonOptimizer'
 * '<S198>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Models/MPC Model'
 * '<S199>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Models/MPC Model/Adaptive Model'
 * '<S200>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model'
 * '<S201>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model/Vehicle combined dynamics'
 * '<S202>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model/Vehicle lateral dynamics'
 * '<S203>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model/Vehicle longitudinal dynamics'
 * '<S204>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Read RC Control/Compare To Constant'
 * '<S205>' : 'D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/Read RC Control/Compare To Constant1'
 */
#endif   /* RTW_HEADER_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_h_ */

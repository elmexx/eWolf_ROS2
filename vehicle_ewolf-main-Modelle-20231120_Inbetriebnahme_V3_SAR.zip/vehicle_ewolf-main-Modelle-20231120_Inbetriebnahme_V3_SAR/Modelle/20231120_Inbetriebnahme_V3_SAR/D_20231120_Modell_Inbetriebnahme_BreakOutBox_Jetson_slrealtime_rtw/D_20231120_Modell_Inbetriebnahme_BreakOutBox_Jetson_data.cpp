/*
 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_data.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
 * Model version              : 4.141
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C++ source code generated on : Fri May 24 11:08:49 2024
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"

/* Invariant block signals (default storage) */
const ConstB_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB = {
  5.0
  ,                                    /* '<S14>/Width' */
  5.0
  ,                                    /* '<S15>/Width' */
  200.0
  ,                                    /* '<S42>/Width' */
  24.0
  ,                                    /* '<S2>/Width' */
  5.0
  ,                                    /* '<S60>/Width' */
  5.0
  ,                                    /* '<S61>/Width' */
  5.0
  /* '<S54>/Width' */
};

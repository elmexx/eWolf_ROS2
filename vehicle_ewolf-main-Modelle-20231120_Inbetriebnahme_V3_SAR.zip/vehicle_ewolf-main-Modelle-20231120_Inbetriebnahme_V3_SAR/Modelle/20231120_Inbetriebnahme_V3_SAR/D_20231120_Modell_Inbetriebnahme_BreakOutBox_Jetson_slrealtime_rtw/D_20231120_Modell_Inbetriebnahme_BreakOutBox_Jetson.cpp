/*
 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
 * Model version              : 4.141
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C++ source code generated on : Fri May 24 11:08:49 2024
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal.h"
#include "rtwtypes.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_private.h"
#include "PathFollowingControlSystem.h"
#include "rte_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_parameters.h"
#include <cstring>
#include <cmath>
#include <stddef.h>
#include "zero_crossing_types.h"

extern "C"
{

#include "rt_nonfinite.h"

}

/* Named constants for State Transition Table: '<S28>/State Transition Table' */
const uint8_T D_20231120_M_IN_NO_ACTIVE_CHILD = 0U;
const int32_T D_20231120_Modell_In_CALL_EVENT = -1;
const uint32_T D_20231120_Modell__IN_state_0_0 = 1U;
const uint32_T D_20231120_Modell__IN_state_0_1 = 2U;
const uint32_T D_20231120_Modell__IN_state_1_0 = 3U;
const uint32_T D_20231120_Modell__IN_state_1_1 = 4U;

/* Block signals (default storage) */
B_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B;

/* Continuous states */
X_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X;

/* Block states (default storage) */
DW_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX;

/* Real-time model */
RT_MODEL_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M_ =
  RT_MODEL_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T();
RT_MODEL_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *const
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M =
  &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M_;

/* Forward declaration for local functions */
static void D_202_packLaneBoundaryDetection(const
  c_driving_internal_parabolicL_T boundary_Data_data[], real32_T
  *detection_Curvature, real32_T *detection_CurvatureDerivative, real32_T
  *detection_HeadingAngle, real32_T *detection_LateralOffset, real32_T
  *detection_Strength, real32_T detection_XExtent[2], LaneBoundaryType
  *detection_BoundaryType);
real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  real_T yL_0d0;
  uint32_T iLeft;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    uint32_T bpIdx;
    uint32_T iRght;

    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1U] - yL_0d0) * frac + yL_0d0;
}

uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T maxIndex)
{
  uint32_T bpIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Interpolation method: 'Use nearest'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp[0U]) {
    bpIndex = 0U;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d(u, bp, maxIndex >> 1U, maxIndex);
    if ((bpIndex < maxIndex) && (bp[bpIndex + 1U] - u <= u - bp[bpIndex])) {
      bpIndex++;
    }
  } else {
    bpIndex = maxIndex;
  }

  return bpIndex;
}

uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex)
{
  uint32_T bpIdx;
  uint32_T bpIndex;
  uint32_T iRght;

  /* Binary Search */
  bpIdx = startIndex;
  bpIndex = 0U;
  iRght = maxIndex;
  while (iRght - bpIndex > 1U) {
    if (u < bp[bpIdx]) {
      iRght = bpIdx;
    } else {
      bpIndex = bpIdx;
    }

    bpIdx = (iRght + bpIndex) >> 1U;
  }

  return bpIndex;
}

int32_T div_nde_s32_floor(int32_T numerator, int32_T denominator)
{
  return (((numerator < 0) != (denominator < 0)) && (numerator % denominator !=
           0) ? -1 : 0) + numerator / denominator;
}

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = static_cast<ODE1_IntgData *>(rtsiGetSolverData(si));
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/*
 * System initialize for enable system:
 *    '<S81>/Enabled Subsystem'
 *    '<S81>/Enabled Subsystem1'
 */
void D_202_EnabledSubsystem_Init(B_EnabledSubsystem_D_20231120_T *localB,
  D_202_EnabledSubsystem_cal_type *D_20231120_Mo_PageSwitching_arg)
{
  /* SystemInitialize for SignalConversion generated from: '<S82>/Drehmomentsvorgabe normiert' incorporates:
   *  Outport: '<S82>/Out1'
   */
  localB->Drehmomentsvorgabenormiert = D_20231120_Mo_PageSwitching_arg->Out1_Y0;
}

/*
 * Disable for enable system:
 *    '<S81>/Enabled Subsystem'
 *    '<S81>/Enabled Subsystem1'
 */
void D__EnabledSubsystem_Disable(DW_EnabledSubsystem_D_2023112_T *localDW)
{
  localDW->EnabledSubsystem_MODE = false;
}

/*
 * Output and update for enable system:
 *    '<S81>/Enabled Subsystem'
 *    '<S81>/Enabled Subsystem1'
 */
void D_20231120_EnabledSubsystem
  (RT_MODEL_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T * const
   D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, boolean_T rtu_Enable,
   real_T rtu_Drehmomentsvorgabenormiert, B_EnabledSubsystem_D_20231120_T
   *localB, DW_EnabledSubsystem_D_2023112_T *localDW)
{
  /* Outputs for Enabled SubSystem: '<S81>/Enabled Subsystem' incorporates:
   *  EnablePort: '<S82>/Enable'
   */
  if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M) &&
      rtsiIsModeUpdateTimeStep
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
    if (rtu_Enable) {
      if (!localDW->EnabledSubsystem_MODE) {
        localDW->EnabledSubsystem_MODE = true;
      }
    } else if (localDW->EnabledSubsystem_MODE) {
      D__EnabledSubsystem_Disable(localDW);
    }
  }

  if (localDW->EnabledSubsystem_MODE) {
    /* SignalConversion generated from: '<S82>/Drehmomentsvorgabe normiert' */
    localB->Drehmomentsvorgabenormiert = rtu_Drehmomentsvorgabenormiert;
    if (rtsiIsModeUpdateTimeStep
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      srUpdateBC(localDW->EnabledSubsystem_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S81>/Enabled Subsystem' */
}

static void D_202_packLaneBoundaryDetection(const
  c_driving_internal_parabolicL_T boundary_Data_data[], real32_T
  *detection_Curvature, real32_T *detection_CurvatureDerivative, real32_T
  *detection_HeadingAngle, real32_T *detection_LateralOffset, real32_T
  *detection_Strength, real32_T detection_XExtent[2], LaneBoundaryType
  *detection_BoundaryType)
{
  c_driving_internal_parabolicL_T b_this_Data_data;
  real_T s_idx_0;
  real_T s_idx_1;
  real_T s_idx_2;
  int32_T n;

  /*  Parameters of parabolicLaneBoundary object = [A B C] */
  /*   corresponds to the three coefficients of a second-degree */
  /*   polynomial equation: */
  /*                 y = Ax^2 + Bx + C */
  /*  Comparing this equation with lane model using 2nd order */
  /*  polynomial approximation: */
  /*   y = (curvature/2)*(x^2) + (headingAngle)*x + lateralOffset */
  /*  */
  /*  This leads to the following relationship */
  /*    curvature           = 2 * A = 2 * Parameters(1)  (unit: 1/m) */
  /*    headingAngle        = B     = Parameters(2)      (unit: radians) */
  /*    lateralOffset       = C     = Parameters(3)      (unit: meters) */
  /*  */
  /*  Default lane of zero strength */
  *detection_Curvature = 0.0F;
  *detection_CurvatureDerivative = 0.0F;
  *detection_HeadingAngle = 0.0F;
  *detection_LateralOffset = 0.0F;
  *detection_Strength = 0.0F;
  detection_XExtent[0] = 0.0F;
  detection_XExtent[1] = 0.0F;
  *detection_BoundaryType = Unmarked;
  b_this_Data_data = boundary_Data_data[0];
  s_idx_0 = b_this_Data_data.Parameters[0];
  s_idx_1 = b_this_Data_data.Parameters[1];
  s_idx_2 = b_this_Data_data.Parameters[2];
  n = 0;
  if (s_idx_0 != 0.0) {
    n = 1;
  }

  if (s_idx_1 != 0.0) {
    n++;
  }

  if (s_idx_2 != 0.0) {
    n++;
  }

  if (n != 0) {
    b_this_Data_data = boundary_Data_data[0];
    s_idx_0 = b_this_Data_data.Parameters[0];
    *detection_Curvature = static_cast<real32_T>(2.0 * s_idx_0);
    b_this_Data_data = boundary_Data_data[0];
    s_idx_1 = b_this_Data_data.Parameters[1];
    *detection_HeadingAngle = static_cast<real32_T>(s_idx_1);

    /*  Coordinate transform */
    b_this_Data_data = boundary_Data_data[0];
    s_idx_2 = b_this_Data_data.Parameters[2];
    *detection_LateralOffset = static_cast<real32_T>(s_idx_2);

    /*  Coordinate transform */
    *detection_Strength = 1.0F;
    b_this_Data_data = boundary_Data_data[0];
    s_idx_0 = b_this_Data_data.XExtent[0];
    detection_XExtent[0] = static_cast<real32_T>(s_idx_0);
    s_idx_0 = b_this_Data_data.XExtent[1];
    detection_XExtent[1] = static_cast<real32_T>(s_idx_0);
    *detection_BoundaryType = Solid;
  }
}

/* Model step function for TID0 */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step0(void) /* Sample time: [0.0s, 0.0s] */
{
  if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* set solver stop time */
    if (!(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick0
          +1)) {
      rtsiSetSolverStopTime
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
         ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH0
           + 1) *
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0
          * 4294967296.0));
    } else {
      rtsiSetSolverStopTime
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
         ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick0
           + 1) *
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0
          + D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH0
          * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0
          * 4294967296.0));
    }

    /* Update the flag to indicate when data transfers from
     *  Sample time: [0.001s, 0.0s] to Sample time: [0.005s, 0.0s]  */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
      [7] =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
       == 0);
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2)
      ++;
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2)
        > 4) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        = 0;
    }

    /* Update the flag to indicate when data transfers from
     *  Sample time: [0.001s, 0.0s] to Sample time: [0.1s, 0.0s]  */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
      [8] =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
       == 0);
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3)
      ++;
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3)
        > 99) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        = 0;
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0] =
      rtsiGetT
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);
  }

  {
    real_T lastTime;
    real_T tmp;
    real_T u1;
    real_T u2;
    real_T *lastU;
    uint32_T bpIdx;
    boolean_T didZcEventOccur;

    /* Bias: '<S17>/Bias' */
    tmp = *get_Ts();

    /* Reset subsysRan breadcrumbs */
    srClearBC
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TriggeredSubsystem_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_SubsysRanBC);

    /* Reset subsysRan breadcrumbs */
    srClearBC
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.EnabledSubsystem.EnabledSubsystem_SubsysRanBC);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* S-Function (sg_IO191_setup_s): '<S6>/Setup ' */

      /* Level2 S-Function Block: '<S6>/Setup ' (sg_IO191_setup_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[2];
        sfcnOutputs(rts,0);
      }

      /* S-Function (sg_IO191_ad_s): '<S6>/Analog input ' */

      /* Level2 S-Function Block: '<S6>/Analog input ' (sg_IO191_ad_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[3];
        sfcnOutputs(rts,0);
      }

      /* S-Function (sg_IO191_di_s): '<S6>/Digital input ' */

      /* Level2 S-Function Block: '<S6>/Digital input ' (sg_IO191_di_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[4];
        sfcnOutputs(rts,0);
      }

      /* Gain: '<S6>/Gain1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH9_Bremspedal_1
        = D_20231120_Modell_Inbetrieb_cal->Gain1_Gain_b *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1;

      /* Gain: '<S6>/Gain10' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2_FP_2_G =
        D_20231120_Modell_Inbetrieb_cal->Gain10_Gain_e *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2;

      /* Gain: '<S6>/Gain11' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3_LG_1_G =
        D_20231120_Modell_Inbetrieb_cal->Gain11_Gain_g *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3;

      /* Gain: '<S6>/Gain12' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4_LG_2_G =
        D_20231120_Modell_Inbetrieb_cal->Gain12_Gain_h *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4;

      /* Gain: '<S6>/Gain2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH10_Bremspedal_2
        = D_20231120_Modell_Inbetrieb_cal->Gain2_Gain_n *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2;

      /* Gain: '<S6>/Gain3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH11_BR_Licht
        = D_20231120_Modell_Inbetrieb_cal->Gain3_Gain_m *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o3;

      /* Gain: '<S6>/Gain4' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH12_Totmann_Taster_1
        = D_20231120_Modell_Inbetrieb_cal->Gain4_Gain_c *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o4;

      /* Gain: '<S6>/Gain5' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH13_Totmann_Taster_2
        = D_20231120_Modell_Inbetrieb_cal->Gain5_Gain_c *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o5;

      /* Gain: '<S6>/Gain6' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH14_Freigabe_Taster
        = D_20231120_Modell_Inbetrieb_cal->Gain6_Gain_i *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o6;

      /* Gain: '<S6>/Gain7' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH15 =
        D_20231120_Modell_Inbetrieb_cal->Gain7_Gain_a *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o7;

      /* Gain: '<S6>/Gain8' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH16 =
        D_20231120_Modell_Inbetrieb_cal->Gain8_Gain_i *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o8;

      /* Gain: '<S6>/Gain9' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1_FP_1_G =
        D_20231120_Modell_Inbetrieb_cal->Gain9_Gain_n *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1;

      /* RateTransition generated from: '<S3>/Switch' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx
           == 0);
      }

      /* RateTransition generated from: '<S3>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx];

      /* S-Function (slrealtimeUDPReceive): '<S2>/UDP Receive1' */
      {
        try {
          slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
            udp::Socket*>
            (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK
             [0]);
          char *buffer = (char *)
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK
            [1];
          memset(buffer,0,12);
          void *dataPort =
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o1
            [0];
          int_T numBytesAvail = (int_T)(udpSock->bytesToRead());
          if (numBytesAvail > 0) {
            uint8_t* fmAddArg = (uint8_t *)
              D_20231120_Modell_Inbetrieb_cal->UDPReceive1_fmAddress;
            size_t num_bytesRcvd = (size_t)(udpSock->receive(buffer,
              ( numBytesAvail<65507 )? numBytesAvail:65507, !1,fmAddArg));
            if (num_bytesRcvd == 0) {
              D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2
                = 0;
            } else {
              D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2
                = (double)num_bytesRcvd;
              memcpy(dataPort,(void*)buffer,12);
            }
          } else {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2
              = 0;
          }
        } catch (std::exception& e) {
          std::string tmp = std::string(e.what());
          static std::string eMsg = tmp;
          rtmSetErrorStatus
            (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, eMsg.c_str());
          rtmSetStopRequested
            (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
          ;
        }
      }

      /* SignalConversion generated from: '<S42>/Vector Concatenate' incorporates:
       *  Concatenate: '<S42>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate[0]
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2;

      /* S-Function (sfix_udelay): '<S42>/Tapped Delay1' incorporates:
       *  Concatenate: '<S42>/Vector Concatenate'
       */
      std::memcpy
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate
         [1],
         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X
         [0], 199U * sizeof(real_T));

      /* Sum: '<S42>/Sum of Elements' */
      lastTime = -0.0;
      for (int32_T i = 0; i < 200; i++) {
        lastTime +=
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate
          [i];
      }

      /* Sum: '<S42>/Sum of Elements' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements =
        lastTime;

      /* Product: '<S42>/Divide' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements /
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_g;

      /* RelationalOperator: '<S44>/Compare' incorporates:
       *  Constant: '<S44>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide ==
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant_const);

      /* S-Function (slrealtimebytepacking): '<S2>/Byte Unpacking' */

      /* Byte Unpacking: <S2>/Byte Unpacking */
      (void)memcpy((uint8_T*)
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ByteUnpacking
                   [0], (uint8_T*)
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o1
                   [0] + 0, 12);

      /* DataTypeConversion: '<S2>/Data Type Conversion1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ByteUnpacking[1];

      /* Switch: '<S2>/Switch1' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare) {
        /* Switch: '<S2>/Switch1' incorporates:
         *  Constant: '<S2>/Constant5'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1 =
          D_20231120_Modell_Inbetrieb_cal->Constant5_Value;
      } else {
        /* Saturate: '<S2>/Saturation1' */
        lastTime =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1;
        u1 = D_20231120_Modell_Inbetrieb_cal->Saturation1_LowerSat;
        u2 = D_20231120_Modell_Inbetrieb_cal->Saturation1_UpperSat;
        if (lastTime > u2) {
          /* Saturate: '<S2>/Saturation1' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p =
            u2;
        } else if (lastTime < u1) {
          /* Saturate: '<S2>/Saturation1' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p =
            u1;
        } else {
          /* Saturate: '<S2>/Saturation1' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p =
            lastTime;
        }

        /* End of Saturate: '<S2>/Saturation1' */

        /* Sum: '<S2>/Add' incorporates:
         *  Constant: '<S2>/Constant1'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_n =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p -
          D_20231120_Modell_Inbetrieb_cal->Constant1_Value;

        /* Product: '<S2>/Divide' incorporates:
         *  Constant: '<S2>/Constant2'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_cy =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_n /
          D_20231120_Modell_Inbetrieb_cal->Constant2_Value;

        /* Saturate: '<S2>/Saturation2' */
        lastTime =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_cy;
        u1 = D_20231120_Modell_Inbetrieb_cal->Saturation2_LowerSat;
        u2 = D_20231120_Modell_Inbetrieb_cal->Saturation2_UpperSat;
        if (lastTime > u2) {
          /* Saturate: '<S2>/Saturation2' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j =
            u2;
        } else if (lastTime < u1) {
          /* Saturate: '<S2>/Saturation2' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j =
            u1;
        } else {
          /* Saturate: '<S2>/Saturation2' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j =
            lastTime;
        }

        /* End of Saturate: '<S2>/Saturation2' */

        /* Switch: '<S2>/Switch1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1 =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j;
      }

      /* End of Switch: '<S2>/Switch1' */

      /* InitialCondition: '<S2>/IC1' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_b)
      {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_b
          = false;

        /* InitialCondition: '<S2>/IC1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1 =
          D_20231120_Modell_Inbetrieb_cal->IC1_Value;
      } else {
        /* InitialCondition: '<S2>/IC1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1 =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1;
      }

      /* End of InitialCondition: '<S2>/IC1' */
    }

    /* TransferFcn: '<S12>/Transfer Fcn' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn =
      D_20231120_Modell_Inbetrieb_cal->TransferFcn_C *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn_CSTATE;

    /* InitialCondition: '<S12>/IC' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S12>/IC' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC =
        D_20231120_Modell_Inbetrieb_cal->IC_Value;
    } else {
      /* InitialCondition: '<S12>/IC' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn;
    }

    /* End of InitialCondition: '<S12>/IC' */

    /* Switch: '<Root>/Switch' incorporates:
     *  Constant: '<Root>/Android_ON'
     */
    if (D_20231120_Modell_Inbetrieb_cal->Android_ON_Value >
        D_20231120_Modell_Inbetrieb_cal->Switch_Threshold) {
      /* Switch: '<Root>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1;
    } else {
      /* Switch: '<Root>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC;
    }

    /* End of Switch: '<Root>/Switch' */

    /* Switch: '<S3>/Switch' incorporates:
     *  Constant: '<Root>/Autonom_ON'
     */
    if (D_20231120_Modell_Inbetrieb_cal->Autonom_ON_Value >
        D_20231120_Modell_Inbetrieb_cal->Switch_Threshold_m) {
      /* Switch: '<S3>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1;
    } else {
      /* Switch: '<S3>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal;
    }

    /* End of Switch: '<S3>/Switch' */

    /* Saturate: '<S3>/Saturation3' */
    lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation3_LowerSat_e;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation3_UpperSat_m;
    if (lastTime > u2) {
      /* Saturate: '<S3>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3 = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S3>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3 = u1;
    } else {
      /* Saturate: '<S3>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3 =
        lastTime;
    }

    /* End of Saturate: '<S3>/Saturation3' */

    /* Lookup_n-D: '<S3>/1-D Lookup Table' incorporates:
     *  Saturate: '<S3>/Saturation3'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable =
      look1_binlxpw
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable_bp01Data,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable_tableData, 1U);

    /* InitialCondition: '<S3>/IC2' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S3>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2 =
        D_20231120_Modell_Inbetrieb_cal->IC2_Value;
    } else {
      /* InitialCondition: '<S3>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable;
    }

    /* End of InitialCondition: '<S3>/IC2' */

    /* Bias: '<S3>/Bias1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_1_G
      = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2 +
      D_20231120_Modell_Inbetrieb_cal->Bias1_Bias;

    /* Lookup_n-D: '<S3>/1-D Lookup Table1' incorporates:
     *  Saturate: '<S3>/Saturation3'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1 =
      look1_binlxpw
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable1_bp01Data,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable1_tableData, 1U);

    /* InitialCondition: '<S3>/IC3' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S3>/IC3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3 =
        D_20231120_Modell_Inbetrieb_cal->IC3_Value;
    } else {
      /* InitialCondition: '<S3>/IC3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1;
    }

    /* End of InitialCondition: '<S3>/IC3' */

    /* Bias: '<S3>/Bias2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_2_G
      = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3 +
      D_20231120_Modell_Inbetrieb_cal->Bias2_Bias;

    /* RateTransition generated from: '<S10>/Switch' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g
           == 0);
      }

      /* RateTransition generated from: '<S10>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_i
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_e
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g];

      /* DataTypeConversion: '<S2>/Data Type Conversion' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ByteUnpacking[0];

      /* Switch: '<S2>/Switch' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare) {
        /* Switch: '<S2>/Switch' incorporates:
         *  Constant: '<S2>/Constant'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_j =
          D_20231120_Modell_Inbetrieb_cal->Constant_Value;
      } else {
        /* Saturate: '<S2>/Saturation' */
        lastTime =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion;
        u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat;
        u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat;
        if (lastTime > u2) {
          /* Saturate: '<S2>/Saturation' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c =
            u2;
        } else if (lastTime < u1) {
          /* Saturate: '<S2>/Saturation' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c =
            u1;
        } else {
          /* Saturate: '<S2>/Saturation' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c =
            lastTime;
        }

        /* End of Saturate: '<S2>/Saturation' */

        /* Sum: '<S2>/Add1' incorporates:
         *  Constant: '<S2>/Constant3'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1 =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c +
          D_20231120_Modell_Inbetrieb_cal->Constant3_Value_j;

        /* Product: '<S2>/Divide1' incorporates:
         *  Constant: '<S2>/Constant4'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1_o =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1 /
          D_20231120_Modell_Inbetrieb_cal->Constant4_Value;

        /* Math: '<S43>/Power' incorporates:
         *  Constant: '<S43>/Constant7'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Power =
          rt_powd_snf
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1_o,
           D_20231120_Modell_Inbetrieb_cal->Constant7_Value);

        /* Gain: '<S43>/Multiply' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Multiply =
          D_20231120_Modell_Inbetrieb_cal->Multiply_Gain *
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Power;

        /* Sum: '<S43>/Add2' incorporates:
         *  Constant: '<S43>/Constant6'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2 =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Multiply +
          D_20231120_Modell_Inbetrieb_cal->Constant6_Value;

        /* Saturate: '<S2>/Saturation3' */
        lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2;
        u1 = D_20231120_Modell_Inbetrieb_cal->Saturation3_LowerSat;
        u2 = D_20231120_Modell_Inbetrieb_cal->Saturation3_UpperSat;
        if (lastTime > u2) {
          /* Saturate: '<S2>/Saturation3' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m =
            u2;
        } else if (lastTime < u1) {
          /* Saturate: '<S2>/Saturation3' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m =
            u1;
        } else {
          /* Saturate: '<S2>/Saturation3' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m =
            lastTime;
        }

        /* End of Saturate: '<S2>/Saturation3' */

        /* Switch: '<S2>/Switch' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_j =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m;
      }

      /* End of Switch: '<S2>/Switch' */

      /* InitialCondition: '<S2>/IC' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime_j)
      {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime_j
          = false;

        /* InitialCondition: '<S2>/IC' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC_p =
          D_20231120_Modell_Inbetrieb_cal->IC_Value_j;
      } else {
        /* InitialCondition: '<S2>/IC' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC_p =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_j;
      }

      /* End of InitialCondition: '<S2>/IC' */
    }

    /* End of RateTransition generated from: '<S10>/Switch' */

    /* TransferFcn: '<S12>/Transfer Fcn1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn1 =
      D_20231120_Modell_Inbetrieb_cal->TransferFcn1_C *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn1_CSTATE;

    /* InitialCondition: '<S12>/IC1' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S12>/IC1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_h =
        D_20231120_Modell_Inbetrieb_cal->IC1_Value_g;
    } else {
      /* InitialCondition: '<S12>/IC1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_h =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn1;
    }

    /* End of InitialCondition: '<S12>/IC1' */

    /* Switch: '<Root>/Switch1' incorporates:
     *  Constant: '<Root>/Android_ON'
     */
    if (D_20231120_Modell_Inbetrieb_cal->Android_ON_Value >
        D_20231120_Modell_Inbetrieb_cal->Switch1_Threshold) {
      /* Switch: '<Root>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC_p;
    } else {
      /* Switch: '<Root>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_h;
    }

    /* End of Switch: '<Root>/Switch1' */

    /* Saturate: '<S76>/Saturation' */
    lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_e;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_o;
    if (lastTime > u2) {
      /* Saturate: '<S76>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_LenkwinkelEingang
        = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S76>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_LenkwinkelEingang
        = u1;
    } else {
      /* Saturate: '<S76>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_LenkwinkelEingang
        = lastTime;
    }

    /* End of Saturate: '<S76>/Saturation' */

    /* Lookup_n-D: '<S76>/1-D Lookup Table1' incorporates:
     *  Saturate: '<S76>/Saturation'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_LenkwinkelVorgabe =
      look1_binlxpw
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_LenkwinkelEingang,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable1_bp01Data_k,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable1_tableData_b, 4U);

    /* RateTransition: '<S10>/RT' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* RateTransition: '<S10>/RT' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_LenkwinkelVorgabe;

      /* RateTransition generated from: '<S10>/Index Vector1' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_RdB
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_RdB
           == 0);
      }

      /* RateTransition generated from: '<S10>/Index Vector1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtIndexVector1Inport3
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_RdB];
    }

    /* End of RateTransition: '<S10>/RT' */

    /* FromFile: '<S72>/From File' */
    {
      static const real_T *pStart = (NULL);
      static boolean_T initBasePtr = true;
      real_T time =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      const real_T *pU = (NULL);
      const real_T *pT = (const real_T *)
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromFile_PWORK.PrevTimePtr;
      if (initBasePtr == true) {
        pStart = (real_T *)
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromFile_PWORK.PrevTimePtr;
        initBasePtr = false;
      }

      pU = pStart + 5681;
      if (time <= pStart[0]) {
        pT = pStart;
      } else if (time >= pU[0]) {
        pT = pU;
      } else {
        if (time < pT[0]) {
          while (time < pT[0]) {
            pT--;
          }
        } else {
          while (time >= pT[1]) {
            pT++;
          }
        }
      }

      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromFile_PWORK.PrevTimePtr
        = (void *) pT;
      pU = pT + 5683;
      if (pT[0] == pT[1]) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkwinkelVorgabeMessungJetson
          = pU[ (time < pT[0]) ? 0 : 1 ];
      } else {
        real_T f = (pT[1]-time)/(pT[1]-pT[0]);
        if (pU[0] == pU[1]) {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkwinkelVorgabeMessungJetson
            = pU[0];
        } else {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkwinkelVorgabeMessungJetson
            = f*pU[0]+(1.0-f)*pU[1];
        }
      }
    }

    /* FromWorkspace: '<S86>/FromWs' */
    {
      real_T *pDataValues = (real_T *)
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_PWORK.DataPtr;
      real_T *pTimeValues = (real_T *)
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_PWORK.TimePtr;
      int_T currTimeIndex =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_IWORK.PrevIndex;
      real_T t = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
        Timing.t[0];

      /* Get index */
      if (t <= pTimeValues[0]) {
        currTimeIndex = 0;
      } else if (t >= pTimeValues[39]) {
        currTimeIndex = 38;
      } else {
        if (t < pTimeValues[currTimeIndex]) {
          while (t < pTimeValues[currTimeIndex]) {
            currTimeIndex--;
          }
        } else {
          while (t >= pTimeValues[currTimeIndex + 1]) {
            currTimeIndex++;
          }
        }
      }

      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_IWORK.PrevIndex
        = currTimeIndex;

      /* Post output */
      {
        real_T t1 = pTimeValues[currTimeIndex];
        real_T t2 = pTimeValues[currTimeIndex + 1];
        if (t1 == t2) {
          if (t < t1) {
            {
              int_T elIdx;
              for (elIdx = 0; elIdx < 5; ++elIdx) {
                (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[0])
                  [elIdx] = pDataValues[currTimeIndex];
                pDataValues += 40;
              }
            }
          } else {
            {
              int_T elIdx;
              for (elIdx = 0; elIdx < 5; ++elIdx) {
                (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[0])
                  [elIdx] = pDataValues[currTimeIndex + 1];
                pDataValues += 40;
              }
            }
          }
        } else {
          real_T f1 = (t2 - t) / (t2 - t1);
          real_T f2 = 1.0 - f1;
          real_T d1;
          real_T d2;
          int_T TimeIndex = currTimeIndex;

          {
            int_T elIdx;
            for (elIdx = 0; elIdx < 5; ++elIdx) {
              d1 = pDataValues[TimeIndex];
              d2 = pDataValues[TimeIndex + 1];
              (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[0])
                [elIdx] = (real_T) rtInterpolate(d1, d2, f1, f2);
              pDataValues += 40;
            }
          }
        }
      }
    }

    /* MultiPortSwitch: '<S72>/Index Vector2' incorporates:
     *  Constant: '<S72>/Constant3'
     */
    switch (static_cast<int32_T>
            (D_20231120_Modell_Inbetrieb_cal->Constant3_Value_f)) {
     case 0:
      /* MultiPortSwitch: '<S72>/Index Vector2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkwinkelVorgabeMessungJetson;
      break;

     case 1:
      /* MultiPortSwitch: '<S72>/Index Vector2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[0];
      break;

     case 2:
      /* MultiPortSwitch: '<S72>/Index Vector2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[1];
      break;

     case 3:
      /* MultiPortSwitch: '<S72>/Index Vector2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[2];
      break;

     case 4:
      /* MultiPortSwitch: '<S72>/Index Vector2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[3];
      break;

     default:
      /* MultiPortSwitch: '<S72>/Index Vector2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromWs[4];
      break;
    }

    /* End of MultiPortSwitch: '<S72>/Index Vector2' */

    /* Lookup_n-D: '<S72>/1-D Lookup Table' incorporates:
     *  MultiPortSwitch: '<S72>/Index Vector2'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_l =
      look1_binlxpw
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector2,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_g,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable_tableData_n, 1U);

    /* Saturate: '<S72>/Saturation' */
    lastTime =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_l;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_j;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_e;
    if (lastTime > u2) {
      /* Saturate: '<S72>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S72>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u1;
    } else {
      /* Saturate: '<S72>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation =
        lastTime;
    }

    /* End of Saturate: '<S72>/Saturation' */

    /* MultiPortSwitch: '<S10>/Index Vector1' incorporates:
     *  Constant: '<S10>/Constant1'
     */
    switch (static_cast<int32_T>
            (D_20231120_Modell_Inbetrieb_cal->Constant1_Value_c)) {
     case 0:
      /* MultiPortSwitch: '<S10>/Index Vector1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_g;
      break;

     case 1:
      /* MultiPortSwitch: '<S10>/Index Vector1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtIndexVector1Inport3;
      break;

     default:
      /* MultiPortSwitch: '<S10>/Index Vector1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation;
      break;
    }

    /* End of MultiPortSwitch: '<S10>/Index Vector1' */

    /* RateTransition generated from: '<S10>/Switch1' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_RdBufIdx
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_RdBufIdx
           == 0);
      }

      /* RateTransition generated from: '<S10>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitch1Inport1
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_RdBufIdx];
    }

    /* End of RateTransition generated from: '<S10>/Switch1' */

    /* Switch: '<S10>/Switch1' incorporates:
     *  Constant: '<Root>/Autonom_ON'
     */
    if (D_20231120_Modell_Inbetrieb_cal->Autonom_ON_Value >
        D_20231120_Modell_Inbetrieb_cal->Switch1_Threshold_l) {
      /* Switch: '<S10>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollLenkwinkel =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitch1Inport1;
    } else {
      /* Switch: '<S10>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollLenkwinkel =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector1;
    }

    /* End of Switch: '<S10>/Switch1' */

    /* RateTransition generated from: '<S75>/Sum' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_RdBufIdx
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_RdBufIdx
           == 0);
      }

      /* RateTransition generated from: '<S75>/Sum' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_RdBufIdx];

      /* RelationalOperator: '<S64>/Compare' incorporates:
       *  Constant: '<S64>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_n =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH12_Totmann_Taster_1
         == D_20231120_Modell_Inbetrieb_cal->CompareToConstant_const_a);

      /* RelationalOperator: '<S65>/Compare' incorporates:
       *  Constant: '<S65>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_m =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH13_Totmann_Taster_2
         == D_20231120_Modell_Inbetrieb_cal->CompareToConstant1_const);

      /* Logic: '<S49>/AND' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_n &&
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_m);
    }

    /* End of RateTransition generated from: '<S75>/Sum' */

    /* Integrator: '<S49>/Integrator' */
    if (rtsiIsModeUpdateTimeStep
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      didZcEventOccur =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE
          != POS_ZCSIG));
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND;

      /* evaluate zero-crossings */
      if (didZcEventOccur) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE =
          D_20231120_Modell_Inbetrieb_cal->Integrator_IC;
      }
    }

    /* Integrator: '<S49>/Integrator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE;

    /* RelationalOperator: '<S67>/Compare' incorporates:
     *  Constant: '<S67>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_p =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator <=
       D_20231120_Modell_Inbetrieb_cal->CompareToConstant3_const);

    /* Switch: '<S49>/Switch2' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_p) {
      /* Switch: '<S49>/Switch2' incorporates:
       *  Constant: '<S49>/Constant2'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2 =
        D_20231120_Modell_Inbetrieb_cal->Constant2_Value_e;
    } else {
      /* Switch: '<S49>/Switch2' incorporates:
       *  Constant: '<S49>/Constant1'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2 =
        D_20231120_Modell_Inbetrieb_cal->Constant1_Value_ns;
    }

    /* End of Switch: '<S49>/Switch2' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* SignalConversion generated from: '<S60>/Vector Concatenate' incorporates:
       *  Concatenate: '<S60>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
        [0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1_FP_1_G;

      /* S-Function (sfix_udelay): '<S60>/Tapped Delay' incorporates:
       *  Concatenate: '<S60>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
        [1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[0];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
        [2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
        [3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
        [4] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3];

      /* Sum: '<S60>/Sum of Elements' */
      lastTime = -0.0;
      for (int32_T i = 0; i < 5; i++) {
        lastTime +=
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
          [i];
      }

      /* Sum: '<S60>/Sum of Elements' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_i =
        lastTime;

      /* Product: '<S60>/Divide' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_d =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_i /
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_gx;

      /* RelationalOperator: '<S58>/Compare' incorporates:
       *  Constant: '<S58>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_pz =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_d <=
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant_const_k);

      /* SignalConversion generated from: '<S61>/Vector Concatenate' incorporates:
       *  Concatenate: '<S61>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
        [0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2_FP_2_G;

      /* S-Function (sfix_udelay): '<S61>/Tapped Delay' incorporates:
       *  Concatenate: '<S61>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
        [1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[0];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
        [2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
        [3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
        [4] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3];

      /* Sum: '<S61>/Sum of Elements' */
      lastTime = -0.0;
      for (int32_T i = 0; i < 5; i++) {
        lastTime +=
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
          [i];
      }

      /* Sum: '<S61>/Sum of Elements' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_d =
        lastTime;

      /* Product: '<S61>/Divide' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_p =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_d /
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_gf;

      /* RelationalOperator: '<S59>/Compare' incorporates:
       *  Constant: '<S59>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_h =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_p <=
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant1_const_f);

      /* Logic: '<S52>/AND' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_m =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_pz &&
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_h);

      /* Sum: '<S53>/Subtract2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3_LG_1_G
        - D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4_LG_2_G;

      /* Abs: '<S53>/Abs2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Abs2 = std::abs
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract2);

      /* RelationalOperator: '<S62>/Compare' incorporates:
       *  Constant: '<S62>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Abs2 >
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant4_const);

      /* DataTypeConversion: '<S53>/Data Type Conversion2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j;

      /* DiscreteIntegrator: '<S53>/Discrete-Time Integrator2' */
      if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
           <= 0.0) &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
           == 1)) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE
          = D_20231120_Modell_Inbetrieb_cal->DiscreteTimeIntegrator2_IC;
      }

      /* DiscreteIntegrator: '<S53>/Discrete-Time Integrator2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DiscreteTimeIntegrator2
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE;

      /* RelationalOperator: '<S53>/Relational Operator2' incorporates:
       *  Constant: '<S53>/Delta_Time1'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator2 =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DiscreteTimeIntegrator2
         < D_20231120_Modell_Inbetrieb_cal->Delta_Time1_Value);

      /* S-Function (sg_IO291_di_isol_s): '<S7>/Isolated digital input ' */

      /* Level2 S-Function Block: '<S7>/Isolated digital input ' (sg_IO291_di_isol_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[5];
        sfcnOutputs(rts,0);
      }

      /* Gain: '<S7>/Gain' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH1_NotAus_1
        = D_20231120_Modell_Inbetrieb_cal->Gain_Gain_c *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o1;

      /* Gain: '<S7>/Gain1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH2_NotAus_2
        = D_20231120_Modell_Inbetrieb_cal->Gain1_Gain_j *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o2;

      /* UnitDelay: '<S48>/Unit Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_f =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_e;

      /* Logic: '<S48>/Logical Operator' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator =
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH9_Bremspedal_1
          != 0.0) ==
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_f);

      /* Logic: '<S48>/Logical Operator1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1 =
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH10_Bremspedal_2
          != 0.0) ==
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_f);

      /* Memory: '<S48>/Memory' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput;
    }

    /* Logic: '<S48>/AND2' incorporates:
     *  Constant: '<S48>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2 =
      ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2 != 0.0) &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_m &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator2
       &&
       (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH1_NotAus_1
        != 0.0) &&
       (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH2_NotAus_2
        != 0.0) && (D_20231120_Modell_Inbetrieb_cal->Constant_Value_go != 0.0) &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1);

    /* Logic: '<S48>/AND3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3 =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2 &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory);

    /* DataTypeConversion: '<S48>/Data Type Conversion' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3;

    /* Gain: '<S5>/Gain5' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe =
      D_20231120_Modell_Inbetrieb_cal->Gain5_Gain_cp *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

    /* Switch: '<S75>/Switch2' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe >
        D_20231120_Modell_Inbetrieb_cal->Switch2_Threshold) {
      /* Saturate: '<S75>/Saturation1' */
      lastTime =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollLenkwinkel;
      u1 = D_20231120_Modell_Inbetrieb_cal->Saturation1_LowerSat_h;
      u2 = D_20231120_Modell_Inbetrieb_cal->Saturation1_UpperSat_i;
      if (lastTime > u2) {
        /* Saturate: '<S75>/Saturation1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_a = u2;
      } else if (lastTime < u1) {
        /* Saturate: '<S75>/Saturation1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_a = u1;
      } else {
        /* Saturate: '<S75>/Saturation1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_a =
          lastTime;
      }

      /* End of Saturate: '<S75>/Saturation1' */

      /* Sum: '<S75>/Sum' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_k =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_a -
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler;

      /* Switch: '<S75>/Switch2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Regelabweichung =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_k;
    } else {
      /* Switch: '<S75>/Switch2' incorporates:
       *  Constant: '<S75>/Constant6'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Regelabweichung =
        D_20231120_Modell_Inbetrieb_cal->Constant6_Value_c;
    }

    /* End of Switch: '<S75>/Switch2' */

    /* Product: '<S124>/PProd Out' incorporates:
     *  Constant: '<S75>/Constant1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PProdOut =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Regelabweichung *
      D_20231120_Modell_Inbetrieb_cal->Constant1_Value_i;

    /* Integrator: '<S119>/Integrator' */
    if (rtsiIsModeUpdateTimeStep
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      ZCEventType zcEvent;
      zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE_p,
                         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe));
      didZcEventOccur = (zcEvent != NO_ZCEVENT);

      /* evaluate zero-crossings and the level of the reset signal */
      if (didZcEventOccur ||
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe
           != 0.0)) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE_k
          = D_20231120_Modell_Inbetrieb_cal->PIDController_InitialConditionF;
      }
    }

    /* Integrator: '<S119>/Integrator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator_a =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE_k;

    /* Sum: '<S128>/Sum' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PProdOut +
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator_a;

    /* Saturate: '<S126>/Saturation' */
    lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum;
    u1 = D_20231120_Modell_Inbetrieb_cal->PIDController_LowerSaturationLi;
    u2 = D_20231120_Modell_Inbetrieb_cal->PIDController_UpperSaturationLi;
    if (lastTime > u2) {
      /* Saturate: '<S126>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S126>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i = u1;
    } else {
      /* Saturate: '<S126>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i =
        lastTime;
    }

    /* End of Saturate: '<S126>/Saturation' */

    /* Lookup_n-D: '<S75>/1-D Lookup Table4' incorporates:
     *  Saturate: '<S126>/Saturation'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.StellgrenachOffset =
      look1_binlxpw
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable4_bp01Data,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable4_tableData, 3U);

    /* Sum: '<S75>/Sum1' incorporates:
     *  Constant: '<S75>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum1 =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.StellgrenachOffset +
      D_20231120_Modell_Inbetrieb_cal->Constant_Value_pv;

    /* Saturate: '<S75>/Saturation3' */
    lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum1;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation3_LowerSat_k;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation3_UpperSat_e;
    if (lastTime > u2) {
      /* Saturate: '<S75>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_e = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S75>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_e = u1;
    } else {
      /* Saturate: '<S75>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_e =
        lastTime;
    }

    /* End of Saturate: '<S75>/Saturation3' */

    /* Switch: '<S10>/Switch' incorporates:
     *  Constant: '<Root>/Autonom_ON'
     */
    if (D_20231120_Modell_Inbetrieb_cal->Autonom_ON_Value >
        D_20231120_Modell_Inbetrieb_cal->Switch_Threshold_j) {
      /* Switch: '<S10>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_i;
    } else {
      /* MultiPortSwitch: '<S10>/Index Vector' incorporates:
       *  Constant: '<S10>/Constant'
       */
      switch (static_cast<int32_T>
              (D_20231120_Modell_Inbetrieb_cal->Constant_Value_o)) {
       case 0:
        /* MultiPortSwitch: '<S10>/Index Vector' incorporates:
         *  Constant: '<S10>/Constant2'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector =
          D_20231120_Modell_Inbetrieb_cal->Constant2_Value_o;
        break;

       case 1:
        /* MultiPortSwitch: '<S10>/Index Vector' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector1;
        break;

       default:
        /* MultiPortSwitch: '<S10>/Index Vector' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_e;
        break;
      }

      /* End of MultiPortSwitch: '<S10>/Index Vector' */

      /* Switch: '<S10>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IndexVector;
    }

    /* End of Switch: '<S10>/Switch' */

    /* RelationalOperator: '<S81>/Relational Operator' incorporates:
     *  Constant: '<S81>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o >
       D_20231120_Modell_Inbetrieb_cal->Constant_Value_f);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* SignalConversion generated from: '<S83>/Enable' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HiddenBuf_InsertedFor_EnabledSu
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator;
    }

    /* Outputs for Enabled SubSystem: '<S81>/Enabled Subsystem1' */
    D_20231120_EnabledSubsystem
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HiddenBuf_InsertedFor_EnabledSu,
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.EnabledSubsystem1,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.EnabledSubsystem1);

    /* End of Outputs for SubSystem: '<S81>/Enabled Subsystem1' */

    /* RateTransition: '<S78>/RT' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx =
          static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx ==
           0);
      }

      /* RateTransition: '<S78>/RT' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_i =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx];
    }

    /* End of RateTransition: '<S78>/RT' */

    /* Logic: '<S81>/Logical Operator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator_b =
      !D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* SignalConversion generated from: '<S82>/Enable' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HiddenBuf_InsertedFor_Enabled_m
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator_b;
    }

    /* Outputs for Enabled SubSystem: '<S81>/Enabled Subsystem' */
    D_20231120_EnabledSubsystem
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HiddenBuf_InsertedFor_Enabled_m,
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.EnabledSubsystem,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.EnabledSubsystem);

    /* End of Outputs for SubSystem: '<S81>/Enabled Subsystem' */

    /* RateTransition generated from: '<S78>/Switch' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_RdBufIdx
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_RdBufIdx
           == 0);
      }

      /* RateTransition generated from: '<S78>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport2
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_RdBufIdx];
    }

    /* End of RateTransition generated from: '<S78>/Switch' */

    /* Switch: '<S78>/Switch2' incorporates:
     *  Switch: '<S78>/Switch'
     */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator)
    {
      /* Switch: '<S78>/Switch1' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_i) {
        /* Switch: '<S78>/Switch1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cq =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.EnabledSubsystem1.Drehmomentsvorgabenormiert;
      } else {
        /* Switch: '<S78>/Switch1' incorporates:
         *  Constant: '<S78>/Constant1'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cq =
          D_20231120_Modell_Inbetrieb_cal->Constant1_Value_j;
      }

      /* End of Switch: '<S78>/Switch1' */

      /* Switch: '<S78>/Switch2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_d =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cq;
    } else {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport2)
      {
        /* Switch: '<S78>/Switch' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_fo =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.EnabledSubsystem.Drehmomentsvorgabenormiert;
      } else {
        /* Switch: '<S78>/Switch' incorporates:
         *  Constant: '<S78>/Constant1'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_fo =
          D_20231120_Modell_Inbetrieb_cal->Constant1_Value_j;
      }

      /* Switch: '<S78>/Switch2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_d =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_fo;
    }

    /* End of Switch: '<S78>/Switch2' */

    /* InitialCondition: '<S78>/IC1' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_n
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_n
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_n
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S78>/IC1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d =
        D_20231120_Modell_Inbetrieb_cal->IC1_Value_a;
    } else {
      /* InitialCondition: '<S78>/IC1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_d;
    }

    /* End of InitialCondition: '<S78>/IC1' */

    /* Saturate: '<S77>/Saturation1' */
    lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation1_LowerSat_o;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation1_UpperSat_j;
    if (lastTime > u2) {
      /* Saturate: '<S77>/Saturation1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S77>/Saturation1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u1;
    } else {
      /* Saturate: '<S77>/Saturation1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 =
        lastTime;
    }

    /* End of Saturate: '<S77>/Saturation1' */

    /* Sum: '<S10>/Sum' incorporates:
     *  Constant: '<S10>/Constant5'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_m =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 -
      D_20231120_Modell_Inbetrieb_cal->Constant5_Value_o;

    /* Lookup_n-D: '<S10>/1-D Lookup Table' incorporates:
     *  Sum: '<S10>/Sum'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_a =
      look1_binlxpw(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_m,
                    D_20231120_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_m,
                    D_20231120_Modell_Inbetrieb_cal->uDLookupTable_tableData_d,
                    1U);

    /* InitialCondition: '<S10>/IC2' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_n
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_n
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_n
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S10>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_g =
        D_20231120_Modell_Inbetrieb_cal->IC2_Value_j;
    } else {
      /* InitialCondition: '<S10>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_a;
    }

    /* End of InitialCondition: '<S10>/IC2' */

    /* Bias: '<S10>/Bias' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_1_G =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_g +
      D_20231120_Modell_Inbetrieb_cal->Bias_Bias;

    /* Lookup_n-D: '<S10>/1-D Lookup Table1' incorporates:
     *  Sum: '<S10>/Sum'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1_i =
      look1_binlxpw(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_m,
                    D_20231120_Modell_Inbetrieb_cal->uDLookupTable1_bp01Data_c,
                    D_20231120_Modell_Inbetrieb_cal->uDLookupTable1_tableData_c,
                    1U);

    /* InitialCondition: '<S10>/IC3' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S10>/IC3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3_l =
        D_20231120_Modell_Inbetrieb_cal->IC3_Value_h;
    } else {
      /* InitialCondition: '<S10>/IC3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3_l =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1_i;
    }

    /* End of InitialCondition: '<S10>/IC3' */

    /* Bias: '<S10>/Bias1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_2_G =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3_l +
      D_20231120_Modell_Inbetrieb_cal->Bias1_Bias_f;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* S-Function (sg_IO191_da_s): '<S6>/Analog output ' */

      /* Level2 S-Function Block: '<S6>/Analog output ' (sg_IO191_da_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[6];
        sfcnOutputs(rts,0);
      }
    }

    /* Gain: '<S5>/Gain6' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_1_On =
      D_20231120_Modell_Inbetrieb_cal->Gain6_Gain_f *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

    /* Gain: '<S5>/Gain7' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_2_On =
      D_20231120_Modell_Inbetrieb_cal->Gain7_Gain_b *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

    /* Gain: '<S5>/Gain8' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_1_On =
      D_20231120_Modell_Inbetrieb_cal->Gain8_Gain_f *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

    /* Gain: '<S5>/Gain9' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_2_On =
      D_20231120_Modell_Inbetrieb_cal->Gain9_Gain_m *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Constant: '<S5>/Constant8' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Br_Licht_On =
        D_20231120_Modell_Inbetrieb_cal->Constant8_Value;

      /* Constant: '<S6>/Constant' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant =
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_hc;

      /* S-Function (sg_IO191_do_s): '<S6>/Digital output ' */

      /* Level2 S-Function Block: '<S6>/Digital output ' (sg_IO191_do_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[7];
        sfcnOutputs(rts,0);
      }

      /* S-Function (sg_IO291_setup_s): '<S7>/Setup ' */

      /* Level2 S-Function Block: '<S7>/Setup ' (sg_IO291_setup_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[8];
        sfcnOutputs(rts,0);
      }

      /* Constant: '<S7>/Alive' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Alive =
        D_20231120_Modell_Inbetrieb_cal->Alive_Value;

      /* Gain: '<S7>/Gain2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH3_Brmslcht
        = D_20231120_Modell_Inbetrieb_cal->Gain2_Gain_a *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o3;

      /* RateTransition generated from: '<S1>/Switch' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufI_gy
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufI_gy
           == 0);
      }

      /* RateTransition generated from: '<S1>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_iu
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_eu
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufI_gy];
    }

    /* Switch: '<S1>/Switch' incorporates:
     *  Constant: '<Root>/Autonom_ON'
     */
    if (D_20231120_Modell_Inbetrieb_cal->Autonom_ON_Value >
        D_20231120_Modell_Inbetrieb_cal->Switch_Threshold_o) {
      /* Switch: '<S1>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_p =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_iu;
    } else {
      /* Switch: '<S1>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_p =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal;
    }

    /* End of Switch: '<S1>/Switch' */

    /* Saturate: '<S1>/Saturation3' */
    lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_p;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation3_LowerSat_j;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation3_UpperSat_i;
    if (lastTime > u2) {
      /* Saturate: '<S1>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S1>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j = u1;
    } else {
      /* Saturate: '<S1>/Saturation3' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j =
        lastTime;
    }

    /* End of Saturate: '<S1>/Saturation3' */

    /* Gain: '<S1>/Gain -1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremssignal =
      D_20231120_Modell_Inbetrieb_cal->Gain1_Gain_h *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j;

    /* RelationalOperator: '<S23>/Compare' incorporates:
     *  Constant: '<S23>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_d =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremssignal >
       D_20231120_Modell_Inbetrieb_cal->CompareToConstant6_const);

    /* Lookup_n-D: '<S16>/1-D Lookup Table' incorporates:
     *  Gain: '<S1>/Gain -1'
     */
    bpIdx = plook_u32d_binckan
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremssignal,
       D_20231120_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_n, 4U);

    /* Lookup_n-D: '<S16>/1-D Lookup Table' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_j =
      D_20231120_Modell_Inbetrieb_cal->uDLookupTable_tableData_e[bpIdx];
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* S-Function (sg_fpga_di_sf_a2): '<S8>/Digital input' */

      /* Level2 S-Function Block: '<S8>/Digital input' (sg_fpga_di_sf_a2) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[9];
        sfcnOutputs(rts,0);
      }

      /* Gain: '<S8>/Gain' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch8_Bremsaktuator_Hall
        = D_20231120_Modell_Inbetrieb_cal->Gain_Gain_g *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1_p;

      /* SignalConversion generated from: '<S14>/Vector Concatenate' incorporates:
       *  Concatenate: '<S14>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
        [0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch8_Bremsaktuator_Hall;

      /* S-Function (sfix_udelay): '<S14>/Tapped Delay' incorporates:
       *  Concatenate: '<S14>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
        [1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[0];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
        [2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
        [3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
        [4] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3];

      /* Sum: '<S14>/Sum of Elements' */
      lastTime = -0.0;
      for (int32_T i = 0; i < 5; i++) {
        lastTime +=
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
          [i];
      }

      /* Sum: '<S14>/Sum of Elements' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_f =
        lastTime;

      /* Product: '<S14>/Divide' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_l =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_f /
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width;

      /* Rounding: '<S14>/Round' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round =
        rt_roundd_snf
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_l);

      /* DataTypeConversion: '<S28>/Data Type Conversion' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round;

      /* Gain: '<S8>/Gain1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch9_Bremsaktuator_Hall
        = D_20231120_Modell_Inbetrieb_cal->Gain1_Gain_c *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2_b;

      /* SignalConversion generated from: '<S15>/Vector Concatenate' incorporates:
       *  Concatenate: '<S15>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
        [0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch9_Bremsaktuator_Hall;

      /* S-Function (sfix_udelay): '<S15>/Tapped Delay' incorporates:
       *  Concatenate: '<S15>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
        [1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[0];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
        [2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
        [3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
        [4] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3];

      /* Sum: '<S15>/Sum of Elements' */
      lastTime = -0.0;
      for (int32_T i = 0; i < 5; i++) {
        lastTime +=
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
          [i];
      }

      /* Sum: '<S15>/Sum of Elements' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_g =
        lastTime;

      /* Product: '<S15>/Divide' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_e =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_g /
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_d;

      /* Rounding: '<S15>/Round' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round_m =
        rt_roundd_snf
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_e);

      /* DataTypeConversion: '<S28>/Data Type Conversion1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round_m;

      /* State Transition Table: '<S28>/State Transition Table' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.sfEvent =
        D_20231120_Modell_In_CALL_EVENT;
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_active_c4_D_20231120_Modell_
          == 0U) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_active_c4_D_20231120_Modell_
          = 1U;
        if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
             == 0.0) &&
            (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
             == 0.0)) {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
            = D_20231120_Modell__IN_state_0_0;
        } else if
            ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
            = D_20231120_Modell__IN_state_1_0;
        } else if
            ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
            = D_20231120_Modell__IN_state_1_1;
        } else {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
            = D_20231120_Modell__IN_state_0_1;
        }
      } else {
        switch
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri)
        {
         case D_20231120_Modell__IN_state_0_0:
          if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
               == 1.0) &&
              (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
               == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_0;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 0.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_1;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 0.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_0;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 1.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_1;
          }
          break;

         case D_20231120_Modell__IN_state_0_1:
          if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
               == 0.0) &&
              (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
               == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_0;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 1.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_1;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 0.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_1;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 1.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_0;
          }
          break;

         case D_20231120_Modell__IN_state_1_0:
          if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
               == 1.0) &&
              (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
               == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_1;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 0.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_0;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 1.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_0;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 0.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_1;
          }
          break;

         default:
          /* case IN_state_1_1: */
          if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
               == 0.0) &&
              (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
               == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_1;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 1.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              1.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_0;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 1.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 1.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_1_1;
          } else if
              ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
                == 0.0) &&
               (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
                == 0.0)) {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
              0.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir =
              2.0;
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
              = D_20231120_Modell__IN_state_0_0;
          }
          break;
        }
      }

      /* End of State Transition Table: '<S28>/State Transition Table' */

      /* RelationalOperator: '<S35>/Compare' incorporates:
       *  Constant: '<S35>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_f =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir ==
         D_20231120_Modell_Inbetrieb_cal->Constant_Value_n);

      /* UnitDelay: '<S16>/Unit Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_c =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_c;

      /* RelationalOperator: '<S20>/Compare' incorporates:
       *  Constant: '<S20>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_ig = (
        static_cast<int32_T>
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_c) >
        static_cast<int32_T>
        (D_20231120_Modell_Inbetrieb_cal->CompareToConstant2_const_a));
    }

    /* RelationalOperator: '<S19>/Compare' incorporates:
     *  Constant: '<S19>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_i =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremssignal >
       D_20231120_Modell_Inbetrieb_cal->CompareToConstant1_const_o);

    /* Logic: '<S16>/OR' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_i ||
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_ig);

    /* Switch: '<S16>/Switch' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR) {
      /* Switch: '<S16>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_f =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable;
    } else {
      /* Switch: '<S16>/Switch' incorporates:
       *  Constant: '<S16>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_f =
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_eq;
    }

    /* End of Switch: '<S16>/Switch' */

    /* RelationalOperator: '<S34>/Compare' incorporates:
     *  Constant: '<S34>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fa =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_f >
       D_20231120_Modell_Inbetrieb_cal->Constant_Value_a);

    /* Logic: '<S26>/AND6' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND6 =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_f &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fa);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* RelationalOperator: '<S33>/Compare' incorporates:
       *  Constant: '<S33>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_o =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir ==
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant5_const);

      /* UnitDelay: '<S26>/Unit Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay1_DSTATE;

      /* UnitDelay: '<S26>/Unit Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE;

      /* Switch: '<S26>/Switch2' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay1) {
        /* Switch: '<S26>/Switch2' incorporates:
         *  Constant: '<S26>/Constant3'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_f =
          D_20231120_Modell_Inbetrieb_cal->Constant3_Value;
      } else {
        /* Switch: '<S26>/Switch2' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_f =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay;
      }

      /* End of Switch: '<S26>/Switch2' */
    }

    /* Switch: '<S26>/Switch1' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND6) {
      /* Switch: '<S26>/Switch1' incorporates:
       *  Constant: '<S26>/Constant2'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_c =
        D_20231120_Modell_Inbetrieb_cal->Constant2_Value_l;
    } else {
      /* Logic: '<S26>/AND5' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND5 =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_o &&
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fa);

      /* Switch: '<S26>/Switch' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND5) {
        /* Switch: '<S26>/Switch' incorporates:
         *  Constant: '<S26>/Constant'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oi =
          D_20231120_Modell_Inbetrieb_cal->Constant_Value_ai;
      } else {
        /* Switch: '<S26>/Switch' incorporates:
         *  Constant: '<S26>/Constant1'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oi =
          D_20231120_Modell_Inbetrieb_cal->Constant1_Value_f;
      }

      /* End of Switch: '<S26>/Switch' */

      /* Switch: '<S26>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_c =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oi;
    }

    /* End of Switch: '<S26>/Switch1' */

    /* Sum: '<S26>/Add' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_c +
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_f;

    /* Sum: '<S16>/Add' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_a =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add -
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_j;

    /* RelationalOperator: '<S24>/Compare' incorporates:
     *  Constant: '<S24>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fx =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_a <=
       D_20231120_Modell_Inbetrieb_cal->CompareToConstant7_const);

    /* Logic: '<S16>/AND7' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7 =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_d &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fx);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Delay: '<S17>/Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE;

      /* RelationalOperator: '<S29>/Compare' incorporates:
       *  Constant: '<S29>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hi =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1 ==
         D_20231120_Modell_Inbetrieb_cal->Constant_Value_k);
    }

    /* Switch: '<S17>/Switch1' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hi) {
      /* Switch: '<S17>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_h =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7;
    } else {
      /* Switch: '<S17>/Switch1' incorporates:
       *  Constant: '<S17>/Constant1'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_h =
        D_20231120_Modell_Inbetrieb_cal->Constant1_Value_m;
    }

    /* End of Switch: '<S17>/Switch1' */

    /* InitialCondition: '<S16>/IC1' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S16>/IC1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_di =
        D_20231120_Modell_Inbetrieb_cal->IC1_Value_m;
    } else {
      /* InitialCondition: '<S16>/IC1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_di =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_h;
    }

    /* End of InitialCondition: '<S16>/IC1' */

    /* Logic: '<S1>/AND3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_1 =
      ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe !=
        0.0) && (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_di !=
                 0.0));

    /* DataTypeConversion: '<S7>/Data Type Conversion' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_g =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_1;

    /* RelationalOperator: '<S21>/Compare' incorporates:
     *  Constant: '<S21>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_c =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_a >
       D_20231120_Modell_Inbetrieb_cal->CompareToConstant3_const_k);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* RelationalOperator: '<S25>/Compare' incorporates:
       *  Constant: '<S25>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_co =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH3_Brmslcht
         > D_20231120_Modell_Inbetrieb_cal->Constant_Value_d);

      /* Delay: '<S18>/Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_n =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_o;

      /* RelationalOperator: '<S31>/Compare' incorporates:
       *  Constant: '<S31>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_dk =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_n ==
         D_20231120_Modell_Inbetrieb_cal->Constant_Value_h);
    }

    /* Logic: '<S16>/AND8' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND8 =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_c &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_co);

    /* RelationalOperator: '<S22>/Compare' incorporates:
     *  Constant: '<S22>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_cr =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremssignal <
       D_20231120_Modell_Inbetrieb_cal->CompareToConstant4_const_k);

    /* Logic: '<S16>/AND1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1 =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_cr &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_co);

    /* Logic: '<S16>/AND2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND8 ||
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1);

    /* Switch: '<S18>/Switch1' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_dk) {
      /* Switch: '<S18>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_j =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;
    } else {
      /* Switch: '<S18>/Switch1' incorporates:
       *  Constant: '<S18>/Constant1'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_j =
        D_20231120_Modell_Inbetrieb_cal->Constant1_Value_pm;
    }

    /* End of Switch: '<S18>/Switch1' */

    /* InitialCondition: '<S16>/IC2' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S16>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_e =
        D_20231120_Modell_Inbetrieb_cal->IC2_Value_n;
    } else {
      /* InitialCondition: '<S16>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_e =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_j;
    }

    /* End of InitialCondition: '<S16>/IC2' */

    /* Logic: '<S1>/AND4' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_2 =
      ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe !=
        0.0) && (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_e !=
                 0.0));

    /* DataTypeConversion: '<S7>/Data Type Conversion1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_c =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_2;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Constant: '<S5>/Constant13' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Reverse =
        D_20231120_Modell_Inbetrieb_cal->Constant13_Value;

      /* DiscretePulseGenerator: '<S49>/Pulse Generator' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PulseGenerator =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter
         < D_20231120_Modell_Inbetrieb_cal->PulseGenerator_Duty) &&
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter
         >= 0) ? D_20231120_Modell_Inbetrieb_cal->PulseGenerator_Amp : 0.0;

      /* DiscretePulseGenerator: '<S49>/Pulse Generator' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter
          >= D_20231120_Modell_Inbetrieb_cal->PulseGenerator_Period - 1.0) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter =
          0;
      } else {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter
          ++;
      }
    }

    /* Switch: '<S49>/Switch1' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_p) {
      /* RelationalOperator: '<S66>/Compare' incorporates:
       *  Constant: '<S66>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hy =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator <
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant2_const);

      /* Switch: '<S49>/Switch' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hy) {
        /* Switch: '<S49>/Switch' incorporates:
         *  Constant: '<S49>/Constant'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_jr =
          D_20231120_Modell_Inbetrieb_cal->Constant_Value_ph;
      } else {
        /* Switch: '<S49>/Switch' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_jr =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PulseGenerator;
      }

      /* End of Switch: '<S49>/Switch' */

      /* Switch: '<S49>/Switch1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_m =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_jr;
    } else {
      /* Switch: '<S49>/Switch1' incorporates:
       *  Constant: '<S49>/Constant1'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_m =
        D_20231120_Modell_Inbetrieb_cal->Constant1_Value_ns;
    }

    /* End of Switch: '<S49>/Switch1' */

    /* Gain: '<S5>/Gain4' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LED_Totmann =
      D_20231120_Modell_Inbetrieb_cal->Gain4_Gain_i *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_m;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* S-Function (sg_IO291_do_fet_s): '<S7>/FET digital output ' */

      /* Level2 S-Function Block: '<S7>/FET digital output ' (sg_IO291_do_fet_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[10];
        sfcnOutputs(rts,0);
      }

      /* S-Function (sg_IO291_di_ttl_s): '<S7>/LVTTL digital input ' */

      /* Level2 S-Function Block: '<S7>/LVTTL digital input ' (sg_IO291_di_ttl_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[11];
        sfcnOutputs(rts,0);
      }

      /* S-Function (sg_IO291_do_ttl_s): '<S7>/LVTTL digital output ' */

      /* Level2 S-Function Block: '<S7>/LVTTL digital output ' (sg_IO291_do_ttl_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[12];
        sfcnOutputs(rts,0);
      }

      /* S-Function (sg_IO602_IO691_setup_s): '<S9>/CAN Setup ' */

      /* Level2 S-Function Block: '<S9>/CAN Setup ' (sg_IO602_IO691_setup_s) */
      {
        SimStruct *rts =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
          childSfunctions[13];
        sfcnOutputs(rts,0);
      }

      /* Bias: '<S17>/Bias' */
      lastTime = -tmp;

      /* Bias: '<S17>/Bias' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1 + lastTime;

      /* UnitDelay: '<S30>/Delay Input1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE;

      /* Saturate: '<S17>/Saturation' */
      lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias;
      u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_j3;
      u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_j;
      if (lastTime > u2) {
        /* Saturate: '<S17>/Saturation' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_io = u2;
      } else if (lastTime < u1) {
        /* Saturate: '<S17>/Saturation' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_io = u1;
      } else {
        /* Saturate: '<S17>/Saturation' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_io =
          lastTime;
      }

      /* End of Saturate: '<S17>/Saturation' */
    }

    /* RelationalOperator: '<S30>/FixPt Relational Operator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator
      = (static_cast<int32_T>
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7) >
         static_cast<int32_T>
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1));

    /* Switch: '<S17>/Switch' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator)
    {
      /* Switch: '<S17>/Switch' incorporates:
       *  Constant: '<S17>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oz =
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_kc;
    } else {
      /* Switch: '<S17>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oz =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_io;
    }

    /* End of Switch: '<S17>/Switch' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Bias: '<S18>/Bias' */
      lastTime = -tmp;

      /* Bias: '<S18>/Bias' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_n =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_n +
        lastTime;

      /* UnitDelay: '<S32>/Delay Input1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_e =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_b;

      /* Saturate: '<S18>/Saturation' */
      lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_n;
      u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_n;
      u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_k;
      if (lastTime > u2) {
        /* Saturate: '<S18>/Saturation' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g = u2;
      } else if (lastTime < u1) {
        /* Saturate: '<S18>/Saturation' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g = u1;
      } else {
        /* Saturate: '<S18>/Saturation' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g =
          lastTime;
      }

      /* End of Saturate: '<S18>/Saturation' */
    }

    /* RelationalOperator: '<S32>/FixPt Relational Operator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_p
      = (static_cast<int32_T>
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m) >
         static_cast<int32_T>
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_e));

    /* Switch: '<S18>/Switch' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_p)
    {
      /* Switch: '<S18>/Switch' incorporates:
       *  Constant: '<S18>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_g =
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_f3;
    } else {
      /* Switch: '<S18>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g;
    }

    /* End of Switch: '<S18>/Switch' */

    /* Clock: '<S37>/Clock' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Clock =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* DataTypeConversion: '<S36>/Data Type Conversion2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Memory: '<S36>/Memory' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_p =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_o;

      /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
       *  Constant: '<S36>/Constant1'
       */
      switch (static_cast<int32_T>
              (D_20231120_Modell_Inbetrieb_cal->EdgeDetector_model)) {
       case 1:
        /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
         *  Constant: '<S36>/pos. edge'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[0]
          = D_20231120_Modell_Inbetrieb_cal->posedge_Value[0];
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1]
          = D_20231120_Modell_Inbetrieb_cal->posedge_Value[1];
        break;

       case 2:
        /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
         *  Constant: '<S36>/neg. edge'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[0]
          = D_20231120_Modell_Inbetrieb_cal->negedge_Value[0];
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1]
          = D_20231120_Modell_Inbetrieb_cal->negedge_Value[1];
        break;

       default:
        /* MultiPortSwitch: '<S36>/Multiport Switch' incorporates:
         *  Constant: '<S36>/either edge'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[0]
          = D_20231120_Modell_Inbetrieb_cal->eitheredge_Value[0];
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1]
          = D_20231120_Modell_Inbetrieb_cal->eitheredge_Value[1];
        break;
      }

      /* End of MultiPortSwitch: '<S36>/Multiport Switch' */

      /* Outputs for Enabled SubSystem: '<S36>/POSITIVE Edge' incorporates:
       *  EnablePort: '<S39>/Enable'
       */
      if (rtsiIsModeUpdateTimeStep
          (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo))
      {
        if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch
            [0] > 0.0) {
          if (!D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE)
          {
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE
              = true;
          }
        } else if
            (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE)
        {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE
            = false;
        }
      }

      /* End of Outputs for SubSystem: '<S36>/POSITIVE Edge' */
    }

    /* Outputs for Enabled SubSystem: '<S36>/POSITIVE Edge' incorporates:
     *  EnablePort: '<S39>/Enable'
     */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE)
    {
      /* RelationalOperator: '<S39>/Relational Operator1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_g
        = (static_cast<int32_T>
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_p) <
           static_cast<int32_T>
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i));
      if (rtsiIsModeUpdateTimeStep
          (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo))
      {
        srUpdateBC
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_SubsysRanBC);
      }
    }

    /* End of Outputs for SubSystem: '<S36>/POSITIVE Edge' */

    /* Outputs for Enabled SubSystem: '<S36>/NEGATIVE Edge' incorporates:
     *  EnablePort: '<S38>/Enable'
     */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
        && rtsiIsModeUpdateTimeStep
        (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch
          [1] > 0.0) {
        if (!D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE)
        {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE
            = true;
        }
      } else if
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE)
      {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE
          = false;
      }
    }

    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE)
    {
      /* RelationalOperator: '<S38>/Relational Operator1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_c
        = (static_cast<int32_T>
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_p) >
           static_cast<int32_T>
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i));
      if (rtsiIsModeUpdateTimeStep
          (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo))
      {
        srUpdateBC
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_SubsysRanBC);
      }
    }

    /* End of Outputs for SubSystem: '<S36>/NEGATIVE Edge' */

    /* Logic: '<S36>/Logical Operator1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_g
       ||
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_c);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Outputs for Triggered SubSystem: '<S37>/Triggered Subsystem' incorporates:
       *  TriggerPort: '<S40>/Trigger'
       */
      if (rtsiIsModeUpdateTimeStep
          (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo))
      {
        didZcEventOccur =
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h
           &&
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.TriggeredSubsystem_Trig_ZCE
            != POS_ZCSIG));
        if (didZcEventOccur) {
          /* SignalConversion generated from: '<S40>/In1' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.In1 =
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Clock;
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TriggeredSubsystem_SubsysRanBC
            = 4;
        }

        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.TriggeredSubsystem_Trig_ZCE
          =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h;
      }

      /* End of Outputs for SubSystem: '<S37>/Triggered Subsystem' */

      /* Sum: '<S37>/Sum' incorporates:
       *  Constant: '<S37>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_j =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.In1 +
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_l;
    }

    /* RelationalOperator: '<S37>/Relational Operator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator_a =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_j >
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Clock);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* RateTransition generated from: '<S4>/Lenkradwinkel' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_R
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_R
           == 0);
      }

      /* RateTransition generated from: '<S4>/Lenkradwinkel' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelOutport1
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_B
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_R];

      /* RateTransition generated from: '<S4>/Lenkradwinkelgeschwindigkeit' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_p
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_p
           == 0);
      }

      /* RateTransition generated from: '<S4>/Lenkradwinkelgeschwindigkeit' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwindi
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_p];

      /* RateTransition generated from: '<S4>/Derivative' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdBuf
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdBuf
           == 0);
      }

      /* RateTransition generated from: '<S4>/Derivative' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdBuf];
    }

    /* Derivative: '<S4>/Derivative' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA >=
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]) &&
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB >=
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
      /* Derivative: '<S4>/Derivative' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Derivative = 0.0;
    } else {
      lastTime =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA;
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeA;
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA <
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB) {
        if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB <
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])
        {
          lastTime =
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB;
          lastU =
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB;
        }
      } else if
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA >=
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]) {
        lastTime =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB;
        lastU =
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB;
      }

      lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
        Timing.t[0] - lastTime;

      /* Derivative: '<S4>/Derivative' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Derivative =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel -
         *lastU) / lastTime;
    }

    /* End of Derivative: '<S4>/Derivative' */

    /* MATLAB Function: '<S4>/Lenkradwinkelgeschwindigkeit' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
         > 0.0) &&
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
         <= 5.0)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitLenkradwinkel_OK
        = (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Derivative <
           -200.0 *
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
           + 3500.0);
    } else if
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
          > 5.0) &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
          <= 15.0)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitLenkradwinkel_OK
        = (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Derivative <
           2500.0);
    } else if
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
          > 15.0) &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
          <= 25.0)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitLenkradwinkel_OK
        = (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Derivative <
           -150.0 *
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
           + 4750.0);
    } else {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitLenkradwinkel_OK
        =
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
          > 25.0) &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
          <= 45.0) &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Derivative <
          1000.0));
    }

    /* End of MATLAB Function: '<S4>/Lenkradwinkelgeschwindigkeit' */

    /* RateTransition generated from: '<S4>/Fahrzeuggeschwindigkeit' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigkeit
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigkeit
           == 0);
      }

      /* RateTransition generated from: '<S4>/Fahrzeuggeschwindigkeit' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtFahrzeuggeschwindigkeit
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_k
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigkeit];
    }

    /* End of RateTransition generated from: '<S4>/Fahrzeuggeschwindigkeit' */

    /* Logic: '<S4>/AND' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_i =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelOutport1
       &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitLenkradwinkel_OK
       &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtFahrzeuggeschwindigkeit);

    /* InitialCondition: '<S4>/IC2' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_ny
         == (rtMinusInf)) ||
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_ny
         == D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]))
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_ny
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

      /* InitialCondition: '<S4>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_j =
        D_20231120_Modell_Inbetrieb_cal->IC2_Value_e;
    } else {
      /* InitialCondition: '<S4>/IC2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_j =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_i;
    }

    /* End of InitialCondition: '<S4>/IC2' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Delay: '<S50>/Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_a =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_p;

      /* RelationalOperator: '<S56>/Compare' incorporates:
       *  Constant: '<S56>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j5 =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_a ==
         D_20231120_Modell_Inbetrieb_cal->Constant_Value_g);

      /* UnitDelay: '<S57>/Delay Input1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_k =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_j;

      /* SignalConversion generated from: '<S54>/Vector Concatenate' incorporates:
       *  Concatenate: '<S54>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
        [0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH14_Freigabe_Taster;

      /* S-Function (sfix_udelay): '<S54>/Tapped Delay1' incorporates:
       *  Concatenate: '<S54>/Vector Concatenate'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
        [1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [0];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
        [2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
        [3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
        [4] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [3];

      /* Sum: '<S54>/Sum of Elements' */
      lastTime = -0.0;
      for (int32_T i = 0; i < 5; i++) {
        lastTime +=
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
          [i];
      }

      /* Sum: '<S54>/Sum of Elements' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_fw =
        lastTime;

      /* Product: '<S54>/Divide' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_fw /
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_m;

      /* RelationalOperator: '<S63>/Compare' incorporates:
       *  Constant: '<S63>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_g ==
         D_20231120_Modell_Inbetrieb_cal->CompareToConstant_const_j);

      /* RelationalOperator: '<S57>/FixPt Relational Operator' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_c
        = (static_cast<int32_T>
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on) >
           static_cast<int32_T>
           (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_k));

      /* Switch: '<S50>/Switch' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_c)
      {
        /* Switch: '<S50>/Switch' incorporates:
         *  Constant: '<S50>/Constant'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_k =
          D_20231120_Modell_Inbetrieb_cal->Constant_Value_e;
      } else {
        /* Bias: '<S50>/Bias' */
        lastTime = -tmp;

        /* Bias: '<S50>/Bias' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_nf =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_a +
          lastTime;

        /* Saturate: '<S50>/Saturation' */
        lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_nf;
        u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_o;
        u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_a;
        if (lastTime > u2) {
          /* Saturate: '<S50>/Saturation' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz =
            u2;
        } else if (lastTime < u1) {
          /* Saturate: '<S50>/Saturation' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz =
            u1;
        } else {
          /* Saturate: '<S50>/Saturation' */
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz =
            lastTime;
        }

        /* End of Saturate: '<S50>/Saturation' */

        /* Switch: '<S50>/Switch' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_k =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz;
      }

      /* End of Switch: '<S50>/Switch' */

      /* Switch: '<S50>/Switch1' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j5) {
        /* Switch: '<S50>/Switch1' */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on;
      } else {
        /* Switch: '<S50>/Switch1' incorporates:
         *  Constant: '<S50>/Constant1'
         */
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc =
          D_20231120_Modell_Inbetrieb_cal->Constant1_Value_p;
      }

      /* End of Switch: '<S50>/Switch1' */
    }

    /* Logic: '<S48>/NOT' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.NOT =
      !D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2;

    /* Logic: '<S48>/OR' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR_j =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.NOT ||
       (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc != 0.0));

    /* Logic: '<S48>/AND' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_n =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR_j &&
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory);
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Memory: '<S48>/Memory1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory1 =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory1_PreviousInput;

      /* Logic: '<S48>/AND1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1_a =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory1 &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc !=
          0.0));

      /* Memory: '<S55>/Memory' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_b =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_d;
    }

    /* CombinatorialLogic: '<S55>/Logic' */
    didZcEventOccur =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1_a;
    bpIdx = didZcEventOccur;
    didZcEventOccur =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_n;
    bpIdx = (bpIdx << 1) + didZcEventOccur;
    didZcEventOccur =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_b;
    bpIdx = (bpIdx << 1) + didZcEventOccur;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[0U] =
      D_20231120_Modell_Inbetrieb_cal->Logic_table[bpIdx];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[1U] =
      D_20231120_Modell_Inbetrieb_cal->Logic_table[bpIdx + 8U];
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Product: '<S8>/Divide' incorporates:
       *  Constant: '<S8>/Constant1'
       *  Constant: '<S8>/Gear Ratio'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_h =
        D_20231120_Modell_Inbetrieb_cal->Constant1_Value_g /
        D_20231120_Modell_Inbetrieb_cal->GearRatio_Value;

      /* Product: '<S8>/Divide1' incorporates:
       *  Constant: '<S8>/Constant2'
       *  Constant: '<S8>/Gear Ratio'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1 =
        D_20231120_Modell_Inbetrieb_cal->Constant2_Value_k /
        D_20231120_Modell_Inbetrieb_cal->GearRatio_Value;

      /* Gain: '<S8>/Gain4' incorporates:
       *  Constant: '<S8>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_QAD_Position =
        D_20231120_Modell_Inbetrieb_cal->Gain4_Gain_cp *
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_ov;

      /* Gain: '<S8>/Gain5' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_QAD_Turns =
        D_20231120_Modell_Inbetrieb_cal->Gain5_Gain_o *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_h;

      /* Gain: '<S8>/Gain6' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_QAD_rpm =
        D_20231120_Modell_Inbetrieb_cal->Gain6_Gain_e *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1;

      /* RateTransition generated from: '<S79>/Derivative' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdB_e
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdB_e
           == 0);
      }

      /* RateTransition generated from: '<S79>/Derivative' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtDerivativeInport1
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_Buf_a
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdB_e];
    }

    /* Derivative: '<S79>/Derivative' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a >=
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]) &&
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g >=
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
      /* Derivative: '<S79>/Derivative' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkradwinkelGeschwindigkeit
        = 0.0;
    } else {
      lastTime =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a;
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeA_a;
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a <
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g) {
        if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g <
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])
        {
          lastTime =
            D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g;
          lastU =
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB_o;
        }
      } else if
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a >=
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0]) {
        lastTime =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g;
        lastU =
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB_o;
      }

      lastTime = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
        Timing.t[0] - lastTime;

      /* Derivative: '<S79>/Derivative' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkradwinkelGeschwindigkeit
        =
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtDerivativeInport1
         - *lastU) / lastTime;
    }

    /* End of Derivative: '<S79>/Derivative' */

    /* RateTransition generated from: '<S79>/MATLAB Function1' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_p
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_p
           == 0);
      }

      /* RateTransition generated from: '<S79>/MATLAB Function1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport2_
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_p];
    }

    /* End of RateTransition generated from: '<S79>/MATLAB Function1' */

    /* MATLAB Function: '<S79>/MATLAB Function1' */
    if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
         > 0.0) &&
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
         <= 5.0)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkDrehmomentMaxNomiert
        = -0.04 *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkradwinkelGeschwindigkeit
        + 0.8;
    } else if
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
          > 5.0) &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
          <= 15.0)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkDrehmomentMaxNomiert
        = 0.59952038369304561;
    } else if
        ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
          > 15.0) &&
         (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
          <= 25.0)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkDrehmomentMaxNomiert
        = -0.02 *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkradwinkelGeschwindigkeit
        + 0.9;
    } else if
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
         > 25.0) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkDrehmomentMaxNomiert
        = 0.4;
    } else {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkDrehmomentMaxNomiert
        = 0.0;
    }

    /* End of MATLAB Function: '<S79>/MATLAB Function1' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
    }

    /* Saturate: '<S77>/Saturation' */
    lastTime =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LenkDrehmomentMaxNomiert;
    u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_m;
    u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_p;
    if (lastTime > u2) {
      /* Saturate: '<S77>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i2 = u2;
    } else if (lastTime < u1) {
      /* Saturate: '<S77>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i2 = u1;
    } else {
      /* Saturate: '<S77>/Saturation' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i2 =
        lastTime;
    }

    /* End of Saturate: '<S77>/Saturation' */

    /* RelationalOperator: '<S80>/LowerRelop1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LowerRelop1 =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d >
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i2);

    /* RelationalOperator: '<S80>/UpperRelop' incorporates:
     *  Constant: '<S77>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UpperRelop =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d <
       D_20231120_Modell_Inbetrieb_cal->Constant_Value_h3);

    /* Switch: '<S80>/Switch' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UpperRelop) {
      /* Switch: '<S80>/Switch' incorporates:
       *  Constant: '<S77>/Constant'
       */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_d =
        D_20231120_Modell_Inbetrieb_cal->Constant_Value_h3;
    } else {
      /* Switch: '<S80>/Switch' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_d =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d;
    }

    /* End of Switch: '<S80>/Switch' */

    /* Switch: '<S80>/Switch2' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LowerRelop1) {
      /* Switch: '<S80>/Switch2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i2;
    } else {
      /* Switch: '<S80>/Switch2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_d;
    }

    /* End of Switch: '<S80>/Switch2' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
    }

    /* Product: '<S116>/IProd Out' incorporates:
     *  Constant: '<S75>/Constant5'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IProdOut =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Regelabweichung *
      D_20231120_Modell_Inbetrieb_cal->Constant5_Value_b;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* RateTransition: '<S11>/Rate Transition2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m;
    }

    /* Logic: '<Root>/OR' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR_k =
      !D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_j;

    /* RateTransition generated from: '<S12>/Transfer Fcn1' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB
           == 0);
      }

      /* RateTransition generated from: '<S12>/Transfer Fcn1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB];

      /* RateTransition generated from: '<S12>/Transfer Fcn' */
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
          == 1) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu
          = static_cast<int8_T>
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu
           == 0);
      }

      /* RateTransition generated from: '<S12>/Transfer Fcn' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_Buf
        [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu];

      /* Stop: '<Root>/Stop Simulation' incorporates:
       *  Constant: '<Root>/Constant'
       */
      if (D_20231120_Modell_Inbetrieb_cal->Constant_Value_b != 0.0) {
        rtmSetStopRequested
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
      }

      /* End of Stop: '<Root>/Stop Simulation' */
    }

    /* End of RateTransition generated from: '<S12>/Transfer Fcn1' */
  }

  if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    real_T *lastU;
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Update for S-Function (sfix_udelay): '<S42>/Tapped Delay1' */
      for (int_T i = 0; i < 198; i++) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[i]
          =
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[i
          + 1];
      }

      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[198]
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2;

      /* End of Update for S-Function (sfix_udelay): '<S42>/Tapped Delay1' */

      /* Update for S-Function (sfix_udelay): '<S60>/Tapped Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1_FP_1_G;

      /* Update for S-Function (sfix_udelay): '<S61>/Tapped Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2_FP_2_G;

      /* Update for DiscreteIntegrator: '<S53>/Discrete-Time Integrator2' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE
        += D_20231120_Modell_Inbetrieb_cal->DiscreteTimeIntegrator2_gainval *
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2;
      if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
          > 0.0) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = 1;
      } else if
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
           < 0.0) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = -1;
      } else if
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
           == 0.0) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = 0;
      } else {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = 2;
      }

      /* End of Update for DiscreteIntegrator: '<S53>/Discrete-Time Integrator2' */

      /* Update for UnitDelay: '<S48>/Unit Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_e =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3;

      /* Update for Memory: '<S48>/Memory' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[0];

      /* Update for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch8_Bremsaktuator_Hall;

      /* Update for S-Function (sfix_udelay): '<S15>/Tapped Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[0] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3] =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch9_Bremsaktuator_Hall;

      /* Update for UnitDelay: '<S16>/Unit Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_c =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;

      /* Update for UnitDelay: '<S26>/Unit Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay1_DSTATE =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h;

      /* Update for UnitDelay: '<S26>/Unit Delay' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add;

      /* Update for Delay: '<S17>/Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oz;

      /* Update for Delay: '<S18>/Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_o =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_g;

      /* Update for UnitDelay: '<S30>/Delay Input1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7;

      /* Update for UnitDelay: '<S32>/Delay Input1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_b
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;

      /* Update for Memory: '<S36>/Memory' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_o
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i;
    }

    /* Update for Derivative: '<S4>/Derivative' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA ==
        (rtInf)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeA;
    } else if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB
               == (rtInf)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB;
    } else if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA
               <
               D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB)
    {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeA;
    } else {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB;
    }

    *lastU = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel;

    /* End of Update for Derivative: '<S4>/Derivative' */
    if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Update for Delay: '<S50>/Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_p =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_k;

      /* Update for UnitDelay: '<S57>/Delay Input1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_j
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on;

      /* Update for S-Function (sfix_udelay): '<S54>/Tapped Delay1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[0]
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [1];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[1]
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [2];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[2]
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [3];
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[3]
        =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH14_Freigabe_Taster;

      /* Update for Memory: '<S48>/Memory1' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory1_PreviousInput
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[1];

      /* Update for Memory: '<S55>/Memory' */
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_d
        = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[0];
    }

    /* Update for Derivative: '<S79>/Derivative' */
    if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a ==
        (rtInf)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeA_a;
    } else if
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g ==
         (rtInf)) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB_o;
    } else if
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a <
         D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeA_a;
    } else {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
      lastU =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LastUAtTimeB_o;
    }

    *lastU =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtDerivativeInport1;

    /* End of Update for Derivative: '<S79>/Derivative' */
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    rt_ertODEUpdateContinuousStates
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);

    /* Update absolute time */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick0))
    {
      ++D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH0;
    }

    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0] =
      rtsiGetSolverStopTime
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);

    /* Update absolute time */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick1))
    {
      ++D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH1;
    }

    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[1] =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick1 *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize1 +
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH1 *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize1 *
      4294967296.0;
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_derivatives(void)
{
  XDot_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *_rtXdot;
  _rtXdot = ((XDot_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *)
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->derivs);

  /* Derivatives for TransferFcn: '<S12>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE = D_20231120_Modell_Inbetrieb_cal->TransferFcn_A *
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE +=
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1;

  /* Derivatives for TransferFcn: '<S12>/Transfer Fcn1' */
  _rtXdot->TransferFcn1_CSTATE = D_20231120_Modell_Inbetrieb_cal->TransferFcn1_A
    * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn1_CSTATE;
  _rtXdot->TransferFcn1_CSTATE +=
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1;

  /* Derivatives for Integrator: '<S49>/Integrator' incorporates:
   *  Constant: '<S49>/Constant'
   */
  _rtXdot->Integrator_CSTATE =
    D_20231120_Modell_Inbetrieb_cal->Constant_Value_ph;

  /* Derivatives for Integrator: '<S119>/Integrator' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe ==
      0.0) {
    _rtXdot->Integrator_CSTATE_k =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IProdOut;
  } else {
    /* level reset is active */
    _rtXdot->Integrator_CSTATE_k = 0.0;
  }

  /* End of Derivatives for Integrator: '<S119>/Integrator' */
}

/* Model step function for TID2 */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step2(void) /* Sample time: [0.005s, 0.0s] */
{
  real_T u0;
  real_T u1;
  real_T u2;
  int32_T s68_iter;

  /* Update the flag to indicate when data transfers from
   *  Sample time: [0.005s, 0.0s] to Sample time: [0.1s, 0.0s]  */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
    [13] =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
     == 0);
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3)
    ++;
  if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3)
      > 19) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      = 0;
  }

  /* Update the flag to indicate when data transfers from
   *  Sample time: [0.005s, 0.0s] to Sample time: [60.0s, 0.0s]  */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
    [14] =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
     == 0);
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4)
    ++;
  if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4)
      > 11999) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
      = 0;
  }

  /* Constant: '<S9>/RX Sample Time' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RXSampleTime =
    D_20231120_Modell_Inbetrieb_cal->RXSampleTime_Value;

  /* Outputs for Iterator SubSystem: '<S9>/CAN Read Loop - Port 1' incorporates:
   *  WhileIterator: '<S68>/While Iterator'
   */
  s68_iter = 1;
  do {
    /* Level2 S-Function Block: '<S68>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];
      sfcnOutputs(rts,2);
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1041 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 56
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o2
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 40
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o4
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack1' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1045 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 56
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1_k
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 40
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o2_m
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o3_h
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4_f
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack2' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1056 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1_f
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 56
             *  length                  = 32
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint32_T unpackedValue = 0;

                {
                  uint32_T tempValue = (uint32_T) (0);

                  {
                    tempValue = tempValue | (uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]) << 16);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 24);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o2_a
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3_m
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack3' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1057 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 16
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.5
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.5;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o2
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack4' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1059 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 8
             *  length                  = 1
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]) & (uint8_T)(0x1U));
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1_n
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2_n
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack5' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1024 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 56
             *  length                  = 24
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint32_T unpackedValue = 0;

                {
                  uint32_T tempValue = (uint32_T) (0);

                  {
                    tempValue = tempValue | (uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]) << 16);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack6' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((644 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 48
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = SIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = SIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 40
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o4
                  = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o5
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack7' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((645 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o2
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S68>/CAN Unpack8' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1477 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 2
             *  length                  = 1
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) & (uint8_T)(0x4U)) >> 2);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 24
             *  length                  = 24
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = -1937.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint32_T unpackedValue = 0;

                {
                  uint32_T tempValue = (uint32_T) (0);

                  {
                    tempValue = tempValue | (uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]) << 16);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result + -1937.0;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o2
                  = result;
              }
            }
          }
        }
      }
    }

    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ChargeRequest =
      D_20231120_Modell_Inbetrieb_cal->Gain_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IBatt =
      D_20231120_Modell_Inbetrieb_cal->Gain1_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Range =
      D_20231120_Modell_Inbetrieb_cal->Gain10_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3_m;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed =
      D_20231120_Modell_Inbetrieb_cal->Gain11_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b =
      D_20231120_Modell_Inbetrieb_cal->Gain12_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BrakePedal =
      D_20231120_Modell_Inbetrieb_cal->Gain13_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1_n;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DriveMode =
      D_20231120_Modell_Inbetrieb_cal->Gain14_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2_n;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceToral_24Bit =
      D_20231120_Modell_Inbetrieb_cal->Gain15_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VehicleSpeedFromABS =
      D_20231120_Modell_Inbetrieb_cal->Gain16_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o3;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FL =
      D_20231120_Modell_Inbetrieb_cal->Gain17_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o4;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FR =
      D_20231120_Modell_Inbetrieb_cal->Gain18_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o5;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RL =
      D_20231120_Modell_Inbetrieb_cal->Gain19_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL15 =
      D_20231120_Modell_Inbetrieb_cal->Gain2_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o3;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RR =
      D_20231120_Modell_Inbetrieb_cal->Gain20_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Handbremse =
      D_20231120_Modell_Inbetrieb_cal->Gain21_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e =
      D_20231120_Modell_Inbetrieb_cal->Gain22_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL30 =
      D_20231120_Modell_Inbetrieb_cal->Gain3_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o4;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BMSStatus =
      D_20231120_Modell_Inbetrieb_cal->Gain4_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1_k;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.InverterStatus =
      D_20231120_Modell_Inbetrieb_cal->Gain5_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o2_m;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorSpeed =
      D_20231120_Modell_Inbetrieb_cal->Gain6_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o3_h;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorTorque =
      D_20231120_Modell_Inbetrieb_cal->Gain7_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4_f;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Distance =
      D_20231120_Modell_Inbetrieb_cal->Gain8_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1_f;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceTotal =
      D_20231120_Modell_Inbetrieb_cal->Gain9_Gain *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o2_a;
    s68_iter++;
  } while (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1_f &&
           (s68_iter <= 501));

  /* End of Outputs for SubSystem: '<S9>/CAN Read Loop - Port 1' */

  /* Outputs for Iterator SubSystem: '<S9>/CAN Read Loop - Port 3' incorporates:
   *  WhileIterator: '<S69>/While Iterator'
   */
  s68_iter = 1;

  /* SignalConversion generated from: '<S69>/Bus Creator2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.isvalid = 0.0;

  /* SignalConversion generated from: '<S69>/Bus Creator2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.radardatalength1788 =
    0.0;

  /* SignalConversion generated from: '<S69>/Bus Creator2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Punkt = 0.0;

  /* SignalConversion generated from: '<S69>/Bus Creator2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Mode = 0.0;

  /* SignalConversion generated from: '<S69>/Bus Creator' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_2 = 0.0;
  do {
    /* Level2 S-Function Block: '<S69>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];
      sfcnOutputs(rts,2);
    }

    {
      /* S-Function (scanunpack): '<S69>/CAN Unpack' */
      if ((5 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((2 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 0
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.09882
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.09882;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack =
                  result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S69>/CAN Unpack1' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((304 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 32
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.0001274
             *  offset                  = -4.1768
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [4]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [5]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.0001274) + -4.1768;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 48
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 16
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 0
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = -163.84
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.005) + -163.84;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4
                  = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 52
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 7 ------------------
             *  startBit                = 20
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S69>/CAN Unpack2' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((305 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 32
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.0001274
             *  offset                  = -4.1768
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [4]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [5]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.0001274) + -4.1768;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 52
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 0
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.125
             *  offset                  = -4096.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.125) + -4096.0;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 20
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 48
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 16
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 7 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S69>/CAN Unpack4' */
      if ((8 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((16 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 32
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [4]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 40
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [5]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [7]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 48
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [6]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o4
                  = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o5
                  = result;
              }
            }

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o6
                  = result;
              }
            }

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [3]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o7
                  = result;
              }
            }

            /* --------------- START Unpacking signal 7 ------------------
             *  startBit                = 16
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [2]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o8
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S69>/CAN Unpack5' */
      if ((2 ==
           D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((17 ==
             D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o2
                  = result;
              }
            }
          }
        }
      }
    }

    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m =
      D_20231120_Modell_Inbetrieb_cal->Gain_Gain_i *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AY =
      D_20231120_Modell_Inbetrieb_cal->Gain1_Gain_f *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLM =
      D_20231120_Modell_Inbetrieb_cal->Gain10_Gain_l *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o6;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRA =
      D_20231120_Modell_Inbetrieb_cal->Gain11_Gain_e *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o7;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRM =
      D_20231120_Modell_Inbetrieb_cal->Gain12_Gain_f *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o8;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal =
      D_20231120_Modell_Inbetrieb_cal->Gain13_Gain_k *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung =
      D_20231120_Modell_Inbetrieb_cal->Gain14_Gain_n *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierrate =
      D_20231120_Modell_Inbetrieb_cal->Gain2_Gain_m *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AX =
      D_20231120_Modell_Inbetrieb_cal->Gain3_Gain_p *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierbeschleunigung =
      D_20231120_Modell_Inbetrieb_cal->Gain4_Gain_n *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLA =
      D_20231120_Modell_Inbetrieb_cal->Gain5_Gain_m *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLM =
      D_20231120_Modell_Inbetrieb_cal->Gain6_Gain_p *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRA =
      D_20231120_Modell_Inbetrieb_cal->Gain7_Gain_h *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o3;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRM =
      D_20231120_Modell_Inbetrieb_cal->Gain8_Gain_l *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o4;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLA =
      D_20231120_Modell_Inbetrieb_cal->Gain9_Gain_e *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o5;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_b =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m /
      D_20231120_Modell_Inbetrieb_cal->RatioLenkradwinkelLenkwinkel_Va;
    s68_iter++;
  } while (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1 &&
           (s68_iter <= 501));

  /* End of Outputs for SubSystem: '<S9>/CAN Read Loop - Port 3' */
  /* SignalConversion generated from: '<S2>/Byte Packing' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
    [0] = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
    [1] = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
    [2] = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m;

  /* S-Function (slrealtimebytepacking): '<S2>/Byte Packing' */

  /* Byte Packing: <S2>/Byte Packing */
  (void)memcpy((uint8_T*)
               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking
               [0] + 0, (uint8_T*)
               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
               [0], 24);

  /* RateTransition generated from: '<S2>/Byte Packing' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      == 1) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
      = static_cast<int8_T>
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
       == 0);
  }

  for (s68_iter = 0; s68_iter < 24; s68_iter++) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_Buf
      [s68_iter +
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
      * 24] =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking[s68_iter];
  }

  /* End of RateTransition generated from: '<S2>/Byte Packing' */

  /* Product: '<S4>/Product' incorporates:
   *  Constant: '<S4>/Constant3'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed *
    D_20231120_Modell_Inbetrieb_cal->Constant3_Value_d;

  /* MATLAB Function: '<S4>/Fahrzeuggeschwindigkeit' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitFahrzeug_OK
    = (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product <= 45.0);

  /* MATLAB Function: '<S4>/Lenkradwinkel' */
  if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product > 0.0) &&
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product <= 5.0)) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkel_OK =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m <
       650.0);
  } else if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product >
              5.0) &&
             (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product <=
              15.0)) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkel_OK =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m <
       -50.0 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product +
       900.0);
  } else if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product >
              15.0) &&
             (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product <=
              25.0)) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkel_OK =
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m <
       -5.0 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product +
       225.0);
  } else {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkel_OK =
      ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product > 25.0) &&
       (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m <
        100.0));
  }

  /* End of MATLAB Function: '<S4>/Lenkradwinkel' */

  /* RateTransition generated from: '<S4>/Derivative' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrBuf
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrBuf
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrBuf]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m;

  /* RateTransition generated from: '<S4>/Fahrzeuggeschwindigkeit' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_b
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_b
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_k
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_b]
    =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.geschwindigkeitFahrzeug_OK;

  /* RateTransition generated from: '<S4>/Lenkradwinkel' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_W
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_W
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_B
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_W]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkel_OK;

  /* RateTransition generated from: '<S4>/Lenkradwinkelgeschwindigkeit' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_k
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_k
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwindi
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_k]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product;

  /* RelationalOperator: '<S51>/Compare' incorporates:
   *  Constant: '<S51>/Constant'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_e =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Handbremse ==
     D_20231120_Modell_Inbetrieb_cal->Constant_Value_j);

  /* Lookup_n-D: '<S74>/1-D Lookup Table' incorporates:
   *  Product: '<S70>/Divide'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_o =
    look1_binlxpw(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_b,
                  D_20231120_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_mj,
                  D_20231120_Modell_Inbetrieb_cal->uDLookupTable_tableData_l, 1U);

  /* Saturate: '<S74>/Saturation' */
  u0 = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_o;
  u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_nj;
  u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_jd;
  if (u0 > u2) {
    /* Saturate: '<S74>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_m = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S74>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_m = u1;
  } else {
    /* Saturate: '<S74>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_m = u0;
  }

  /* End of Saturate: '<S74>/Saturation' */
  /* Product: '<S79>/Product' incorporates:
   *  Constant: '<S79>/Constant'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed *
    D_20231120_Modell_Inbetrieb_cal->Constant_Value_lk;

  /* MATLAB Function: '<S79>/MATLAB Function' */
  if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o > 0.0) &&
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o <= 5.0))
  {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert
      = 0.8;
  } else if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o >
              5.0) &&
             (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o <=
              15.0)) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert
      = (-50.0 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o
         + 900.0) / 650.0;
  } else if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o >
              15.0) &&
             (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o <=
              25.0)) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert
      = (-5.0 * D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o
         + 225.0) / 650.0;
  } else if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o >
             25.0) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert
      = 0.15384615384615385;
  } else {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert
      = 0.8;
  }

  /* End of MATLAB Function: '<S79>/MATLAB Function' */

  /* RelationalOperator: '<S78>/Relational Operator1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1 =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_m <=
     D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert);

  /* RateTransition: '<S78>/RT' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx =
    static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1;

  /* Sum: '<S78>/Sum' incorporates:
   *  Constant: '<S78>/Constant'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_p =
    D_20231120_Modell_Inbetrieb_cal->Constant_Value_ow -
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.lenkradwinkelMaxNomiert;

  /* RelationalOperator: '<S78>/Relational Operator' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator_j =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_m >=
     D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_p);

  /* RateTransition generated from: '<S78>/Switch' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_WrBufIdx
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_WrBufIdx
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator_j;

  /* RateTransition generated from: '<S79>/Derivative' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrB_j
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrB_j
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_Buf_a
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrB_j]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_b;

  /* RateTransition generated from: '<S79>/MATLAB Function1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_m
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_m
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport2_
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_m]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_o;

  /* Saturate: '<S75>/Saturation2' */
  u0 = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_m;
  u1 = D_20231120_Modell_Inbetrieb_cal->Saturation2_LowerSat_b;
  u2 = D_20231120_Modell_Inbetrieb_cal->Saturation2_UpperSat_b;
  if (u0 > u2) {
    /* Saturate: '<S75>/Saturation2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler_h =
      u2;
  } else if (u0 < u1) {
    /* Saturate: '<S75>/Saturation2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler_h =
      u1;
  } else {
    /* Saturate: '<S75>/Saturation2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler_h =
      u0;
  }

  /* End of Saturate: '<S75>/Saturation2' */

  /* RateTransition generated from: '<S75>/Sum' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_WrBufIdx
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_WrBufIdx
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler_h;

  /* DataTypeConversion: '<S11>/Data Type Conversion' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Data = 0.0;

  /* RateTransition: '<S11>/Rate Transition1' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      == 1) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
      = static_cast<int8_T>
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
       == 0);
  }

  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed;

  /* End of RateTransition: '<S11>/Rate Transition1' */

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
      == 1) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx =
      static_cast<int8_T>
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx ==
       0);
  }

  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e;

  /* End of RateTransition generated from: '<Root>/S-Function Builder' */

  /* RelationalOperator: '<S204>/Compare' incorporates:
   *  Constant: '<S204>/Constant'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_nw =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal ==
     D_20231120_Modell_Inbetrieb_cal->CompareToConstant_const_kb);

  /* Switch: '<S12>/Switch' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_nw) {
    /* Switch: '<S12>/Switch' incorporates:
     *  Constant: '<S12>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l =
      D_20231120_Modell_Inbetrieb_cal->Constant_Value_p;
  } else {
    /* Switch: '<S12>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal;
  }

  /* End of Switch: '<S12>/Switch' */

  /* Saturate: '<S12>/Saturation' */
  u0 = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l;
  u1 = D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_k;
  u2 = D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_i;
  if (u0 > u2) {
    /* Saturate: '<S12>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S12>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k = u1;
  } else {
    /* Saturate: '<S12>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k = u0;
  }

  /* End of Saturate: '<S12>/Saturation' */

  /* Lookup_n-D: '<S12>/1-D Lookup Table' incorporates:
   *  Saturate: '<S12>/Saturation'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_p =
    look1_binlxpw
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k,
     D_20231120_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_b,
     D_20231120_Modell_Inbetrieb_cal->uDLookupTable_tableData_m, 2U);

  /* RelationalOperator: '<S205>/Compare' incorporates:
   *  Constant: '<S205>/Constant'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_if =
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung ==
     D_20231120_Modell_Inbetrieb_cal->CompareToConstant1_const_k);

  /* Switch: '<S12>/Switch1' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_if) {
    /* Switch: '<S12>/Switch1' incorporates:
     *  Constant: '<S12>/Constant1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_l =
      D_20231120_Modell_Inbetrieb_cal->Constant1_Value_n;
  } else {
    /* Switch: '<S12>/Switch1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_l =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung;
  }

  /* End of Switch: '<S12>/Switch1' */

  /* Saturate: '<S12>/Saturation1' */
  u0 = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_l;
  u1 = D_20231120_Modell_Inbetrieb_cal->Saturation1_LowerSat_o4;
  u2 = D_20231120_Modell_Inbetrieb_cal->Saturation1_UpperSat_a;
  if (u0 > u2) {
    /* Saturate: '<S12>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_n = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S12>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_n = u1;
  } else {
    /* Saturate: '<S12>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_n = u0;
  }

  /* End of Saturate: '<S12>/Saturation1' */

  /* Product: '<S12>/Divide' incorporates:
   *  Constant: '<S12>/Constant2'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_c =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_n /
    D_20231120_Modell_Inbetrieb_cal->Constant2_Value_a;

  /* RateTransition generated from: '<S12>/Transfer Fcn1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_c;

  /* RateTransition generated from: '<S12>/Transfer Fcn' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_p;

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
      == 1) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx =
      static_cast<int8_T>
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx == 0);
  }

  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b;

  /* End of RateTransition generated from: '<Root>/S-Function Builder' */

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick2))
  {
    ++D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH2;
  }

  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[2] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick2 *
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize2 +
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH2 *
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize2 *
    4294967296.0;
}

/* Model step function for TID3 */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step3(void) /* Sample time: [0.1s, 0.0s] */
{
  LaneSensor tmp;
  c_driving_internal_parabolicL_T b_data;
  c_driving_internal_parabolicL_T leftEgoBoundary_Data_data;
  c_driving_internal_parabolicL_T rightEgoBoundary_Data_data;
  packLaneMarkerBus_D_20231120__T *obj;
  struct_AzXAydn5whPkCj5deW4WYB expl_temp;
  real_T x1_2[3];
  real_T x1_3[3];
  real_T x1_4[3];
  real_T x2_2[3];
  real_T x2_3[3];
  real_T x2_4[3];
  real_T x1[2];
  real_T x1_0[2];
  real_T x1_1[2];
  real_T x1_5[2];
  real_T x1_6[2];
  real_T x1_7[2];
  real_T x1_8[2];
  real_T x2[2];
  real_T x2_0[2];
  real_T x2_1[2];
  real_T x2_5[2];
  real_T x2_6[2];
  real_T x2_7[2];
  real_T x2_8[2];
  real_T leftEgoParameters_idx_0;
  real_T leftEgoParameters_idx_1;
  real_T leftEgoParameters_idx_2;
  real_T rightEgoParameters_idx_0;
  real_T rightEgoParameters_idx_1;
  real_T rightEgoParameters_idx_2;
  int32_T i;
  uint8_T msgs[48];
  uint8_T x[8];
  boolean_T out;
  boolean_T p;
  boolean_T p_0;
  static const LaneSensorBoundaries tmp_0 = { 0.0F,/* Curvature */
    0.0F,                              /* CurvatureDerivative */
    0.0F,                              /* HeadingAngle */
    0.0F,                              /* LateralOffset */
    0.0F,                              /* Strength */

    { 0.0F, 0.0F },                    /* XExtent */
    0U                                 /* BoundaryType */
  };

  real_T *x1_9;
  real_T *x2_9;
  boolean_T exitg1;

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeftandRight1_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeft1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromRight1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromNone1_SubsysRanBC);

  /* RateTransition: '<S11>/Rate Transition1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
     == 0);

  /* RateTransition: '<S11>/Rate Transition1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx];

  /* Switch: '<S138>/Switch' */
  if (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity
      > D_20231120_Modell_Inbetrieb_cal->Switch_Threshold_c) {
    /* Switch: '<S138>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity;
  } else {
    /* Switch: '<S138>/Switch' incorporates:
     *  Constant: '<S138>/Initial Velocity'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp =
      D_20231120_Modell_Inbetrieb_cal->InitialVelocity_Value;
  }

  /* End of Switch: '<S138>/Switch' */

  /* S-Function (slrealtimeUDPReceive): '<S11>/From Jetson' */
  {
    try {
      slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
        udp::Socket*>
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK[
         0]);
      char *buffer = (char *)
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
        [1];
      memset(buffer,0,48);
      void *dataPort =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o1[0];
      int_T numBytesAvail = (int_T)(udpSock->bytesToRead());
      if (numBytesAvail > 0) {
        uint8_t* fmAddArg = (uint8_t *)
          D_20231120_Modell_Inbetrieb_cal->FromJetson_fmAddress;
        size_t num_bytesRcvd = (size_t)(udpSock->receive(buffer,( numBytesAvail<
          65507 )? numBytesAvail:65507, !1,fmAddArg));
        if (num_bytesRcvd == 0) {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 =
            0;
        } else {
          D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 =
            (double)num_bytesRcvd;
          memcpy(dataPort,(void*)buffer,48);
        }
      } else {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 = 0;
      }
    } catch (std::exception& e) {
      std::string tmp = std::string(e.what());
      static std::string eMsg = tmp;
      rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                        eMsg.c_str());
      rtmSetStopRequested(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          1);
      ;
    }
  }

  /* MATLABSystem: '<S11>/PackLaneBus' */
  expl_temp = *get_camera();
  rightEgoParameters_idx_2 = expl_temp.NumColumns;
  leftEgoParameters_idx_0 = expl_temp.NumRows;
  for (i = 0; i < 48; i++) {
    msgs[i] =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o1[i];
  }

  leftEgoParameters_idx_1 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns;
  leftEgoParameters_idx_2 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows;
  x1_8[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
    [0];
  x1_8[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
    [1];
  x1_7[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
    [0];
  x1_7[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
    [1];
  x1_6[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
    [0];
  x1_6[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
    [1];
  x1_5[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
    [0];
  x1_5[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
    [1];
  x1_4[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0];
  x1_4[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1];
  x1_4[2] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2];
  x1_3[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [0];
  x1_3[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [1];
  x1_3[2] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [2];
  x1_2[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0];
  x1_2[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1];
  x1_2[2] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2];
  x1_1[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
    [0];
  x1_1[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
    [1];
  x1_0[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
    [0];
  x1_0[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
    [1];
  x1_9 =
    &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
    [0];
  x1[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
    [0];
  x1[1] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
    [1];
  x2_8[0] = expl_temp.FieldOfView[0];
  x2_7[0] = expl_temp.ImageSize[0];
  x2_6[0] = expl_temp.PrincipalPoint[0];
  x2_5[0] = expl_temp.FocalLength[0];
  x2_8[1] = expl_temp.FieldOfView[1];
  x2_7[1] = expl_temp.ImageSize[1];
  x2_6[1] = expl_temp.PrincipalPoint[1];
  x2_5[1] = expl_temp.FocalLength[1];
  x2_4[0] = expl_temp.Position[0];
  x2_3[0] = expl_temp.PositionSim3d[0];
  x2_2[0] = expl_temp.Rotation[0];
  x2_4[1] = expl_temp.Position[1];
  x2_3[1] = expl_temp.PositionSim3d[1];
  x2_2[1] = expl_temp.Rotation[1];
  x2_4[2] = expl_temp.Position[2];
  x2_3[2] = expl_temp.PositionSim3d[2];
  x2_2[2] = expl_temp.Rotation[2];
  x2_1[0] = expl_temp.DetectionRanges[0];
  x2_0[0] = expl_temp.LaneDetectionRanges[0];
  x2_1[1] = expl_temp.DetectionRanges[1];
  x2_0[1] = expl_temp.LaneDetectionRanges[1];
  x2_9 = &expl_temp.MeasurementNoise[0];
  x2[0] = expl_temp.MinObjectImageSize[0];
  x2[1] = expl_temp.MinObjectImageSize[1];
  p = false;
  out = true;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 2)) {
    rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
    rightEgoParameters_idx_1 = x1[static_cast<int32_T>(rightEgoParameters_idx_0)
      - 1];
    rightEgoParameters_idx_0 = x2[static_cast<int32_T>(rightEgoParameters_idx_0)
      - 1];
    p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
    if (!p_0) {
      out = false;
      exitg1 = true;
    } else {
      i++;
    }
  }

  if (out) {
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 9)) {
      rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
      rightEgoParameters_idx_1 = x1_9[static_cast<int32_T>
        (rightEgoParameters_idx_0) - 1];
      rightEgoParameters_idx_0 = x2_9[static_cast<int32_T>
        (rightEgoParameters_idx_0) - 1];
      p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
      if (!p_0) {
        out = false;
        exitg1 = true;
      } else {
        i++;
      }
    }

    if (out) {
      i = 0;
      exitg1 = false;
      while ((!exitg1) && (i < 2)) {
        rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
        rightEgoParameters_idx_1 = x1_0[static_cast<int32_T>
          (rightEgoParameters_idx_0) - 1];
        rightEgoParameters_idx_0 = x2_0[static_cast<int32_T>
          (rightEgoParameters_idx_0) - 1];
        p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
        if (!p_0) {
          out = false;
          exitg1 = true;
        } else {
          i++;
        }
      }

      if (out) {
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i < 2)) {
          rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
          rightEgoParameters_idx_1 = x1_1[static_cast<int32_T>
            (rightEgoParameters_idx_0) - 1];
          rightEgoParameters_idx_0 = x2_1[static_cast<int32_T>
            (rightEgoParameters_idx_0) - 1];
          p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
          if (!p_0) {
            out = false;
            exitg1 = true;
          } else {
            i++;
          }
        }

        if (out) {
          i = 0;
          exitg1 = false;
          while ((!exitg1) && (i < 3)) {
            rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
            rightEgoParameters_idx_1 = x1_2[static_cast<int32_T>
              (rightEgoParameters_idx_0) - 1];
            rightEgoParameters_idx_0 = x2_2[static_cast<int32_T>
              (rightEgoParameters_idx_0) - 1];
            p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
            if (!p_0) {
              out = false;
              exitg1 = true;
            } else {
              i++;
            }
          }

          if (out) {
            i = 0;
            exitg1 = false;
            while ((!exitg1) && (i < 3)) {
              rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
              rightEgoParameters_idx_1 = x1_3[static_cast<int32_T>
                (rightEgoParameters_idx_0) - 1];
              rightEgoParameters_idx_0 = x2_3[static_cast<int32_T>
                (rightEgoParameters_idx_0) - 1];
              p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
              if (!p_0) {
                out = false;
                exitg1 = true;
              } else {
                i++;
              }
            }

            if (out) {
              i = 0;
              exitg1 = false;
              while ((!exitg1) && (i < 3)) {
                rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                rightEgoParameters_idx_1 = x1_4[static_cast<int32_T>
                  (rightEgoParameters_idx_0) - 1];
                rightEgoParameters_idx_0 = x2_4[static_cast<int32_T>
                  (rightEgoParameters_idx_0) - 1];
                p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                if (!p_0) {
                  out = false;
                  exitg1 = true;
                } else {
                  i++;
                }
              }

              if (out) {
                i = 0;
                exitg1 = false;
                while ((!exitg1) && (i < 2)) {
                  rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                  rightEgoParameters_idx_1 = x1_5[static_cast<int32_T>
                    (rightEgoParameters_idx_0) - 1];
                  rightEgoParameters_idx_0 = x2_5[static_cast<int32_T>
                    (rightEgoParameters_idx_0) - 1];
                  p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                  if (!p_0) {
                    out = false;
                    exitg1 = true;
                  } else {
                    i++;
                  }
                }

                if (out) {
                  i = 0;
                  exitg1 = false;
                  while ((!exitg1) && (i < 2)) {
                    rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                    rightEgoParameters_idx_1 = x1_6[static_cast<int32_T>
                      (rightEgoParameters_idx_0) - 1];
                    rightEgoParameters_idx_0 = x2_6[static_cast<int32_T>
                      (rightEgoParameters_idx_0) - 1];
                    p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                    if (!p_0) {
                      out = false;
                      exitg1 = true;
                    } else {
                      i++;
                    }
                  }

                  if (out) {
                    i = 0;
                    exitg1 = false;
                    while ((!exitg1) && (i < 2)) {
                      rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                      rightEgoParameters_idx_1 = x1_7[static_cast<int32_T>
                        (rightEgoParameters_idx_0) - 1];
                      rightEgoParameters_idx_0 = x2_7[static_cast<int32_T>
                        (rightEgoParameters_idx_0) - 1];
                      p_0 = (rightEgoParameters_idx_1 ==
                             rightEgoParameters_idx_0);
                      if (!p_0) {
                        out = false;
                        exitg1 = true;
                      } else {
                        i++;
                      }
                    }

                    if (out) {
                      i = 0;
                      exitg1 = false;
                      while ((!exitg1) && (i < 2)) {
                        rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                        rightEgoParameters_idx_1 = x1_8[static_cast<int32_T>
                          (rightEgoParameters_idx_0) - 1];
                        rightEgoParameters_idx_0 = x2_8[static_cast<int32_T>
                          (rightEgoParameters_idx_0) - 1];
                        p_0 = (rightEgoParameters_idx_1 ==
                               rightEgoParameters_idx_0);
                        if (!p_0) {
                          out = false;
                          exitg1 = true;
                        } else {
                          i++;
                        }
                      }

                      if (out) {
                        p_0 = (leftEgoParameters_idx_2 ==
                               leftEgoParameters_idx_0);
                        out = p_0;
                        if (out) {
                          p_0 = (leftEgoParameters_idx_1 ==
                                 rightEgoParameters_idx_2);
                          out = p_0;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (out) {
    p = true;
  }

  if (!p) {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns
      = rightEgoParameters_idx_2;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows =
      leftEgoParameters_idx_0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [0] = expl_temp.FieldOfView[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [1] = expl_temp.FieldOfView[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [0] = expl_temp.ImageSize[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [1] = expl_temp.ImageSize[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [0] = expl_temp.PrincipalPoint[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [1] = expl_temp.PrincipalPoint[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [0] = expl_temp.FocalLength[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [1] = expl_temp.FocalLength[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0]
      = expl_temp.Position[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1]
      = expl_temp.Position[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2]
      = expl_temp.Position[2];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [0] = expl_temp.PositionSim3d[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [1] = expl_temp.PositionSim3d[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [2] = expl_temp.PositionSim3d[2];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0]
      = expl_temp.Rotation[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1]
      = expl_temp.Rotation[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2]
      = expl_temp.Rotation[2];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [0] = expl_temp.DetectionRanges[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [1] = expl_temp.DetectionRanges[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [0] = expl_temp.LaneDetectionRanges[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [1] = expl_temp.LaneDetectionRanges[1];
    std::memcpy
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
       [0], &expl_temp.MeasurementNoise[0], 9U * sizeof(real_T));
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [0] = expl_temp.MinObjectImageSize[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [1] = expl_temp.MinObjectImageSize[1];
  }

  obj = &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;

  /*  Pack lane boundaries to LaneSensor bus */
  /* ------------------------------------------------------------------ */
  /*  packLaneBoundaryDetections method packs Pack detections into */
  /*  format expected by LaneFollowingDecisionLogicandControl.  */
  /*  y=Ax^2+Bx+C */
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_0 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 8];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_1 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 16];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_2 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 24];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_0 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 32];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_1 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 40];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  b_data.BoundaryType = Solid;
  b_data.Strength = 0.0;
  b_data.XExtent[0] = 0.0;
  b_data.XExtent[1] = (rtInf);
  b_data.Parameters[0] = leftEgoParameters_idx_0;
  b_data.Parameters[1] = leftEgoParameters_idx_1;
  b_data.Parameters[2] = leftEgoParameters_idx_2;
  leftEgoBoundary_Data_data = b_data;
  b_data.BoundaryType = Solid;
  b_data.Strength = 0.0;
  b_data.XExtent[0] = 0.0;
  b_data.XExtent[1] = (rtInf);
  b_data.Parameters[0] = rightEgoParameters_idx_0;
  b_data.Parameters[1] = rightEgoParameters_idx_1;
  b_data.Parameters[2] = rightEgoParameters_idx_2;
  rightEgoBoundary_Data_data = b_data;

  /*  Preallocate struct expected by controller */
  /*  Pack detections into struct */
  D_202_packLaneBoundaryDetection(&leftEgoBoundary_Data_data,
    &tmp.Left.Curvature, &tmp.Left.CurvatureDerivative, &tmp.Left.HeadingAngle,
    &tmp.Left.LateralOffset, &tmp.Left.Strength, tmp.Left.XExtent,
    &tmp.Left.BoundaryType);
  D_202_packLaneBoundaryDetection(&rightEgoBoundary_Data_data,
    &tmp.Right.Curvature, &tmp.Right.CurvatureDerivative,
    &tmp.Right.HeadingAngle, &tmp.Right.LateralOffset, &tmp.Right.Strength,
    tmp.Right.XExtent, &tmp.Right.BoundaryType);

  /*  Shift detections to vehicle center as required by controller */
  /*  Note: camera.PositionSim3d(1) represents the X mount location of the */
  /*        camera sensor with respect to the vehicle center */
  b_data = leftEgoBoundary_Data_data;
  x1_4[0] = b_data.Parameters[0];
  x1_4[1] = b_data.Parameters[1];
  x1_4[2] = b_data.Parameters[2];
  i = 0;
  if (x1_4[0] != 0.0) {
    i = 1;
  }

  if (x1_4[1] != 0.0) {
    i++;
  }

  if (x1_4[2] != 0.0) {
    i++;
  }

  rightEgoParameters_idx_0 = i;
  if (rightEgoParameters_idx_0 != 0.0) {
    b_data = leftEgoBoundary_Data_data;
    x1_4[0] = b_data.Parameters[0];
    x1_4[1] = b_data.Parameters[1];
    x1_4[2] = b_data.Parameters[2];
    leftEgoParameters_idx_0 = -obj->Camera.PositionSim3d[0];
    rightEgoParameters_idx_2 = x1_4[0];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[1];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[2];
    tmp.Left.LateralOffset = static_cast<real32_T>(rightEgoParameters_idx_2);

    /*  Lane to left should always have positive lateral offset */
    if (tmp.Left.LateralOffset < 0.0F) {
      tmp.Left = tmp_0;
    }
  }

  b_data = rightEgoBoundary_Data_data;
  x1_4[0] = b_data.Parameters[0];
  x1_4[1] = b_data.Parameters[1];
  x1_4[2] = b_data.Parameters[2];
  i = 0;
  if (x1_4[0] != 0.0) {
    i = 1;
  }

  if (x1_4[1] != 0.0) {
    i++;
  }

  if (x1_4[2] != 0.0) {
    i++;
  }

  rightEgoParameters_idx_0 = i;
  if (rightEgoParameters_idx_0 != 0.0) {
    b_data = rightEgoBoundary_Data_data;
    x1_4[0] = b_data.Parameters[0];
    x1_4[1] = b_data.Parameters[1];
    x1_4[2] = b_data.Parameters[2];
    leftEgoParameters_idx_0 = -obj->Camera.PositionSim3d[0];
    rightEgoParameters_idx_2 = x1_4[0];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[1];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[2];
    tmp.Right.LateralOffset = static_cast<real32_T>(rightEgoParameters_idx_2);

    /*  Lane to right should always have negative lateral offset */
    if (tmp.Right.LateralOffset > 0.0F) {
      tmp.Right = tmp_0;
    }
  }

  /* MATLABSystem: '<S11>/PackLaneBus' */
  std::memcpy(&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus,
              &tmp, sizeof(LaneSensor));

  /* Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE;

  /* Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE;

  /* Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE;

  /* Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE;

  /* MATLAB Function: '<S137>/MATLAB Function1' incorporates:
   *  MATLABSystem: '<S11>/PackLaneBus'
   */
  if ((D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Strength
       > 0.0F) &&
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Strength
       > 0.0F)) {
    /* Outputs for Function Call SubSystem: '<S137>/Center from Left and Right1' */
    /* Sum: '<S139>/Add' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_nc =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      + D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature;

    /* Sum: '<S139>/Add1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_e =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.CurvatureDerivative
      + D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.CurvatureDerivative;

    /* Sum: '<S139>/Add2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_e =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle
      + D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

    /* Sum: '<S139>/Add3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add3 =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset
      + D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Gain: '<S139>/Gain'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20231120_Modell_Inbetrieb_cal->Gain_Gain_ii *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_nc;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Gain: '<S139>/Gain1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20231120_Modell_Inbetrieb_cal->Gain1_Gain_cq *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_e;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Gain: '<S139>/Gain2'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20231120_Modell_Inbetrieb_cal->Gain2_Gain_o *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_e;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Gain: '<S139>/Gain3'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20231120_Modell_Inbetrieb_cal->Gain3_Gain_d *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add3;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeftandRight1_SubsysR
      = 4;

    /* End of Outputs for SubSystem: '<S137>/Center from Left and Right1' */
  } else if
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Strength
       > 0.0F) {
    /* Outputs for Function Call SubSystem: '<S137>/Center from Left1' */
    /* Product: '<S140>/Product' incorporates:
     *  Constant: '<S140>/Half Lane Width Estimate'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_l =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      * D_20231120_Modell_Inbetrieb_cal->HalfLaneWidthEstimate_Value;

    /* Sum: '<S140>/Subtract' incorporates:
     *  Constant: '<S140>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l =
      D_20231120_Modell_Inbetrieb_cal->Constant_Value_jd -
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_l;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Product: '<S140>/Divide'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      / D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l;

    /* Product: '<S140>/Product1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1_k =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Product: '<S140>/Divide1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.CurvatureDerivative
      / D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1_k;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  SignalConversion generated from: '<S140>/Lanes_BusSelector'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Constant: '<S140>/Half Lane Width Estimate1'
     *  Sum: '<S140>/Subtract1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset
      - D_20231120_Modell_Inbetrieb_cal->HalfLaneWidthEstimate1_Value;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeft1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S137>/Center from Left1' */
  } else if
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Strength
       > 0.0F) {
    /* Outputs for Function Call SubSystem: '<S137>/Center from Right1' */
    /* Product: '<S142>/Product' incorporates:
     *  Constant: '<S142>/Half Lane Width Estimate'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_g =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature
      * D_20231120_Modell_Inbetrieb_cal->HalfLaneWidthEstimate_Value_f;

    /* Sum: '<S142>/Subtract' incorporates:
     *  Constant: '<S142>/Constant'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract =
      D_20231120_Modell_Inbetrieb_cal->Constant_Value_pa +
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_g;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Product: '<S142>/Divide'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature
      / D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract;

    /* Product: '<S142>/Product1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1 =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Product: '<S142>/Divide1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.CurvatureDerivative
      / D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  SignalConversion generated from: '<S142>/Lanes_BusSelector'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  Constant: '<S142>/Half Lane Width Estimate1'
     *  Sum: '<S142>/Subtract1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset
      + D_20231120_Modell_Inbetrieb_cal->HalfLaneWidthEstimate1_Value_h;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromRight1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S137>/Center from Right1' */
  } else {
    /* Outputs for Function Call SubSystem: '<S137>/Center from None1' */
    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  SignalConversion generated from: '<S141>/Out1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  SignalConversion generated from: '<S141>/Out1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  SignalConversion generated from: '<S141>/Out1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle;

    /* Merge generated from: '<S137>/Merge1' incorporates:
     *  SignalConversion generated from: '<S141>/Out1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromNone1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S137>/Center from None1' */
  }

  /* End of MATLAB Function: '<S137>/MATLAB Function1' */

  /* UnaryMinus: '<S145>/Unary Minus' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus_i =
    -D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a;

  /* DataTypeConversion: '<S144>/Data Type Conversion3' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion3 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus_i;

  /* Saturate: '<S144>/Saturation2' */
  rightEgoParameters_idx_2 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion3;
  leftEgoParameters_idx_0 =
    D_20231120_Modell_Inbetrieb_cal->Saturation2_LowerSat_d;
  leftEgoParameters_idx_1 =
    D_20231120_Modell_Inbetrieb_cal->Saturation2_UpperSat_c;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S144>/Saturation2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S144>/Saturation2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S144>/Saturation2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S144>/Saturation2' */

  /* UnaryMinus: '<S145>/Unary Minus1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1_k =
    -D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m;

  /* DataTypeConversion: '<S144>/Data Type Conversion2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_a =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1_k;

  /* Saturate: '<S144>/Saturation3' */
  rightEgoParameters_idx_2 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_a;
  leftEgoParameters_idx_0 =
    D_20231120_Modell_Inbetrieb_cal->Saturation3_LowerSat_h;
  leftEgoParameters_idx_1 =
    D_20231120_Modell_Inbetrieb_cal->Saturation3_UpperSat_p;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S144>/Saturation3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S144>/Saturation3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S144>/Saturation3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S144>/Saturation3' */

  /* Product: '<S144>/Product' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_oh =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b *
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity;
  for (i = 0; i < 21; i++) {
    /* Gain: '<S144>/Gain' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain[i] =
      D_20231120_Modell_Inbetrieb_cal->Gain_Gain_f[i] *
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_oh;
  }

  for (i = 0; i < 21; i++) {
    /* Sum: '<S144>/Sum' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_a[i] =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 +
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain[i];
  }

  /* UnaryMinus: '<S145>/Unary Minus3' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus3 =
    -D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f;

  /* DataTypeConversion: '<S144>/Data Type Conversion1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_f =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus3;

  /* UnaryMinus: '<S144>/Unary Minus1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1 =
    -D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_f;

  /* Saturate: '<S144>/Saturation' */
  rightEgoParameters_idx_2 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1;
  leftEgoParameters_idx_0 =
    D_20231120_Modell_Inbetrieb_cal->Saturation_LowerSat_d;
  leftEgoParameters_idx_1 =
    D_20231120_Modell_Inbetrieb_cal->Saturation_UpperSat_l;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S144>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S144>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S144>/Saturation' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S144>/Saturation' */

  /* UnaryMinus: '<S145>/Unary Minus2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus2 =
    -D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l;

  /* DataTypeConversion: '<S144>/Data Type Conversion' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_gl =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus2;

  /* UnaryMinus: '<S144>/Unary Minus' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus =
    -D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_gl;

  /* Saturate: '<S144>/Saturation1' */
  rightEgoParameters_idx_2 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus;
  leftEgoParameters_idx_0 =
    D_20231120_Modell_Inbetrieb_cal->Saturation1_LowerSat_n;
  leftEgoParameters_idx_1 =
    D_20231120_Modell_Inbetrieb_cal->Saturation1_UpperSat_d;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S144>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S144>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S144>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S144>/Saturation1' */

  /* Outputs for Atomic SubSystem: '<S138>/Path Following Control System' */
  /* Constant: '<S11>/Set Velocity' */
  PathFollowingControlSystem(D_20231120_Modell_Inbetrieb_cal->SetVelocity_Value,
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp,
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_a,
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f,
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l,
    *get_min_ac(), *get_min_steer(), *get_max_ac(), *get_max_steer(),
    *get_default_spacing(),
    &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i,
    &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.PathFollowingControlSystem_i,
    &D_20231120_Modell_Inbetrieb_cal->PathFollowingControlSystem_cal);

  /* End of Outputs for SubSystem: '<S138>/Path Following Control System' */

  /* Lookup_n-D: '<S1>/1-D Lookup Table2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2 =
    look1_binlxpw
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
     [0], D_20231120_Modell_Inbetrieb_cal->uDLookupTable2_bp01Data,
     D_20231120_Modell_Inbetrieb_cal->uDLookupTable2_tableData, 1U);

  /* RateTransition generated from: '<S1>/Switch' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufI_gp
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufI_gp
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_eu
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufI_gp]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2;

  /* RateTransition generated from: '<S2>/Byte Packing' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
     == 0);
  i =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
    * 24;
  for (int32_T i_0 = 0; i_0 < 24; i_0++) {
    /* RateTransition generated from: '<S2>/Byte Packing' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtBytePackingOutport1
      [i_0] =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_Buf
      [i_0 + i];
  }

  /* S-Function (slrealtimeUDPSend): '<S2>/UDP Send' */
  {
    try {
      slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
        udp::Socket*>
        (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_PWORK);
      uint8_t *remoteAddress = (uint8_t *)
        D_20231120_Modell_Inbetrieb_cal->UDPSend_toAddress;
      uint16_t *remotePort = (uint16_t *)
        &D_20231120_Modell_Inbetrieb_cal->UDPSend_toPort;
      udpSock->resetRemoteEndpoint(remoteAddress, remotePort);
      int dataLen =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_f;
      dataLen = (dataLen <=
                 D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK
                 [0]) ? dataLen :
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK[0];
      dataLen = (dataLen <= -1) ? 0 : dataLen;
      void *dataPort =
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtBytePackingOutport1
        [0];
      size_t numBytesSend = udpSock->send((const char*)dataPort,dataLen);
    } catch (std::exception& e) {
      std::string tmp = std::string(e.what());
      static std::string eMsg = tmp;
      rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                        eMsg.c_str());
      rtmSetStopRequested(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          1);
      ;
    }
  }

  /* Lookup_n-D: '<S3>/1-D Lookup Table2' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2_i =
    look1_binlxpw
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
     [0], D_20231120_Modell_Inbetrieb_cal->uDLookupTable2_bp01Data_l,
     D_20231120_Modell_Inbetrieb_cal->uDLookupTable2_tableData_j, 1U);

  /* RateTransition generated from: '<S3>/Switch' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2_i;

  /* Gain: '<S73>/Lenkung umdrehen' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.JetsonWinkelRad =
    D_20231120_Modell_Inbetrieb_cal->Lenkungumdrehen_Gain *
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
    [1];

  /* Gain: '<S73>/Umrechnen von rad in grad' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.JetsonWinkelGrad =
    D_20231120_Modell_Inbetrieb_cal->Umrechnenvonradingrad_Gain *
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.JetsonWinkelRad;

  /* Lookup_n-D: '<S73>/1-D Lookup Table2' incorporates:
   *  Gain: '<S73>/Umrechnen von rad in grad'
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.JetsonWinkelGradNormiert
    = look1_binlxpw
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.JetsonWinkelGrad,
     D_20231120_Modell_Inbetrieb_cal->uDLookupTable2_bp01Data_d,
     D_20231120_Modell_Inbetrieb_cal->uDLookupTable2_tableData_c, 1U);

  /* Saturate: '<S73>/Saturation1' */
  rightEgoParameters_idx_2 =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.JetsonWinkelGradNormiert;
  leftEgoParameters_idx_0 =
    D_20231120_Modell_Inbetrieb_cal->Saturation1_LowerSat_g;
  leftEgoParameters_idx_1 =
    D_20231120_Modell_Inbetrieb_cal->Saturation1_UpperSat_o;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S73>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_d =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S73>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_d =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S73>/Saturation1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_d =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S73>/Saturation1' */
  /* RateTransition generated from: '<S10>/Index Vector1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_WrB
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_WrB
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_WrB]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_d;

  /* RateTransition generated from: '<S10>/Switch1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_WrBufIdx
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_WrBufIdx
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_Buf
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_WrBufIdx]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_d;

  /* RateTransition generated from: '<S10>/Switch' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g
    = static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g
     == 0);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_e
    [D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g]
    = D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_d;

  /* Update for Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f;

  /* Update for Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l;

  /* Update for Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m;

  /* Update for Delay generated from: '<S137>/Delay1' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a;

  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.1, which is the step size
   * of the task. Size of "clockTick3" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick3++;
  if (!D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick3)
  {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH3++;
  }
}

/* Model step function for TID4 */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step4(void) /* Sample time: [60.0s, 0.0s] */
{
  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx =
    static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx ==
     0);

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx];

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx =
    static_cast<int8_T>
    (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx == 0);

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_Buf[D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx];

  /* S-Function (Monitorausgabe_sfun): '<Root>/S-Function Builder' */
  Monitorausgabe_sfun_Outputs_wrapper_cgen
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer,
     &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC,
     &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SFunctionBuilder);

  /* Update absolute time */
  /* The "clockTick4" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 60.0, which is the step size
   * of the task. Size of "clockTick4" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick4 and the high bits
   * Timing.clockTickH4. When the low bit overflows to 0, the high bits increment.
   */
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick4++;
  if (!D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick4)
  {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH4++;
  }
}

/* Model initialize function */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* Set task counter limit used by the static main program */
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[0] = 1;
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[1] = 1;
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[2] = 5;
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[3] = 100;
  (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[4] = 60000;

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.simTimeStep);
    rtsiSetTPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &rtmGetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtsiSetStepSizePtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0);
    rtsiSetdXPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->derivs);
    rtsiSetContStatesPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       (real_T **)
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->contStates);
    rtsiSetNumContStatesPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       (&rtmGetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)));
    rtsiSetRTModelPtr
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
  }

  rtsiSetSimTimeStep
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
     MAJOR_TIME_STEP);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->intgData.f[0] =
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->odeF[0];
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->contStates =
    ((X_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *)
     &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X);
  rtsiSetSolverData
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
     static_cast<void *>
     (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->intgData));
  rtsiSetIsMinorTimeStepWithModeChange
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo, false);
  rtsiSetSolverName
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,"ode1");
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfoPtr =
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimeTaskIDArray;
    int_T i;
    for (i = 0; i < 5; i++) {
      mdlTsMap[i] = i;
    }

    /* polyspace +2 MISRA2012:D4.1 [Justified:Low] "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M points to
       static memory which is guaranteed to be non-NULL" */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimeTaskIDPtr
      = (&mdlTsMap[0]);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes =
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimesArray
       [0]);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes =
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimesArray
       [0]);

    /* task periods */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[0]
      = (0.0);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[1]
      = (0.001);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[2]
      = (0.005);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[3]
      = (0.1);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[4]
      = (60.0);

    /* task offsets */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[0]
      = (0.0);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[1]
      = (0.0);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[2]
      = (0.0);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[3]
      = (0.0);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[4]
      = (0.0);
  }

  rtmSetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
             &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.tArray
             [0]);

  {
    int_T *mdlSampleHits =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHitsArray;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
      = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleHits = (
      &mdlSampleHits[0]);
  }

  rtmSetTFinal(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, -1);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0 =
    0.001;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize1 =
    0.001;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize2 =
    0.005;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfoPtr =
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize =
    (0.001);
  rtsiSetFixedStepSize
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo, 0.001);
  rtsiSetSolverMode
    (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
     SOLVER_MODE_MULTITASKING);

  /* block I/O */
  (void) std::memset((static_cast<void *>
                      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B)),
                     0,
                     sizeof
                     (B_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T));

  {
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2 =
      CAN_DATATYPE_GROUND;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e =
      CAN_DATATYPE_GROUND;
  }

  /* states (continuous) */
  {
    (void) std::memset(static_cast<void *>
                       (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X),
                       0,
                       sizeof
                       (X_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T));
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>
                     (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW),
                     0,
                     sizeof
                     (DW_D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_T));

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo =
      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.sfcnInfo;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)));
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numSampTimes =
      (5);
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numSampTimes);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [0] = &(rtmGetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [0]);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [1] = &(rtmGetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [1]);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [2] = &(rtmGetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [2]);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [3] = &(rtmGetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [3]);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [4] = &(rtmGetTPtr(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [4]);
    rtssSetTPtrPtr(sfcnInfo,
                   D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart
                     (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal
                     (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetStepSizePtr(sfcnInfo,
                       &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo,
                      &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         solverInfoPtr);
  }

  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numSFcns = (14);

  /* register each child */
  {
    (void) std::memset(static_cast<void *>
                       (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.childSFunctions
                        [0]), 0,
                       14*sizeof(SimStruct));
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions =
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.childSFunctionPtrs
       [0]);

    {
      int_T i;
      for (i = 0; i < 14; i++) {
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[i]
          =
          (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.childSFunctions
           [i]);
      }
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S68>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1_f));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 1/CAN Read1");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->CANRead1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK_o);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK_o);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S69>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 3/CAN Read1");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->CANRead1_P1_Size_n);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Setup  (sg_IO191_setup_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [2]);
      }

      /* path info */
      ssSetModelName(rts, "Setup ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Setup ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P9_Size);
      }

      /* work vectors */
      ssSetRWork(rts, (real_T *)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_RWORK
                 [0]);
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 2);

        /* RWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_RWORK
                   [0]);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_PWORK);
      }

      /* registration */
      sg_IO191_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Analog input  (sg_IO191_ad_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [3]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 4);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4));
        }
      }

      /* path info */
      ssSetModelName(rts, "Analog input ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Analog input ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analoginput_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_IWORK
                 [0]);
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 2);

        /* IWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_IWORK
                   [0]);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_PWORK);
      }

      /* registration */
      sg_IO191_ad_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Digital input  (sg_IO191_di_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o4));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidthAsInt(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o5));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidthAsInt(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o6));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidthAsInt(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o7));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidthAsInt(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o8));
        }
      }

      /* path info */
      ssSetModelName(rts, "Digital input ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Digital input ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 4);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P4_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK);
      }

      /* registration */
      sg_IO191_di_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S7>/Isolated digital input  (sg_IO291_di_isol_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[5]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [5]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [5]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 3);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o3));
        }
      }

      /* path info */
      ssSetModelName(rts, "Isolated digital input ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/Isolated digital input ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Isolateddigitalinput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Isolateddigitalinput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Isolateddigitalinput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Isolateddigitalinput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Isolateddigitalinput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Isolateddigitalinput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Isolateddigitalinput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Isolateddigitalinput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_di_isol_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Analog output  (sg_IO191_da_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[6]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [6]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [6]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 4);
        ssSetPortInfoForInputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.inputPortInfo
          [0]);
        ssSetPortInfoForInputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.inputPortInfo
          [0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.inputPortUnits
          [0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_1_G);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_2_G);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidthAsInt(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_1_G);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidthAsInt(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_2_G);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidthAsInt(rts, 3, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Analog output ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Analog output ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Analogoutput_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analogoutput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analogoutput_PWORK);
      }

      /* registration */
      sg_IO191_da_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Digital output  (sg_IO191_do_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[7]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [7]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 8);
        ssSetPortInfoForInputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortInfo
          [0]);
        ssSetPortInfoForInputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortInfo
          [0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortUnits
          [0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        ssSetInputPortUnit(rts, 4, 0);
        ssSetInputPortUnit(rts, 5, 0);
        ssSetInputPortUnit(rts, 6, 0);
        ssSetInputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);
        ssSetInputPortIsContinuousQuantity(rts, 4, 0);
        ssSetInputPortIsContinuousQuantity(rts, 5, 0);
        ssSetInputPortIsContinuousQuantity(rts, 6, 0);
        ssSetInputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_1_On);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_2_On);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidthAsInt(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_1_On);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidthAsInt(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_2_On);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidthAsInt(rts, 3, 1);
        }

        /* port 4 */
        {
          ssSetInputPortRequiredContiguous(rts, 4, 1);
          ssSetInputPortSignal(rts, 4,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Br_Licht_On);
          _ssSetInputPortNumDimensions(rts, 4, 1);
          ssSetInputPortWidthAsInt(rts, 4, 1);
        }

        /* port 5 */
        {
          ssSetInputPortRequiredContiguous(rts, 5, 1);
          ssSetInputPortSignal(rts, 5,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant);
          _ssSetInputPortNumDimensions(rts, 5, 1);
          ssSetInputPortWidthAsInt(rts, 5, 1);
        }

        /* port 6 */
        {
          ssSetInputPortRequiredContiguous(rts, 6, 1);
          ssSetInputPortSignal(rts, 6,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant);
          _ssSetInputPortNumDimensions(rts, 6, 1);
          ssSetInputPortWidthAsInt(rts, 6, 1);
        }

        /* port 7 */
        {
          ssSetInputPortRequiredContiguous(rts, 7, 1);
          ssSetInputPortSignal(rts, 7,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant);
          _ssSetInputPortNumDimensions(rts, 7, 1);
          ssSetInputPortWidthAsInt(rts, 7, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Digital output ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Digital output ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitaloutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitaloutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitaloutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitaloutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitaloutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitaloutput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitaloutput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitaloutput_PWORK);
      }

      /* registration */
      sg_IO191_do_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);
      _ssSetInputPortConnected(rts, 4, 1);
      _ssSetInputPortConnected(rts, 5, 1);
      _ssSetInputPortConnected(rts, 6, 1);
      _ssSetInputPortConnected(rts, 7, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
      ssSetInputPortBufferDstPort(rts, 4, -1);
      ssSetInputPortBufferDstPort(rts, 5, -1);
      ssSetInputPortBufferDstPort(rts, 6, -1);
      ssSetInputPortBufferDstPort(rts, 7, -1);
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S7>/Setup  (sg_IO291_setup_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[8]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [8]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [8]);
      }

      /* path info */
      ssSetModelName(rts, "Setup ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/Setup ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P1_Size_k);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P3_Size_j);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P4_Size_g);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Setup_P5_Size_e);
      }

      /* registration */
      sg_IO291_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S8>/Digital input (sg_fpga_di_sf_a2) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[9]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [9]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[9]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[9]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[9]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[9]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [9]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1_p));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2_b));
        }
      }

      /* path info */
      ssSetModelName(rts, "Digital input");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO397/Digital input");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P1_Size_h);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P2_Size_g);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P3_Size_n);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P4_Size_m);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->Digitalinput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK_i
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK_i
                   [0]);
      }

      /* registration */
      sg_fpga_di_sf_a2(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S7>/FET digital output  (sg_IO291_do_fet_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [10];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[10]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [10]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[10]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[10]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[10]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[10]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [10]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 5);
        ssSetPortInfoForInputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortInfo
          [0]);
        ssSetPortInfoForInputs(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortInfo
          [0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortUnits
          [0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        ssSetInputPortUnit(rts, 4, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);
        ssSetInputPortIsContinuousQuantity(rts, 4, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_g);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_c);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidthAsInt(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Reverse);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidthAsInt(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LED_Totmann);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidthAsInt(rts, 3, 1);
        }

        /* port 4 */
        {
          ssSetInputPortRequiredContiguous(rts, 4, 1);
          ssSetInputPortSignal(rts, 4,
                               &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe);
          _ssSetInputPortNumDimensions(rts, 4, 1);
          ssSetInputPortWidthAsInt(rts, 4, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "FET digital output ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/FET digital output ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->FETdigitaloutput_P8_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FETdigitaloutput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FETdigitaloutput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_do_fet_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);
      _ssSetInputPortConnected(rts, 4, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
      ssSetInputPortBufferDstPort(rts, 4, -1);
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S7>/LVTTL digital input  (sg_IO291_di_ttl_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [11];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[11]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [11]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[11]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[11]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[11]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[11]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [11]);
      }

      /* path info */
      ssSetModelName(rts, "LVTTL digital input ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/LVTTL digital input ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitalinput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitalinput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitalinput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitalinput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitalinput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitalinput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitalinput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitalinput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_di_ttl_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S7>/LVTTL digital output  (sg_IO291_do_ttl_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [12];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[12]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [12]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[12]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[12]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[12]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[12]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [12]);
      }

      /* path info */
      ssSetModelName(rts, "LVTTL digital output ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/LVTTL digital output ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P8_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitaloutput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitaloutput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_do_ttl_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S9>/CAN Setup  (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [13];

      /* timing info */
      time_T *sfcnPeriod =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.sfcnPeriod;
      time_T *sfcnOffset =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.sfcnOffset;
      int_T *sfcnTsMap =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[13]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [13]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[13]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[13]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[13]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[13]);
        ssSetPeriodicStatesInfo(rts,
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [13]);
      }

      /* path info */
      ssSetModelName(rts, "CAN Setup ");
      ssSetPath(rts,
                "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Setup ");
      ssSetRTModel(rts,D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.params;
        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->CANSetup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->CANSetup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20231120_Modell_Inbetrieb_cal->CANSetup_P3_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANSetup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANSetup_PWORK);
      }

      /* registration */
      sg_IO602_IO691_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }
  }

  {
    /* user code (Start function Header) */
    {
      uint16_t moduleArchitecture;
      int32_t ErrCode;
      uint32_t *bitstream, i;
      uint8_t *fpgacode;
      char *devname;
      sg_fpga_io3xxModuleIdT moduleId;
      FILE *mcs;
      static char mcsFileName[200];
      static char msg[256];
      sg_initModelRun();

      // Determine path to bitstream file
      if (sg_getModelBaseDir(mcsFileName, sizeof(mcsFileName))) {
        sprintf(msg,
                "Could not determine location of the model on the target machine.");
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        return;
      }

      if ((strlen(mcsFileName) + strlen("/fpga/speedgoat_IO397_50k_Comms.mcs") +
           1) > sizeof(mcsFileName)) {
        sprintf(msg,
                "Path to the bitstream (model name + bitstream name) is too long.");
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        return;
      }

      strcat(mcsFileName, "/fpga/speedgoat_IO397_50k_Comms.mcs");
      SG_PRINTF(DEBUG, "Bitstream: %s\n", mcsFileName);
      if ((mcs = fopen(mcsFileName, "r")) == NULL) {
        sprintf(msg, "Bitstream file not found at %s.\n", mcsFileName);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      bitstream = (uint32_t *) malloc(2192012*sizeof(uint32_t));
      fpgacode = (uint8_t *) malloc(2192012*sizeof(uint8_t));
      for (i = 0; i<2192012; i++) {
        fscanf(mcs,"%d\n",&bitstream[i]);
        fpgacode[i] = bitstream[i];
      }

      fclose(mcs);

      // Get module IDs (PIC info)
      SG_PRINTF(INFO,"Getting module information.\n");
      ErrCode = (int32_t)sg_fpga_IO3xxGetModuleId(39750, &moduleId);
      if (ErrCode >= 0) {
        devname = moduleId.devname;
        moduleArchitecture = moduleId.moduleArchitecture;
        SG_PRINTF(DEBUG, "boardType: %d\n", 39750);
        SG_PRINTF(DEBUG, "ErrCode: %d\n", ErrCode);
        SG_PRINTF(DEBUG, "******************************************\n");
        SG_PRINTF(DEBUG, "moduleId->devname: %s\n", moduleId.devname);
        SG_PRINTF(DEBUG, "moduleId->vendorid: 0x%x\n", moduleId.vendorid);
        SG_PRINTF(DEBUG, "moduleId->subvendorid: 0x%x\n", moduleId.subvendorid);
        SG_PRINTF(DEBUG, "moduleId->deviceid: 0x%x\n", moduleId.deviceid);
        SG_PRINTF(DEBUG, "moduleId->subdeviceid: 0x%x\n", moduleId.subdeviceid);
        SG_PRINTF(DEBUG, "moduleId.moduleArchitecture: %d\n",
                  moduleId.moduleArchitecture);
      } else {
        sprintf(msg, "Setup block: board type unknown.");
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      // Support for different architectures
      SG_PRINTF(INFO,"Running board specific programming file.\n");
      switch (moduleArchitecture)
      {
       case TEWS_TPMC:
        ErrCode = IO30x_programFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (int32_t)0, (uint32_t)2192012, bitstream,
          &moduleId);
        break;

       case TEWS_TXMC:
        if (39750 == 324200) {
          ErrCode = IO324_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            (uint32_t)-517031625, &moduleId, (uint32_t)84,
            (uint32_t)0);
        } else                         // IO31x, IO32x
        {
          ErrCode = IO31x_IO32x_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            &moduleId, (uint32_t)84);
        }
        break;

       case ACROMAG_PMC:
        ErrCode = IO331_programmFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (uint32_t)2192012, bitstream, &moduleId);
        break;

       case ACROMAG_XMC:
        if (39750 == 332) {
          ErrCode = IO332_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (uint32_t)2192012, bitstream, (uint32_t)-517031625,
            &moduleId);
        } else                         // IO333
        {
          ErrCode = IO333_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (uint32_t)2192012, bitstream, (uint32_t)-517031625,
            &moduleId);
        }
        break;

       case TEWS_MPCIE:
        ErrCode = IO39x_programmFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (uint32_t)2192012, fpgacode, (uint32_t)84, &moduleId);
        break;

       default:
        sprintf(msg, "Setup block: module architecture incorrect.");
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);

        // Free the bitstream allocation
        SG_PRINTF(ERROR,msg);
        free(bitstream);
        free(fpgacode);
        return;
      }

      // Free the bitstream allocation
      free(bitstream);
      free(fpgacode);

      // Handle any error states
      switch (ErrCode)
      {
       case NO_ERR:
        // Nothing to do.
        break;

       case BOARD_NOT_FOUND:
        sprintf(msg, "Setup block %s: Board could not be found.\n",devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case EEPROM_ERROR:
        sprintf(msg, "Setup block %s: Error updating board EEPROM.\n", devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case REPROG_ERROR:
        sprintf(msg, "Setup block %s: Error writing new bitstream to FPGA.\n",
                devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case FLASH_ERROR:
        sprintf(msg, "Setup block %s: Bitstream flash storage error.\n", devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case BIST_ERROR:
        sprintf(msg, "Setup block %s: Built in self test error.\n", devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case ICAP_RECONF_FAILED:
        sprintf(msg,
                "Setup block %s: ICAP Reconfiguration was not successful.\n",
                devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case BOARD_TYPE_UNKNOWN:
        sprintf(msg, "Setup block %s: The board type selected is unknown.\n",
                devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       default:
        sprintf(msg, "Setup block %s: An unknown error occurred.\n",devname);
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      if (1 == 2) {
        IO3xx_21_update(devname, 1, 0, 0, 0);
      } else if (1 == 3) {
        IO3xx_22_update(devname, 1, 0, 0, 0);
      } else if (1 == 4) {
        IO3xx_24_update(devname, 1, 0, 0, 0, 0);
      }
    }

    /* Start for S-Function (sg_IO191_setup_s): '<S6>/Setup ' */
    /* Level2 S-Function Block: '<S6>/Setup ' (sg_IO191_setup_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO191_ad_s): '<S6>/Analog input ' */
    /* Level2 S-Function Block: '<S6>/Analog input ' (sg_IO191_ad_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO191_di_s): '<S6>/Digital input ' */
    /* Level2 S-Function Block: '<S6>/Digital input ' (sg_IO191_di_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition generated from: '<S3>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1 =
      D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_InitialCo;

    /* Start for S-Function (slrealtimeUDPReceive): '<S2>/UDP Receive1' */
    {
      try {
        uint8_t *tempAddr = nullptr;
        uint8_t *tempInterface = nullptr;
        slrealtime::ip::udp::Socket *udpSock = (slrealtime::ip::udp::Socket *)
          slrealtime::ip::SocketFactory::createSocket(slrealtime::ip::SocketType::
          UDP, "192.168.9.10",25001U);
        if (tempAddr)
          delete tempAddr;
        if (tempInterface)
          delete tempInterface;
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_IWORK[
          0] = 12;
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK[
          0] = reinterpret_cast<void*>(udpSock);
        char *buffer = (char *)calloc(65507,sizeof(char));
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK[
          1] = (void*)buffer;
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }

    /* Start for InitialCondition: '<S2>/IC1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_b
      = true;

    /* Start for InitialCondition: '<S12>/IC' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime =
      (rtMinusInf);

    /* Start for InitialCondition: '<S3>/IC2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime =
      (rtMinusInf);

    /* Start for InitialCondition: '<S3>/IC3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime =
      (rtMinusInf);

    /* Start for RateTransition generated from: '<S10>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_i
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_Initial_j;

    /* Start for InitialCondition: '<S2>/IC' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime_j =
      true;

    /* Start for InitialCondition: '<S12>/IC1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime =
      (rtMinusInf);

    /* Start for RateTransition generated from: '<S10>/Index Vector1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtIndexVector1Inport3
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtIndexVector1Inport3_Ini;

    /* Start for FromFile: '<S72>/From File' */
    {
      static const real_T tuData[11366] = { 0.0, 0.1, 0.2, 0.30000000000000004,
        0.4, 0.5, 0.60000000000000009, 0.70000000000000007, 0.8, 0.9, 1.0, 1.1,
        1.2000000000000002, 1.3, 1.4000000000000001, 1.5, 1.6,
        1.7000000000000002, 1.8, 1.9000000000000001, 2.0, 2.1, 2.2,
        2.3000000000000003, 2.4000000000000004, 2.5, 2.6, 2.7,
        2.8000000000000003, 2.9000000000000004, 3.0, 3.1, 3.2,
        3.3000000000000003, 3.4000000000000004, 3.5, 3.6, 3.7,
        3.8000000000000003, 3.9000000000000004, 4.0, 4.1000000000000005, 4.2,
        4.3, 4.4, 4.5, 4.6000000000000005, 4.7, 4.8000000000000007, 4.9, 5.0,
        5.1000000000000005, 5.2, 5.3000000000000007, 5.4, 5.5,
        5.6000000000000005, 5.7, 5.8000000000000007, 5.9, 6.0,
        6.1000000000000005, 6.2, 6.3000000000000007, 6.4, 6.5,
        6.6000000000000005, 6.7, 6.8000000000000007, 6.9, 7.0,
        7.1000000000000005, 7.2, 7.3000000000000007, 7.4, 7.5,
        7.6000000000000005, 7.7, 7.8000000000000007, 7.9, 8.0, 8.1,
        8.2000000000000011, 8.3, 8.4, 8.5, 8.6, 8.7000000000000011, 8.8, 8.9,
        9.0, 9.1, 9.2000000000000011, 9.3, 9.4, 9.5, 9.6000000000000014,
        9.7000000000000011, 9.8, 9.9, 10.0, 10.100000000000001,
        10.200000000000001, 10.3, 10.4, 10.5, 10.600000000000001,
        10.700000000000001, 10.8, 10.9, 11.0, 11.100000000000001,
        11.200000000000001, 11.3, 11.4, 11.5, 11.600000000000001,
        11.700000000000001, 11.8, 11.9, 12.0, 12.100000000000001,
        12.200000000000001, 12.3, 12.4, 12.5, 12.600000000000001,
        12.700000000000001, 12.8, 12.9, 13.0, 13.100000000000001,
        13.200000000000001, 13.3, 13.4, 13.5, 13.600000000000001,
        13.700000000000001, 13.8, 13.9, 14.0, 14.100000000000001,
        14.200000000000001, 14.3, 14.4, 14.5, 14.600000000000001,
        14.700000000000001, 14.8, 14.9, 15.0, 15.100000000000001,
        15.200000000000001, 15.3, 15.4, 15.5, 15.600000000000001,
        15.700000000000001, 15.8, 15.9, 16.0, 16.1, 16.2, 16.3,
        16.400000000000002, 16.5, 16.6, 16.7, 16.8, 16.900000000000002, 17.0,
        17.1, 17.2, 17.3, 17.400000000000002, 17.5, 17.6, 17.7, 17.8,
        17.900000000000002, 18.0, 18.1, 18.2, 18.3, 18.400000000000002, 18.5,
        18.6, 18.7, 18.8, 18.900000000000002, 19.0, 19.1, 19.200000000000003,
        19.3, 19.400000000000002, 19.5, 19.6, 19.700000000000003, 19.8,
        19.900000000000002, 20.0, 20.1, 20.200000000000003, 20.3,
        20.400000000000002, 20.5, 20.6, 20.700000000000003, 20.8,
        20.900000000000002, 21.0, 21.1, 21.200000000000003, 21.3,
        21.400000000000002, 21.5, 21.6, 21.700000000000003, 21.8,
        21.900000000000002, 22.0, 22.1, 22.200000000000003, 22.3,
        22.400000000000002, 22.5, 22.6, 22.700000000000003, 22.8,
        22.900000000000002, 23.0, 23.1, 23.200000000000003, 23.3,
        23.400000000000002, 23.5, 23.6, 23.700000000000003, 23.8,
        23.900000000000002, 24.0, 24.1, 24.200000000000003, 24.3,
        24.400000000000002, 24.5, 24.6, 24.700000000000003, 24.8,
        24.900000000000002, 25.0, 25.1, 25.200000000000003, 25.3,
        25.400000000000002, 25.5, 25.6, 25.700000000000003, 25.8,
        25.900000000000002, 26.0, 26.1, 26.200000000000003, 26.3,
        26.400000000000002, 26.5, 26.6, 26.700000000000003, 26.8,
        26.900000000000002, 27.0, 27.1, 27.200000000000003, 27.3,
        27.400000000000002, 27.5, 27.6, 27.700000000000003, 27.8,
        27.900000000000002, 28.0, 28.1, 28.200000000000003, 28.3,
        28.400000000000002, 28.5, 28.6, 28.700000000000003, 28.8,
        28.900000000000002, 29.0, 29.1, 29.200000000000003, 29.3,
        29.400000000000002, 29.5, 29.6, 29.700000000000003, 29.8,
        29.900000000000002, 30.0, 30.1, 30.200000000000003, 30.3,
        30.400000000000002, 30.5, 30.6, 30.700000000000003, 30.8,
        30.900000000000002, 31.0, 31.1, 31.200000000000003, 31.3,
        31.400000000000002, 31.5, 31.6, 31.700000000000003, 31.8,
        31.900000000000002, 32.0, 32.1, 32.2, 32.300000000000004, 32.4, 32.5,
        32.6, 32.7, 32.800000000000004, 32.9, 33.0, 33.1, 33.2,
        33.300000000000004, 33.4, 33.5, 33.6, 33.7, 33.800000000000004, 33.9,
        34.0, 34.1, 34.2, 34.300000000000004, 34.4, 34.5, 34.6, 34.7,
        34.800000000000004, 34.9, 35.0, 35.1, 35.2, 35.300000000000004, 35.4,
        35.5, 35.6, 35.7, 35.800000000000004, 35.9, 36.0, 36.1, 36.2,
        36.300000000000004, 36.4, 36.5, 36.6, 36.7, 36.800000000000004, 36.9,
        37.0, 37.1, 37.2, 37.300000000000004, 37.4, 37.5, 37.6, 37.7,
        37.800000000000004, 37.9, 38.0, 38.1, 38.2, 38.300000000000004,
        38.400000000000006, 38.5, 38.6, 38.7, 38.800000000000004,
        38.900000000000006, 39.0, 39.1, 39.2, 39.300000000000004,
        39.400000000000006, 39.5, 39.6, 39.7, 39.800000000000004,
        39.900000000000006, 40.0, 40.1, 40.2, 40.300000000000004,
        40.400000000000006, 40.5, 40.6, 40.7, 40.800000000000004,
        40.900000000000006, 41.0, 41.1, 41.2, 41.300000000000004,
        41.400000000000006, 41.5, 41.6, 41.7, 41.800000000000004,
        41.900000000000006, 42.0, 42.1, 42.2, 42.300000000000004,
        42.400000000000006, 42.5, 42.6, 42.7, 42.800000000000004,
        42.900000000000006, 43.0, 43.1, 43.2, 43.300000000000004,
        43.400000000000006, 43.5, 43.6, 43.7, 43.800000000000004,
        43.900000000000006, 44.0, 44.1, 44.2, 44.300000000000004,
        44.400000000000006, 44.5, 44.6, 44.7, 44.800000000000004,
        44.900000000000006, 45.0, 45.1, 45.2, 45.300000000000004,
        45.400000000000006, 45.5, 45.6, 45.7, 45.800000000000004,
        45.900000000000006, 46.0, 46.1, 46.2, 46.300000000000004,
        46.400000000000006, 46.5, 46.6, 46.7, 46.800000000000004,
        46.900000000000006, 47.0, 47.1, 47.2, 47.300000000000004,
        47.400000000000006, 47.5, 47.6, 47.7, 47.800000000000004,
        47.900000000000006, 48.0, 48.1, 48.2, 48.300000000000004,
        48.400000000000006, 48.5, 48.6, 48.7, 48.800000000000004,
        48.900000000000006, 49.0, 49.1, 49.2, 49.300000000000004,
        49.400000000000006, 49.5, 49.6, 49.7, 49.800000000000004,
        49.900000000000006, 50.0, 50.1, 50.2, 50.300000000000004,
        50.400000000000006, 50.5, 50.6, 50.7, 50.800000000000004,
        50.900000000000006, 51.0, 51.1, 51.2, 51.300000000000004,
        51.400000000000006, 51.5, 51.6, 51.7, 51.800000000000004,
        51.900000000000006, 52.0, 52.1, 52.2, 52.300000000000004,
        52.400000000000006, 52.5, 52.6, 52.7, 52.800000000000004,
        52.900000000000006, 53.0, 53.1, 53.2, 53.300000000000004,
        53.400000000000006, 53.5, 53.6, 53.7, 53.800000000000004,
        53.900000000000006, 54.0, 54.1, 54.2, 54.300000000000004,
        54.400000000000006, 54.5, 54.6, 54.7, 54.800000000000004,
        54.900000000000006, 55.0, 55.1, 55.2, 55.300000000000004,
        55.400000000000006, 55.5, 55.6, 55.7, 55.800000000000004,
        55.900000000000006, 56.0, 56.1, 56.2, 56.300000000000004,
        56.400000000000006, 56.5, 56.6, 56.7, 56.800000000000004,
        56.900000000000006, 57.0, 57.1, 57.2, 57.300000000000004,
        57.400000000000006, 57.5, 57.6, 57.7, 57.800000000000004,
        57.900000000000006, 58.0, 58.1, 58.2, 58.300000000000004,
        58.400000000000006, 58.5, 58.6, 58.7, 58.800000000000004,
        58.900000000000006, 59.0, 59.1, 59.2, 59.300000000000004,
        59.400000000000006, 59.5, 59.6, 59.7, 59.800000000000004,
        59.900000000000006, 60.0, 60.1, 60.2, 60.300000000000004,
        60.400000000000006, 60.5, 60.6, 60.7, 60.800000000000004,
        60.900000000000006, 61.0, 61.1, 61.2, 61.300000000000004,
        61.400000000000006, 61.5, 61.6, 61.7, 61.800000000000004,
        61.900000000000006, 62.0, 62.1, 62.2, 62.300000000000004,
        62.400000000000006, 62.5, 62.6, 62.7, 62.800000000000004,
        62.900000000000006, 63.0, 63.1, 63.2, 63.300000000000004,
        63.400000000000006, 63.5, 63.6, 63.7, 63.800000000000004,
        63.900000000000006, 64.0, 64.100000000000009, 64.2, 64.3, 64.4, 64.5,
        64.600000000000009, 64.7, 64.8, 64.9, 65.0, 65.100000000000009, 65.2,
        65.3, 65.4, 65.5, 65.600000000000009, 65.7, 65.8, 65.9, 66.0,
        66.100000000000009, 66.2, 66.3, 66.4, 66.5, 66.600000000000009, 66.7,
        66.8, 66.9, 67.0, 67.100000000000009, 67.2, 67.3, 67.4, 67.5,
        67.600000000000009, 67.7, 67.8, 67.9, 68.0, 68.100000000000009, 68.2,
        68.3, 68.4, 68.5, 68.600000000000009, 68.7, 68.8, 68.9, 69.0,
        69.100000000000009, 69.2, 69.3, 69.4, 69.5, 69.600000000000009, 69.7,
        69.8, 69.9, 70.0, 70.100000000000009, 70.2, 70.3, 70.4, 70.5,
        70.600000000000009, 70.7, 70.8, 70.9, 71.0, 71.100000000000009, 71.2,
        71.3, 71.4, 71.5, 71.600000000000009, 71.7, 71.8, 71.9, 72.0,
        72.100000000000009, 72.2, 72.3, 72.4, 72.5, 72.600000000000009, 72.7,
        72.8, 72.9, 73.0, 73.100000000000009, 73.2, 73.3, 73.4, 73.5,
        73.600000000000009, 73.7, 73.8, 73.9, 74.0, 74.100000000000009, 74.2,
        74.3, 74.4, 74.5, 74.600000000000009, 74.7, 74.8, 74.9, 75.0,
        75.100000000000009, 75.2, 75.3, 75.4, 75.5, 75.600000000000009, 75.7,
        75.8, 75.9, 76.0, 76.100000000000009, 76.2, 76.3, 76.4, 76.5,
        76.600000000000009, 76.7, 76.800000000000011, 76.9, 77.0,
        77.100000000000009, 77.2, 77.300000000000011, 77.4, 77.5,
        77.600000000000009, 77.7, 77.800000000000011, 77.9, 78.0,
        78.100000000000009, 78.2, 78.300000000000011, 78.4, 78.5,
        78.600000000000009, 78.7, 78.800000000000011, 78.9, 79.0,
        79.100000000000009, 79.2, 79.300000000000011, 79.4, 79.5,
        79.600000000000009, 79.7, 79.800000000000011, 79.9, 80.0,
        80.100000000000009, 80.2, 80.300000000000011, 80.4, 80.5,
        80.600000000000009, 80.7, 80.800000000000011, 80.9, 81.0,
        81.100000000000009, 81.2, 81.300000000000011, 81.4, 81.5,
        81.600000000000009, 81.7, 81.800000000000011, 81.9, 82.0,
        82.100000000000009, 82.2, 82.300000000000011, 82.4, 82.5,
        82.600000000000009, 82.7, 82.800000000000011, 82.9, 83.0,
        83.100000000000009, 83.2, 83.300000000000011, 83.4, 83.5,
        83.600000000000009, 83.7, 83.800000000000011, 83.9, 84.0,
        84.100000000000009, 84.2, 84.300000000000011, 84.4, 84.5,
        84.600000000000009, 84.7, 84.800000000000011, 84.9, 85.0,
        85.100000000000009, 85.2, 85.300000000000011, 85.4, 85.5,
        85.600000000000009, 85.7, 85.800000000000011, 85.9, 86.0,
        86.100000000000009, 86.2, 86.300000000000011, 86.4, 86.5,
        86.600000000000009, 86.7, 86.800000000000011, 86.9, 87.0,
        87.100000000000009, 87.2, 87.300000000000011, 87.4, 87.5,
        87.600000000000009, 87.7, 87.800000000000011, 87.9, 88.0,
        88.100000000000009, 88.2, 88.300000000000011, 88.4, 88.5,
        88.600000000000009, 88.7, 88.800000000000011, 88.9, 89.0,
        89.100000000000009, 89.2, 89.300000000000011, 89.4, 89.5,
        89.600000000000009, 89.7, 89.800000000000011, 89.9, 90.0,
        90.100000000000009, 90.2, 90.300000000000011, 90.4, 90.5,
        90.600000000000009, 90.7, 90.800000000000011, 90.9, 91.0,
        91.100000000000009, 91.2, 91.300000000000011, 91.4, 91.5,
        91.600000000000009, 91.7, 91.800000000000011, 91.9, 92.0,
        92.100000000000009, 92.2, 92.300000000000011, 92.4, 92.5,
        92.600000000000009, 92.7, 92.800000000000011, 92.9, 93.0,
        93.100000000000009, 93.2, 93.300000000000011, 93.4, 93.5,
        93.600000000000009, 93.7, 93.800000000000011, 93.9, 94.0,
        94.100000000000009, 94.2, 94.300000000000011, 94.4, 94.5,
        94.600000000000009, 94.7, 94.800000000000011, 94.9, 95.0,
        95.100000000000009, 95.2, 95.300000000000011, 95.4, 95.5,
        95.600000000000009, 95.7, 95.800000000000011, 95.9, 96.0,
        96.100000000000009, 96.2, 96.300000000000011, 96.4, 96.5,
        96.600000000000009, 96.7, 96.800000000000011, 96.9, 97.0,
        97.100000000000009, 97.2, 97.300000000000011, 97.4, 97.5,
        97.600000000000009, 97.7, 97.800000000000011, 97.9, 98.0,
        98.100000000000009, 98.2, 98.300000000000011, 98.4, 98.5,
        98.600000000000009, 98.7, 98.800000000000011, 98.9, 99.0,
        99.100000000000009, 99.2, 99.300000000000011, 99.4, 99.5,
        99.600000000000009, 99.7, 99.800000000000011, 99.9, 100.0,
        100.10000000000001, 100.2, 100.30000000000001, 100.4, 100.5,
        100.60000000000001, 100.7, 100.80000000000001, 100.9, 101.0,
        101.10000000000001, 101.2, 101.30000000000001, 101.4, 101.5,
        101.60000000000001, 101.7, 101.80000000000001, 101.9, 102.0,
        102.10000000000001, 102.2, 102.30000000000001, 102.4, 102.5,
        102.60000000000001, 102.7, 102.80000000000001, 102.9, 103.0,
        103.10000000000001, 103.2, 103.30000000000001, 103.4, 103.5,
        103.60000000000001, 103.7, 103.80000000000001, 103.9, 104.0,
        104.10000000000001, 104.2, 104.30000000000001, 104.4, 104.5,
        104.60000000000001, 104.7, 104.80000000000001, 104.9, 105.0,
        105.10000000000001, 105.2, 105.30000000000001, 105.4, 105.5,
        105.60000000000001, 105.7, 105.80000000000001, 105.9, 106.0,
        106.10000000000001, 106.2, 106.30000000000001, 106.4, 106.5,
        106.60000000000001, 106.7, 106.80000000000001, 106.9, 107.0,
        107.10000000000001, 107.2, 107.30000000000001, 107.4, 107.5,
        107.60000000000001, 107.7, 107.80000000000001, 107.9, 108.0,
        108.10000000000001, 108.2, 108.30000000000001, 108.4, 108.5,
        108.60000000000001, 108.7, 108.80000000000001, 108.9, 109.0,
        109.10000000000001, 109.2, 109.30000000000001, 109.4, 109.5,
        109.60000000000001, 109.7, 109.80000000000001, 109.9, 110.0,
        110.10000000000001, 110.2, 110.30000000000001, 110.4, 110.5,
        110.60000000000001, 110.7, 110.80000000000001, 110.9, 111.0,
        111.10000000000001, 111.2, 111.30000000000001, 111.4, 111.5,
        111.60000000000001, 111.7, 111.80000000000001, 111.9, 112.0,
        112.10000000000001, 112.2, 112.30000000000001, 112.4, 112.5,
        112.60000000000001, 112.7, 112.80000000000001, 112.9, 113.0,
        113.10000000000001, 113.2, 113.30000000000001, 113.4, 113.5,
        113.60000000000001, 113.7, 113.80000000000001, 113.9, 114.0,
        114.10000000000001, 114.2, 114.30000000000001, 114.4, 114.5,
        114.60000000000001, 114.7, 114.80000000000001, 114.9, 115.0,
        115.10000000000001, 115.2, 115.30000000000001, 115.4, 115.5,
        115.60000000000001, 115.7, 115.80000000000001, 115.9, 116.0,
        116.10000000000001, 116.2, 116.30000000000001, 116.4, 116.5,
        116.60000000000001, 116.7, 116.80000000000001, 116.9, 117.0,
        117.10000000000001, 117.2, 117.30000000000001, 117.4, 117.5,
        117.60000000000001, 117.7, 117.80000000000001, 117.9, 118.0,
        118.10000000000001, 118.2, 118.30000000000001, 118.4, 118.5,
        118.60000000000001, 118.7, 118.80000000000001, 118.9, 119.0,
        119.10000000000001, 119.2, 119.30000000000001, 119.4, 119.5,
        119.60000000000001, 119.7, 119.80000000000001, 119.9, 120.0,
        120.10000000000001, 120.2, 120.30000000000001, 120.4, 120.5,
        120.60000000000001, 120.7, 120.80000000000001, 120.9, 121.0,
        121.10000000000001, 121.2, 121.30000000000001, 121.4, 121.5,
        121.60000000000001, 121.7, 121.80000000000001, 121.9, 122.0,
        122.10000000000001, 122.2, 122.30000000000001, 122.4, 122.5,
        122.60000000000001, 122.7, 122.80000000000001, 122.9, 123.0,
        123.10000000000001, 123.2, 123.30000000000001, 123.4, 123.5,
        123.60000000000001, 123.7, 123.80000000000001, 123.9, 124.0,
        124.10000000000001, 124.2, 124.30000000000001, 124.4, 124.5,
        124.60000000000001, 124.7, 124.80000000000001, 124.9, 125.0,
        125.10000000000001, 125.2, 125.30000000000001, 125.4, 125.5,
        125.60000000000001, 125.7, 125.80000000000001, 125.9, 126.0,
        126.10000000000001, 126.2, 126.30000000000001, 126.4, 126.5,
        126.60000000000001, 126.7, 126.80000000000001, 126.9, 127.0,
        127.10000000000001, 127.2, 127.30000000000001, 127.4, 127.5,
        127.60000000000001, 127.7, 127.80000000000001, 127.9, 128.0, 128.1,
        128.20000000000002, 128.3, 128.4, 128.5, 128.6, 128.70000000000002,
        128.8, 128.9, 129.0, 129.1, 129.20000000000002, 129.3, 129.4, 129.5,
        129.6, 129.70000000000002, 129.8, 129.9, 130.0, 130.1,
        130.20000000000002, 130.3, 130.4, 130.5, 130.6, 130.70000000000002,
        130.8, 130.9, 131.0, 131.1, 131.20000000000002, 131.3, 131.4, 131.5,
        131.6, 131.70000000000002, 131.8, 131.9, 132.0, 132.1,
        132.20000000000002, 132.3, 132.4, 132.5, 132.6, 132.70000000000002,
        132.8, 132.9, 133.0, 133.1, 133.20000000000002, 133.3, 133.4, 133.5,
        133.6, 133.70000000000002, 133.8, 133.9, 134.0, 134.1,
        134.20000000000002, 134.3, 134.4, 134.5, 134.6, 134.70000000000002,
        134.8, 134.9, 135.0, 135.1, 135.20000000000002, 135.3, 135.4, 135.5,
        135.6, 135.70000000000002, 135.8, 135.9, 136.0, 136.1,
        136.20000000000002, 136.3, 136.4, 136.5, 136.6, 136.70000000000002,
        136.8, 136.9, 137.0, 137.1, 137.20000000000002, 137.3, 137.4, 137.5,
        137.6, 137.70000000000002, 137.8, 137.9, 138.0, 138.1,
        138.20000000000002, 138.3, 138.4, 138.5, 138.6, 138.70000000000002,
        138.8, 138.9, 139.0, 139.1, 139.20000000000002, 139.3, 139.4, 139.5,
        139.6, 139.70000000000002, 139.8, 139.9, 140.0, 140.1,
        140.20000000000002, 140.3, 140.4, 140.5, 140.6, 140.70000000000002,
        140.8, 140.9, 141.0, 141.1, 141.20000000000002, 141.3, 141.4, 141.5,
        141.6, 141.70000000000002, 141.8, 141.9, 142.0, 142.1,
        142.20000000000002, 142.3, 142.4, 142.5, 142.6, 142.70000000000002,
        142.8, 142.9, 143.0, 143.1, 143.20000000000002, 143.3, 143.4, 143.5,
        143.6, 143.70000000000002, 143.8, 143.9, 144.0, 144.1,
        144.20000000000002, 144.3, 144.4, 144.5, 144.6, 144.70000000000002,
        144.8, 144.9, 145.0, 145.1, 145.20000000000002, 145.3, 145.4, 145.5,
        145.6, 145.70000000000002, 145.8, 145.9, 146.0, 146.1,
        146.20000000000002, 146.3, 146.4, 146.5, 146.6, 146.70000000000002,
        146.8, 146.9, 147.0, 147.1, 147.20000000000002, 147.3, 147.4, 147.5,
        147.6, 147.70000000000002, 147.8, 147.9, 148.0, 148.1,
        148.20000000000002, 148.3, 148.4, 148.5, 148.6, 148.70000000000002,
        148.8, 148.9, 149.0, 149.1, 149.20000000000002, 149.3, 149.4, 149.5,
        149.6, 149.70000000000002, 149.8, 149.9, 150.0, 150.1,
        150.20000000000002, 150.3, 150.4, 150.5, 150.6, 150.70000000000002,
        150.8, 150.9, 151.0, 151.1, 151.20000000000002, 151.3, 151.4, 151.5,
        151.6, 151.70000000000002, 151.8, 151.9, 152.0, 152.1,
        152.20000000000002, 152.3, 152.4, 152.5, 152.6, 152.70000000000002,
        152.8, 152.9, 153.0, 153.1, 153.20000000000002, 153.3, 153.4, 153.5,
        153.60000000000002, 153.70000000000002, 153.8, 153.9, 154.0,
        154.10000000000002, 154.20000000000002, 154.3, 154.4, 154.5,
        154.60000000000002, 154.70000000000002, 154.8, 154.9, 155.0,
        155.10000000000002, 155.20000000000002, 155.3, 155.4, 155.5,
        155.60000000000002, 155.70000000000002, 155.8, 155.9, 156.0,
        156.10000000000002, 156.20000000000002, 156.3, 156.4, 156.5,
        156.60000000000002, 156.70000000000002, 156.8, 156.9, 157.0,
        157.10000000000002, 157.20000000000002, 157.3, 157.4, 157.5,
        157.60000000000002, 157.70000000000002, 157.8, 157.9, 158.0,
        158.10000000000002, 158.20000000000002, 158.3, 158.4, 158.5,
        158.60000000000002, 158.70000000000002, 158.8, 158.9, 159.0,
        159.10000000000002, 159.20000000000002, 159.3, 159.4, 159.5,
        159.60000000000002, 159.70000000000002, 159.8, 159.9, 160.0,
        160.10000000000002, 160.20000000000002, 160.3, 160.4, 160.5,
        160.60000000000002, 160.70000000000002, 160.8, 160.9, 161.0,
        161.10000000000002, 161.20000000000002, 161.3, 161.4, 161.5,
        161.60000000000002, 161.70000000000002, 161.8, 161.9, 162.0,
        162.10000000000002, 162.20000000000002, 162.3, 162.4, 162.5,
        162.60000000000002, 162.70000000000002, 162.8, 162.9, 163.0,
        163.10000000000002, 163.20000000000002, 163.3, 163.4, 163.5,
        163.60000000000002, 163.70000000000002, 163.8, 163.9, 164.0,
        164.10000000000002, 164.20000000000002, 164.3, 164.4, 164.5,
        164.60000000000002, 164.70000000000002, 164.8, 164.9, 165.0,
        165.10000000000002, 165.20000000000002, 165.3, 165.4, 165.5,
        165.60000000000002, 165.70000000000002, 165.8, 165.9, 166.0,
        166.10000000000002, 166.20000000000002, 166.3, 166.4, 166.5,
        166.60000000000002, 166.70000000000002, 166.8, 166.9, 167.0,
        167.10000000000002, 167.20000000000002, 167.3, 167.4, 167.5,
        167.60000000000002, 167.70000000000002, 167.8, 167.9, 168.0,
        168.10000000000002, 168.20000000000002, 168.3, 168.4, 168.5,
        168.60000000000002, 168.70000000000002, 168.8, 168.9, 169.0,
        169.10000000000002, 169.20000000000002, 169.3, 169.4, 169.5,
        169.60000000000002, 169.70000000000002, 169.8, 169.9, 170.0,
        170.10000000000002, 170.20000000000002, 170.3, 170.4, 170.5,
        170.60000000000002, 170.70000000000002, 170.8, 170.9, 171.0,
        171.10000000000002, 171.20000000000002, 171.3, 171.4, 171.5,
        171.60000000000002, 171.70000000000002, 171.8, 171.9, 172.0,
        172.10000000000002, 172.20000000000002, 172.3, 172.4, 172.5,
        172.60000000000002, 172.70000000000002, 172.8, 172.9, 173.0,
        173.10000000000002, 173.20000000000002, 173.3, 173.4, 173.5,
        173.60000000000002, 173.70000000000002, 173.8, 173.9, 174.0,
        174.10000000000002, 174.20000000000002, 174.3, 174.4, 174.5,
        174.60000000000002, 174.70000000000002, 174.8, 174.9, 175.0,
        175.10000000000002, 175.20000000000002, 175.3, 175.4, 175.5,
        175.60000000000002, 175.70000000000002, 175.8, 175.9, 176.0,
        176.10000000000002, 176.20000000000002, 176.3, 176.4, 176.5,
        176.60000000000002, 176.70000000000002, 176.8, 176.9, 177.0,
        177.10000000000002, 177.20000000000002, 177.3, 177.4, 177.5,
        177.60000000000002, 177.70000000000002, 177.8, 177.9, 178.0,
        178.10000000000002, 178.20000000000002, 178.3, 178.4, 178.5,
        178.60000000000002, 178.70000000000002, 178.8, 178.9, 179.0,
        179.10000000000002, 179.20000000000002, 179.3, 179.4, 179.5,
        179.60000000000002, 179.70000000000002, 179.8, 179.9, 180.0,
        180.10000000000002, 180.20000000000002, 180.3, 180.4, 180.5,
        180.60000000000002, 180.70000000000002, 180.8, 180.9, 181.0,
        181.10000000000002, 181.20000000000002, 181.3, 181.4, 181.5,
        181.60000000000002, 181.70000000000002, 181.8, 181.9, 182.0,
        182.10000000000002, 182.20000000000002, 182.3, 182.4, 182.5,
        182.60000000000002, 182.70000000000002, 182.8, 182.9, 183.0,
        183.10000000000002, 183.20000000000002, 183.3, 183.4, 183.5,
        183.60000000000002, 183.70000000000002, 183.8, 183.9, 184.0,
        184.10000000000002, 184.20000000000002, 184.3, 184.4, 184.5,
        184.60000000000002, 184.70000000000002, 184.8, 184.9, 185.0,
        185.10000000000002, 185.20000000000002, 185.3, 185.4, 185.5,
        185.60000000000002, 185.70000000000002, 185.8, 185.9, 186.0,
        186.10000000000002, 186.20000000000002, 186.3, 186.4, 186.5,
        186.60000000000002, 186.70000000000002, 186.8, 186.9, 187.0,
        187.10000000000002, 187.20000000000002, 187.3, 187.4, 187.5,
        187.60000000000002, 187.70000000000002, 187.8, 187.9, 188.0,
        188.10000000000002, 188.20000000000002, 188.3, 188.4, 188.5,
        188.60000000000002, 188.70000000000002, 188.8, 188.9, 189.0,
        189.10000000000002, 189.20000000000002, 189.3, 189.4, 189.5,
        189.60000000000002, 189.70000000000002, 189.8, 189.9, 190.0,
        190.10000000000002, 190.20000000000002, 190.3, 190.4, 190.5,
        190.60000000000002, 190.70000000000002, 190.8, 190.9, 191.0,
        191.10000000000002, 191.20000000000002, 191.3, 191.4, 191.5,
        191.60000000000002, 191.70000000000002, 191.8, 191.9, 192.0,
        192.10000000000002, 192.20000000000002, 192.3, 192.4, 192.5,
        192.60000000000002, 192.70000000000002, 192.8, 192.9, 193.0,
        193.10000000000002, 193.20000000000002, 193.3, 193.4, 193.5,
        193.60000000000002, 193.70000000000002, 193.8, 193.9, 194.0,
        194.10000000000002, 194.20000000000002, 194.3, 194.4, 194.5,
        194.60000000000002, 194.70000000000002, 194.8, 194.9, 195.0,
        195.10000000000002, 195.20000000000002, 195.3, 195.4, 195.5,
        195.60000000000002, 195.70000000000002, 195.8, 195.9, 196.0,
        196.10000000000002, 196.20000000000002, 196.3, 196.4, 196.5,
        196.60000000000002, 196.70000000000002, 196.8, 196.9, 197.0,
        197.10000000000002, 197.20000000000002, 197.3, 197.4, 197.5,
        197.60000000000002, 197.70000000000002, 197.8, 197.9, 198.0,
        198.10000000000002, 198.20000000000002, 198.3, 198.4, 198.5,
        198.60000000000002, 198.70000000000002, 198.8, 198.9, 199.0,
        199.10000000000002, 199.20000000000002, 199.3, 199.4, 199.5,
        199.60000000000002, 199.70000000000002, 199.8, 199.9, 200.0,
        200.10000000000002, 200.20000000000002, 200.3, 200.4, 200.5,
        200.60000000000002, 200.70000000000002, 200.8, 200.9, 201.0,
        201.10000000000002, 201.20000000000002, 201.3, 201.4, 201.5,
        201.60000000000002, 201.70000000000002, 201.8, 201.9, 202.0,
        202.10000000000002, 202.20000000000002, 202.3, 202.4, 202.5,
        202.60000000000002, 202.70000000000002, 202.8, 202.9, 203.0,
        203.10000000000002, 203.20000000000002, 203.3, 203.4, 203.5,
        203.60000000000002, 203.70000000000002, 203.8, 203.9, 204.0,
        204.10000000000002, 204.20000000000002, 204.3, 204.4, 204.5,
        204.60000000000002, 204.70000000000002, 204.8, 204.9, 205.0,
        205.10000000000002, 205.20000000000002, 205.3, 205.4, 205.5,
        205.60000000000002, 205.70000000000002, 205.8, 205.9, 206.0,
        206.10000000000002, 206.20000000000002, 206.3, 206.4, 206.5,
        206.60000000000002, 206.70000000000002, 206.8, 206.9, 207.0,
        207.10000000000002, 207.20000000000002, 207.3, 207.4, 207.5,
        207.60000000000002, 207.70000000000002, 207.8, 207.9, 208.0,
        208.10000000000002, 208.20000000000002, 208.3, 208.4, 208.5,
        208.60000000000002, 208.70000000000002, 208.8, 208.9, 209.0,
        209.10000000000002, 209.20000000000002, 209.3, 209.4, 209.5,
        209.60000000000002, 209.70000000000002, 209.8, 209.9, 210.0,
        210.10000000000002, 210.20000000000002, 210.3, 210.4, 210.5,
        210.60000000000002, 210.70000000000002, 210.8, 210.9, 211.0,
        211.10000000000002, 211.20000000000002, 211.3, 211.4, 211.5,
        211.60000000000002, 211.70000000000002, 211.8, 211.9, 212.0,
        212.10000000000002, 212.20000000000002, 212.3, 212.4, 212.5,
        212.60000000000002, 212.70000000000002, 212.8, 212.9, 213.0,
        213.10000000000002, 213.20000000000002, 213.3, 213.4, 213.5,
        213.60000000000002, 213.70000000000002, 213.8, 213.9, 214.0,
        214.10000000000002, 214.20000000000002, 214.3, 214.4, 214.5,
        214.60000000000002, 214.70000000000002, 214.8, 214.9, 215.0,
        215.10000000000002, 215.20000000000002, 215.3, 215.4, 215.5,
        215.60000000000002, 215.70000000000002, 215.8, 215.9, 216.0,
        216.10000000000002, 216.20000000000002, 216.3, 216.4, 216.5,
        216.60000000000002, 216.70000000000002, 216.8, 216.9, 217.0,
        217.10000000000002, 217.20000000000002, 217.3, 217.4, 217.5,
        217.60000000000002, 217.70000000000002, 217.8, 217.9, 218.0,
        218.10000000000002, 218.20000000000002, 218.3, 218.4, 218.5,
        218.60000000000002, 218.70000000000002, 218.8, 218.9, 219.0,
        219.10000000000002, 219.20000000000002, 219.3, 219.4, 219.5,
        219.60000000000002, 219.70000000000002, 219.8, 219.9, 220.0,
        220.10000000000002, 220.20000000000002, 220.3, 220.4, 220.5,
        220.60000000000002, 220.70000000000002, 220.8, 220.9, 221.0,
        221.10000000000002, 221.20000000000002, 221.3, 221.4, 221.5,
        221.60000000000002, 221.70000000000002, 221.8, 221.9, 222.0,
        222.10000000000002, 222.20000000000002, 222.3, 222.4, 222.5,
        222.60000000000002, 222.70000000000002, 222.8, 222.9, 223.0,
        223.10000000000002, 223.20000000000002, 223.3, 223.4, 223.5,
        223.60000000000002, 223.70000000000002, 223.8, 223.9, 224.0,
        224.10000000000002, 224.20000000000002, 224.3, 224.4, 224.5,
        224.60000000000002, 224.70000000000002, 224.8, 224.9, 225.0,
        225.10000000000002, 225.20000000000002, 225.3, 225.4, 225.5,
        225.60000000000002, 225.70000000000002, 225.8, 225.9, 226.0,
        226.10000000000002, 226.20000000000002, 226.3, 226.4, 226.5,
        226.60000000000002, 226.70000000000002, 226.8, 226.9, 227.0,
        227.10000000000002, 227.20000000000002, 227.3, 227.4, 227.5,
        227.60000000000002, 227.70000000000002, 227.8, 227.9, 228.0,
        228.10000000000002, 228.20000000000002, 228.3, 228.4, 228.5,
        228.60000000000002, 228.70000000000002, 228.8, 228.9, 229.0,
        229.10000000000002, 229.20000000000002, 229.3, 229.4, 229.5,
        229.60000000000002, 229.70000000000002, 229.8, 229.9, 230.0,
        230.10000000000002, 230.20000000000002, 230.3, 230.4, 230.5,
        230.60000000000002, 230.70000000000002, 230.8, 230.9, 231.0,
        231.10000000000002, 231.20000000000002, 231.3, 231.4, 231.5,
        231.60000000000002, 231.70000000000002, 231.8, 231.9, 232.0,
        232.10000000000002, 232.20000000000002, 232.3, 232.4, 232.5,
        232.60000000000002, 232.70000000000002, 232.8, 232.9, 233.0,
        233.10000000000002, 233.20000000000002, 233.3, 233.4, 233.5,
        233.60000000000002, 233.70000000000002, 233.8, 233.9, 234.0,
        234.10000000000002, 234.20000000000002, 234.3, 234.4, 234.5,
        234.60000000000002, 234.70000000000002, 234.8, 234.9, 235.0,
        235.10000000000002, 235.20000000000002, 235.3, 235.4, 235.5,
        235.60000000000002, 235.70000000000002, 235.8, 235.9, 236.0,
        236.10000000000002, 236.20000000000002, 236.3, 236.4, 236.5,
        236.60000000000002, 236.70000000000002, 236.8, 236.9, 237.0,
        237.10000000000002, 237.20000000000002, 237.3, 237.4, 237.5,
        237.60000000000002, 237.70000000000002, 237.8, 237.9, 238.0,
        238.10000000000002, 238.20000000000002, 238.3, 238.4, 238.5,
        238.60000000000002, 238.70000000000002, 238.8, 238.9, 239.0,
        239.10000000000002, 239.20000000000002, 239.3, 239.4, 239.5,
        239.60000000000002, 239.70000000000002, 239.8, 239.9, 240.0,
        240.10000000000002, 240.20000000000002, 240.3, 240.4, 240.5,
        240.60000000000002, 240.70000000000002, 240.8, 240.9, 241.0,
        241.10000000000002, 241.20000000000002, 241.3, 241.4, 241.5,
        241.60000000000002, 241.70000000000002, 241.8, 241.9, 242.0,
        242.10000000000002, 242.20000000000002, 242.3, 242.4, 242.5,
        242.60000000000002, 242.70000000000002, 242.8, 242.9, 243.0,
        243.10000000000002, 243.20000000000002, 243.3, 243.4, 243.5,
        243.60000000000002, 243.70000000000002, 243.8, 243.9, 244.0,
        244.10000000000002, 244.20000000000002, 244.3, 244.4, 244.5,
        244.60000000000002, 244.70000000000002, 244.8, 244.9, 245.0,
        245.10000000000002, 245.20000000000002, 245.3, 245.4, 245.5,
        245.60000000000002, 245.70000000000002, 245.8, 245.9, 246.0,
        246.10000000000002, 246.20000000000002, 246.3, 246.4, 246.5,
        246.60000000000002, 246.70000000000002, 246.8, 246.9, 247.0,
        247.10000000000002, 247.20000000000002, 247.3, 247.4, 247.5,
        247.60000000000002, 247.70000000000002, 247.8, 247.9, 248.0,
        248.10000000000002, 248.20000000000002, 248.3, 248.4, 248.5,
        248.60000000000002, 248.70000000000002, 248.8, 248.9, 249.0,
        249.10000000000002, 249.20000000000002, 249.3, 249.4, 249.5,
        249.60000000000002, 249.70000000000002, 249.8, 249.9, 250.0,
        250.10000000000002, 250.20000000000002, 250.3, 250.4, 250.5,
        250.60000000000002, 250.70000000000002, 250.8, 250.9, 251.0,
        251.10000000000002, 251.20000000000002, 251.3, 251.4, 251.5,
        251.60000000000002, 251.70000000000002, 251.8, 251.9, 252.0,
        252.10000000000002, 252.20000000000002, 252.3, 252.4, 252.5,
        252.60000000000002, 252.70000000000002, 252.8, 252.9, 253.0,
        253.10000000000002, 253.20000000000002, 253.3, 253.4, 253.5,
        253.60000000000002, 253.70000000000002, 253.8, 253.9, 254.0,
        254.10000000000002, 254.20000000000002, 254.3, 254.4, 254.5,
        254.60000000000002, 254.70000000000002, 254.8, 254.9, 255.0,
        255.10000000000002, 255.20000000000002, 255.3, 255.4, 255.5,
        255.60000000000002, 255.70000000000002, 255.8, 255.9, 256.0, 256.1,
        256.2, 256.3, 256.40000000000003, 256.5, 256.6, 256.7, 256.8,
        256.90000000000003, 257.0, 257.1, 257.2, 257.3, 257.40000000000003,
        257.5, 257.6, 257.7, 257.8, 257.90000000000003, 258.0, 258.1, 258.2,
        258.3, 258.40000000000003, 258.5, 258.6, 258.7, 258.8,
        258.90000000000003, 259.0, 259.1, 259.2, 259.3, 259.40000000000003,
        259.5, 259.6, 259.7, 259.8, 259.90000000000003, 260.0, 260.1, 260.2,
        260.3, 260.40000000000003, 260.5, 260.6, 260.7, 260.8,
        260.90000000000003, 261.0, 261.1, 261.2, 261.3, 261.40000000000003,
        261.5, 261.6, 261.7, 261.8, 261.90000000000003, 262.0, 262.1, 262.2,
        262.3, 262.40000000000003, 262.5, 262.6, 262.7, 262.8,
        262.90000000000003, 263.0, 263.1, 263.2, 263.3, 263.40000000000003,
        263.5, 263.6, 263.7, 263.8, 263.90000000000003, 264.0, 264.1, 264.2,
        264.3, 264.40000000000003, 264.5, 264.6, 264.7, 264.8,
        264.90000000000003, 265.0, 265.1, 265.2, 265.3, 265.40000000000003,
        265.5, 265.6, 265.7, 265.8, 265.90000000000003, 266.0, 266.1, 266.2,
        266.3, 266.40000000000003, 266.5, 266.6, 266.7, 266.8,
        266.90000000000003, 267.0, 267.1, 267.2, 267.3, 267.40000000000003,
        267.5, 267.6, 267.7, 267.8, 267.90000000000003, 268.0, 268.1, 268.2,
        268.3, 268.40000000000003, 268.5, 268.6, 268.7, 268.8,
        268.90000000000003, 269.0, 269.1, 269.2, 269.3, 269.40000000000003,
        269.5, 269.6, 269.7, 269.8, 269.90000000000003, 270.0, 270.1, 270.2,
        270.3, 270.40000000000003, 270.5, 270.6, 270.7, 270.8,
        270.90000000000003, 271.0, 271.1, 271.2, 271.3, 271.40000000000003,
        271.5, 271.6, 271.7, 271.8, 271.90000000000003, 272.0, 272.1, 272.2,
        272.3, 272.40000000000003, 272.5, 272.6, 272.7, 272.8,
        272.90000000000003, 273.0, 273.1, 273.2, 273.3, 273.40000000000003,
        273.5, 273.6, 273.7, 273.8, 273.90000000000003, 274.0, 274.1, 274.2,
        274.3, 274.40000000000003, 274.5, 274.6, 274.7, 274.8,
        274.90000000000003, 275.0, 275.1, 275.2, 275.3, 275.40000000000003,
        275.5, 275.6, 275.7, 275.8, 275.90000000000003, 276.0, 276.1, 276.2,
        276.3, 276.40000000000003, 276.5, 276.6, 276.7, 276.8,
        276.90000000000003, 277.0, 277.1, 277.2, 277.3, 277.40000000000003,
        277.5, 277.6, 277.7, 277.8, 277.90000000000003, 278.0, 278.1, 278.2,
        278.3, 278.40000000000003, 278.5, 278.6, 278.7, 278.8,
        278.90000000000003, 279.0, 279.1, 279.2, 279.3, 279.40000000000003,
        279.5, 279.6, 279.7, 279.8, 279.90000000000003, 280.0, 280.1, 280.2,
        280.3, 280.40000000000003, 280.5, 280.6, 280.7, 280.8,
        280.90000000000003, 281.0, 281.1, 281.2, 281.3, 281.40000000000003,
        281.5, 281.6, 281.7, 281.8, 281.90000000000003, 282.0, 282.1, 282.2,
        282.3, 282.40000000000003, 282.5, 282.6, 282.7, 282.8,
        282.90000000000003, 283.0, 283.1, 283.2, 283.3, 283.40000000000003,
        283.5, 283.6, 283.7, 283.8, 283.90000000000003, 284.0, 284.1, 284.2,
        284.3, 284.40000000000003, 284.5, 284.6, 284.7, 284.8,
        284.90000000000003, 285.0, 285.1, 285.2, 285.3, 285.40000000000003,
        285.5, 285.6, 285.7, 285.8, 285.90000000000003, 286.0, 286.1, 286.2,
        286.3, 286.40000000000003, 286.5, 286.6, 286.7, 286.8,
        286.90000000000003, 287.0, 287.1, 287.2, 287.3, 287.40000000000003,
        287.5, 287.6, 287.7, 287.8, 287.90000000000003, 288.0, 288.1, 288.2,
        288.3, 288.40000000000003, 288.5, 288.6, 288.7, 288.8,
        288.90000000000003, 289.0, 289.1, 289.2, 289.3, 289.40000000000003,
        289.5, 289.6, 289.7, 289.8, 289.90000000000003, 290.0, 290.1, 290.2,
        290.3, 290.40000000000003, 290.5, 290.6, 290.7, 290.8,
        290.90000000000003, 291.0, 291.1, 291.2, 291.3, 291.40000000000003,
        291.5, 291.6, 291.7, 291.8, 291.90000000000003, 292.0, 292.1, 292.2,
        292.3, 292.40000000000003, 292.5, 292.6, 292.7, 292.8,
        292.90000000000003, 293.0, 293.1, 293.2, 293.3, 293.40000000000003,
        293.5, 293.6, 293.7, 293.8, 293.90000000000003, 294.0, 294.1, 294.2,
        294.3, 294.40000000000003, 294.5, 294.6, 294.7, 294.8,
        294.90000000000003, 295.0, 295.1, 295.2, 295.3, 295.40000000000003,
        295.5, 295.6, 295.7, 295.8, 295.90000000000003, 296.0, 296.1, 296.2,
        296.3, 296.40000000000003, 296.5, 296.6, 296.7, 296.8,
        296.90000000000003, 297.0, 297.1, 297.2, 297.3, 297.40000000000003,
        297.5, 297.6, 297.7, 297.8, 297.90000000000003, 298.0, 298.1, 298.2,
        298.3, 298.40000000000003, 298.5, 298.6, 298.7, 298.8,
        298.90000000000003, 299.0, 299.1, 299.2, 299.3, 299.40000000000003,
        299.5, 299.6, 299.7, 299.8, 299.90000000000003, 300.0, 300.1, 300.2,
        300.3, 300.40000000000003, 300.5, 300.6, 300.7, 300.8,
        300.90000000000003, 301.0, 301.1, 301.2, 301.3, 301.40000000000003,
        301.5, 301.6, 301.7, 301.8, 301.90000000000003, 302.0, 302.1, 302.2,
        302.3, 302.40000000000003, 302.5, 302.6, 302.7, 302.8,
        302.90000000000003, 303.0, 303.1, 303.2, 303.3, 303.40000000000003,
        303.5, 303.6, 303.7, 303.8, 303.90000000000003, 304.0, 304.1, 304.2,
        304.3, 304.40000000000003, 304.5, 304.6, 304.7, 304.8,
        304.90000000000003, 305.0, 305.1, 305.2, 305.3, 305.40000000000003,
        305.5, 305.6, 305.7, 305.8, 305.90000000000003, 306.0, 306.1, 306.2,
        306.3, 306.40000000000003, 306.5, 306.6, 306.7, 306.8,
        306.90000000000003, 307.0, 307.1, 307.20000000000005, 307.3,
        307.40000000000003, 307.5, 307.6, 307.70000000000005, 307.8,
        307.90000000000003, 308.0, 308.1, 308.20000000000005, 308.3,
        308.40000000000003, 308.5, 308.6, 308.70000000000005, 308.8,
        308.90000000000003, 309.0, 309.1, 309.20000000000005, 309.3,
        309.40000000000003, 309.5, 309.6, 309.70000000000005, 309.8,
        309.90000000000003, 310.0, 310.1, 310.20000000000005, 310.3,
        310.40000000000003, 310.5, 310.6, 310.70000000000005, 310.8,
        310.90000000000003, 311.0, 311.1, 311.20000000000005, 311.3,
        311.40000000000003, 311.5, 311.6, 311.70000000000005, 311.8,
        311.90000000000003, 312.0, 312.1, 312.20000000000005, 312.3,
        312.40000000000003, 312.5, 312.6, 312.70000000000005, 312.8,
        312.90000000000003, 313.0, 313.1, 313.20000000000005, 313.3,
        313.40000000000003, 313.5, 313.6, 313.70000000000005, 313.8,
        313.90000000000003, 314.0, 314.1, 314.20000000000005, 314.3,
        314.40000000000003, 314.5, 314.6, 314.70000000000005, 314.8,
        314.90000000000003, 315.0, 315.1, 315.20000000000005, 315.3,
        315.40000000000003, 315.5, 315.6, 315.70000000000005, 315.8,
        315.90000000000003, 316.0, 316.1, 316.20000000000005, 316.3,
        316.40000000000003, 316.5, 316.6, 316.70000000000005, 316.8,
        316.90000000000003, 317.0, 317.1, 317.20000000000005, 317.3,
        317.40000000000003, 317.5, 317.6, 317.70000000000005, 317.8,
        317.90000000000003, 318.0, 318.1, 318.20000000000005, 318.3,
        318.40000000000003, 318.5, 318.6, 318.70000000000005, 318.8,
        318.90000000000003, 319.0, 319.1, 319.20000000000005, 319.3,
        319.40000000000003, 319.5, 319.6, 319.70000000000005, 319.8,
        319.90000000000003, 320.0, 320.1, 320.20000000000005, 320.3,
        320.40000000000003, 320.5, 320.6, 320.70000000000005, 320.8,
        320.90000000000003, 321.0, 321.1, 321.20000000000005, 321.3,
        321.40000000000003, 321.5, 321.6, 321.70000000000005, 321.8,
        321.90000000000003, 322.0, 322.1, 322.20000000000005, 322.3,
        322.40000000000003, 322.5, 322.6, 322.70000000000005, 322.8,
        322.90000000000003, 323.0, 323.1, 323.20000000000005, 323.3,
        323.40000000000003, 323.5, 323.6, 323.70000000000005, 323.8,
        323.90000000000003, 324.0, 324.1, 324.20000000000005, 324.3,
        324.40000000000003, 324.5, 324.6, 324.70000000000005, 324.8,
        324.90000000000003, 325.0, 325.1, 325.20000000000005, 325.3,
        325.40000000000003, 325.5, 325.6, 325.70000000000005, 325.8,
        325.90000000000003, 326.0, 326.1, 326.20000000000005, 326.3,
        326.40000000000003, 326.5, 326.6, 326.70000000000005, 326.8,
        326.90000000000003, 327.0, 327.1, 327.20000000000005, 327.3,
        327.40000000000003, 327.5, 327.6, 327.70000000000005, 327.8,
        327.90000000000003, 328.0, 328.1, 328.20000000000005, 328.3,
        328.40000000000003, 328.5, 328.6, 328.70000000000005, 328.8,
        328.90000000000003, 329.0, 329.1, 329.20000000000005, 329.3,
        329.40000000000003, 329.5, 329.6, 329.70000000000005, 329.8,
        329.90000000000003, 330.0, 330.1, 330.20000000000005, 330.3,
        330.40000000000003, 330.5, 330.6, 330.70000000000005, 330.8,
        330.90000000000003, 331.0, 331.1, 331.20000000000005, 331.3,
        331.40000000000003, 331.5, 331.6, 331.70000000000005, 331.8,
        331.90000000000003, 332.0, 332.1, 332.20000000000005, 332.3,
        332.40000000000003, 332.5, 332.6, 332.70000000000005, 332.8,
        332.90000000000003, 333.0, 333.1, 333.20000000000005, 333.3,
        333.40000000000003, 333.5, 333.6, 333.70000000000005, 333.8,
        333.90000000000003, 334.0, 334.1, 334.20000000000005, 334.3,
        334.40000000000003, 334.5, 334.6, 334.70000000000005, 334.8,
        334.90000000000003, 335.0, 335.1, 335.20000000000005, 335.3,
        335.40000000000003, 335.5, 335.6, 335.70000000000005, 335.8,
        335.90000000000003, 336.0, 336.1, 336.20000000000005, 336.3,
        336.40000000000003, 336.5, 336.6, 336.70000000000005, 336.8,
        336.90000000000003, 337.0, 337.1, 337.20000000000005, 337.3,
        337.40000000000003, 337.5, 337.6, 337.70000000000005, 337.8,
        337.90000000000003, 338.0, 338.1, 338.20000000000005, 338.3,
        338.40000000000003, 338.5, 338.6, 338.70000000000005, 338.8,
        338.90000000000003, 339.0, 339.1, 339.20000000000005, 339.3,
        339.40000000000003, 339.5, 339.6, 339.70000000000005, 339.8,
        339.90000000000003, 340.0, 340.1, 340.20000000000005, 340.3,
        340.40000000000003, 340.5, 340.6, 340.70000000000005, 340.8,
        340.90000000000003, 341.0, 341.1, 341.20000000000005, 341.3,
        341.40000000000003, 341.5, 341.6, 341.70000000000005, 341.8,
        341.90000000000003, 342.0, 342.1, 342.20000000000005, 342.3,
        342.40000000000003, 342.5, 342.6, 342.70000000000005, 342.8,
        342.90000000000003, 343.0, 343.1, 343.20000000000005, 343.3,
        343.40000000000003, 343.5, 343.6, 343.70000000000005, 343.8,
        343.90000000000003, 344.0, 344.1, 344.20000000000005, 344.3,
        344.40000000000003, 344.5, 344.6, 344.70000000000005, 344.8,
        344.90000000000003, 345.0, 345.1, 345.20000000000005, 345.3,
        345.40000000000003, 345.5, 345.6, 345.70000000000005, 345.8,
        345.90000000000003, 346.0, 346.1, 346.20000000000005, 346.3,
        346.40000000000003, 346.5, 346.6, 346.70000000000005, 346.8,
        346.90000000000003, 347.0, 347.1, 347.20000000000005, 347.3,
        347.40000000000003, 347.5, 347.6, 347.70000000000005, 347.8,
        347.90000000000003, 348.0, 348.1, 348.20000000000005, 348.3,
        348.40000000000003, 348.5, 348.6, 348.70000000000005, 348.8,
        348.90000000000003, 349.0, 349.1, 349.20000000000005, 349.3,
        349.40000000000003, 349.5, 349.6, 349.70000000000005, 349.8,
        349.90000000000003, 350.0, 350.1, 350.20000000000005, 350.3,
        350.40000000000003, 350.5, 350.6, 350.70000000000005, 350.8,
        350.90000000000003, 351.0, 351.1, 351.20000000000005, 351.3,
        351.40000000000003, 351.5, 351.6, 351.70000000000005, 351.8,
        351.90000000000003, 352.0, 352.1, 352.20000000000005, 352.3,
        352.40000000000003, 352.5, 352.6, 352.70000000000005, 352.8,
        352.90000000000003, 353.0, 353.1, 353.20000000000005, 353.3,
        353.40000000000003, 353.5, 353.6, 353.70000000000005, 353.8,
        353.90000000000003, 354.0, 354.1, 354.20000000000005, 354.3,
        354.40000000000003, 354.5, 354.6, 354.70000000000005, 354.8,
        354.90000000000003, 355.0, 355.1, 355.20000000000005, 355.3,
        355.40000000000003, 355.5, 355.6, 355.70000000000005, 355.8,
        355.90000000000003, 356.0, 356.1, 356.20000000000005, 356.3,
        356.40000000000003, 356.5, 356.6, 356.70000000000005, 356.8,
        356.90000000000003, 357.0, 357.1, 357.20000000000005, 357.3,
        357.40000000000003, 357.5, 357.6, 357.70000000000005, 357.8,
        357.90000000000003, 358.0, 358.1, 358.20000000000005, 358.3,
        358.40000000000003, 358.5, 358.6, 358.70000000000005, 358.8,
        358.90000000000003, 359.0, 359.1, 359.20000000000005, 359.3,
        359.40000000000003, 359.5, 359.6, 359.70000000000005, 359.8,
        359.90000000000003, 360.0, 360.1, 360.20000000000005, 360.3,
        360.40000000000003, 360.5, 360.6, 360.70000000000005, 360.8,
        360.90000000000003, 361.0, 361.1, 361.20000000000005, 361.3,
        361.40000000000003, 361.5, 361.6, 361.70000000000005, 361.8,
        361.90000000000003, 362.0, 362.1, 362.20000000000005, 362.3,
        362.40000000000003, 362.5, 362.6, 362.70000000000005, 362.8,
        362.90000000000003, 363.0, 363.1, 363.20000000000005, 363.3,
        363.40000000000003, 363.5, 363.6, 363.70000000000005, 363.8,
        363.90000000000003, 364.0, 364.1, 364.20000000000005, 364.3,
        364.40000000000003, 364.5, 364.6, 364.70000000000005, 364.8,
        364.90000000000003, 365.0, 365.1, 365.20000000000005, 365.3,
        365.40000000000003, 365.5, 365.6, 365.70000000000005, 365.8,
        365.90000000000003, 366.0, 366.1, 366.20000000000005, 366.3,
        366.40000000000003, 366.5, 366.6, 366.70000000000005, 366.8,
        366.90000000000003, 367.0, 367.1, 367.20000000000005, 367.3,
        367.40000000000003, 367.5, 367.6, 367.70000000000005, 367.8,
        367.90000000000003, 368.0, 368.1, 368.20000000000005, 368.3,
        368.40000000000003, 368.5, 368.6, 368.70000000000005, 368.8,
        368.90000000000003, 369.0, 369.1, 369.20000000000005, 369.3,
        369.40000000000003, 369.5, 369.6, 369.70000000000005, 369.8,
        369.90000000000003, 370.0, 370.1, 370.20000000000005, 370.3,
        370.40000000000003, 370.5, 370.6, 370.70000000000005, 370.8,
        370.90000000000003, 371.0, 371.1, 371.20000000000005, 371.3,
        371.40000000000003, 371.5, 371.6, 371.70000000000005, 371.8,
        371.90000000000003, 372.0, 372.1, 372.20000000000005, 372.3,
        372.40000000000003, 372.5, 372.6, 372.70000000000005, 372.8,
        372.90000000000003, 373.0, 373.1, 373.20000000000005, 373.3,
        373.40000000000003, 373.5, 373.6, 373.70000000000005, 373.8,
        373.90000000000003, 374.0, 374.1, 374.20000000000005, 374.3,
        374.40000000000003, 374.5, 374.6, 374.70000000000005, 374.8,
        374.90000000000003, 375.0, 375.1, 375.20000000000005, 375.3,
        375.40000000000003, 375.5, 375.6, 375.70000000000005, 375.8,
        375.90000000000003, 376.0, 376.1, 376.20000000000005, 376.3,
        376.40000000000003, 376.5, 376.6, 376.70000000000005, 376.8,
        376.90000000000003, 377.0, 377.1, 377.20000000000005, 377.3,
        377.40000000000003, 377.5, 377.6, 377.70000000000005, 377.8,
        377.90000000000003, 378.0, 378.1, 378.20000000000005, 378.3,
        378.40000000000003, 378.5, 378.6, 378.70000000000005, 378.8,
        378.90000000000003, 379.0, 379.1, 379.20000000000005, 379.3,
        379.40000000000003, 379.5, 379.6, 379.70000000000005, 379.8,
        379.90000000000003, 380.0, 380.1, 380.20000000000005, 380.3,
        380.40000000000003, 380.5, 380.6, 380.70000000000005, 380.8,
        380.90000000000003, 381.0, 381.1, 381.20000000000005, 381.3,
        381.40000000000003, 381.5, 381.6, 381.70000000000005, 381.8,
        381.90000000000003, 382.0, 382.1, 382.20000000000005, 382.3,
        382.40000000000003, 382.5, 382.6, 382.70000000000005, 382.8,
        382.90000000000003, 383.0, 383.1, 383.20000000000005, 383.3,
        383.40000000000003, 383.5, 383.6, 383.70000000000005, 383.8,
        383.90000000000003, 384.0, 384.1, 384.20000000000005, 384.3,
        384.40000000000003, 384.5, 384.6, 384.70000000000005, 384.8,
        384.90000000000003, 385.0, 385.1, 385.20000000000005, 385.3,
        385.40000000000003, 385.5, 385.6, 385.70000000000005, 385.8,
        385.90000000000003, 386.0, 386.1, 386.20000000000005, 386.3,
        386.40000000000003, 386.5, 386.6, 386.70000000000005, 386.8,
        386.90000000000003, 387.0, 387.1, 387.20000000000005, 387.3,
        387.40000000000003, 387.5, 387.6, 387.70000000000005, 387.8,
        387.90000000000003, 388.0, 388.1, 388.20000000000005, 388.3,
        388.40000000000003, 388.5, 388.6, 388.70000000000005, 388.8,
        388.90000000000003, 389.0, 389.1, 389.20000000000005, 389.3,
        389.40000000000003, 389.5, 389.6, 389.70000000000005, 389.8,
        389.90000000000003, 390.0, 390.1, 390.20000000000005, 390.3,
        390.40000000000003, 390.5, 390.6, 390.70000000000005, 390.8,
        390.90000000000003, 391.0, 391.1, 391.20000000000005, 391.3,
        391.40000000000003, 391.5, 391.6, 391.70000000000005, 391.8,
        391.90000000000003, 392.0, 392.1, 392.20000000000005, 392.3,
        392.40000000000003, 392.5, 392.6, 392.70000000000005, 392.8,
        392.90000000000003, 393.0, 393.1, 393.20000000000005, 393.3,
        393.40000000000003, 393.5, 393.6, 393.70000000000005, 393.8,
        393.90000000000003, 394.0, 394.1, 394.20000000000005, 394.3,
        394.40000000000003, 394.5, 394.6, 394.70000000000005, 394.8,
        394.90000000000003, 395.0, 395.1, 395.20000000000005, 395.3,
        395.40000000000003, 395.5, 395.6, 395.70000000000005, 395.8,
        395.90000000000003, 396.0, 396.1, 396.20000000000005, 396.3,
        396.40000000000003, 396.5, 396.6, 396.70000000000005, 396.8,
        396.90000000000003, 397.0, 397.1, 397.20000000000005, 397.3,
        397.40000000000003, 397.5, 397.6, 397.70000000000005, 397.8,
        397.90000000000003, 398.0, 398.1, 398.20000000000005, 398.3,
        398.40000000000003, 398.5, 398.6, 398.70000000000005, 398.8,
        398.90000000000003, 399.0, 399.1, 399.20000000000005, 399.3,
        399.40000000000003, 399.5, 399.6, 399.70000000000005, 399.8,
        399.90000000000003, 400.0, 400.1, 400.20000000000005, 400.3,
        400.40000000000003, 400.5, 400.6, 400.70000000000005, 400.8,
        400.90000000000003, 401.0, 401.1, 401.20000000000005, 401.3,
        401.40000000000003, 401.5, 401.6, 401.70000000000005, 401.8,
        401.90000000000003, 402.0, 402.1, 402.20000000000005, 402.3,
        402.40000000000003, 402.5, 402.6, 402.70000000000005, 402.8,
        402.90000000000003, 403.0, 403.1, 403.20000000000005, 403.3,
        403.40000000000003, 403.5, 403.6, 403.70000000000005, 403.8,
        403.90000000000003, 404.0, 404.1, 404.20000000000005, 404.3,
        404.40000000000003, 404.5, 404.6, 404.70000000000005, 404.8,
        404.90000000000003, 405.0, 405.1, 405.20000000000005, 405.3,
        405.40000000000003, 405.5, 405.6, 405.70000000000005, 405.8,
        405.90000000000003, 406.0, 406.1, 406.20000000000005, 406.3,
        406.40000000000003, 406.5, 406.6, 406.70000000000005, 406.8,
        406.90000000000003, 407.0, 407.1, 407.20000000000005, 407.3,
        407.40000000000003, 407.5, 407.6, 407.70000000000005, 407.8,
        407.90000000000003, 408.0, 408.1, 408.20000000000005, 408.3,
        408.40000000000003, 408.5, 408.6, 408.70000000000005, 408.8,
        408.90000000000003, 409.0, 409.1, 409.20000000000005, 409.3,
        409.40000000000003, 409.5, 409.6, 409.70000000000005, 409.8,
        409.90000000000003, 410.0, 410.1, 410.20000000000005, 410.3,
        410.40000000000003, 410.5, 410.6, 410.70000000000005, 410.8,
        410.90000000000003, 411.0, 411.1, 411.20000000000005, 411.3,
        411.40000000000003, 411.5, 411.6, 411.70000000000005, 411.8,
        411.90000000000003, 412.0, 412.1, 412.20000000000005, 412.3,
        412.40000000000003, 412.5, 412.6, 412.70000000000005, 412.8,
        412.90000000000003, 413.0, 413.1, 413.20000000000005, 413.3,
        413.40000000000003, 413.5, 413.6, 413.70000000000005, 413.8,
        413.90000000000003, 414.0, 414.1, 414.20000000000005, 414.3,
        414.40000000000003, 414.5, 414.6, 414.70000000000005, 414.8,
        414.90000000000003, 415.0, 415.1, 415.20000000000005, 415.3,
        415.40000000000003, 415.5, 415.6, 415.70000000000005, 415.8,
        415.90000000000003, 416.0, 416.1, 416.20000000000005, 416.3,
        416.40000000000003, 416.5, 416.6, 416.70000000000005, 416.8,
        416.90000000000003, 417.0, 417.1, 417.20000000000005, 417.3,
        417.40000000000003, 417.5, 417.6, 417.70000000000005, 417.8,
        417.90000000000003, 418.0, 418.1, 418.20000000000005, 418.3,
        418.40000000000003, 418.5, 418.6, 418.70000000000005, 418.8,
        418.90000000000003, 419.0, 419.1, 419.20000000000005, 419.3,
        419.40000000000003, 419.5, 419.6, 419.70000000000005, 419.8,
        419.90000000000003, 420.0, 420.1, 420.20000000000005, 420.3,
        420.40000000000003, 420.5, 420.6, 420.70000000000005, 420.8,
        420.90000000000003, 421.0, 421.1, 421.20000000000005, 421.3,
        421.40000000000003, 421.5, 421.6, 421.70000000000005, 421.8,
        421.90000000000003, 422.0, 422.1, 422.20000000000005, 422.3,
        422.40000000000003, 422.5, 422.6, 422.70000000000005, 422.8,
        422.90000000000003, 423.0, 423.1, 423.20000000000005, 423.3,
        423.40000000000003, 423.5, 423.6, 423.70000000000005, 423.8,
        423.90000000000003, 424.0, 424.1, 424.20000000000005, 424.3,
        424.40000000000003, 424.5, 424.6, 424.70000000000005, 424.8,
        424.90000000000003, 425.0, 425.1, 425.20000000000005, 425.3,
        425.40000000000003, 425.5, 425.6, 425.70000000000005, 425.8,
        425.90000000000003, 426.0, 426.1, 426.20000000000005, 426.3,
        426.40000000000003, 426.5, 426.6, 426.70000000000005, 426.8,
        426.90000000000003, 427.0, 427.1, 427.20000000000005, 427.3,
        427.40000000000003, 427.5, 427.6, 427.70000000000005, 427.8,
        427.90000000000003, 428.0, 428.1, 428.20000000000005, 428.3,
        428.40000000000003, 428.5, 428.6, 428.70000000000005, 428.8,
        428.90000000000003, 429.0, 429.1, 429.20000000000005, 429.3,
        429.40000000000003, 429.5, 429.6, 429.70000000000005, 429.8,
        429.90000000000003, 430.0, 430.1, 430.20000000000005, 430.3,
        430.40000000000003, 430.5, 430.6, 430.70000000000005, 430.8,
        430.90000000000003, 431.0, 431.1, 431.20000000000005, 431.3,
        431.40000000000003, 431.5, 431.6, 431.70000000000005, 431.8,
        431.90000000000003, 432.0, 432.1, 432.20000000000005, 432.3,
        432.40000000000003, 432.5, 432.6, 432.70000000000005, 432.8,
        432.90000000000003, 433.0, 433.1, 433.20000000000005, 433.3,
        433.40000000000003, 433.5, 433.6, 433.70000000000005, 433.8,
        433.90000000000003, 434.0, 434.1, 434.20000000000005, 434.3,
        434.40000000000003, 434.5, 434.6, 434.70000000000005, 434.8,
        434.90000000000003, 435.0, 435.1, 435.20000000000005, 435.3,
        435.40000000000003, 435.5, 435.6, 435.70000000000005, 435.8,
        435.90000000000003, 436.0, 436.1, 436.20000000000005, 436.3,
        436.40000000000003, 436.5, 436.6, 436.70000000000005, 436.8,
        436.90000000000003, 437.0, 437.1, 437.20000000000005, 437.3,
        437.40000000000003, 437.5, 437.6, 437.70000000000005, 437.8,
        437.90000000000003, 438.0, 438.1, 438.20000000000005, 438.3,
        438.40000000000003, 438.5, 438.6, 438.70000000000005, 438.8,
        438.90000000000003, 439.0, 439.1, 439.20000000000005, 439.3,
        439.40000000000003, 439.5, 439.6, 439.70000000000005, 439.8,
        439.90000000000003, 440.0, 440.1, 440.20000000000005, 440.3,
        440.40000000000003, 440.5, 440.6, 440.70000000000005, 440.8,
        440.90000000000003, 441.0, 441.1, 441.20000000000005, 441.3,
        441.40000000000003, 441.5, 441.6, 441.70000000000005, 441.8,
        441.90000000000003, 442.0, 442.1, 442.20000000000005, 442.3,
        442.40000000000003, 442.5, 442.6, 442.70000000000005, 442.8,
        442.90000000000003, 443.0, 443.1, 443.20000000000005, 443.3,
        443.40000000000003, 443.5, 443.6, 443.70000000000005, 443.8,
        443.90000000000003, 444.0, 444.1, 444.20000000000005, 444.3,
        444.40000000000003, 444.5, 444.6, 444.70000000000005, 444.8,
        444.90000000000003, 445.0, 445.1, 445.20000000000005, 445.3,
        445.40000000000003, 445.5, 445.6, 445.70000000000005, 445.8,
        445.90000000000003, 446.0, 446.1, 446.20000000000005, 446.3,
        446.40000000000003, 446.5, 446.6, 446.70000000000005, 446.8,
        446.90000000000003, 447.0, 447.1, 447.20000000000005, 447.3,
        447.40000000000003, 447.5, 447.6, 447.70000000000005, 447.8,
        447.90000000000003, 448.0, 448.1, 448.20000000000005, 448.3,
        448.40000000000003, 448.5, 448.6, 448.70000000000005, 448.8,
        448.90000000000003, 449.0, 449.1, 449.20000000000005, 449.3,
        449.40000000000003, 449.5, 449.6, 449.70000000000005, 449.8,
        449.90000000000003, 450.0, 450.1, 450.20000000000005, 450.3,
        450.40000000000003, 450.5, 450.6, 450.70000000000005, 450.8,
        450.90000000000003, 451.0, 451.1, 451.20000000000005, 451.3,
        451.40000000000003, 451.5, 451.6, 451.70000000000005, 451.8,
        451.90000000000003, 452.0, 452.1, 452.20000000000005, 452.3,
        452.40000000000003, 452.5, 452.6, 452.70000000000005, 452.8,
        452.90000000000003, 453.0, 453.1, 453.20000000000005, 453.3,
        453.40000000000003, 453.5, 453.6, 453.70000000000005, 453.8,
        453.90000000000003, 454.0, 454.1, 454.20000000000005, 454.3,
        454.40000000000003, 454.5, 454.6, 454.70000000000005, 454.8,
        454.90000000000003, 455.0, 455.1, 455.20000000000005, 455.3,
        455.40000000000003, 455.5, 455.6, 455.70000000000005, 455.8,
        455.90000000000003, 456.0, 456.1, 456.20000000000005, 456.3,
        456.40000000000003, 456.5, 456.6, 456.70000000000005, 456.8,
        456.90000000000003, 457.0, 457.1, 457.20000000000005, 457.3,
        457.40000000000003, 457.5, 457.6, 457.70000000000005, 457.8,
        457.90000000000003, 458.0, 458.1, 458.20000000000005, 458.3,
        458.40000000000003, 458.5, 458.6, 458.70000000000005, 458.8,
        458.90000000000003, 459.0, 459.1, 459.20000000000005, 459.3,
        459.40000000000003, 459.5, 459.6, 459.70000000000005, 459.8,
        459.90000000000003, 460.0, 460.1, 460.20000000000005, 460.3,
        460.40000000000003, 460.5, 460.6, 460.70000000000005, 460.8,
        460.90000000000003, 461.0, 461.1, 461.20000000000005, 461.3,
        461.40000000000003, 461.5, 461.6, 461.70000000000005, 461.8,
        461.90000000000003, 462.0, 462.1, 462.20000000000005, 462.3,
        462.40000000000003, 462.5, 462.6, 462.70000000000005, 462.8,
        462.90000000000003, 463.0, 463.1, 463.20000000000005, 463.3,
        463.40000000000003, 463.5, 463.6, 463.70000000000005, 463.8,
        463.90000000000003, 464.0, 464.1, 464.20000000000005, 464.3,
        464.40000000000003, 464.5, 464.6, 464.70000000000005, 464.8,
        464.90000000000003, 465.0, 465.1, 465.20000000000005, 465.3,
        465.40000000000003, 465.5, 465.6, 465.70000000000005, 465.8,
        465.90000000000003, 466.0, 466.1, 466.20000000000005, 466.3,
        466.40000000000003, 466.5, 466.6, 466.70000000000005, 466.8,
        466.90000000000003, 467.0, 467.1, 467.20000000000005, 467.3,
        467.40000000000003, 467.5, 467.6, 467.70000000000005, 467.8,
        467.90000000000003, 468.0, 468.1, 468.20000000000005, 468.3,
        468.40000000000003, 468.5, 468.6, 468.70000000000005, 468.8,
        468.90000000000003, 469.0, 469.1, 469.20000000000005, 469.3,
        469.40000000000003, 469.5, 469.6, 469.70000000000005, 469.8,
        469.90000000000003, 470.0, 470.1, 470.20000000000005, 470.3,
        470.40000000000003, 470.5, 470.6, 470.70000000000005, 470.8,
        470.90000000000003, 471.0, 471.1, 471.20000000000005, 471.3,
        471.40000000000003, 471.5, 471.6, 471.70000000000005, 471.8,
        471.90000000000003, 472.0, 472.1, 472.20000000000005, 472.3,
        472.40000000000003, 472.5, 472.6, 472.70000000000005, 472.8,
        472.90000000000003, 473.0, 473.1, 473.20000000000005, 473.3,
        473.40000000000003, 473.5, 473.6, 473.70000000000005, 473.8,
        473.90000000000003, 474.0, 474.1, 474.20000000000005, 474.3,
        474.40000000000003, 474.5, 474.6, 474.70000000000005, 474.8,
        474.90000000000003, 475.0, 475.1, 475.20000000000005, 475.3,
        475.40000000000003, 475.5, 475.6, 475.70000000000005, 475.8,
        475.90000000000003, 476.0, 476.1, 476.20000000000005, 476.3,
        476.40000000000003, 476.5, 476.6, 476.70000000000005, 476.8,
        476.90000000000003, 477.0, 477.1, 477.20000000000005, 477.3,
        477.40000000000003, 477.5, 477.6, 477.70000000000005, 477.8,
        477.90000000000003, 478.0, 478.1, 478.20000000000005, 478.3,
        478.40000000000003, 478.5, 478.6, 478.70000000000005, 478.8,
        478.90000000000003, 479.0, 479.1, 479.20000000000005, 479.3,
        479.40000000000003, 479.5, 479.6, 479.70000000000005, 479.8,
        479.90000000000003, 480.0, 480.1, 480.20000000000005, 480.3,
        480.40000000000003, 480.5, 480.6, 480.70000000000005, 480.8,
        480.90000000000003, 481.0, 481.1, 481.20000000000005, 481.3,
        481.40000000000003, 481.5, 481.6, 481.70000000000005, 481.8,
        481.90000000000003, 482.0, 482.1, 482.20000000000005, 482.3,
        482.40000000000003, 482.5, 482.6, 482.70000000000005, 482.8,
        482.90000000000003, 483.0, 483.1, 483.20000000000005, 483.3,
        483.40000000000003, 483.5, 483.6, 483.70000000000005, 483.8,
        483.90000000000003, 484.0, 484.1, 484.20000000000005, 484.3,
        484.40000000000003, 484.5, 484.6, 484.70000000000005, 484.8,
        484.90000000000003, 485.0, 485.1, 485.20000000000005, 485.3,
        485.40000000000003, 485.5, 485.6, 485.70000000000005, 485.8,
        485.90000000000003, 486.0, 486.1, 486.20000000000005, 486.3,
        486.40000000000003, 486.5, 486.6, 486.70000000000005, 486.8,
        486.90000000000003, 487.0, 487.1, 487.20000000000005, 487.3,
        487.40000000000003, 487.5, 487.6, 487.70000000000005, 487.8,
        487.90000000000003, 488.0, 488.1, 488.20000000000005, 488.3,
        488.40000000000003, 488.5, 488.6, 488.70000000000005, 488.8,
        488.90000000000003, 489.0, 489.1, 489.20000000000005, 489.3,
        489.40000000000003, 489.5, 489.6, 489.70000000000005, 489.8,
        489.90000000000003, 490.0, 490.1, 490.20000000000005, 490.3,
        490.40000000000003, 490.5, 490.6, 490.70000000000005, 490.8,
        490.90000000000003, 491.0, 491.1, 491.20000000000005, 491.3,
        491.40000000000003, 491.5, 491.6, 491.70000000000005, 491.8,
        491.90000000000003, 492.0, 492.1, 492.20000000000005, 492.3,
        492.40000000000003, 492.5, 492.6, 492.70000000000005, 492.8,
        492.90000000000003, 493.0, 493.1, 493.20000000000005, 493.3,
        493.40000000000003, 493.5, 493.6, 493.70000000000005, 493.8,
        493.90000000000003, 494.0, 494.1, 494.20000000000005, 494.3,
        494.40000000000003, 494.5, 494.6, 494.70000000000005, 494.8,
        494.90000000000003, 495.0, 495.1, 495.20000000000005, 495.3,
        495.40000000000003, 495.5, 495.6, 495.70000000000005, 495.8,
        495.90000000000003, 496.0, 496.1, 496.20000000000005, 496.3,
        496.40000000000003, 496.5, 496.6, 496.70000000000005, 496.8,
        496.90000000000003, 497.0, 497.1, 497.20000000000005, 497.3,
        497.40000000000003, 497.5, 497.6, 497.70000000000005, 497.8,
        497.90000000000003, 498.0, 498.1, 498.20000000000005, 498.3,
        498.40000000000003, 498.5, 498.6, 498.70000000000005, 498.8,
        498.90000000000003, 499.0, 499.1, 499.20000000000005, 499.3,
        499.40000000000003, 499.5, 499.6, 499.70000000000005, 499.8,
        499.90000000000003, 500.0, 500.1, 500.20000000000005, 500.3,
        500.40000000000003, 500.5, 500.6, 500.70000000000005, 500.8,
        500.90000000000003, 501.0, 501.1, 501.20000000000005, 501.3,
        501.40000000000003, 501.5, 501.6, 501.70000000000005, 501.8,
        501.90000000000003, 502.0, 502.1, 502.20000000000005, 502.3,
        502.40000000000003, 502.5, 502.6, 502.70000000000005, 502.8,
        502.90000000000003, 503.0, 503.1, 503.20000000000005, 503.3,
        503.40000000000003, 503.5, 503.6, 503.70000000000005, 503.8,
        503.90000000000003, 504.0, 504.1, 504.20000000000005, 504.3,
        504.40000000000003, 504.5, 504.6, 504.70000000000005, 504.8,
        504.90000000000003, 505.0, 505.1, 505.20000000000005, 505.3,
        505.40000000000003, 505.5, 505.6, 505.70000000000005, 505.8,
        505.90000000000003, 506.0, 506.1, 506.20000000000005, 506.3,
        506.40000000000003, 506.5, 506.6, 506.70000000000005, 506.8,
        506.90000000000003, 507.0, 507.1, 507.20000000000005, 507.3,
        507.40000000000003, 507.5, 507.6, 507.70000000000005, 507.8,
        507.90000000000003, 508.0, 508.1, 508.20000000000005, 508.3,
        508.40000000000003, 508.5, 508.6, 508.70000000000005, 508.8,
        508.90000000000003, 509.0, 509.1, 509.20000000000005, 509.3,
        509.40000000000003, 509.5, 509.6, 509.70000000000005, 509.8,
        509.90000000000003, 510.0, 510.1, 510.20000000000005, 510.3,
        510.40000000000003, 510.5, 510.6, 510.70000000000005, 510.8,
        510.90000000000003, 511.0, 511.1, 511.20000000000005, 511.3,
        511.40000000000003, 511.5, 511.6, 511.70000000000005, 511.8,
        511.90000000000003, 512.0, 512.1, 512.2, 512.30000000000007, 512.4,
        512.5, 512.6, 512.7, 512.80000000000007, 512.9, 513.0, 513.1, 513.2,
        513.30000000000007, 513.4, 513.5, 513.6, 513.7, 513.80000000000007,
        513.9, 514.0, 514.1, 514.2, 514.30000000000007, 514.4, 514.5, 514.6,
        514.7, 514.80000000000007, 514.9, 515.0, 515.1, 515.2,
        515.30000000000007, 515.4, 515.5, 515.6, 515.7, 515.80000000000007,
        515.9, 516.0, 516.1, 516.2, 516.30000000000007, 516.4, 516.5, 516.6,
        516.7, 516.80000000000007, 516.9, 517.0, 517.1, 517.2,
        517.30000000000007, 517.4, 517.5, 517.6, 517.7, 517.80000000000007,
        517.9, 518.0, 518.1, 518.2, 518.30000000000007, 518.4, 518.5, 518.6,
        518.7, 518.80000000000007, 518.9, 519.0, 519.1, 519.2,
        519.30000000000007, 519.4, 519.5, 519.6, 519.7, 519.80000000000007,
        519.9, 520.0, 520.1, 520.2, 520.30000000000007, 520.4, 520.5, 520.6,
        520.7, 520.80000000000007, 520.9, 521.0, 521.1, 521.2,
        521.30000000000007, 521.4, 521.5, 521.6, 521.7, 521.80000000000007,
        521.9, 522.0, 522.1, 522.2, 522.30000000000007, 522.4, 522.5, 522.6,
        522.7, 522.80000000000007, 522.9, 523.0, 523.1, 523.2,
        523.30000000000007, 523.4, 523.5, 523.6, 523.7, 523.80000000000007,
        523.9, 524.0, 524.1, 524.2, 524.30000000000007, 524.4, 524.5, 524.6,
        524.7, 524.80000000000007, 524.9, 525.0, 525.1, 525.2,
        525.30000000000007, 525.4, 525.5, 525.6, 525.7, 525.80000000000007,
        525.9, 526.0, 526.1, 526.2, 526.30000000000007, 526.4, 526.5, 526.6,
        526.7, 526.80000000000007, 526.9, 527.0, 527.1, 527.2,
        527.30000000000007, 527.4, 527.5, 527.6, 527.7, 527.80000000000007,
        527.9, 528.0, 528.1, 528.2, 528.30000000000007, 528.4, 528.5, 528.6,
        528.7, 528.80000000000007, 528.9, 529.0, 529.1, 529.2,
        529.30000000000007, 529.4, 529.5, 529.6, 529.7, 529.80000000000007,
        529.9, 530.0, 530.1, 530.2, 530.30000000000007, 530.4, 530.5, 530.6,
        530.7, 530.80000000000007, 530.9, 531.0, 531.1, 531.2,
        531.30000000000007, 531.4, 531.5, 531.6, 531.7, 531.80000000000007,
        531.9, 532.0, 532.1, 532.2, 532.30000000000007, 532.4, 532.5, 532.6,
        532.7, 532.80000000000007, 532.9, 533.0, 533.1, 533.2,
        533.30000000000007, 533.4, 533.5, 533.6, 533.7, 533.80000000000007,
        533.9, 534.0, 534.1, 534.2, 534.30000000000007, 534.4, 534.5, 534.6,
        534.7, 534.80000000000007, 534.9, 535.0, 535.1, 535.2,
        535.30000000000007, 535.4, 535.5, 535.6, 535.7, 535.80000000000007,
        535.9, 536.0, 536.1, 536.2, 536.30000000000007, 536.4, 536.5, 536.6,
        536.7, 536.80000000000007, 536.9, 537.0, 537.1, 537.2,
        537.30000000000007, 537.4, 537.5, 537.6, 537.7, 537.80000000000007,
        537.9, 538.0, 538.1, 538.2, 538.30000000000007, 538.4, 538.5, 538.6,
        538.7, 538.80000000000007, 538.9, 539.0, 539.1, 539.2,
        539.30000000000007, 539.4, 539.5, 539.6, 539.7, 539.80000000000007,
        539.9, 540.0, 540.1, 540.2, 540.30000000000007, 540.4, 540.5, 540.6,
        540.7, 540.80000000000007, 540.9, 541.0, 541.1, 541.2,
        541.30000000000007, 541.4, 541.5, 541.6, 541.7, 541.80000000000007,
        541.9, 542.0, 542.1, 542.2, 542.30000000000007, 542.4, 542.5, 542.6,
        542.7, 542.80000000000007, 542.9, 543.0, 543.1, 543.2,
        543.30000000000007, 543.4, 543.5, 543.6, 543.7, 543.80000000000007,
        543.9, 544.0, 544.1, 544.2, 544.30000000000007, 544.4, 544.5, 544.6,
        544.7, 544.80000000000007, 544.9, 545.0, 545.1, 545.2,
        545.30000000000007, 545.4, 545.5, 545.6, 545.7, 545.80000000000007,
        545.9, 546.0, 546.1, 546.2, 546.30000000000007, 546.4, 546.5, 546.6,
        546.7, 546.80000000000007, 546.9, 547.0, 547.1, 547.2,
        547.30000000000007, 547.4, 547.5, 547.6, 547.7, 547.80000000000007,
        547.9, 548.0, 548.1, 548.2, 548.30000000000007, 548.4, 548.5, 548.6,
        548.7, 548.80000000000007, 548.9, 549.0, 549.1, 549.2,
        549.30000000000007, 549.4, 549.5, 549.6, 549.7, 549.80000000000007,
        549.9, 550.0, 550.1, 550.2, 550.30000000000007, 550.4, 550.5, 550.6,
        550.7, 550.80000000000007, 550.9, 551.0, 551.1, 551.2,
        551.30000000000007, 551.4, 551.5, 551.6, 551.7, 551.80000000000007,
        551.9, 552.0, 552.1, 552.2, 552.30000000000007, 552.4, 552.5, 552.6,
        552.7, 552.80000000000007, 552.9, 553.0, 553.1, 553.2,
        553.30000000000007, 553.4, 553.5, 553.6, 553.7, 553.80000000000007,
        553.9, 554.0, 554.1, 554.2, 554.30000000000007, 554.4, 554.5, 554.6,
        554.7, 554.80000000000007, 554.9, 555.0, 555.1, 555.2,
        555.30000000000007, 555.4, 555.5, 555.6, 555.7, 555.80000000000007,
        555.9, 556.0, 556.1, 556.2, 556.30000000000007, 556.4, 556.5, 556.6,
        556.7, 556.80000000000007, 556.9, 557.0, 557.1, 557.2,
        557.30000000000007, 557.4, 557.5, 557.6, 557.7, 557.80000000000007,
        557.9, 558.0, 558.1, 558.2, 558.30000000000007, 558.4, 558.5, 558.6,
        558.7, 558.80000000000007, 558.9, 559.0, 559.1, 559.2,
        559.30000000000007, 559.4, 559.5, 559.6, 559.7, 559.80000000000007,
        559.9, 560.0, 560.1, 560.2, 560.30000000000007, 560.4, 560.5, 560.6,
        560.7, 560.80000000000007, 560.9, 561.0, 561.1, 561.2,
        561.30000000000007, 561.4, 561.5, 561.6, 561.7, 561.80000000000007,
        561.9, 562.0, 562.1, 562.2, 562.30000000000007, 562.4, 562.5, 562.6,
        562.7, 562.80000000000007, 562.9, 563.0, 563.1, 563.2,
        563.30000000000007, 563.4, 563.5, 563.6, 563.7, 563.80000000000007,
        563.9, 564.0, 564.1, 564.2, 564.30000000000007, 564.4, 564.5, 564.6,
        564.7, 564.80000000000007, 564.9, 565.0, 565.1, 565.2,
        565.30000000000007, 565.4, 565.5, 565.6, 565.7, 565.80000000000007,
        565.9, 566.0, 566.1, 566.2, 566.30000000000007, 566.4, 566.5, 566.6,
        566.7, 566.80000000000007, 566.9, 567.0, 567.1, 567.2,
        567.30000000000007, 567.4, 567.5, 567.6, 567.7, 567.80000000000007,
        567.9, 568.0, 568.1, 568.2, 0.0043405784546131912, -0.016603223016307289,
        -0.049101693216502131, -0.084708093358320247, -0.1192719870565591,
        -0.1509078711790996, -0.17890739132614683, -0.20315874412101323,
        -0.22383849594259941, -0.24124953120736389, -0.25573721627274415,
        -0.26764727464361115, -0.27730576896159281, -0.29595743462188984,
        -0.26004649688966014, -0.23101952078524368, -0.20907211908129972,
        -0.1917167776950143, -0.17752394172193348, -0.16564289205134788,
        -0.15554346532596705, -0.14687625686120714, -0.13939652788381243,
        -0.1329224401703466, -0.12731183805448251, -0.080575769187652371,
        -0.015819993421445151, 0.052729300943502679, 0.11816830623974568,
        0.14005395452942476, 0.13730801459979464, 0.12309834383377366,
        0.10429741201217971, 0.08441613393377409, 0.06517854930126489,
        0.047366339328780288, 0.031271000640350453, 0.016935225165300185,
        0.0042810866509361946, -0.0068224891828940065, -0.01652475796555811,
        -0.024975530950324846, -0.032316747355970607, -0.038678877433262093,
        -0.03691449313148449, -0.032428480912226144, -0.027009479191447788,
        -0.021552981252364517, -0.016481392754064555, -0.011969502988146353,
        -0.00806512571286934, -0.0047533353108453183, 0.042218240408261845,
        0.11192373003484075, 0.1871385218026527, 0.25945498310277665,
        0.32510358332970946, 0.38271878573795126, 0.43214826520613825,
        0.47382173577180242, 0.47723709485114174, 0.45641771628235944,
        0.42525756818261196, 0.39091372579976086, 0.35695777330138245,
        0.32506496803419327, 0.29591873619492315, 0.26969392408588427,
        0.24631392646574138, 0.22558651418646858, 0.20727468764904577,
        0.1911328212576543, 0.17692435353488475, 0.16442974434032145,
        0.15344937035842304, 0.14380385302455537, 0.13533314369193883,
        0.12789506345677409, 0.12136365913307856, 0.11562755761386162,
        0.11058840575210065, 0.10615943293206237, 0.10226414769865919,
        0.09883516689237079, 0.09581316964321282, 0.093145966061303556,
        0.090787669786184591, 0.088697963796434617, 0.086841449545433283,
        0.085187070322247274, 0.083707600607344113, 0.082379194036514267,
        0.081180983373489474, 0.08009472661107013, 0.079104493970273221,
        0.078196391149781885, 0.028602155882729768, 0.020318445690144762,
        0.03166115570253808, 0.051310634157858463, 0.073455923923013131,
        0.095217043296406, 0.073275593667121122, 0.032229879704123707,
        -0.014835633530943106, -0.06141976420479002, -0.10449918302851828,
        -0.099005496176771873, -0.0707755133428475, -0.033844399088357485,
        0.0046730245820876875, 0.041333905543186111, 0.074625657041818713,
        0.1040340341685561, 0.12954629781963958, 0.15138797148753566,
        0.16988483681664188, 0.18539191328119758, 0.19825811814781552,
        0.20880980076958078, 0.21734414306034522, 0.22412761070225362,
        0.22939689258254389, 0.233360975295126, 0.2362036475417866,
        0.23800642576491987, 0.23882771236915748, 0.23889627947859124,
        0.23837235383935021, 0.23737440304390503, 0.23599409945293728,
        0.23430488851861711, 0.23236706575703542, 0.23023092375042592,
        0.22793881271725858, 0.19659557998674659, 0.15046756789942853,
        0.10057708037960923, 0.0523258339532839, 0.00815591055902835,
        -0.031027139046094061, -0.0650954214961743, -0.064792068124289587,
        -0.0450191266063873, -0.017472636338039846, 0.011888080481049543,
        0.040149487395682158, 0.066001866218464933, 0.0889678486521675,
        0.10899094267184317, 0.12621726456394766, 0.14088085169354903,
        0.15324439266181833, 0.14859642813720839, 0.13334955461023784,
        0.11416367770135834, 0.09440121471861701, 0.0756779789605723,
        0.058693419709790119, 0.0436742981121439, 0.045958586837448023,
        0.059495850730987426, 0.077281751957660863, 0.095776030207172277,
        0.11327342721890218, 0.12903169227045092, 0.1428056113910959,
        0.15259996914511506, 0.16002385561221147, 0.16569514833482418,
        0.17001158361745389, 0.17324422499476569, 0.18215908523380339,
        0.19135249333800283, 0.19988023650786385, 0.2073419546722482,
        0.21361761615055402, 0.20811281906537069, 0.19891038124674093,
        0.18843721137109726, 0.17791548486799774, 0.16792789172814115,
        0.15872134248867786, 0.15036965752773609, 0.14286032963872203,
        0.13614046789247106, 0.13014084047698032, 0.13688215280105676,
        0.14752129304859363, 0.15914001577995435, 0.17031006996262246,
        0.18038873202260047, 0.18914112113406051, 0.19653849807889759,
        0.202651204276296, 0.19140251925265378, 0.17413677950084108,
        0.15512294880955316, 0.13647478751176551, 0.11916721571494647,
        0.1035812895255393, 0.08979546352231943, 0.077740441889840611,
        0.0672807923026478, 0.058257325094123825, 0.067425675597024975,
        0.082954734687362919, 0.10034749971299389, 0.11737829350279295,
        0.13302139698247836, 0.14687663331031825, 0.15886240623376233,
        0.16905252851744895, 0.17759024415061292, 0.15965563847258257,
        0.13171655016513226, 0.10095712021229079, 0.070922558669970132,
        0.04323742567569791, 0.018526273523707597, -0.0030946631466706878,
        -0.021756264200664292, -0.0376990042992528, -0.051201662025322538,
        -0.06254536754223522, -0.071996395232700475, -0.079798800282120483,
        -0.0861721356872316, -0.065932967163407963, -0.035695673064867324,
        -0.0028125639194169342, 0.029099034709627967, 0.058392111732318945,
        0.084444620223411912, 0.1071546950990807, 0.12667257834754678,
        0.14325955340179736, 0.12856097105218744, 0.10099547540341115,
        0.0692526238998978, 0.037665932263826807, 0.0082650951592744635,
        -0.018124138764174944, -0.041292134238156454, -0.06133266575168634,
        -0.078477882067040233, -0.093012380694409313, -0.10522953241342449,
        -0.11541025288392429, -0.1238135953162728, -0.13067347409764404,
        -0.13619848282791186, -0.14057319561160303, -0.14396010508376031,
        -0.14650175989888872, -0.14832288263065552, -0.14953236465142175,
        -0.15022509516238849, -0.15048361271420993, -0.15037958304690893,
        -0.149975114271405, -0.14932392327169561, -0.14847236784330498,
        -0.14746035862651924, -0.14632216393720957, -0.14508711945389427,
        -0.1437802535451117, -0.14242283789326898, -0.14103287202430384,
        -0.13962550939901217, -0.13821343186273963, -0.13680717848093155,
        -0.13541543410197152, -0.1340452823782905, -0.13270242743433958,
        -0.13139138788855159, -0.13011566650930476, -0.12887789840615327,
        -0.10318218336730581, -0.067687508496247009, -0.030095883020155388,
        0.0058499246735089269, 0.038489584640368106, 0.067240983300719967,
        0.092064769956713532, 0.11318056383744732, 0.13091808728451176,
        0.12457842337748916, 0.10714938344345887, 0.085570690254869228,
        0.063356909915755807, 0.0422051989142935, 0.022857404352001485,
        0.0055613703593156939, -0.0096831122448413284, -0.022993984811245465,
        -0.03453859616753218, -0.027451202103917733, -0.01188299806584347,
        0.00649955056928521, 0.024868996972056544, 0.041898920388635318,
        0.057047206839040562, 0.0701731299036659, 0.081333700820126129,
        0.090676204394828278, 0.086298698986691152, 0.075608079305257037,
        0.0625890823897289, 0.049256476817596637, 0.036580143721239161,
        0.024981065625872743, 0.022320489938280605, 0.02401642732507997,
        0.027541707521959745, 0.031602864160052223, 0.035562243966668246,
        0.039128035763747973, 0.042188304851383182, 0.040049570505832417,
        0.035459515727982872, 0.029974710743863004, 0.024381329132396455,
        0.01905705653321884, 0.014165089865373117, 0.00975790857379909,
        0.0058325750057925127, 0.0023600154456135283, -0.00069964634027397225,
        -0.0080866727071855077, -0.017346912328681074, -0.026848059192572483,
        -0.035809768011489114, -0.043898193715135536, -0.051009337292480868,
        -0.046732932996242607, -0.037089910201156338, -0.025614010594199928,
        -0.014075176115757681, -0.0033100096217305868, 0.0063333247778240911,
        0.014757331347887866, 0.02198865014510442, 0.028111213391251038,
        0.015545603976246389, -0.005590972333572565, -0.029275679870894425,
        -0.052527938580349778, -0.07397282368933715, -0.093071959059773127,
        -0.10971292072348422, -0.12399111802227598, -0.13609490930038365,
        -0.12673781973630729, -0.10707323673947472, -0.083907536127511728,
        -0.060649298167544684, -0.03890920960404598, -0.019357096435193014,
        -0.002179928021408593, 0.012674455300829928, 0.025368586498126931,
        0.0361082073235584, 0.045108006075038613, 0.052574847462756744,
        0.05870022581107337, 0.063657512982778677, 0.060893932308901708,
        0.054530881284348839, 0.046816296612171987, 0.03889049104881568,
        0.031305795065094885, 0.024305220093922154, 0.017971598487988998,
        0.012307126836029315, 0.0072755393795363651, -0.013747628168418824,
        -0.041829130256680072, -0.071244103927632335, -0.099225367280389984,
        -0.12455923077044509, -0.14683473152420018, -0.16604362724167038,
        -0.18236858600875738, -0.1906471892972269, -0.19352766767931115,
        -0.19354190851226008, -0.19205606397705796, -0.18980850135199653,
        -0.18719902046238091, -0.18444448807007152, -0.18166266807949613,
        -0.17891742844014666, -0.17624315959805043, -0.17365799623855316,
        -0.17412420488838071, -0.1766869888496882, -0.17991894530330335,
        -0.18311564987591633, -0.18595335968569732, -0.18830611828861132,
        -0.190148282379665, -0.19150283423576625, -0.19241421917011936,
        -0.20180093168475624, -0.2134578014398244, -0.22523568800432975,
        -0.23612226171287307, -0.245699870649426, -0.25385551231193981,
        -0.26062644830696163, -0.26611868789662929, -0.27046453277590665,
        -0.27380099099860411, -0.27625928077000017, -0.25313802978567174,
        -0.21994561541677821, -0.18424288694679661, -0.14973572365106355,
        -0.1180984191102428, -0.089949983916481777, -0.065375178751157892,
        -0.044201034828394242, -0.026142221191185103, -0.047863756533699522,
        -0.086352214925465631, -0.13002334932642662, -0.17312426540910755,
        -0.21298302943262992, -0.24853523368116934, -0.27953689866629822,
        -0.30614605033729991, -0.32870211917546532, -0.34761128381636591,
        -0.36328837099479772, -0.376128782813149, -0.38649621920800376,
        -0.39471857672830474, -0.40108795960342841, -0.40586264835624775,
        -0.40926989522276847, -0.41150896355409283, -0.41275412039283482,
        -0.41315744601599386, -0.41285140515822494, -0.41195116614975508,
        -0.41055667474337526, -0.40875449885517362, -0.40661946410504607,
        -0.40421610074868636, -0.40159992184984783, -0.39881855114550263,
        -0.39591271742096018, -0.39291713054733918, -0.38986125274191274,
        -0.38676997713779115, -0.383664224408452, -0.380561466985367,
        -0.37747618932648752, -0.37442029173003449, -0.37140344433098449,
        -0.368433397156281, -0.36551625143899308, -0.36265669679218238,
        -0.35985821831169679, -0.35712327720592912, -0.3544534681330665,
        -0.35184965605637619, -0.34931209510042543, -0.34684053160087663,
        -0.34443429328354797, -0.29510453757405597, -0.22736692716444487,
        -0.15574214177037762, -0.087280900729153774, -0.02510546610595733,
        0.029695326451507978, 0.077055655196863068, 0.11739724136431644,
        0.151348520894278, 0.12291559969098168, 0.067320948919407042,
        0.00263385656693948, -0.062102020225263718, -0.12261991467313317,
        -0.17715292779219152, -0.22521681141800257, -0.26696211885231846,
        -0.30283194657835272, -0.33338341470057054, -0.35919662689085263,
        -0.38083013952983036, -0.39880095348711964, -0.41357725206833912,
        -0.42557759763351038, -0.38990939663598978, -0.33454139252546783,
        -0.27364566670891788, -0.21421540569268996, -0.15945571357244737,
        -0.11059954472430751, -0.067877267933769789, -0.031031658254273495,
        0.00041097145590805484, -0.022230121647500083, -0.067833301800804921,
        -0.1210840644609139, -0.17432670975792419, -0.22395795545423716,
        -0.26849411045893956, -0.30753792866093205, -0.3412288428964424,
        -0.36995264215089047, -0.39419015295962351, -0.37615430200169581,
        -0.3403520962722637, -0.29856904649932325, -0.2567043842827747,
        -0.21754170858590041, -0.18223412620787316, -0.15109823778263426,
        -0.1240367420111947, -0.13804004784218, -0.16833135257432028,
        -0.20411975148423175, -0.24000649778935815, -0.27344697301215715,
        -0.30338986686755515, -0.32954956872497831, -0.35201890387621876,
        -0.37106459097693029, -0.38702061566297835, -0.4002339159865938,
        -0.41103787442226497, -0.39421049456608076, -0.36734375507189532,
        -0.3374508186903557, -0.30801487246669595, -0.28065276985584675,
        -0.256007042912696, -0.234222709132855, -0.21520086925007978,
        -0.22123011936743051, -0.23596147978126486, -0.25369948448451413,
        -0.27158804574308826, -0.28827552272985535, -0.30319825591498845,
        -0.31619719381314654, -0.32731371259707115, -0.33668170040132928,
        -0.3444712527892167, -0.35085995307043638, -0.36161534864016126,
        -0.37643871360088615, -0.39192495770489494, -0.40644345998142661,
        -0.41929237197970759, -0.43024767082821036, -0.43932345173576154,
        -0.43617802402445865, -0.42347959633475257, -0.40703045142119171,
        -0.38978308722689925, -0.3731783861860789, -0.35786176648843765,
        -0.34406600200902832, -0.33181529222975031, -0.32103347730488924,
        -0.33418805778078486, -0.36156892617290021, -0.39350623265609691,
        -0.42519375869370973, -0.454392630041914, -0.48020300079421585,
        -0.50240854663541779, -0.521128210920267, -0.51296848020693553,
        -0.48809890596903455, -0.45696360309082268, -0.42484538770844371,
        -0.39429185528201005, -0.36641433455612132, -0.34158220213500967,
        -0.31979275560431725, -0.30086705701742655, -0.28455253247532231,
        -0.27057572439691763, -0.2986870711979776, -0.34943530664025707,
        -0.40707746268558587, -0.463813550563229, -0.51603488797765251,
        -0.562316832968951, -0.602347566864574, -0.63635911332229178,
        -0.66482762230687975, -0.64957978488127577, -0.60947247439122543,
        -0.56025824825906878, -0.50988594096357265, -0.46217006580912179,
        -0.41875589713067785, -0.38016986271835462, -0.34637898817799623,
        -0.31708696138567705, -0.2918890788983351, -0.31214841369661867,
        -0.3573575597324381, -0.4109369589299966, -0.46460483421625393,
        -0.51446545643933361, -0.55891537135332081, -0.59752524752775837,
        -0.6304452816007553, -0.61708920343694484, -0.577127960715629,
        -0.527316240915482, -0.47611385600606659, -0.42758584695618712,
        -0.38349106208523392, -0.34439855693499011, -0.31028220632522657,
        -0.28083539695294518, -0.25563574108708709, -0.23422962401611414,
        -0.21617408083831383, -0.23948847731412806, -0.28566319798202794,
        -0.33927322483483768, -0.3926303946870881, -0.44213431697057193,
        -0.48631946743385518, -0.52481245597258375, -0.55777768768387659,
        -0.55437503300485946, -0.52853142485583682, -0.4938514530530228,
        -0.45725299155910021, -0.42210624645310524, -0.38991500291040188,
        -0.36121571144964137, -0.33605680381847758, -0.314252795955721,
        -0.2955176856387679, -0.27953379075622725, -0.26598618562629789,
        -0.273655206596109, -0.29428864400430244, -0.31952383541744223,
        -0.34515856414102236, -0.36919217460417236, -0.39077712268155818,
        -0.4096588951827051, -0.42587794796222078, -0.43961215712719032,
        -0.43725503039366559, -0.42269730565413016, -0.40339560392251744,
        -0.38313339243712363, -0.36374726865529222, -0.34605070412672378,
        -0.33032768218458869, -0.31659568998623849, -0.30474503838360295,
        -0.29461192941966957, -0.28601610399797134, -0.27877962441185544,
        -0.27273567481838845, -0.26773213977634325, -0.263632505299472,
        -0.26031543667901008, -0.25767374856251324, -0.25561314051726047,
        -0.25405088843747364, -0.25291458491568886, -0.252140970413679,
        -0.25167487039922887, -0.25146824009043423, -0.25147931190653339,
        -0.25167183785692893, -0.2548890349445887, -0.26259383341297521,
        -0.27187351113380759, -0.28126614299838887, -0.29007630655229011,
        -0.29800967237810549, -0.30497810165053929, -0.31099602393195291,
        -0.31612569372888144, -0.32044859991310082, -0.32405083826118886,
        -0.32701590783376666, -0.32942142505192845, -0.33133787828880112,
        -0.33282842070341939, -0.33394916878164183, -0.33474972601013736,
        -0.33527378601313107, -0.3355597414808803, -0.33564126343599821,
        -0.3355478354802337, -0.33530523806119927, -0.33493598302193711,
        -0.33445970117678137, -0.33389348669835495, -0.33325220240023851,
        -0.332548749929612, -0.33179430864083642, -0.3309985466075302,
        -0.33016980690009246, -0.32931527193398435, -0.32844110839344476,
        -0.32755259496035871, -0.32665423482960743, -0.3257498547694857,
        -0.32484269228685964, -0.31575717670920012, -0.30219130941338213,
        -0.28745874355612933, -0.27318447022894127, -0.26010436922281377,
        -0.24849270622994982, -0.23839006045430816, -0.22972421309312829,
        -0.22237367424614293, -0.21620052822644, -0.21106692495096627,
        -0.206842907215687, -0.20340969584162552, -0.20066063711763676,
        -0.198500986754905, -0.19684715155091428, -0.19562571355339303,
        -0.1928299330667142, -0.18831235480114114, -0.18341014976621395,
        -0.17876909203790756, -0.1746726767630726, -0.17121760616539228,
        -0.17222564726076428, -0.17457467910564514, -0.17749758440114066,
        -0.18059528439617861, -0.1836657934760296, -0.18661205592783858,
        -0.18939236491225311, -0.19199375831758722, -0.19883482826937721,
        -0.20821397545779052, -0.21817718422868368, -0.22777075747949815,
        -0.23656717209686207, -0.2444116971571392, -0.25128736528575923,
        -0.25724339730491314, -0.2623576200731107, -0.26671706107673337,
        -0.27040822820296911, -0.27351251812270655, -0.27610431128171037,
        -0.2782504478094085, -0.2800103890585513, -0.28143669711391212,
        -0.282575640185164, -0.28346782564073336, -0.28414881236746431,
        -0.28464968049960521, -0.28499755029133234, -0.28521604889207686,
        -0.28532572718358928, -0.28534443034793017, -0.28528762636470772,
        -0.28516869666883321, -0.28499919299423826, -0.28478906411982646,
        -0.28454685589144824, -0.28427988755313371, -0.28399440709889562,
        -0.28369572806017612, -0.28338834987545847, -0.28307606374727468,
        -0.28276204567612068, -0.28244893816858918, -0.28213892194607432,
        -0.28183377882856109, -0.28153494683322172, -0.28124356840797832,
        -0.28096053261415332, -0.28068651197832817, -0.2804219946502044,
        -0.28016731242942727, -0.27992266515891034, -0.27968814192424818,
        -0.27946373944747244, -0.27924937801795824, -0.27904491526304753,
        -0.27885015802533192, -0.27866487258201844, -0.27848879341390925,
        -0.27832163070685495, -0.2781630767467233, -0.27801281134963679,
        -0.27787050645217726, -0.27773582997120055, -0.27760844902958648,
        -0.277488032632506, -0.2773742538684133, -0.27726679169981377,
        -0.27716533240079255, -0.277069570691165, -0.27697921061084596,
        -0.27689396617249745, -0.2768135618256643, -0.27673773276132113,
        -0.276666225081988, -0.27659879585926955, -0.27653521309776996,
        -0.276475255621778, -0.27641871289889158, -0.276365384812788,
        -0.27631508139563127, -0.27626762252911097, -0.27622283762179806,
        -0.27618056526935708, -0.27614065290316092, -0.27610295643198896,
        -0.27606733988073379, -0.27603367502938952, -0.27600184105502606,
        -0.27597172417897348, -0.27594321732100485, -0.27591621976195907,
        -0.27589063681591941, -0.27586637951280507, -0.27584336429201045,
        -0.27582151270751892, -0.27580075114477309, -0.275781010549435,
        -0.27576222616805746, -0.275744337300596, -0.27572728706461241,
        -0.27571102217095439, -0.27569549271064492, -0.27568065195268254,
        -0.27939696678026321, -0.28667642242615127, -0.295069454614103,
        -0.30336142490357237, -0.3109886897422548, -0.31772672232340854,
        -0.3235238585845383, -0.32841304691359791, -0.33246537141167343,
        -0.33576591695891533, -0.33840154952688239, -0.34045501807135448,
        -0.34200237975753839, -0.34311214446353933, -0.34384528334051351,
        -0.34425564817256338, -0.34439056377950283, -0.34429147097765278,
        -0.34399455903295456, -0.34353135904843946, -0.34292928673761258,
        -0.34221213175813042, -0.34140049509133041, -0.34051217793295357,
        -0.33956252632362344, -0.33856473589006181, -0.3375301209065284,
        -0.33646835158772614, -0.33538766317639213, -0.33429504003513683,
        -0.33319637761420234, -0.33209662485406838, -0.33099990929743472,
        -0.32990964692911207, -0.3288286385333084, -0.3277591541535948,
        -0.32670300705920896, -0.32566161846002328, -0.32463607406932676,
        -0.32362717348658193, -0.32263547325974906, -0.32166132438698597,
        -0.32070490492913839, -0.31976624832612888, -0.31884526794099,
        -0.31794177829389564, -0.31705551339417, -0.31618614253014538,
        -0.31533328383416914, -0.31449651590238442, -0.31367538771561193,
        -0.31286942707819576, -0.31207814776563875, -0.31130105554884863,
        -0.31053765324248461, -0.30978744490694154, -0.30904993931766289,
        -0.30832465280147614, -0.30761111152732423, -0.30690885332785695,
        -0.30621742911879024, -0.30553640397445481, -0.30486535791054525,
        -0.3042038864185177, -0.30355160079032095, -0.30290812826709679,
        -0.30227311204102442, -0.30164621113558632, -0.30102710018610362,
        -0.30041546913939143, -0.29981102288875344, -0.29921348085823396,
        -0.29862257654803848, -0.29803805705127834, -0.29745968255066163,
        -0.296887225802427, -0.29632047161365027, -0.29575921631805524,
        -0.29520326725458318, -0.29465244225222448, -0.29410656912396371,
        -0.2935654851721281, -0.29302903670694741, -0.29249707857972779,
        -0.29196947373167609, -0.29144609275912564, -0.2909268134956538,
        -0.290411520611369, -0.28990010522946785, -0.28939246456000917,
        -0.28888850155073809, -0.28838812455468066, -0.28789124701416219,
        -0.28739778716082448, -0.2869076677311781, -0.2864208156971802,
        -0.28593716201130737, -0.28545664136556781, -0.28497919196389287,
        -0.28450475530733377, -0.28403327599150274, -0.28356470151568547,
        -0.28309898210307688, -0.28263607053159084, -0.28217592197471175,
        -0.28171849385187431, -0.28126374568786722, -0.28081163898077793,
        -0.28036213707801733, -0.27991520505997231, -0.27947080963086046,
        -0.27902891901637794, -0.27858950286775064, -0.27815253217181335,
        -0.27771797916676594, -0.27728581726326856, -0.27685602097055784,
        -0.27642856582727937, -0.27600342833675162, -0.275580585906391,
        -0.27516001679104057, -0.27474170003995957, -0.27432561544725165,
        -0.27391174350550707, -0.27350006536246463, -0.27309056278050303,
        -0.27268321809877172, -0.27227801419780745, -0.27187493446646571,
        -0.27147396277102576, -0.27107508342632292, -0.27067828116878756,
        -0.27028354113125169, -0.26989084881942355, -0.26950019008991283,
        -0.26911155112970614, -0.2687249184369998, -0.26834027880330069,
        -0.26795761929671025, -0.26757692724631293, -0.26719819022760094,
        -0.26682139604886013, -0.2664465327384592, -0.26607358853297752,
        -0.2657025518661193, -0.26533341135836125, -0.26496615580728161,
        -0.26460077417853067, -0.26423725559739358, -0.2638755893409121,
        -0.26351576483052319, -0.26315777162518195, -0.26280159941493542,
        -0.262447238014918, -0.2620946773597409, -0.26174390749824539,
        -0.26139491858860037, -0.26104770089371676, -0.26070224477696019,
        -0.26035854069814157, -0.26001657920976468, -0.25967635095351677,
        -0.25933784665698129, -0.25900105713056432, -0.25866597326461371,
        -0.25833258602671938, -0.25800088645918823, -0.25767086567667352,
        -0.25734251486395354, -0.25701582527384892, -0.25669078822526592,
        -0.25636739510136364, -0.25604563734783, -0.25572550647126141,
        -0.25540699403764383, -0.2550900916709184, -0.25477479105163775,
        -0.25446108391569594, -0.25414896205313675, -0.25383841730702617,
        -0.25352944157239116, -0.25322202679521827, -0.25291616497150726,
        -0.25261184814637661, -0.252309068413217, -0.25200781791289167,
        -0.25170808883297757, -0.25140987340704535, -0.2511131639139782,
        -0.25081795267732249, -0.25052423206467272, -0.25023199448708427,
        -0.24994123239851523, -0.24965193829529381, -0.24936410471561149,
        -0.24907772423903632, -0.24879278948604913, -0.24850929311759945,
        -0.24822722783467985, -0.24794658637791728, -0.24766736152718125,
        -0.24738954610120661, -0.24711313295722989, -0.24683811499064071,
        -0.24656448513464502, -0.24629223635993741, -0.24602136167438884,
        -0.24575185412273998, -0.2454837067863079, -0.24521691278269903,
        -0.24495146526553249, -0.24468735742416939, -0.24442458248345081,
        -0.24416313370344239, -0.24390300437918594, -0.24364418784045627,
        -0.24338667745152456, -0.24313046661092549, -0.24287554875123257,
        -0.24262191733883587, -0.24236956587372505, -0.24211848788927548,
        -0.24186867695204117, -0.24162012666154933, -0.24137283065009771,
        -0.24112678258255882, -0.24088197615618293, -0.2406384051004084,
        -0.24039606317667267, -0.24015494417822481, -0.23991504192994356,
        -0.2396763502881564, -0.23943886314046031, -0.2392025744055461,
        -0.23896747803302468, -0.238733568003254, -0.23850083832716953,
        -0.23826928304611639, -0.23803889623168323, -0.23780967198553601,
        -0.23758160443925733, -0.23735468775418231, -0.23712891612124115,
        -0.23690428376079978, -0.23668078492250261, -0.23645841388511776,
        -0.23623716495638122, -0.23601703247284572, -0.23579801079972754,
        -0.23558009433075747, -0.23536327748802904, -0.23514755472185289,
        -0.23493292051060796, -0.23471936936059551, -0.23450689580589579,
        -0.23429549440822128, -0.23408515975677513, -0.23387588646810983,
        -0.23366766918598464, -0.23346050258122589, -0.23325438135158874,
        -0.23304930022161657, -0.23284525394250538, -0.23264223729196654,
        -0.23244024507409042, -0.23223927211921275, -0.23203931328377875,
        -0.23184036345021108, -0.23164241752677545, -0.23144547044745142,
        -0.23124951717179898, -0.23105455268482916, -0.23086057199687532,
        -0.23066757014346229, -0.23047554218517988, -0.23028448320755515,
        -0.23009438832092474, -0.22990525266031039, -0.22971707138529276,
        -0.22952983967988672, -0.22934355275241775, -0.22915820583539842,
        -0.2289737941854057, -0.22879031308295933, -0.22860775783240056,
        -0.22842612376177104, -0.22824540622269301, -0.22806560059025022,
        -0.22788670226286845, -0.22770870666219795, -0.22753160923299637,
        -0.22735540544301056, -0.22718009078286142, -0.22700566076592757,
        -0.22683211092823052, -0.22665943682832074, -0.22648763404716252,
        -0.22631669818802225, -0.22614662487635329, -0.22597740975968694,
        -0.22580904850751857, -0.22564153681119722, -0.22547487038381606,
        -0.22530904496010151, -0.22514405629630407, -0.22497990017008998,
        -0.22481657238043268, -0.22465406874750579, -0.22449238511257541,
        -0.22433151733789422, -0.22417146130659418, -0.2240122129225833,
        -0.22385376811043875, -0.22369612281530357, -0.22353927300278167,
        -0.22338321465883668, -0.22322794378968674, -0.22307345642170456,
        -0.22291974860131308, -0.22276681639488682, -0.22261465588864895,
        -0.222463263188573, -0.22231263442028174, -0.22216276572894939,
        -0.22201365327920095, -0.22186529325501633, -0.22171768185963081,
        -0.2215708153154386, -0.2214246898638966, -0.22127930176542687,
        -0.22113464729932239, -0.2209907227636512, -0.22084752447516118,
        -0.22070504876918631, -0.220563291999553, -0.22042225053848666,
        -0.2202819207765182, -0.2201422991223925, -0.220003382002976,
        -0.21986516586316546, -0.21972764716579715, -0.2195908223915557,
        -0.21945468803888465, -0.21931924062389641, -0.21918447668028329,
        -0.21905039275922938, -0.21891698542932056, -0.2187842512764589,
        -0.21865218690377308, -0.21852078893153362, -0.21839005399706471,
        -0.2182599787546588, -0.21813055987549071, -0.21800179404753342,
        -0.21787367797547177, -0.21774620838061939, -0.21761938200083406,
        -0.21749319559043398, -0.21736764592011618, -0.21724272977687215,
        -0.21711844396390684, -0.21699478530055566, -0.21687175062220423,
        -0.21674933678020705, -0.21662754064180662, -0.21650635909005339,
        -0.216385789023726, -0.21626582735725156, -0.21614647102062803,
        -0.2160277169593445, -0.21590956213430276, -0.21579200352173972,
        -0.21567503811315122, -0.21555866291521358, -0.21544287494970754,
        -0.21532767125344204, -0.21521304887817785, -0.21509900489055417,
        -0.21498553637201023, -0.21487264041871379, -0.21476031414148475,
        -0.21464855466572152, -0.21453735913132907, -0.21442672469264315,
        -0.21431664851835958, -0.21420712779146112, -0.21409815970914461,
        -0.21398974148275077, -0.21388187033769102, -0.21377454351337843,
        -0.21366775826315515, -0.21356151185422392, -0.21345580156757651,
        -0.21335062469792523, -0.21324597855363331, -0.21314186045664626,
        -0.21303826774242263, -0.21293519775986666, -0.21283264787126038,
        -0.21273061545219502, -0.21262909789150514, -0.21252809259120112,
        -0.2124275969664037, -0.212327608445276, -0.212228124468959,
        -0.21212914249150561, -0.21203065997981602, -0.21193267441357203,
        -0.21183518328517389, -0.21173818409967429, -0.21164167437471626,
        -0.21154565164046821, -0.21145011343956141, -0.2113550573270282,
        -0.21126048087023674, -0.21116638164883109, -0.21107275725466873,
        -0.21097960529175808, -0.21088692337619847, -0.21079470913611831,
        -0.21070296021161389, -0.21061167425469035, -0.21052084892920031,
        -0.21043048191078495, -0.21034057088681438, -0.21025111355632845,
        -0.21016210762997711, -0.21007355082996285, -0.20998544088998206,
        -0.20989777555516662, -0.20981055258202624, -0.20972376973839263,
        -0.20963742480335987, -0.20955151556722942, -0.20946603983145234,
        -0.20938099540857422, -0.20929638012217844, -0.20921219180683037,
        -0.2091284283080227, -0.20904508748211909, -0.20896216719630115,
        -0.2088796653285116, -0.20879757976740204, -0.20871590841227713,
        -0.2086346491730427, -0.20855379997015036, -0.20847335873454531,
        -0.20839332340761366, -0.20831369194112934, -0.20823446229720155,
        -0.20815563244822216, -0.20807720037681532, -0.20799916407578434,
        -0.20792152154806137, -0.20784427080665549, -0.20776740987460213,
        -0.20769093678491241, -0.20761484958052343, -0.20753914631424747,
        -0.2074638250487226, -0.20738888385636187, -0.20731432081930573,
        -0.20724013402937264, -0.20716632158800963, -0.20709288160624262,
        -0.20701981220463112, -0.20694711151321721, -0.20687477767147916,
        -0.20680280882828353, -0.20673120314183754, -0.20665995877964255,
        -0.20658907391844641, -0.20651854674419715, -0.20644837545199643,
        -0.20637855824605472, -0.20630909333964215, -0.20623997895504587,
        -0.2061712133235232, -0.20610279468525686, -0.20603472128930894,
        -0.20596699139357791, -0.20589960326475173, -0.20583255517826529,
        -0.20576584541825582, -0.2056994722775185, -0.2056334340574634,
        -0.20556772906807164, -0.20550235562785227, -0.20543731206379889,
        -0.20537259671134761, -0.20530820791433346, -0.20524414402494892,
        -0.20518040340370122, -0.20511698441937032, -0.20505388544896791,
        -0.20499110487769451, -0.20492864109889997, -0.20486649251404015,
        -0.20480465753263821, -0.20474313457224244, -0.20468192205838656,
        -0.20462101842454836, -0.20456042211211123, -0.20450013157032257,
        -0.20444014525625576, -0.20438046163476936, -0.20432107917846798,
        -0.20426199636766432, -0.20420321169033886, -0.20414472364210148,
        -0.20408653072615413, -0.20402863145325145, -0.2039710243416625,
        -0.20391370791713295, -0.20385668071284777, -0.20379994126939419,
        -0.20374348813472282, -0.20368731986411237, -0.20363143502013037,
        -0.2035758321725987, -0.20352050989855527, -0.20346546678221852,
        -0.20341070141495138, -0.20335621239522436, -0.20330199832858004,
        -0.20324805782759756, -0.20319438951185745, -0.20314099200790536,
        -0.2030878639492178, -0.20303500397616647, -0.202982410735984,
        -0.2029300828827286, -0.20287801907725087, -0.20282621798715883,
        -0.20277467828678344, -0.20272339865714437, -0.20267237778591815,
        -0.20262161436740242, -0.20257110710248385, -0.20252085469860481,
        -0.20247085586972929, -0.20242110933631069, -0.20237161382525923,
        -0.20232236806990947, -0.202273370809987, -0.20222462079157749,
        -0.20217611676709302, -0.20212785749524229, -0.20207984174099572,
        -0.20203206827555753, -0.20198453587633161, -0.20193724332689153,
        -0.20189018941694853, -0.20184337294232119, -0.20179679270490422,
        -0.20175044751263826, -0.20170433617947961, -0.20165845752536804,
        -0.20161281037619913, -0.20156739356379239, -0.20152220592586226,
        -0.20147724630598823, -0.20143251355358494, -0.20138800652387315,
        -0.20134372407784965, -0.20129966508225872, -0.20125582840956402,
        -0.20121221293791797, -0.20116881755113364, -0.20112564113865714,
        -0.20108268259553813, -0.20103994082240181, -0.2009974147254209,
        -0.12532414682815152, -0.019437374574789758, 0.092989269383443623,
        0.200453408387359, 0.2978538326488061, 0.38340312374756891,
        0.45698152143410675, 0.51926453271896478, 0.57126537360796925,
        0.61409929529438678, 0.64886611550822715, 0.67659529356846071,
        0.69822371333208533, 0.71459022378349568, 0.72643844834291993,
        0.73442337913724731, 0.73911941864210784, 0.74102867774840631,
        0.7405889489094033, 0.73818109440863788, 0.73413575679083276,
        0.728739383072741, 0.72223959515494973, 0.714849956629907,
        0.70675419203076528, 0.69810991441484238, 0.68905191416672851,
        0.6796950576892189, 0.670136840076062, 0.66045963135437424,
        0.65073265164601191, 0.64101370670772662, 0.63135071179047153,
        0.62178302859941548, 0.61234263731501049, 0.60305516312313545,
        0.59394077446929, 0.58501496826921384, 0.57628925554944965,
        0.56777175943181923, 0.55946773599344335, 0.55138002730908231,
        0.54350945489749214, 0.535855160832484, 0.52841490292839444,
        0.52118530965635446, 0.5141620997809323, 0.507340271116694,
        0.50071426228223137, 0.49427809086749, 0.533599082611017,
        0.58815118173748615, 0.64561233524529782, 0.70002932621829483,
        0.74879619737346226, 0.79103667022198054, 0.82674164232145364,
        0.85631231864184965, 0.8803208881319029, 0.89938756102512807,
        0.91411957372029828, 0.9250829538824068, 0.93279139006719158,
        0.93770383832862947, 0.99138788157013236, 1.0608533933425561,
        1.1320219483543867, 1.1982050942648366, 1.2565845889248659,
        1.3063301085186649, 1.347597130778367, 1.3809973910878137,
        1.4073226042566882, 1.4274035140859826, 1.44204089486703,
        1.4519744900517393, 1.4578716680210633, 1.4603260672978657,
        1.4598610660491198, 1.4569353586841061, 1.4982682174682695,
        1.5527446198146431, 1.6084245612699524, 1.6596642165742985,
        1.7041139947097537, 1.7411130747104133, 1.7708349040454754,
        1.7938359817073226, 1.8108207768639493, 1.8225221115694865,
        1.8296429029200221, 1.8328302259041891, 1.8326661446031356,
        1.8296670112915354, 1.86499343927748, 1.9122657416750937,
        1.9605296254607147, 2.0046217221101319, 2.0424060564382382,
        2.0732967576111645, 2.0974721418365094, 2.1154599502193721,
        2.1279214432410738, 2.1355416954734365, 2.1389763046398809,
        2.1388277994360725, 2.1356374409457022, 2.1298847848467193,
        2.121990955808629, 2.1123235080875138, 2.1012017752252983,
        2.0889021602492477, 2.075663108254838, 2.061689655396588,
        2.0471575264584394, 2.0322167919141121, 2.0169951132893935,
        2.00160061265623, 1.9861244035438368, 1.9706428192757255,
        1.9552193722278277, 1.93990647452998, 1.924746947696637,
        1.9097753457649715, 1.8950191138247834, 1.8804996013742417,
        1.8662329477301789, 1.8522308547490154, 1.8385012603567952,
        1.8250489248243775, 1.8118759403369689, 1.7989821731773221,
        1.7863656467521174, 1.7740228727256422, 1.761949136670188,
        1.7501387438859737, 1.6814353832589217, 1.5906652423658181,
        1.4953915854476412, 1.40413770888283, 1.3206729070425622,
        1.246305918242272, 1.2019348622592545, 1.1747452642301139,
        1.1573190538653131, 1.1455797306400879, 1.1372601358580452,
        1.1310767473322338, 1.1262841522477991, 1.1224342014264181,
        1.1192454298282528, 1.116531931319336, 1.1141643323803612,
        1.1120481314547, 1.1101114640788907, 1.1082980111538394,
        1.1065627371052027, 1.1048692056027267, 1.1031877923745317,
        1.1014944231979553, 1.0997696318782482, 1.0979978233480252,
        1.0961666761486251, 1.0942666454511758, 1.0922905426536655,
        1.0902331759540564, 1.0880910411157909, 1.0858620545130984,
        1.0835453223354234, 1.0811409410132249, 1.0786498247573304,
        1.0760735567218436, 1.0734142607844861, 1.0706744913325663,
        1.0678571387734843, 1.0649653487713302, 1.0620024534558639,
        1.0589719130636588, 1.0558772666583842, 1.0527220907417145,
        1.0495099647112955, 1.0462444422498927, 1.0429290278424421,
        1.0395671577169774, 1.0361621845929707, 1.0327173656977102,
        1.0292358535793233, 1.0035012383165325, 0.96926107132765726,
        0.93322476782279951, 0.89864883519685457, 0.866974046538543,
        0.83870154561777055, 0.81385997800344245, 0.79225302750369,
        0.91666659427194963, 1.0953861161064113, 1.2866980414625464,
        1.4702580036179584, 1.63697215285023, 1.7835796716247061,
        1.9097625361793276, 2.0166127027822509, 1.9411469783343702,
        1.7899510798220306, 1.612850742480709, 1.4348326372229894,
        1.2677295844810037, 1.1164854073872144, 0.98250505390884846,
        0.865438320219523, 0.7641226483262652, 0.8276598767953055,
        0.95849281987091506, 1.1114388990870587, 1.2639509094466137,
        1.4054546602663398, 1.5316340924791596, 1.6413767178769623,
        1.7351485869211314, 1.8141365561940466, 1.7091744356827423,
        1.5302979991445702, 1.3286097507435954, 1.129497855611076,
        0.94476069322664935, 0.77910405989599452, 0.63361268951235727,
        0.50759607300831333, 0.39956180493921928, 0.30772160524671854,
        0.23024783723481954, 0.29496309703916684, 0.41846351971838719,
        0.56121716564383139, 0.70347716543586913, 0.83596518930909924,
        0.95487775691665033, 1.0592168227686327, 1.1493692861963549,
        1.2263568811492178, 1.1395085775815859, 0.98582471297950069,
        0.81136939213790682, 0.63902285861133568, 0.47941494941989343,
        0.3367833663951027, 0.2121034604369206, 0.10475212519160444,
        0.013385043982774691, 0.0630705082604428, 0.1724096667012327,
        0.30246233716017962, 0.43367266849004993, 0.55675286135498214,
        0.66779557510152, 0.76566007319224327, 0.85058024930280507,
        0.78602265735396282, 0.65962843987055553, 0.51311754371501761,
        0.36728344426590487, 0.23185454878960485, 0.11077886958443242,
        0.0050481000956421858, -0.085800354390572417, -0.16289087316665002,
        -0.22759719754645363, -0.2813329712170029, -0.21513642895672361,
        -0.099677356952416654, 0.031358261527402023, 0.16118614718202981,
        0.28196046327897284, 0.39050605257138044, 0.48603752838594855,
        0.56894591067965639, 0.64015823383271053, 0.58586069605362512,
        0.47940852295568392, 0.35593471395178572, 0.23295870284533055,
        0.11868543358655352, 0.016452872532833708, -0.072891171811293176,
        -0.14972478257969515, -0.21498477187489237, -0.26981938683701934,
        -0.25695352776503944, -0.21474140196303509, -0.16121564219943013,
        -0.10554758522054716, -0.05220077675630691, -0.0031596208127616324,
        0.0408772611144306, 0.0798602327657078, 0.1140508023438119,
        0.082335710190191938, 0.024149843960513277, -0.042095390605864667,
        -0.10728145016944961, -0.1671966835316534, -0.22018662170644124,
        -0.26589900904093244, -0.30461696699541368, -0.33690773668956719,
        -0.36344040767938163, -0.34738334592638748, -0.31346860593564824,
        -0.27306196747495121, -0.23191136286133432, -0.19278339705899575,
        -0.15687774393721754, -0.12458420083918297, -0.095886377781900983,
        -0.070575601980020761, -0.085623177430543082, -0.11662620766781198,
        -0.15267836862749729, -0.18836350695054291, -0.22116620984093349,
        -0.2500841884003101, -0.27488693864100311, -0.29572167109632541,
        -0.31290560928476174, -0.32681810415781443, -0.337846029057324,
        -0.34635745584392891, -0.3526902003849362, -0.3571480581377483,
        -0.360000901014878, -0.36148660622187356, -0.36181375284230455,
        -0.36116453826191985, -0.359697641631747, -0.3575509071530738,
        -0.35484379611021211, -0.35167959559094109, -0.34814739108447762,
        -0.34432381895505837, -0.34027461815192167, -0.33605600110323336,
        -0.33171586297205047, -0.32729484707537304, -0.32282728267202859,
        -0.31834200970882448, -0.31386310357254993, -0.30941051146961535,
        -0.30500061075939028, -0.30064669840143671, -0.29635941963408319,
        -0.29214714307248157, -0.28801628858789874, -0.28397161359618339,
        -0.280016462732282, -0.27615298531042148, -0.27238232445796207,
        -0.26870478135763426, -0.26511995763139412, -0.26162687854361361,
        -0.25822409938655921, -0.25490979713254758, -0.25168184919063769,
        -0.2485379008876219, -0.26581918048231545, -0.29145179613409916,
        -0.31897515510190533, -0.34524705822242413, -0.36887064480888737,
        -0.38935275344083509, -0.40665518459453476, -0.42095688199703479,
        -0.43252919101424159, -0.44167159818394836, -0.4313678636937347,
        -0.41207078655550172, -0.38958695072567467, -0.36684316106044557,
        -0.34523971269832404, -0.32537579985526294, -0.30743751433019384,
        -0.29140457982950463, -0.27715978306239125, -0.26454624811400684,
        -0.25339682436538069, -0.26707685727953639, -0.29108925539951291,
        -0.31806471205846421, -0.34436817809744374, -0.368334548288821,
        -0.38932388046956956, -0.40721702935880816, -0.42214780923590506,
        -0.41413460767242755, -0.39554317651355314, -0.37303266779084293,
        -0.34997145403613111, -0.32798233686562633, -0.30777103022958535,
        -0.28956941662776275, -0.27337182245876662, -0.25906016948503985,
        -0.26750210281308484, -0.28602315861247118, -0.30778265087937318,
        -0.329377042203596, -0.34921906502870481, -0.36666951746623805,
        -0.38157349538308044, -0.39401383513638544, -0.40418109467141616,
        -0.39610919109708642, -0.37937583550653603, -0.35951479489244864,
        -0.33931730076171362, -0.32012090075758459, -0.30250025275823739,
        -0.28663657515794927, -0.27251448355783808, -0.260026175681823,
        -0.26190832661258956, -0.27073891066764949, -0.2820433858254367,
        -0.29357446443818863, -0.30426392973119182, -0.31366107976629226,
        -0.32163257795803674, -0.32820268634156408, -0.33346882780793624,
        -0.33112373668150191, -0.32443194365377109, -0.31598874524490062,
        -0.30712038191643259, -0.29847877763175484, -0.29036030015188935,
        -0.28287636001390054, -0.27604445526621879, -0.26983651433746542,
        -0.26420434018226446, -0.26151487296812681, -0.26105356535442686,
        -0.26151776053737219, -0.26224239940922539, -0.26290077061062367,
        -0.26334433328409623, -0.26351708126635959, -0.26340988562386286,
        -0.26303627758564069, -0.26965625871410692, -0.278183315818739,
        -0.28685403488192091, -0.2948329544867232, -0.30177069842787063,
        -0.30756749986173504, -0.31224724712419877, -0.31589091270786046,
        -0.31860182272303456, -0.32048794485001764, -0.32165322622188508,
        -0.32219370306367617, -0.30965142353314662, -0.29234000014065992,
        -0.27381936366686488, -0.25583765353596594, -0.2391875199522579,
        -0.22416486396760829, -0.21081377055081216, -0.19905655978450637,
        -0.18876219556349849, -0.19890385383884313, -0.21708013268383994,
        -0.23764049882107222, -0.25778809017605614, -0.27623299158983589,
        -0.292470671503453, -0.3063965606322413, -0.31810123430545456,
        -0.32776251013650859, -0.33558944587712397, -0.34179403637712369,
        -0.34657760935074344, -0.3501249459486358, -0.35260239335625854,
        -0.354157978968354, -0.35492247144291889, -0.35501083575744136,
        -0.3545237978386937, -0.35354937735274439, -0.3578212464095295,
        -0.36398539238732269, -0.37034381801705324, -0.37609389569467228,
        -0.38090115578237127, -0.384671023657918, -0.38742740586594143,
        -0.38924860668404448, -0.39023395177549591, -0.39048680934430025,
        -0.35540160410790411, -0.30629830878694908, -0.25388195442282313,
        -0.20338211825798275, -0.15714505050365815, -0.11602120741465327,
        -0.080105482437095629, -0.049129846626957255, -0.06419749495137364,
        -0.0994143112773443, -0.14160728628941549, -0.18416739350295663,
        -0.22396122958013148, -0.25967566912315254, -0.29093281738079729,
        -0.31781882228640984, -0.34063483056034938, -0.35976698419732356,
        -0.37562002698950425, -0.348507240754935, -0.3031034829487077,
        -0.25212956971572, -0.20189708076742502, -0.15533203726493766,
        -0.11359456260208847, -0.076943997821567883, -0.045198736651230247,
        -0.071416537658819987, -0.12234143442827897, -0.1812260253279829,
        -0.23972622514757425, -0.29394077586372369, -0.34228919604531161,
        -0.38437789370624742, -0.42039712016678826, -0.45080279095880477,
        -0.47615089590746718, -0.45316366354579612, -0.40900592404816816,
        -0.35773090367128513, -0.30637340411817032, -0.25825370978132833,
        -0.21474819762917036, -0.17623582373046462, -0.14260187089416351,
        -0.11350407401298941, -0.15521741632379679, -0.22633372446984648,
        -0.30609837254381839, -0.38424785732698047, -0.45605648308371954,
        -0.51968337246838492, -0.57475579212657846, -0.62161652265289691,
        -0.66092748433750059, -0.6934641088997836, -0.7200114935524512,
        -0.74131455520832157, -0.75805655529818072, -0.77085227885600016,
        -0.7802485548806154, -0.78672824375787553, -0.79071566150284922,
        -0.79258239692354959, -0.79265300320959065, -0.79121032335854236,
        -0.78850035409289854, -0.78473662723648252, -0.78010412409198659,
        -0.77476275500357028, -0.76885044254476387, -0.76248584774187089,
        -0.7557707771374772, -0.74879230574657074, -0.74162464780135928,
        -0.73433080399592265, -0.72696401090930507, -0.71956901548412777,
        -0.71218319489291027, -0.7048375398349, -0.69755751725848336,
        -0.69036382667920171, -0.68327306264010745, -0.67629829441946032,
        -0.66944957281130235, -0.66273437266965762, -0.61228810796839073,
        -0.545388168974444, -0.47519333333078573, -0.40808578332666079,
        -0.34688400129958569, -0.29256220448338338, -0.24516719500554807,
        -0.20430424822037654, -0.16939191721926378, -0.22554629688172761,
        -0.31869437523102073, -0.42261362606804059, -0.52433714224939554,
        -0.61789595038728484, -0.70096698438956617, -0.77308294407703559,
        -0.83468115775510443, -0.88660260288491244, -0.92983196733336171,
        -0.96536633996349142, -0.91322090381046606, -0.82496932593133143,
        -0.72542429794539709, -0.62693297092724443, -0.5352523756538804,
        -0.45269787837419267, -0.37982560436240836, -0.31632720847442275,
        -0.3983964672644178, -0.54005827053529731, -0.69939965087570055,
        -0.85568196229665816, -0.99934538979089982, -1.1266547873472803,
        -1.2368403203496987, -1.3305782292391533, -1.4091906110594736,
        -1.4742302007385402, -1.5272706025583997, -1.5698055317546626,
        -1.6032053353891675, -1.6287031061184429, -1.5149899091778534,
        -1.3455714297839669, -1.1608717276624403, -0.9808277283878517,
        -0.8145651298055292, -0.66558104666434692, -0.5345114184882569,
        -0.4206010503064247, -0.32247759824961075, -0.43451901231503809,
        -0.63360656307402274, -0.85925552878254818, -1.0814680067599869,
        -1.2863493630020104, -1.4684027589829778, -1.6264132896559556,
        -1.7612603978941443, -1.8747649456570255, -1.7864064561942257,
        -1.6116523255297313, -1.4075790832485717, -1.202784192323507,
        -1.0107882903811514, -0.83721896907935944, -0.68365153609044993,
        -0.54965355606703947, -0.43386522668126304, -0.33456309734940626,
        -0.49232612920397251, -0.75592559599200559, -1.0503263073801277,
        -1.338442941284993, -1.6032207048072802, -1.8380376694696212,
        -2.0415797740238282, -2.2151182183646689, -2.3610757337190345,
        -2.4822829348270572, -2.3509341880326642, -2.1116399842953624,
        -1.8370052324048725, -1.5632976550037228, -1.3075605683741143,
        -1.0767837443213901, -0.872805197963072, -0.694919427585167,
        -0.54125469724533781, -0.68894194052754787, -0.96431636986142655,
        -1.2797306028952082, -1.5916281961281182, -1.8797499756172036,
        -2.1359943910325851, -2.3584666610932792, -2.5483151439626726,
        -2.7080632701525134, -2.8407424413631093, -2.9494525188821159,
        -3.037149341040454, -3.1065516734651544, -2.9241464625534515,
        -2.6362810050287022, -2.3172181572685862, -2.0037698448441654,
        -1.7129659201248464, -1.4515191011363593, -1.2208806728789583,
        -1.0199277909932551, -1.1026061721421443, -1.3103433361167309,
        -1.5614250474078297, -1.8148887720672826, -2.0513433362771267,
        -2.2626896134601528, -2.4466254654265955, -2.6037209370617491,
        -2.7358729490328666, -2.8454991380440857, -2.9351265980506063,
        -2.7747543095994027, -2.5074765292509325, -2.2073067086995906,
        -1.911019164201663, -1.6357103487740452, -1.3882065339387124,
        -1.1700895357171852, -0.98036873207231423, -0.81689014945704674,
        -0.90771817548337486, -1.1105998309695726, -1.35149713701283,
        -1.5933525713918408, -1.8186780553198292, -2.0202247008221978,
        -2.1959956767831987, -2.3465922171564513, -2.4738117956841568,
        -2.5799171738206303, -2.6672638340806794, -2.7381179217688612,
        -2.5996774702672578, -2.3716760357536915, -2.1163152229080211,
        -1.8644834033754234, -1.6305245072117056, -1.4201494272694695,
        -1.2346621770759172, -1.0732066160687832, -0.9339510985136571,
        -0.814704322244361, -0.88755381545197531, -1.0455520380950163,
        -1.2322453813562393, -1.419387321441175, -1.593657099791848,
        -1.7495428262991766, -1.8855375449271647, -2.0021149655611068,
        -2.1006602924436688, -2.1829127543957836, -2.1514130871646104,
        -2.0662120493052569, -1.9607961568622954, -1.8521246668916169,
        -1.7483887047672142, -1.6531712075961509, -1.567672611697227,
        -1.4918973500494737, -1.4252824480493005, -1.3670270159627771,
        -1.3835898718124497, -1.4358590462743626, -1.5006176812259158,
        -1.5662201769842079, -1.6271453498600155, -1.6810783530108697,
        -1.7273510583747009, -1.7661119850427953, -1.7978876983053109,
        -1.823353935866219, -1.8432187799703108, -1.85816540410582,
        -1.8688262381591461, -1.8757734714150043, -1.8795178415481688,
        -1.8805114334083761, -1.8791522370966764, -1.8757892993950447,
        -1.8707278812658648, -1.864234341059777, -1.8565406242386746,
        -1.847848323587703, -1.8383323154736846, -1.8281439972656328,
        -1.8174141590526987, -1.8062555248862988, -1.7947649979236906,
        -1.7830256416403729, -1.7711084265341286, -1.7590737688864591,
        -1.7469728853853737, -1.7348489848410922, -1.7227383158786962,
        -1.7106710873739805, -1.6986722765016009, -1.6867623375717744,
        -1.6749578233253148, -1.6632719290181259, -1.6517149684378836,
        -1.6402947899415052, -1.6290171396671576, -1.6178859782460149,
        -1.6069037566046169, -1.5960716557982015, -1.5853897952390559,
        -1.5748574131735997, -1.5644730228100587, -1.5542345470985657,
        -1.5441394348114559, -1.5341847602582654, -1.5243673086927982,
        -1.5146836492245, -1.5051301968296489, -1.4957032648662809,
        -1.4863991093274711, -1.4772139659179955, -1.4681440809073614,
        -1.4591857365955008, -1.4503352721245695, -1.441589100279465,
        -1.4329437208396323, -1.4243957309741833, -1.4159418331101281,
        -1.4075788406488485, -1.3993036818577171, -1.3911134022214073,
        -1.3830051655002027, -1.3749762537098551, -1.3670240662088813,
        -1.3273536463379672, -1.2746404977919235, -1.2190898854570444,
        -1.1656640985488218, -1.1165677596885122, -1.0725775137376992,
        -1.0337509854320417, -0.99980252766820865, -0.970300333024943,
        -0.94476799697804947, -0.92273517681068318, -0.90376131309655572,
        -0.88744526053811912, -0.87342769630703487, -0.8613899615075058,
        -0.85105126693221234, -0.84216527021204068, -0.83451653772539092,
        -0.82791714211516387, -0.7783911277597706, -0.71229043095967726,
        -0.64309187233957132, -0.57729459042658515, -0.51773396268794114,
        -0.46535410703038688, -0.42015231893709232, -0.381679014772698,
        -0.34929942700477679, -0.3223279244992856, -0.30009452931517766,
        -0.28197560595350135, -0.26740585756627056, -0.25588078439730938,
        -0.24695447263517459, -0.24023528107365805, -0.23538076053766077,
        -0.23209248296284507, -0.23011110751252764, -0.22921182717133246,
        -0.18642135861843537, -0.12725016224535468, -0.064951253107102175,
        -0.0059103802898292, 0.047091238421451929, 0.093132038601453,
        0.13222056379609148, 0.16480354196465333, 0.19150850334829653,
        0.21301177470857474, 0.22997319965433702, 0.24300610568012662,
        0.25266565108192135, 0.2594465407800024, 0.26378532069380894,
        0.26606472527751496, 0.26661876595731415, 0.2657378958715429,
        0.26367393020269136, 0.26064458229920173, 0.29465620187996877,
        0.34321326207218394, 0.39458315849600889, 0.44311568053048078,
        0.48635254519182131, 0.52348171065953719, 0.55451402907490022,
        0.57984759373667261, 0.60003985910619717, 0.61569081956623872,
        0.6273852874058431, 0.63566638273704257, 0.64102529393945662,
        0.64389932696506291, 0.64467400091311433, 0.64368695376456031,
        0.64123249679078731, 0.6699602449143488, 0.710676120398653,
        0.75340805143040235, 0.79338202826983906, 0.82854852134476187,
        0.85826012381914207, 0.8825675218308332, 0.90184729311406109,
        0.91660750211978537, 0.9273882982354541, 0.93471304012957,
        0.93906607821780919, 0.94088441025479252, 0.94055638297136823,
        0.93842381323565, 0.934785619447906, 0.92990197335405644,
        0.944976883597906, 0.96775632578754989, 0.99174971490626807,
        1.0138643697488352, 1.0327864615883389, 1.0481157940105768,
        1.0599054033628776, 1.0684183678582233, 1.0740009698679671,
        1.077018006558395, 1.0778211334103329, 1.0767346188294826,
        1.0740501441146209, 1.0700261833838056, 1.0648895930571864,
        1.0588381643544205, 1.0698958244847414, 1.0875232309016805,
        1.1062396141823374, 1.1234291063972726, 1.1379762204726125,
        1.14953655144772, 1.1581486354619395, 1.1640288742666483,
        1.1674645322447128, 1.1687591235697088, 1.1682056504260849,
        1.1660745251461113, 1.1626091244847898, 1.1580252115508567,
        1.1525122266984582, 1.1462353959869942, 1.1393381129396485,
        1.1319443198401955, 1.1241607582339657, 1.1311433273155427,
        1.1439346765927698, 1.1578796220590846, 1.170740380747012,
        1.1815470503768302, 1.1899829962940129, 1.1960575504591502,
        1.19993290661664, 1.2018336426380405, 1.202000400166074,
        1.2006670546138956, 1.198050284218094, 1.1943455964761283,
        1.1897266386635652, 1.1843461063322533, 1.1783373616869137,
        1.1718163010602547, 1.1648832387629724, 1.1699345750022265,
        1.1796405121831395, 1.1902189735720063, 1.1998559136630418,
        1.2077690709357904, 1.2137074238097774, 1.2176846739843659,
        1.2198383261989629, 1.2203560663266968, 1.2194381013177762,
        1.2172786265179036, 1.2140573861345005, 1.2099364874749119,
        1.205059884647788, 1.1995541588463789, 1.1935298723260628,
        1.1870831212310473, 1.1802970981478045, 1.1732435737968712,
        1.1659842590394642, 1.158572035109023, 1.1510520533650952,
        1.14346271218344, 1.1459689711538141, 1.1525580719764024,
        1.1600538019584576, 1.166920324461687, 1.1724832367943734,
        1.1765129748126653, 1.179002848679799, 1.1800515446799809,
        1.1798016170810439, 1.1784079125854288, 1.1760219277129336,
        1.1727845849197707, 1.1688234010930092, 1.1642518971542319,
        1.1591701049265164, 1.153665568061548, 1.147814523414266,
        1.1416831038743591, 1.1353284857790591, 1.1287999472441883,
        1.1221398261338877, 1.1228059271539597, 1.1263491888122836,
        1.1304872399835502, 1.134120880838968, 1.1367717598867575,
        1.1382816692612994, 1.1386523738453975, 1.1379608695444594,
        1.1363150652755323, 1.1338310714312152, 1.130621985144342,
        1.1267927464056797, 1.1224381580153155, 1.1176425165393333,
        1.1124800289705077, 1.1070155801920489, 1.101305625424013,
        1.0953990934357596, 1.0893382455489042, 1.0831594666047815,
        1.0768939801822366, 1.0705684884426048, 1.064205740818104,
        1.0578250373687645, 1.0514426730930106, 1.0450723293644353,
        1.0387254182873398, 1.0324113852757488, 1.0261379746469097,
        1.0199114625209953, 1.0137368608526494, 1.007618095994087,
        1.0015581648051595, 0.99555927098150243, 0.98962294396480055,
        0.98375014252609128, 0.97794134487046236, 0.97219662689635189,
        0.96651573005197489, 0.96089812006243291, 0.95534303765148232,
        0.94984954224946572, 0.94441654956170273, 0.93904286376795465,
        0.93372720503181439, 0.92846823291775715, 0.92326456624191966,
        0.91811479981923882, 0.91923936851397248, 0.92290453135679129,
        0.92715890171909521, 0.931053605521507, 0.93416703352779906,
        0.93635055546740031, 0.937592940712372, 0.93794850681238529,
        0.93749943456473261, 0.93633635772065, 0.93454868800179114,
        0.93222009103203041, 0.92942665587567974, 0.92623644452640352,
        0.92270972222357306, 0.91889949934397352, 0.91485219237549542,
        0.9106083059151403, 0.90620308783761128, 0.90166713624675154,
        0.90218007485037466, 0.90467740797113394, 0.90756145873476735,
        0.9100632476165974, 0.911848664540777, 0.91280786748456433,
        0.91294310022014824, 0.91230933383560187, 0.91098321768037283,
        0.929598229115201, 0.9558126839940756, 0.98331838856053666,
        1.0090825568658075, 1.0317913271202968, 1.05101734726336,
        1.0500809819068428, 1.0392976430034382, 1.0241623920513068,
        1.0075262679446773, 0.99082943237508225, 0.974763350228571,
        0.95962594634887177, 0.94551169041603589, 0.93241296648957417,
        0.92027380137185522, 0.90901804450413881, 0.89856387929184589,
        0.88883105071229229, 0.8797442376253799, 0.87123440787729733,
        0.86323913910614691, 0.85570242856979517, 0.84857426857555163,
        0.84181013184710152, 0.83537044048658637, 0.82922005459553849,
        0.826739914488511, 0.82590466455310829, 0.82559001185913394,
        0.82523927279017739, 0.82459532926057721, 0.82355711033793977,
        0.83554567743503261, 0.85241266060650178, 0.87004217528227157,
        0.88645938100427346, 0.90081271568589549, 0.91282960855063777,
        0.92252655040888654, 0.91939706374533736, 0.91018396684243374,
        0.89836222359561357, 0.88572675296721071, 0.87317685637987574,
        0.86113737755679853, 0.8497845087821797, 0.83916656596647743,
        0.82926832240520032, 0.8200450401898336, 0.8114402586024,
        0.81431522879198881, 0.82193770453518078, 0.830908682324006,
        0.8395553364729017, 0.847114937324373, 0.84491457005794668,
        0.83812439439189634, 0.82932028452746243, 0.81983684976184057,
        0.8103465355778513, 0.80117061865761907, 0.7924459981982,
        0.78421444498300141, 0.77647017460875645, 0.777504090484152,
        0.78208412023888985, 0.78768971592284165, 0.79307911687777322,
        0.79768497427747154, 0.8012906941890332, 0.80385766760724542,
        0.80543354430820246, 0.80000902783888472, 0.79149753478852514,
        0.78181036567824524, 0.771919790559287, 0.76229917623615218,
        0.75315912469319168, 0.7445739137455073, 0.73654897130244013,
        0.72905667758481374, 0.72205517814946141, 0.71549810404793512,
        0.70933944353323186, 0.70353584476666442, 0.69804757190197009,
        0.69283876844952363, 0.68787737628565493, 0.68313489461325638,
        0.67858607523031678, 0.67420860344115152, 0.63500407602676756,
        0.58313178959271, 0.52880065305242652, 0.47695105957338524,
        0.42975407399682125, 0.38794890467862969, 0.35155597145684958,
        0.35817423117417085, 0.38338442337833178, 0.41554490355686619,
        0.4487630315248417, 0.48019678165135715, 0.50860738562886354,
        0.53358474062336836, 0.55513442411022784, 0.57345889790010751,
        0.58884283979798191, 0.6015941711696241, 0.61201475094649482,
        0.62038676043047014, 0.63004910404452374, 0.63918825828881742,
        0.64716464429801746, 0.65375165409084779, 0.65893063396185225,
        0.66278218173061465, 0.66542911679076189, 0.66700710111497963,
        0.53430150364861417, 0.34797269748914622, 0.14959133193422952,
        -0.040603535901357908, -0.21359671577355044, -0.36618783101480018,
        -0.498106737755554, -0.61048433108203715, -0.7050500939059493,
        -0.78371841564271516, -0.71492918437003983, -0.581019858922777,
        -0.42511765266025392, -0.26883477216738616, -0.12239322194403471,
        0.0099488882738437423, 0.12699634001615956, 0.22907246272237794,
        0.19901226408168068, 0.11079605388284343, 0.0017265587184105986,
        -0.10944001000560695, -0.21377106065386842, -0.30748179843736928,
        -0.38943496675221972, -0.45980951171902423, -0.51939671124343811,
        -0.56923256478336182, -0.61040988311134414, -0.52538349419923591,
        -0.38792153531017037, -0.23506642521927745, -0.0851581604594797,
        0.053339247013851294, 0.1771098332967902, 0.28546054936259041,
        0.37897934285971951, 0.45882807708766732, 0.52637539795306687,
        0.48153917545722119, 0.38779478282372204, 0.27736475676626976,
        0.16639539434352368, 0.062522780210695281, -0.031072082977883338,
        -0.11349536728112881, -0.18498644475803463, -0.24630813363345846,
        -0.29842855752064712, -0.34235881301310311, -0.379073482590956,
        -0.40947483634745507, -0.33267731814938417, -0.21166606616445865,
        -0.0781914228079847, 0.052077826092715128, 0.17195873958430002,
        0.27868632099548885, 0.37174156586881613, 0.45169781002664133,
        0.51961336026081217, 0.5181545489579038, 0.48527684167711171,
        0.43952776514399866, 0.39040724314631342, 0.34260157503034039,
        0.29825581042556337, 0.25819114678246041, 0.222555162580638,
        0.19116734989117404, 0.1637011458353749, 0.13977840572232902,
        0.1190171441302898, 0.10105447453203388, 0.085556512321665348,
        0.072221538665986865, 0.060779783587293613, 0.050991608195429652,
        0.042645019442241139, 0.035552997867341181, 0.029550877478621916,
        0.024493889198787422, 0.020254912508176123, 0.0167224456829543,
        0.013798788135026389, 0.011398420628507436, 0.0094465661948585546,
        0.0078779140528288487, 0.0066354895146756116, 0.00566965406977696,
        0.0049372212390294259, 0.004400675215035621, 0.0040274806601932629,
        0.0037894732906472196, 0.0036623220163284342, 0.0036250544359561357,
        0.0036596384067906769, 0.0037506132304685651, 0.0038847647275803846,
        0.0040508391238069444, 0.0042392912479369549, 0.0044420630547891337,
        0.0046523889410602388, 0.0655741322239949, 0.14913570014670446,
        0.23732626902475346, 0.32141261439380275, 0.39753989705779008,
        0.46437732359843259, 0.52186279836467664, 0.56305986730280588,
        0.59560357370517025, 0.62125330101580079, 0.64127003600644272,
        0.65660601685180986, 0.66801241254343846, 0.67610173201441537,
        0.68138516564808227, 0.68429593053501192, 0.6852046793672415,
        0.68443029669335909, 0.68224791642367988, 0.67889518377022062,
        0.6325510122207576, 0.56874622323629986, 0.50071624049036378,
        0.43494747122928756, 0.37436950937581132, 0.32006412640676707,
        0.27217729189790818, 0.33083690355504419, 0.43424900189348231,
        0.55101357056131239, 0.66559400532669855, 0.77082765284495214,
        0.86391459153728722, 0.94427569519285171, 1.0124146813675241,
        1.0693187797569894, 1.1161477849713151, 1.1540769920682024,
        1.1842217753713937, 1.2076050628714461, 1.1175404229030841,
        0.98152062389384009, 0.83267843805143582, 0.68737116127702735,
        0.5531020155154831, 0.4327630595011247, 0.32690091458461012,
        0.23492044943314963, 0.31436695056334168, 0.46506823799075281,
        0.63830906084902828, 0.80986335567956569, 0.96844767028635115,
        1.109534488161479, 1.2320468485883997, 1.3366008800342168,
        1.4245789877601334, 1.4976479451088847, 1.5575145142662781,
        1.6058071978958892, 1.4807199753653806, 1.2874717321910465,
        1.0747930640422196, 0.8667709657784779, 0.67448122079327844,
        0.50222047296244832, 0.35083484203330406, 0.21948864723233738,
        0.31148148664055192, 0.49574949103412441, 0.71010552665644211,
        0.92353839751077693, 1.1215241955325828, 1.2981542948213018,
        1.4519282958316397, 1.5835161570222582, 1.6945772084882753,
        1.7871453503038708, 1.8633166196053852, 1.9250973939356872,
        1.7827885125832783, 1.5576675059006673, 1.3083461320713221,
        1.0638411180191656, 0.83754014592349513, 0.63468371082764641,
        0.45636140447012485, 0.30163574473780591, 0.16866128939460828,
        0.2605486286616357, 0.44694170972950986, 0.66450321089997944,
        0.88160858509706219, 1.0834087082773476, 1.2638245609802694,
        1.4212685909054952, 1.5563683564373485, 1.6707648201328604,
        1.7664863778064552, 1.8456303955264168, 1.910208151058856,
        1.9423283956969069, 1.9568319951572923, 1.9605883973523877,
        1.9575168467190396, 1.9499181802414778, 1.9391956734864673,
        1.9262464202410889, 1.9116749179373642, 1.895910584683127,
        1.8938764950688591, 1.8951677577767909, 1.8965749361604309,
        1.8966247130080947, 1.8947462076668178, 1.8908255888150785,
        1.8849696289139919, 1.8773814612290256, 1.8682964218069076,
        1.8579499304292164, 1.8719374177993293, 1.8970965227050696,
        1.9244995936182225, 1.9498547512478122, 1.9713004704882946,
        1.9882271877098532, 2.0006500420301183, 2.0088772171750997,
        2.0133366163021971, 1.9783792332212946, 1.9237844891676779,
        1.8627216672338234, 1.8017892437127614, 1.7441077472842714,
        1.6909764422054823, 1.6427587692715058, 1.5993536864589613,
        1.5604448243519877, 1.4635927887665716, 1.3501249229234213,
        1.2362743380318284, 1.1296951663063073, 1.0335521048454235,
        0.94870765458535433, 0.874886468012155, 0.81129038471209136,
        0.75691904992881054, 0.71073322354272384, 0.719226064450598,
        0.74820759318422581, 0.7849167433759614, 0.8228713647748831,
        0.85892645838605863, 0.89169437721440281, 0.92069845279836815,
        0.94592122705421788, 0.967564761165019, 1.030220119771474,
        1.1108048511979218, 1.1937992083329954, 1.2717705548006122,
        1.3415264596205576, 1.402058931532294, 1.4534499021048735,
        1.4387170663448352, 1.3900739975481538, 1.328353227291496,
        1.2641300322267093, 1.2025366869549865, 1.1458428467667932,
        1.0948360308034573, 1.0495576604543249, 1.0096931799778543,
        0.9747767306215489, 0.944296631546855, 0.91774801042055154,
        0.9927776219801604, 1.1131714894118083, 1.2458861917995687,
        1.3746731686067886, 1.4921363943502293, 1.595481563704966,
        1.6842479016075949, 1.7591042985585201, 1.7017710267873656,
        1.5819778053346838, 1.4405125493130531, 1.2978458837133451,
        1.163692122473531, 1.042132013151621, 0.934351070282842,
        0.84009729871544991, 0.75845169494580711, 0.68823053667332834,
        0.62819092618655192, 0.57713169849777368, 0.53393912453127446,
        0.49760388744778322, 0.46722347176165124, 0.44199747671249306,
        0.42121980896023048, 0.40426980534362716, 0.39060332021459038,
        0.37974427267219651, 0.37127686572953966, 0.36483854311948621,
        0.36011367615116946, 0.35682793843252208, 0.354743311962364,
        0.35365366421806915, 0.35338083717376473, 0.35377119290255088,
        0.35469256509251573, 0.356031570696889, 0.35769124067705405,
        0.35958893321609259, 0.36165449681668987, 0.36382865434008771,
        0.36606158230780006, 0.36831166270186078, 0.37054438709365572,
        0.37273139523722909, 0.37484963231047325, 0.3768806108044811,
        0.37880976467287308, 0.38062588478182391, 0.38232062596817712,
        0.38388807713564577, 0.38532438681384917, 0.38662743748617984,
        0.51012352357575241, 0.68228486824976753, 0.86486586928636744,
        1.0392864439342495, 1.1973092717970579, 1.3360514392270861,
        1.455324692620529, 1.5562258361860086, 1.4947395116544726,
        1.3605142216216044, 1.2006954614984744, 1.0389882182485781,
        0.88667995391366694, 0.74854910253258711, 0.62602461655652608,
        0.5188686306819098, 0.42606636555754279, 0.34629116662212983,
        0.41187795663241905, 0.540667087907358, 0.68984129110406689,
        0.83807116378291768, 0.97538653184031332, 1.0977501160536396,
        1.2041583233346409, 1.2950994670174387, 1.3717403726651669,
        1.2810653345329541, 1.1180330834482541, 0.93191654161491455,
        0.74725610685426269, 0.57551725607023885, 0.42133618134863077,
        0.2858568486447261, 0.16850570169138712, 0.067928001251890052,
        -0.017524889752418022, 0.046861744242791471, 0.17671606454072319,
        0.32836173891435855, 0.47996422965081476, 0.62124510797804788,
        0.74797028251675357, 0.85900406455011369, 0.95474161046348682,
        1.0362811093853184, 0.95034959055936086, 0.79243309081392677,
        0.61156086472297067, 0.43213953510626635, 0.26556071827618627,
        0.11641979171140425, -0.014161583415436212, -0.12676868418325066,
        -0.22276175448439628, -0.30379116370088388, -0.37155130282061871,
        -0.42766127635990181, -0.473612332257486, -0.51074987487104784,
        -0.540272905373649, -0.56324179008476438, -0.58058957845173043,
        -0.59313440486692182, -0.61948816329433343, -0.6492814816291701,
        -0.67760886043787816, -0.70229825934139545, -0.72258988612631181,
        -0.73843221698065165, -0.75010932281722931, -0.758045767095087,
        -0.762706433984873, -0.76454688596613363, -0.76399041895241326,
        -0.76141904521793247, -0.75717158161611042, -0.75154521579981148,
        -0.7447986378718342, -0.73715574333172573, -0.72880940353378343,
        -0.73391773254368387, -0.74420428242671521, -0.75541862471531807,
        -0.76553912129255708, -0.77370993119042442, -0.77967306452657348,
        -0.783466294811737, -0.78526371135171413, -0.78529266780898588,
        -0.69480610317659164, -0.56837585923934464, -0.43350511132513869,
        -0.30363216695734574, -0.18478821722071542, -0.079161221030141365,
        0.013002724304909659, 0.092390759318585092, 0.060151515749837015,
        -0.021692168083004865, -0.12113043396399928, -0.22206831039274066,
        -0.31684129494118296, -0.40220348513021231, -0.47718227439151195,
        -0.54193590447409468, -0.59714933670377413, -0.643718620470394,
        -0.68258945001934968, -0.63494059439536232, -0.55000558515242082,
        -0.45320433706114893, -0.35719635294776264, -0.26789524942035664,
        -0.18769113170387386, -0.11717233760202142, -0.14140455298836244,
        -0.20783197505740547, -0.28924922051830543, -0.37198284167645179,
        -0.44952640425214485, -0.51912889535080831, -0.57997056074773323,
        -0.6321915996757842, -0.67637864265978509, -0.71329655107901835,
        -0.678899311232064, -0.61325139473332757, -0.53716487709039107,
        -0.46105122968286139, -0.38981820154250685, -0.3254940011333104,
        -0.26862997059678706, -0.21904705432004279, -0.17623008667660714,
        -0.139533389125424, -0.17760604511341477, -0.2476463221010955,
        -0.32768507636167082, -0.40680389769611663, -0.47992359603401558,
        -0.54501236718571289, -0.6015943895677458, -0.64995693607674,
        -0.69073228630508909, -0.72468036739334818, -0.75257855460725087,
        -0.77516837132460559, -0.79313212484844586, -0.80708504319859053,
        -0.81757521266356037, -0.8250872330063227, -0.83004744722826351,
        -0.83282964087650724, -0.8337606591744563, -0.83312568321813663,
        -0.83117305985886036, -0.82811865862000833, -0.8241497679705404,
        -0.81942856123709906, -0.814095169423112, -0.80827039958502611,
        -0.80205813604842713, -0.79554745913734659, -0.7888145130232922,
        -0.78192415117499092, -0.77493138489916358, -0.76788265769232356,
        -0.76081696560306222, -0.75376684153460061, -0.74675921938623135,
        -0.7398161921210562, -0.73295567623617119, -0.72619199367998577,
        -0.71953638099086936, -0.71299743430423068, -0.70658149787590441,
        -0.70029300288388618, -0.69413476248553851, -0.68810822841192976,
        -0.68221371376496276, -0.67645058613739373, -0.67081743469279143,
        -0.66531221441485844, -0.65993237035705843, -0.65467494438859952,
        -0.64953666663654308, -0.64451403356175441, -0.63960337437472359,
        -0.634800907292466, -0.63010278695669153, -0.62103020565059619,
        -0.60926470732300542, -0.59682290179792452, -0.58469451622233748,
        -0.57332852778161536, -0.56289300893940108, -0.55341365940639375,
        -0.54484729409231047, -0.54325722115935837, -0.54581189179476741,
        -0.54992674568712863, -0.55429643753111579, -0.55829328952570367,
        -0.56164519835828564, -0.56426348837509011, -0.56615123359341346,
        -0.5673547439759884, -0.56793817687697012, -0.56797050823275,
        -0.567519081884671, -0.56664663456478115, -0.565410134367379,
        -0.56386054465555269, -0.56204304119893522, -0.55999743348998232,
        -0.55775866071340285, -0.55535729666651557, -0.55282003182793138,
        -0.55017011861643073, -0.54665228995816317, -0.54229558802221134,
        -0.53763889587560443, -0.53295514998690885, -0.52837636240933472,
        -0.52396048085613611, -0.51972710822900736, -0.51567653336200081,
        -0.511799816415388, -0.508084082750604, -0.5045152548809988,
        -0.50107941936222145, -0.49776347081248945, -0.49455537722747728,
        -0.49144425061741653, -0.48842032097465971, -0.4854748654100205,
        -0.48260011955184423, -0.47978918507481483, -0.477035940186471,
        -0.47433495618181809, -0.47168142123851658, -0.46907107163810419,
        -0.46650013011725477, -0.46396525083815576, -0.46146347039076108,
        -0.45899216423347583, -0.45654900800656922, -0.4541319431950816,
        -0.45173914666535181, -0.44936900364654236, -0.44702008377329677,
        -0.4446911198469064, -0.44238098900983758, -0.44008869606216278,
        -0.43781335867860471, -0.43555419431183895, -0.43331050859166659,
        -0.4310816850510174, -0.4288671760286944, -0.42666649461564571,
        -0.42447920752650153, -0.42230492879143627, -0.42014331417520773,
        -0.41799405624073555, -0.43518308721393528, -0.46030742435888611,
        -0.48719196352336658, -0.51283390412032115, -0.53589899528435936,
        -0.55591698331158146, -0.57285264117284407, -0.586878415111328,
        -0.59825516128588185, -0.58564620372394727, -0.5619065898659934,
        -0.53432781370354054, -0.50657045837483661, -0.480372453592416,
        -0.45646447448271488, -0.43505932707117512, -0.41611250914297776,
        -0.39945996461214772, -0.38489003240601127, -0.37218022950201873,
        -0.38364981800286396, -0.40549555608147697, -0.43052665236513138,
        -0.4551759432239606, -0.47779015636913985, -0.49771413125554637,
        -0.51480170475019049, -0.52915575671302906, -0.54099120319884464,
        -0.5285972110726922, -0.50548691808602964, -0.478746359113536,
        -0.451925161278169, -0.4267010848829566, -0.40377206782237024,
        -0.38333308486996448, -0.36532996502519749, -0.34959350053277416,
        -0.33590941480760689, -0.32405406100970924, -0.31381189963933803,
        -0.32608843518669872, -0.34799289741365469, -0.37277996573596872,
        -0.39710796148919342, -0.41943249801785504, -0.43914612848411566,
        -0.45611887395645773, -0.47045405589030892, -0.48235963831366058,
        -0.46400544460072951, -0.43260995611086461, -0.39713173979174587,
        -0.3620250917215429, -0.3293640237013315, -0.299980084539919,
        -0.27407020229696349, -0.25151985980388042, -0.23207352783098706,
        -0.21542329369149479, -0.20125381596622546, -0.18926408713327642,
        -0.20212416775737183, -0.22603524845030246, -0.25344869605141895,
        -0.2806052800610373, -0.30574896520192341, -0.32817006167196655,
        -0.3476940097050471, -0.36440950689746776, -0.34904376417900218,
        -0.31924804023666564, -0.284700702409949, -0.25023070966188382,
        -0.2181029021610717, -0.18924223542249977, -0.16388788498609566,
        -0.14194114320591369, -0.12314901497023337, -0.10719980963082783,
        -0.093771738583595943, -0.082556546667744535, -0.073269995962582,
        -0.0928961159754342, -0.12527032603783228, -0.1614024808065814,
        -0.19683992123020957, -0.22952585038004869, -0.25865246191115387,
        -0.28404849876946, -0.30585379973260235, -0.32434779954478,
        -0.33986046210012855, -0.31493717042642561, -0.27185568357063822,
        -0.22319279505000431, -0.17518996968729306, -0.13074267319120861,
        -0.091001219184363588, -0.056225687927068974, -0.026240291483062086,
        -0.0006728628530420595, -0.012552784500698577, -0.04192237049247205,
        -0.07750335345467288, -0.11362179919766245, -0.14757256070389116,
        -0.17820683977399621, -0.20517696476344849, -0.2285341944596708,
        -0.19953805398263991, -0.14657941779637235, -0.086144548357121431,
        -0.026419457914713822, 0.028793621602115974, 0.077979038846226742,
        0.12078777846670236, 0.15744225183674265, 0.18842256726393861,
        0.21430351558236632, 0.23567199765707411, 0.25308715320752911,
        0.22782414568783135, 0.1834616234972771, 0.13297093061680562,
        0.082823544045986755, 0.036053371873130555, -0.0061026365191180305,
        -0.043327797444623777, -0.075759302643020068, -0.10374199809339998,
        -0.079596570087253474, -0.031526029819264861, 0.024297870428475071,
        0.079820146244311552, 0.13127558485277455, 0.17713905986288264,
        0.21703064872983482, 0.251133480435859, 0.27988665822239833,
        0.30382549640119583, 0.32350040721923529, 0.33943755841100037,
        0.30602522889835332, 0.25070625667330637, 0.18871654413079536,
        0.12762162573824384, 0.07093474760458103, 0.020054671914134958,
        -0.024699284673028853, -0.063537025417480825, -0.047793871023118314,
        -0.0055490734266283167, 0.046067984799264619, 0.09845452326778778,
        0.1475217163056424, 0.19154497721383348, 0.23001493451064323,
        0.26302579710049806, 0.29095207906305576, 0.31427981730735582,
        0.28174504602679129, 0.22291787708302779, 0.15570970460941563,
        0.089039094505423438, 0.027072016223473147, -0.028507407011444087,
        -0.0772839873122453, -0.11946655391663392, -0.10082987694768389,
        -0.050937649681365167, 0.010057426285538009, 0.0720277296546954,
        0.13015291148738117, 0.182392953366244, 0.22813764764957331,
        0.26748768977762011, 0.30087464330683095, 0.32886245056705621,
        0.35204594533792827, 0.37100095724160131, 0.3862616407954228,
        0.39831197684160469, 0.40758447601108266, 0.41446238093043536,
        0.41928341680764453, 0.42234407868544471, 0.42390394458819936,
        0.42418976961075328, 0.423399255696412, 0.42170446404195727,
        0.41925487325828703, 0.41618010352774393, 0.41259233410850971,
        0.40858844349764967, 0.4042519009644191, 0.39965443637324088,
        0.39485751294736426, 0.38991362524641188, 0.38486744232487713,
        0.37975681388686894, 0.37461365528660306, 0.36946472544974496,
        0.36433231020036588, 0.35923482205897045, 0.35418732631361605,
        0.34920200204331636, 0.34428854577601287, 0.33945452457893677,
        0.33470568459478761, 0.330046220341795, 0.32547900947942865,
        0.32100581719540222, 0.31662747388583973, 0.31234402937193895,
        0.2791634951716857, 0.22936645934138905, 0.17519808139355034,
        0.12266729423093045, 0.074499403001049846, 0.031714548749685718,
        -0.00553074676443206, -0.037497225103287415, -0.064628296851681921,
        -0.087428711388702687, -0.086136028974443168, -0.066061556430503085,
        -0.038523014956328656, -0.0092856171740597713, 0.018831269077832717,
        0.044559025331159241, 0.067433969820228784, 0.087399735240990581,
        0.10459637084298266, 0.1192495019717502, 0.13161300866117484,
        0.14194023345660289, 0.1504703066472812, 0.15742239958664253,
        0.16299406094199481, 0.16736158733855225, 0.17068134431095208,
        0.17309147043805409, 0.17471367392996343, 0.17565497806704292,
        0.1760093496341226, 0.175859185052212, 0.17527664959886993,
        0.17432487522986184, 0.17305902706190227, 0.17152725022396656,
        0.16977150896135934, 0.16782832934133649, 0.16572945606118214,
        0.16350243290638436, 0.16117111545243, 0.15991586136938829,
        0.15386662658725464, 0.14588692121284941, 0.13743497811574373,
        0.12922540638153288, 0.12158190289023864, 0.11462531058971651,
        0.040206677282489278, -0.05527377985755369, -0.15393236533566493,
        -0.24717964104325549, -0.33130649326709749, -0.40512131730763479,
        -0.46869049245910643, -0.52267159090246984, -0.56796446127759281,
        -0.60553230765785071, -0.63631326618307515, -0.66117979291132745,
        -0.68092298474275126, -0.62358311920017473, -0.536509376049081,
        -0.44108888181436695, -0.34789167888372613, -0.26177594838743223,
        -0.18462345055118953, -0.11680070242336536, -0.057935489599427084,
        -0.0073259604528524277, 0.035847047041560547, 0.072412698446002371,
        0.10315858987351159, 0.12880846852147165, 0.1500150940799585,
        0.16736069379717589, 0.18136101165305929, 0.19247085467924938,
        0.20109005730986357, 0.20756932695141406, 0.21221572091134613,
        0.13721392695016715, 0.029369159114540119, -0.086475520221217655,
        -0.19816727287129632, -0.30023696521593807, -0.39068425536897189,
        -0.46926247244214353, -0.5365687597208495, -0.59356604582123174,
        -0.64133608157607569, -0.68095565636374711, -0.71343806518307384,
        -0.73970876714312961, -0.76059862349726082, -0.77684586740621175,
        -0.78910212601506113, -0.7979400497367688, -0.80386129797777262,
        -0.74617183638012152, -0.65941087088427963, -0.56462627770698959,
        -0.47220222531478268, -0.38689726658812235, -0.3105412105835238,
        -0.24347465078151256, -0.1853135022582251, -0.13535153764823574,
        -0.092769147550939873, -0.056738719237567965, -0.02647517328575676,
        -0.0012576901398049431, 0.019563442969013089, 0.036567438007484021,
        0.050267130645434456, 0.061114561498341227, 0.069506953955910791,
        0.075792561992699709, 0.0098332990152542581, -0.084376019992664739,
        -0.18543603043675275, -0.28287672171295541, -0.37198567017412687,
        -0.45103915400838529, -0.51982468903054357, -0.57885712560080993,
        -0.58315488857863329, -0.559381876050826, -0.52390738001926063,
        -0.48512870137870545, -0.44720228933876544, -0.41204504813512471,
        -0.380406164621608, -0.3524395424410276, -0.32800804687525004,
        -0.30684387039011329, -0.28863185194659374, -0.27305167027113547,
        -0.25979820373286705, -0.24859040617548614, -0.23917423883102312,
        -0.23132261346716529, -0.22483391360902327, -0.21952991609015873,
        -0.21525353677902634, -0.21186661198353995, -0.20924781460918498,
        -0.20729074529109942, -0.20590220851601812, -0.22694065009138656,
        -0.25580003953766872, -0.28639163055785188, -0.31574911059989957,
        -0.3425501625917981, -0.36632469918161381, -0.38703238789910904,
        -0.40483858294118247, -0.41999669191375338, -0.43278750067305305,
        -0.44348885731048659, -0.45236142995727041, -0.45964287863725811,
        -0.465546344837423, -0.47026107772854542, -0.47395404428149507,
        -0.47677192167043431, -0.47884316490342244, -0.48027999928177534,
        -0.5001186507718699, -0.52640854190996789, -0.55370575144643808,
        -0.57940123230624418, -0.60237291673399918, -0.6222647440361796,
        -0.63910261247567124, -0.65309122399922559, -0.66450788878463463,
        -0.67364815755096508, -0.68079902943721393, -0.686226717630152,
        -0.69017199799447082, -0.69284941515800158, -0.69444836623681283,
        -0.69513501919446741, -0.69505452453462924, -0.69433324680924891,
        -0.69308088454693306, -0.69139242191444661, -0.68934989404639169,
        -0.68702396735473292, -0.6844753453060658, -0.68175601398120478,
        -0.6789103428044011, -0.675976055531014, -0.67298508564491888,
        -0.66996432912307524, -0.6669363062708541, -0.66391974311471769,
        -0.6609300817031456, -0.65797992762917346, -0.65507944215164193,
        -0.65223668545338576, -0.64945791682624832, -0.64674785690695158,
        -0.64410991649638716, -0.64154639597010243, -0.63905865882236046,
        -0.636647282473723, -0.63431218910671838, -0.63205275897052193,
        -0.629867928309041, -0.6277562738131387, -0.6257160852732454,
        -0.62374542790998921, -0.62184219568477184, -0.62000415673685438,
        -0.61822899195614112, -0.61651432757943692, -0.61485776259067526,
        -0.61325689161086, -0.61170932387977917, -0.61021269885769691,
        -0.60876469891005247, -0.60736305948072955, -0.6060055771087598,
        -0.60469011559868568, -0.60341461061546475, -0.6021770729401692,
        -0.60097559059227967, -0.59980832999755385, -0.598673536356945,
        -0.59756953335133445, -0.59649472229872935, -0.59544758086464133,
        -0.59442666141245082, -0.59343058906834012, -0.59245805956471986,
        -0.59150783691676034, -0.59057875097849544, -0.58966969491789567,
        -0.58877962264413164, -0.58790754621489172, -0.58705253324698659,
        -0.58621370434942055, -0.58539023059466422, -0.58458133104083732,
        -0.58378627031494446, -0.58300435626509817, -0.58223493768776036,
        -0.58147740213442545, -0.5807311738008043, -0.57999571150040752,
        -0.57927050672345726, -0.57475028367641023, -0.56834353032700824,
        -0.56147329641540711, -0.55483524644263793, -0.54874223065428485,
        -0.54330855028637348, -0.53854819774082718, -0.53442694543866587,
        -0.53088969978808687, -0.52787462540800878, -0.52532021909645576,
        -0.523168650356945, -0.52136714635361925, -0.51986837196093,
        -0.5186303111390691, -0.517615917298738, -0.5167926724630918,
        -0.51613212669985775, -0.51560945294249338, -0.51520303313016047,
        -0.56469780843447148, -0.63407021934470231, -0.70777843705690324,
        -0.77826695686821845, -0.84218108264228664, -0.89834131824528363,
        -0.94666327446076559, -0.98758520047528, -1.021767682154421,
        -1.0499389230043008, -1.0728175872649155, -1.0910766866080321,
        -1.1053289350514404, -1.1161231065681314, -1.1239458250923389,
        -1.1292258443837924, -1.1323392833397725, -1.1336150347112506,
        -1.1333399652012834, -1.1318966564637314, -1.1312112791703994,
        -1.1303234536642441, -1.1288166890582687, -1.1265529238233087,
        -1.123532063722434, -1.1198180845913899, -1.1155006051470178,
        -1.1106753348112668, -1.1054345260497, -1.0998626880035842,
        -1.0940350275699444, -1.0880172679649358, -1.0818661293081269,
        -1.075630095599694, -1.0693502741474366, -1.0630612502966392,
        -1.0567918915677412, -1.0505660821529539, -1.0444033825208756,
        -1.0383196157284142, -1.0323273852157928, -1.0264365301177869,
        -1.0206545244001861, -1.0149868259237693, -1.0094371811120937,
        -1.0040078903913581, -0.99870003905027949, -0.993513697669228,
        -0.98844809580592241, -0.98350177220506063, -0.97867270442159593,
        -0.97395842041003833, -0.96935609433192882, -0.96486262856711169,
        -0.96047472367831044, -0.95618893786936554, -0.95200173729258886,
        -0.94790953839713177, -0.94390874336581365, -0.93999576956021524,
        -0.93616707378119424, -0.932419172052523, -0.92874865554766439,
        -0.92515220320234925, -0.92162659148745141, -0.91816870175662113,
        -0.91477552553027208, -0.911444168030981, -0.90817185024444447,
        -0.90495590974420492, -0.9017938004867212, -0.89868309175569949,
        -0.89562146641020568, -0.89260671856986251, -0.88963675085172256,
        -0.8867095712570926, -0.883823289792375, -0.880976114895488,
        -0.87816634972863206, -0.87539238838869748, -0.87265271207841344,
        -0.86994588527420713, -0.86727055192059066, -0.86462543167553363,
        -0.86200931622668342, -0.85942106569435472, -0.85685960513376236,
        -0.85432392114612821, -0.85181305860572909, -0.84932611750790821,
        -0.84686224994127468, -0.8444206571857803, -0.84200058693714486,
        -0.83960133065705045, -0.8372222210476471, -0.83486262964823321,
        -0.83252196455140337, -0.830199668235509, -0.82789521550993306,
        -0.82560811156942215, -0.82333789015353687, -0.82108411180716045,
        -0.81884636223790663, -0.81662425076630007, -0.81441740886453673,
        -0.81222548877973355, -0.81004816223761211, -0.80788511922264528,
        -0.80573606683078947, -0.80360072819107531, -0.80147884145239023,
        -0.79937015883196549, -0.797274445722198, -0.79519147985255167,
        -0.79312105050345416, -0.79106295776921887, -0.789017011867173,
        -0.78698303249027846, -0.78496084820072221, -0.782950295861998,
        -0.7809512201072093, -0.77896347284138567, -0.776986912775762,
        -0.775021404992029, -0.77306682053475839, -0.77112303603020682,
        -0.769189933329885, -0.76726739917732412, -0.76535532489659108,
        -0.76345360610116575, -0.7615621424218888, -0.75968083725276969,
        -0.75780959751350851, -0.75594833342764656, -0.75409695831535506,
        -0.75225538839990791, -0.75042354262694544, -0.7486013424957022,
        -0.74678871190142748, -0.74498557698823986, -0.74319186601176379,
        -0.74140750921088561, -0.73963243868803308, -0.73786658829741825,
        -0.73610989354071721, -0.7343622914696909, -0.73262372059529024,
        -0.73089412080281713, -0.72917343327273065, -0.72746160040673014,
        -0.72575856575875786, -0.72406427397059825, -0.72237867071175921,
        -0.72070170262335376, -0.71903331726571917, -0.71737346306950955,
        -0.71572208929003478, -0.71407914596463717, -0.71244458387288689,
        -0.71081835449941211, -0.70920040999919376, -0.70759070316514494,
        -0.70598918739783323, -0.70439581667719176, -0.70281054553609346,
        -0.70123332903565749, -0.69966412274217071, -0.69810288270551468,
        -0.69654956543900537, -0.69500412790053046, -0.693466527474921,
        -0.69193672195745126, -0.69041466953840791, -0.68890032878864282,
        -0.68739365864605417, -0.685894618402925, -0.68440316769406317,
        -0.67855053155315281, -0.67257764633884309, -0.666851419145296,
        -0.66153102010441722, -0.65666754844495212, -0.65225779997616162,
        -0.64827296139086155, -0.64467370664060675, -0.64141796610369628,
        -0.63846477510289368, -0.6357760439337472, -0.63331724147573509,
        -0.63105752422532368, -0.62896959414612141, -0.62702943497274832,
        -0.62521600480436423, -0.62351092443336842, -0.62189818044950163,
        -0.62036385141731254, -0.66647117318878135, -0.735548272555616,
        -0.8102769063930999, -0.882193113739421, -0.94749291605312,
        -1.0047891003470679, -1.0539151923048109, -1.09529129580627,
        -1.1295910864170891, -1.1575698860740333, -1.1799785795708104,
        -1.1975229866847728, -1.2108470417944053, -1.2205282052597453,
        -1.2270789426239828, -1.2309510127188359, -1.2325408626476257,
        -1.2321952597141532, -1.2302167330228262, -1.2268686311091834,
        -1.2223797236062963, -1.216948336782266, -1.2107460428264349,
        -1.2039209360585308, -1.1966005338410088, -1.1888943401904235,
        -1.1808961081909009, -1.1726858345116806, -1.1643315162417631,
        -1.1558906971893053, -1.1474118278992487, -1.1389354609813049,
        -1.1304953009292638, -1.1221191254470337, -1.1138295933616933,
        -1.1056449524802296, -1.0975796592142053, -1.0896449204359304,
        -1.0818491668224459, -1.0741984658730535, -1.0666968818371929,
        -1.0593467889484709, -1.0521491436156949, -1.0451037205618428,
        -1.0382093173175619, -1.031463930958427, -1.0248649105172205,
        -1.0184090880972478, -1.0120928913540783, -1.0059124396959902,
        -0.99986362627281311, -0.99394218757496189, -0.98814376224521816,
        -0.98246394051216623, -0.97689830548314127, -0.9714424673834634,
        -0.96609209169542609, -0.96084292203285993, -0.9556907984833003,
        -0.95063167205833421, -0.945661615812086, -0.94077683311676819,
        -0.93597366352174716, -0.931248586567561, -0.92659822387796,
        -0.92201933981055773, -0.91750884090934193, -0.91306377436956121,
        -0.90868132569677518, -0.904358815716706, -0.90009369707050635,
        -0.89588355031079181, -0.891726079696985, -0.887619108773834,
        -0.883560575804173, -0.87954852911586634, -0.8755811224132356,
        -0.87165661009483753, -0.86777334261222194, -0.86392976189803206,
        -0.86012439688637476, -0.85635585914375068, -0.85262283862482846,
        -0.84892409956394954, -0.84525847651032882, -0.841624870512442,
        -0.83802224545502024, -0.83444962455031435, -0.832436465086604,
        -0.82752420597326426, -0.82142191145608445, -0.81500133819062537,
        -0.80869131322188126, -0.80268778911119842, -0.79706578261149141,
        -0.79183893895560253, -0.74439027654646828, -0.68855092517300354,
        -0.63250094495940767, -0.58009938819685214, -0.53294077319484356,
        -0.49145746142304014, -0.45550736385898138, -0.42468466246272019,
        -0.39848186084283543, -0.37637232433929357, -0.35785053001096911,
        -0.34245002281017545, -0.32974979516757669, -0.31937481328159623,
        -0.31099372877644821, -0.304315373449753, -0.29908486325588207,
        -0.29507972608985572, -0.2921062497650303, -0.28999613215534187,
        -0.28860345656507391, -0.28780198606478008, -0.28748275686472446,
        -0.2875519453198494, -0.28792898187993637, -0.28854488608952034,
        -0.28934079848106314, -0.2902666873059867, -0.2912802102126168,
        -0.29234571306193219, -0.29343335000561421, -0.29451831071278872,
        -0.29558014221955314, -0.29660215429688752, -0.29757089850023077,
        -0.2984757121918068, -0.29930831982864592, -0.30006248469834723,
        -0.30073370507318903, -0.30131894945222465, -0.25359959135709209,
        -0.18503490479302673, -0.11164219054247229, -0.041222227657433316,
        0.022746362179855744, 0.079023823466289528, 0.12749855446315331,
        0.1685983992847572, 0.20298176776607743, 0.23137842335411321,
        0.25451000993810918, 0.27305277867708744, 0.2876223935634,
        0.29877005837316523, 0.30698423902659366, 0.31269495612880643,
        0.31627906969952946, 0.3180657513918867, 0.3183417506851855,
        0.317356278382265, 0.31532544348542135, 0.3124362366804575,
        0.30885008128958158, 0.30470598464546794, 0.30012332687903837,
        0.29520432409798109, 0.29003620098132893, 0.28469310504077228,
        0.27923779177644026, 0.27372310697109842, 0.26819328955740263,
        0.26268511591364313, 0.25722890410891858, 0.25184939452319294,
        0.24656652139603227, 0.24139608819115302, 0.23635035818252559,
        0.23143857035265167, 0.2266673895270003, 0.22204129863423563,
        0.21756294006515764, 0.21323341229105869, 0.20905252718277814,
        0.20501903283461875, 0.20113080613322368, 0.19738501881220805,
        0.19377828029146726, 0.19030676020913037, 0.18696629320831276,
        0.18375246823499858, 0.18066070433301323, 0.17768631468308374,
        0.17482456042183395, 0.17207069559006763, 0.16942000439499927,
        0.19419490961888061, 0.22683200606685969, 0.26072067375749325,
        0.29268395905596784, 0.32134852578224815, 0.34627161907524995,
        0.36747552826996815, 0.38520108507611905, 0.39977866594080191,
        0.41156204704611743, 0.420895722710384, 0.42809990331666509,
        0.43346473219877146, 0.43724920032274434, 0.43968235491802043,
        0.44096553475790745, 0.44127497363590978, 0.44076443866443804,
        0.43956774263647264, 0.43780106049487438, 0.48957256897108975,
        0.56035365914023028, 0.63466474875653811, 0.70503853257488036,
        0.768216297067166, 0.8231125625802983, 0.86973023503690527,
        0.90858618318594064, 0.94041048146736284, 0.96599199454352613,
        0.98610187554668793, 1.0014582414240263, 1.0127123370877149,
        1.0204456673109603, 1.0251725012782351, 1.0273447985926849,
        1.0273580218827183, 1.0255570574758011, 1.0222418673376534,
        1.0176727069363174, 1.0120748532703479, 1.0056428425163679,
        1.039720745175674, 1.0877000634802005, 1.1380681153558436,
        1.1853004241614409, 1.2270141224996658, 1.2624450818191182,
        1.2916366148428169, 1.3150102784317381, 1.3331415061028316,
        1.3466447346417652, 1.356116790113495, 1.3621110303538897,
        1.3651275077885845, 1.3656112812071504, 1.3639546935784681,
        1.3605014123642265, 1.3555510888352764, 1.3493640586830677,
        1.3421658064906352, 1.3378533471640963, 1.3328497295678861,
        1.327081191943805, 1.3205831343616403, 1.3134400362164795,
        1.3057538057703515, 1.2976276850940296, 1.2891585382418986,
        1.2804335829597713, 1.271529424636954, 1.2625122397905231,
        1.25343849519478, 1.244355880510488, 1.235304289260214,
        1.2263167668871917, 1.2174203890366009, 1.2086370563513416,
        1.1999842038463242, 1.1914754286391014, 1.18312104233434,
        1.1749285552220254, 1.1669030994753891, 1.1350441431777041,
        1.0947931977543774, 1.0530293862112299, 1.0130818357710509,
        0.976413048008103, 0.94351995936692845, 0.91441444631270252,
        0.888877956534105, 0.86659500975039228, 0.84722190120450058,
        0.8304208862495579, 0.81587610404183941, 0.80329995569504586,
        0.79243459611854794, 0.783051018985074, 0.774947044130483,
        0.76794488966658037, 0.76188867610436, 0.74267028638943444,
        0.71856146241801211, 0.69383137277051987, 0.67051437886987819,
        0.64947427123168466, 0.63097313546621137, 0.614974155555457,
        0.60130163828926275, 0.589724540909773, 0.579999128886162,
        0.57188990235107129, 0.56517906120806449, 0.55967000966064318,
        0.55518783712694508, 0.551578335289838, 0.54870637213521,
        0.54645404822894073, 0.54471884942094, 0.5434118982221755,
        0.54245634732373293, 0.54178592840129081, 0.52888462947079717,
        0.511306945821421, 0.4928357863612744, 0.47529246601051783,
        0.45946888242003486, 0.44562604968728736, 0.43375966684716422,
        0.42374063626064262, 0.41538856114250294, 0.40850941809273256,
        0.51496902342221151, 0.66473764913663336, 0.82416773862861648,
        0.97687694299664629, 1.1155688231300542, 1.2376547918708776,
        1.3429189704008921, 1.4322801097308135, 1.3851828158585959,
        1.2793221199645257, 1.1526129288295028, 1.0241366524687705,
        0.90299432485337849, 0.79305333224171326, 0.69548628803991064,
        0.61012344940291263, 0.53616815409232732, 0.59773599064554139,
        0.71542461981297645, 0.85091247266928938, 0.98513885341345575,
        1.1092229807981893, 1.2195982410004358, 1.315412473171941,
        1.3971456634327253, 1.4658809479735693, 1.3883912537953385,
        1.250235602183954, 1.0926810011283234, 0.93629240705715644,
        0.79068736948030038, 0.65976352646328362, 0.54449226433712672,
        0.44440473092452376, 0.35837604112090632, 0.28503351976961017,
        0.22296416250660425, 0.17081542720773307, 0.25807696807686881,
        0.40115453117136879, 0.560568351157154, 0.716781114329596,
        0.86078614037201406, 0.98906511177188738, 1.1008948879554612,
        1.196916316034105, 1.2783802122663097, 1.34675597364955,
        1.2629085173568686, 1.1162306477631825, 0.94985673448650043,
        0.78524256460203978, 0.63238486266390126, 0.49529733159792622,
        0.374936636786602, 0.27075836351648291, 0.1815377404761305,
        0.10579653969260025, 0.042019696241531707, -0.011239751698219148,
        -0.055314499965676528, -0.09140726831755687, -0.12059043121337663,
        -0.1438129743885895, -0.16191056872395082, -0.17561659000792906,
        -0.18557299912365452, -0.19234057232708349, -0.19640827251915186,
        -0.19820170715271429, -0.1980906951279128, -0.19639600048201139,
        -0.19339530457880555, -0.189328491383037, -0.18440231787208919,
        -0.17879453664988326, -0.17265753192770106, -0.16612152400762195,
        -0.15929739162764764, -0.15227915617263457, -0.14514616688077822,
        -0.13796502178491479, -0.13079125519776427, -0.12367081904530777,
        -0.11664138223390737, -0.10973346946590573, -0.10297145845875759,
        -0.096374452340610664, -0.089957042060169454, 0.009094943092126738,
        0.14250258157952594, 0.28276993487267271, 0.41656720015676091,
        0.53801376805258649, 0.645083404860231, 0.73768740924988185,
        0.81665883243003989, 0.78790058075492775, 0.71236117856514192,
        0.61972598458263917, 0.52498157954236169, 0.43531987109712633,
        0.3538404903066007, 0.281531649836607, 0.21832580719175357,
        0.16365855451314376, 0.11676118189592109, 0.15436393876824298,
        0.2279405759487782, 0.31318018885481691, 0.39796746384185566,
        0.47663502665042012, 0.54688377618566986, 0.60813729673270134,
        0.66066666741680058, 0.70512869572067971, 0.74232560221424637,
        0.69653423047838259, 0.61582382064652208, 0.5240718046779449,
        0.43316706649353121, 0.34866026337767442, 0.27279142823439362,
        0.2061077707817211, 0.14832410165238225, 0.098776809818446873,
        0.056660121277763736, 0.021146096164968219, 0.036030326022367234,
        0.074438847249765364, 0.12136515423559233, 0.1692425539626807,
        0.21444756756732272, 0.25542573038091504, 0.29168923273707914,
        0.32328291424663858, 0.35050165889442514, 0.33002947233489666,
        0.288131174259258, 0.239154801710371, 0.19026014284971796,
        0.14480611497424242, 0.10416541503764079, 0.068694094031253067,
        0.038247248592254618, 0.01245117195544595, 0.017084668826174598,
        0.036184205723728928, 0.060913792876357307, 0.086778226491764962,
        0.11158770687622629, 0.13436627393785439, 0.1547675176891484,
        0.1727628624955963, 0.18847621532555484, 0.17625982664455522,
        0.15204008355322995, 0.1239890245531772, 0.0961698103252416,
        0.070474569746858923, 0.047662483780364105, 0.027914305910526183,
        0.01112714463214862, -0.0029301174047062428, -0.014536038782549103,
        -0.012262143270677338, -0.0038786742044122557, 0.0069852952586510449,
        0.0184684049705527, 0.029650434039966589, 0.040108528159475541,
        0.049679357689062363, 0.058332011316967185, 0.06610039478514379,
        0.058853979359504038, 0.046076049976759605, 0.031736092469900341,
        0.017787440048956181, 0.0051201326588435365, -0.005928605170897815,
        -0.015301819414396234, -0.023078132024053649, -0.029395646880985976,
        -0.03441258046944503, -0.038287479234931948, -0.041169818105974268,
        -0.038908661501952893, -0.035422720146136406, -0.031406545760649614,
        -0.027225827591604846, -0.023069156916964945, -0.019030161092753965,
        -0.015151846744310492, -0.011450489260126411, -0.0079284736749506927,
        -0.012839829965346416, -0.019689342406846746, -0.026827643220688126,
        -0.03346618349154442, -0.039268362329092289, -0.044130314564355504,
        -0.048063982972565193, -0.051135234020337511, -0.053431520912937604,
        -0.055045353690644679, -0.056066182013369645, -0.052321845289776674,
        -0.048208854644200189, -0.044032469788257388, -0.039946331943259972,
        -0.036022500642181737, -0.032289782982140337, -0.028754531503258678,
        -0.02541184153110633, -0.022251526629060134, -0.027520314560290717,
        -0.034109513312274443, -0.040742804435832385, -0.046819520093732976,
        -0.052093253743361288, -0.056499269286598375, -0.0600624022570604,
        -0.06284835912670321, -0.064938336387395254, -0.066416118186062689,
        -0.059147002196764643, -0.050083209449911029, -0.040658954042111554,
        -0.031574759363491363, -0.023143574985620634, -0.015476871557629722,
        -0.0085842244385809265, -0.0024262498213530525, 0.003057546900929332,
        -0.00431611669046115, -0.014936307500344833, -0.026258869428855622,
        -0.03704651782885935, -0.046750597195536418, -0.0551793562532073,
        -0.062320748169962428, -0.068248407612875123, -0.07307230149678029,
        -0.076913303048239776, -0.065391125592438343, -0.049250916170316225,
        -0.0319407766521617, -0.015154773241385418, 0.00033884701343143704,
        0.014253429134638363, 0.026546532938822281, 0.037293824763805661,
        0.046622718926714775, 0.036384083695672649, 0.019975758423948851,
        0.001858439687926232, -0.015768505142507456, -0.031899843090031493,
        -0.04615209353694693, -0.058457642599265634, -0.068902196216893585,
        -0.077639201566249746, -0.084845499093310711, -0.090698978645012279,
        -0.07539054334202859, -0.05309441072520845, -0.028950685901175187,
        -0.0054888152917929684, 0.016139627545654258, 0.035500032397693032,
        0.052521677781709887, 0.0673101670215262, 0.080048714000571078,
        0.0700013994096512, 0.052379613803099349, 0.032439847287404643,
        0.012793032951416998, -0.0053489849182201373, -0.021504757697294524,
        -0.035565685232323209, -0.047605826204261306, -0.057781589049431765,
        -0.0662795879271128, -0.073290220806858972, -0.078994907480443,
        -0.083560513940521469, -0.087137496751885618, -0.089859918108882719,
        -0.0918463509956327, -0.093201159865869715, -0.094015891627078879,
        -0.094370644623932562, -0.0943353536824655, -0.0939709661067526,
        -0.0933305024150812, -0.092460004947833616, -0.091399381776616564,
        -0.090183155006647975, -0.08884112288178779, -0.08739894475990645,
        -0.085878657387548921, -0.084299130155470081, -0.082676466256248568,
        -0.081024355938236162, -0.079354387376991756, -0.077676320073078675,
        -0.075998325133828579, -0.074327196303337839, -0.072668535165066342,
        -0.071026913550054208, -0.069406015836077153, -0.067808763514441886,
        -0.066237424127337768, -0.064693706435895754, -0.063178843463891229,
        -0.06169366487130782, -0.044360641964214381, -0.022097697261757251,
        0.00098049300606591928, 0.0228912452726241, 0.042772190549576,
        0.0603395729398081, 0.075599391485240516, 0.088694401683715757,
        0.09982398929846, 0.10920302426868049, 0.11704147287850694,
        0.12353498280906898, 0.12886119572314489, 0.13317898390659608,
        0.13662911985364523, 0.13933559215622549, 0.14140715848680394,
        0.14293892803312855, 0.144013872822342, 0.14081194216668039,
        0.13601008352036478, 0.13070981537042661, 0.12546371805084591,
        0.1205332974957798, 0.11602734868252905, 0.11197601141872325,
        0.10837024570915232, 0.092821231720635375, 0.074121416387193328,
        0.055235345012584536, 0.037569181658342443, 0.021712292784828686,
        0.0078342335440778222, -0.0041037342691747792, -0.01423679475705714,
        -0.022738182841008335, -0.029789365990876778, -0.032631676893550482,
        -0.03426073768765877, -0.035078590945227348, -0.035327639884510952,
        -0.035160377387772848, -0.0346777686532213, -0.033950428816216183,
        -0.033030393250567766, -0.03195774898672251, -0.032053564529661675,
        -0.03132653287255098, -0.030163845991198895, -0.028775903488429275,
        -0.027278188458860878, -0.025734868172949954, -0.024182135382199325,
        -0.022640764881613058, -0.021122904093746574, -0.021343000297209976,
        -0.023356486365558073, -0.025965743017814694, -0.028576368633103477,
        -0.030911837698477544, -0.032861143619024827, -0.034397605393441916,
        -0.035535784717590571, -0.036308808247565764, -0.033561842833850671,
        -0.027351675310001163, -0.019893877996611787, -0.012304044280954572,
        -0.0051159172535129981, 0.0014416637140892061, 0.0072969260535973857,
        0.012456503036402297, 0.016963838447035678, 0.020877433816335274,
        0.024259695105388238, 0.027171418294545138, 0.029669253297323912,
        0.031804721254228688, 0.033624024090557883, 0.035168241709304382,
        0.036473703446910477, 0.037572422847802649, 0.038492539500446128,
        0.039258740721850927, 0.039892651164675441, 0.038298371320350411,
        0.036013433249925876, 0.033558937434528896, 0.031190665804261681,
        0.02902438921660272, 0.027103061537133561, 0.025432719771062508,
        0.02400155442358784, 0.022789943900953267, 0.021775649192751611,
        0.017927992027311219, 0.011622230790517232, 0.0046531934099483313,
        -0.0020984027917907364, -0.0082327474796042716, -0.013599628871124671,
        -0.018175216799910958, -0.02199674574291989, -0.026510499327711715,
        -0.029258326322632783, -0.030932843244592438, -0.03192406972927813,
        -0.032457890697574023, -0.032670113577593508, -0.03264631192973861,
        -0.032443401425992738, -0.032101421394153888, -0.031650044242628489,
        -0.031112234472091372, -0.030255868637441584, -0.030450733057517967,
        -0.031042742769457985, -0.031704269281292011, -0.03227965784267206,
        -0.032702972252133582, -0.032954224575100464, -0.033036155560095218,
        -0.032961998489341678, -0.034535263383062731, -0.035302315846988959,
        -0.035587145988188351, -0.035571289608508777, -0.03535941765027547,
        -0.035014161196179942, -0.0345747548175601, -0.034067099873403971,
        -0.033509249400393869, -0.0329144363639904, -0.032292776330022754,
        -0.0316522500323038, -0.030999291147837907, -0.030339154722345978,
        -0.029676161298336879, -0.029013868572094845, -0.02835519910544616,
        -0.027702540019509763, -0.027057823755960046, -0.029221588298241251,
        -0.032235800198022288, -0.035397486754333268, -0.038368616193535147,
        -0.041002807172262533, -0.043252543381896345, -0.045119707995883121,
        -0.046629396941991655, -0.047816217957678951, -0.048717267187220317,
        -0.049368660427876652, -0.049803942049032227, -0.05005347277897771,
        -0.050144316107841459, -0.050100367996756087, -0.049942595320041333,
        -0.049689313140930697, -0.049356465449219782, -0.04895789232066098,
        -0.050831669014710604, -0.053836702235151808, -0.05710200265880222,
        -0.060204809307453686, -0.062957836077043791, -0.065295556244217873,
        -0.0672136239279074, -0.068736795926712932, -0.069902122965581334,
        -0.070750303420695743, -0.0713213829662569, -0.071652752118210358,
        -0.071778344313916428, -0.071728448107173146, -0.071529821527831938,
        -0.0712059439499708, -0.0707773197196741, -0.070261789937893115,
        -0.069674831189060968, -0.069029831804201733, -0.068338342370287616,
        -0.06761030029157665, -0.0668542296949469, -0.066077418612336736,
        -0.06528607557747497, -0.064485467758837567, -0.063680042631589259,
        -0.062873535028692834, -0.062069061236565692, -0.061269201629159172,
        -0.060476073173383743, -0.059691392991309704, -0.058916534031239809,
        -0.058152573780161775, -0.057400336843346007, -0.056660432121846779,
        -0.05593328523425805, -0.055219166754174084, -0.054518216768387417,
        -0.05383046620199422, -0.0531558553044303, -0.0524942496442822,
        -0.051845453919829781, -0.0410782950578847, -0.026588487060909459,
        -0.011353696764496508, 0.0031831750156832992, 0.016386175094449305,
        0.028036780566242939, 0.0381262083691319, 0.046745366826726177,
        0.054027164121015207, 0.050678402767726109, 0.042577678754350444,
        0.032770757694825181, 0.022793204984578302, 0.01338000871558513,
        0.0048460325564793879, -0.002710474606884629, -0.0092994435960667421,
        -0.01498159153932924, -0.019838389177082645, -0.023956656825714767,
        -0.027420947508369518, -0.030310044708474298, -0.032695606677980625,
        -0.034641905670917156, -0.036206102883427856, -0.037438764159639308,
        -0.038384463093370909, -0.039082393753590357, -0.03956695541598073,
        -0.0377901494426362, -0.035522634801352031, -0.033130944670525325,
        -0.03079623559810224, -0.028601492560570308, -0.02657844709130594,
        -0.024732710348552282, -0.023057155960587838, -0.021538980608634951,
        -0.020163372554355897, -0.018915367357502919, -0.015523289810619076,
        -0.010308141347761242, -0.00459657186760408, 0.00095963423189671061,
        0.0060638490876522575, 0.010603872379079478, 0.014560970610082893,
        0.017176687273925111, 0.017658669596288097, 0.017116193552093963,
        0.016131198329250463, 0.015004270449081177, 0.013886256614623322,
        0.012848728651996594, 0.011921696195500908, 0.011113757769640371,
        0.01042283155859302, 0.0098418342595247722, 0.0093616535817088471,
        0.0089726741368659751, 0.0086655331810177351, 0.0084314691996823527,
        0.0082624578377198145, 0.0081512391218585365, 0.0080912912797207158,
        0.0080767803528249259, 0.0081025008141145365, 0.0081638149286584,
        0.0082565946243687016, 0.0091369923218399662, 0.010048870457246971,
        0.010934948639950065, 0.011769723979777153, 0.012544306508929218,
        0.013258211842554338, 0.013914968984527336, 0.014519802726406374,
        0.01279332576826853, 0.011703561040513998, 0.010987406589288339,
        0.010500480403891824, 0.01016174435472081, 0.0099243368346130911,
        0.00976007416214597, 0.0096511521850492811, 0.0095856692006714081,
        0.0095551888816641384, 0.011386157229547557, 0.012295681829741742,
        0.012743635543002176, 0.012971867973013354, 0.01310650183443306,
        0.013212192803284411, 0.013321015145868646, 0.013447869285522039,
        0.0135987032633679, 0.013774893657111964, 0.012605269849189252,
        0.01258560385119716, 0.013106585994702782, 0.013851187664199717,
        0.014657452837401139, 0.015445523247386558, 0.016178743950302023,
        0.01684292462685506, 0.017435298008658055, 0.019156337709811008,
        0.019746115986333791, 0.019792224660781666, 0.019601652710112213,
        0.019332332492893067, 0.019063144946284537, 0.018831255048803865,
        0.018652035430539879, 0.018529686502555726, 0.018462878647563123,
        0.01842995332543489, 0.01951499860203362, 0.021051492280783398,
        0.022700434074716069, 0.024296125048143345, 0.025763913211391709,
        0.027076328394219532, 0.028229738196012807, 0.029273114135244704,
        0.029103539998071543, 0.02839748438515043, 0.02750388252704521,
        0.026597796636078211, 0.025762431544868479, 0.025032929641303114,
        0.024419729741946665, 0.023920985805253602, 0.023529127484131062,
        0.022736925425042659, 0.022509052092402383, 0.022572683860676741,
        0.022782804153149337, 0.023062593982746363, 0.023371665652283925,
        0.023689087440321267, 0.024004297134964825, 0.0243122346215662,
        0.024090491386292844, 0.023197719015968173, 0.022077124289793019,
        0.02094980330888041, 0.019919671036559602, 0.019029485930396613,
        0.018290717109634206, 0.017699406777228321, 0.017244534184165439,
        0.01691236898907637, 0.016688684944314448, 0.016559837500971345,
        0.016513243285729503, 0.016537549319899113, 0.016622645540491379,
        0.016759602084917703, 0.016940574141828178, 0.017158696484782708,
        0.017407978776914402, 0.017683206891343551, 0.017979852428840933,
        0.017675214137928504, 0.017223717351782904, 0.016762778358342334,
        0.016357050172939213, 0.016033123578613858, 0.015798100191038549,
        0.015649481029541317, 0.015580387301335943, 0.015582278296249596,
        0.015646331928505453, 0.015764114670143752, 0.018029223675551025,
        0.0204228151681059, 0.022744888402681369, 0.024904690185607845,
        0.026868667114512756, 0.028632377730123577, 0.030205473227061297,
        0.031603761372133519, 0.0328450883057232, 0.033947265996804879,
        0.03293896085513788, 0.031727515905455653, 0.03051723818782253,
        0.029404736890191938, 0.028429865334502789, 0.027603240401451876,
        0.026920991196465394, 0.026372585047376964, 0.025944919543546163,
        0.025624410893197048, 0.025398014048835852, 0.025253678727242667,
        0.025180512097815182, 0.025168792960250305, 0.025209914388599337,
        0.025296295354152478, 0.025421282294933796, 0.025579051166142893,
        0.025764514971835697, 0.02597323887389525, 0.0262013634779494,
        0.032108370515927957, 0.039562795201606778, 0.0472398626125365,
        0.054503537546030954, 0.061079598109606149, 0.066880496079554666,
        0.071911950619516427, 0.071653605782423968, 0.069721549789895892,
        0.067120740506887169, 0.064365116081445739, 0.061707045939774684,
        0.059260771790657543, 0.057068639108371261, 0.055136501264340942,
        0.05345253685619783, 0.05199715808866591, 0.050748145744146246,
        0.049683236139411925, 0.048781356213317688, 0.048023148639982353,
        0.04739113058483415, 0.046869669319750569, 0.046444871747054785,
        0.04610443866866773, 0.045837509915362624, 0.048114837999787677,
        0.050890122570978545, 0.053718806227657644, 0.056388452064994626,
        0.058808622868239652, 0.060951773062862681, 0.062821691344994143,
        0.064005308239953, 0.065526427953180047, 0.067087791331832416,
        0.068548632935460582, 0.069849649313109483, 0.070973212674073013,
        0.0719223115999973, 0.072709466567649456, 0.074030163979056318,
        0.074937172081982584, 0.075578607726554073, 0.076040227474099692,
        0.076373751639656859, 0.076611965951568092, 0.078724342371397013,
        0.081949320468946749, 0.085446282402156, 0.088805593203699365,
        0.09184414524394946, 0.094496118975962412, 0.096754790557683532,
        0.098641705825245313, 0.10019051272800449, 0.1014386296470058,
        0.10242308684618059, 0.09926537649773115, 0.094022491284200954,
        0.0881482563657156, 0.082364132787136043, 0.077004858799408743,
        0.072203458106650742, 0.075661247361886758, 0.083289280226576085,
        0.092310376263739724, 0.10133826578132442, 0.1097219011382634,
        0.11719439106752282, 0.12368549246889236, 0.12922190140716006,
        0.1338746380409698, 0.13773165056262585, 0.13132659048860335,
        0.11995178068011839, 0.10700955136461954, 0.094192776809229,
        0.082291104328153342, 0.0716226352001191, 0.06226447237548681,
        0.05417528853242215, 0.061704884272382889, 0.076743031007090345,
        0.094229691778847713, 0.1116426887727659, 0.12780118663510817,
        0.1422249617517419, 0.15479216322949607, 0.16555733475647952,
        0.1746554060384114, 0.18225172294056219, 0.18851665834604739,
        0.19361327941618595, 0.19769188896944367, 0.20088813106442882,
        0.20332289471859527, 0.2051030788596849, 0.20632272634669596,
        0.20706427290899104, 0.20739978374970908, 0.20739211778629879,
        0.20709599473013759, 0.20655895832055476, 0.20582223802446759,
        0.20895114451178395, 0.21380330926964278, 0.2189913722439846,
        0.22384825647945511, 0.22808457797414661, 0.231605566890309,
        0.23441360085820223, 0.23655666172849424, 0.23810139282535231,
        0.23911930075445084, 0.22086174939735109, 0.19422795283349506,
        0.16545469681965411, 0.13760124851260017, 0.11205259636188521,
        0.089323989643327356, 0.069490193610120835, 0.052413275180285525,
        0.0555167501180905, 0.068714969403403131, 0.0857388615851072,
        0.10341356189157032, 0.12020535737448178, 0.13544289549749802,
        0.14890060293460586, 0.16057664823614745, 0.17057532657826927,
        0.17904541910242619, 0.18614848574415924, 0.1920431002741331,
        0.19687751700433864, 0.20078674382467024, 0.20389186996591402,
        0.2063005036554954, 0.20810771521537583, 0.20939717068739136,
        0.21024229574116882, 0.21070739182960807, 0.21084866988138939,
        0.21401613385436849, 0.21915940895236369, 0.22473246012310083,
        0.22998785951872555, 0.23459711313313228, 0.23844795959328829,
        0.24153649183175213, 0.2439100882260328, 0.24563754528769063,
        0.24679374207399027, 0.2299336006387524, 0.20398230853302832,
        0.17551406263235481, 0.14776780110625404, 0.12222419671315346,
        0.0994493495682634, 0.079544912641505053, 0.076407437229668321,
        0.0831881865434655, 0.094130376002008354, 0.10628116341479285,
        0.1181785129417588, 0.1291473714932645, 0.1389229195863548,
        0.14744943418145764, 0.15477341585448787, 0.16098727035034324,
        0.16620005490543432, 0.17052266842361274, 0.17406070831545695,
        0.17691135903968527, 0.17916236677482755, 0.18089206257540308,
        0.18216988393384762, 0.18305710613999068, 0.18360763472303898,
        0.18386878481265914, 0.18388201272144125, 0.1836835857057442,
        0.18330518645734886, 0.1766277128934659, 0.16751941666925343,
        0.15783063102035447, 0.14846659007559965, 0.139834617408352,
        0.13208355956975806, 0.12523155382194909, 0.119233822095853,
        0.11401829648748425, 0.10950402889388741, 0.10561042166202758,
        0.10226159520716933, 0.099388206923209654, 0.096927959306368508,
        0.094825456702753358, 0.093031759474232326, 0.091503817872514839,
        0.090203878900542253, 0.089098912073668976, 0.0881600749814426,
        0.087362226517994634, 0.086683489015933132, 0.086104857287435582,
        0.085609851138117879, 0.085184207412468557, 0.08481560759409397,
        0.08449343717544848, 0.084208573301616962, 0.0839531975145523,
        0.083720630744523239, 0.083505187998465638, 0.083302050473783362,
        0.083107153078932475, 0.082917085569286023, 0.082729005709824721,
        0.082540563057132546, 0.082349832114075386, 0.0821552537534566,
        0.081955583933781592, 0.081749848842774142, 0.081537305704050614,
        0.0813174085707951, 0.098937008744595115, 0.12303345755236601,
        0.14841912663370418, 0.17258113319274995, 0.19441286801668606,
        0.21353509902621681, 0.2299339804955238, 0.24376925096308794,
        0.25527369105470915, 0.24228770677909761, 0.21933201164842453,
        0.19315384194019164, 0.16712069394164311, 0.14281201933895893,
        0.12087240083949947, 0.10146761410586286, 0.08452729530428621,
        0.069873064055903392, 0.057285274059917117, 0.046536980804202606,
        0.0374104869939889, 0.029704708732557754, 0.023237777053191019,
        0.0178472311436004, 0.013389053920008626, 0.0097362074285296512,
        0.0067770080223230221, 0.0044135119140673211, 0.0025599919414646768,
        -0.0024510670156689452, -0.0082961933776695956, -0.014050930596336428,
        -0.019290695466530474, -0.023851011005240366, -0.027699466105802869,
        -0.030867721170125113, -0.033415737010019174, -0.035413256309856547,
        -0.036930487708918124, -0.00813877180283607, 0.032432605705381042,
        0.075691714450318845, 0.11720569100146837, 0.15499420428226698,
        0.18834836343944789, 0.21720069622272087, 0.24179105004180318,
        0.26249118883987216, 0.24034306365848424, 0.19962964935238012,
        0.15291627597552088, 0.10646909816756481, 0.0632232053829098,
        0.024372937949413448, -0.00977829506436761, -0.039365975601251144,
        -0.064725897124844931, -0.086269931219149235, -0.1044228607495227,
        -0.11959165822093162, -0.097002745935718449, -0.057884991421334846,
        -0.013678183134497276, 0.029935790837301766, 0.070317072187512208,
        0.1064131392938835, 0.13798178643452702, 0.16517805984183334,
        0.15139167117717378, 0.11931582484785905, 0.080858375980900191,
        0.041995427901662025, 0.0055623752844366032, -0.027250255713243493,
        -0.056097094957057309, -0.081052191467851933, -0.10238399962501571,
        -0.088567033216445212, -0.059183412354346307, -0.024509050523913951,
        0.010310086082766953, 0.042843066897390078, 0.072079868157270341,
        0.097739610976475419, 0.0840038437267732, 0.053040320486678692,
        0.016172455129077758, -0.020928811880207045, -0.055584059242520571,
        -0.086679333672686251, -0.11390386645434428, -0.13734438836362775,
        -0.15727083383991777, -0.1740245890069021, -0.18796152098178068,
        -0.17030432480439192, -0.1391679793084904, -0.1037609364716514,
        -0.068669954263282734, -0.036038186354225905, -0.0067322186814242346,
        0.019034321112264795, 0.041369080185700985, 0.024441390854171709,
        -0.009330474338637415, -0.048605813372722746, -0.087729883462012881,
        -0.12405442554359281, -0.15650197547144026, -0.18479870343236313,
        -0.20906638469563321, -0.22960709298395265, -0.22471923684148143,
        -0.20855022940990775, -0.18805775685603626, -0.16677547074844104,
        -0.14641879424703461, -0.12774633123143186, -0.13911588964443639,
        -0.16313279088212326, -0.19122874663405653, -0.21914164291505953,
        -0.24488491836912607, -0.26765964687475341, -0.28727334713465752,
        -0.30383100314141187, -0.31757215163446323, -0.32878619818477278,
        -0.31429869687990541, -0.28907861899195736, -0.26036617625907432,
        -0.23177976339908735, -0.20502109270224408, -0.180789153006598,
        -0.15926880530214188, -0.14039082106244793, -0.15235042964620144,
        -0.17705297344429391, -0.20588246094262969, -0.23454826997470582,
        -0.26104635041133373, -0.28456671001909434, -0.30490964316959429,
        -0.32217529279003854, -0.33659990101131365, -0.34847063294560621,
        -0.35808235370531638, -0.36571668608448787, -0.37163279395149446,
        -0.37606424024951207, -0.3792189046848724, -0.38128036214224925,
        -0.38240988235089363, -0.38274861774885144, -0.38241976313691745,
        -0.38153058544340723, -0.38917901525012122, -0.39989128384070388,
        -0.41100969130747433, -0.42127104777699659, -0.43014211039558242,
        -0.43746437071428756, -0.44326502417487484, -0.44765712497623394,
        -0.45078752164202918, -0.45281031554166473, -0.45387388520293626,
        -0.45411506028483228, -0.45365700911151119, -0.45260900566407025,
        -0.45106710246080445, -0.44911519740304234, -0.44682622978099562,
        -0.444263372432408, -0.44148115690939183, -0.43852650515465708,
        -0.43543966006238422, -0.432255016702851, -0.42900186038137417,
        -0.42570501947117, -0.422385441384374, -0.41906069980607979,
        -0.41574544077234271, -0.41245177451232179, -0.40918961929271891,
        -0.4059670028462396, -0.40279032635602863, -0.39966459541247573,
        -0.3965936218583348, -0.39358019999018939, -0.39062626018509888,
        -0.38773300266629041, -0.3849010138066305, -0.38213036708915354,
        -0.3794207105962214, -0.37677134267950291, -0.37418127726866884,
        -0.37164930010474656, -0.36917401703187525, -0.36675389534658664,
        -0.3643872990846489, -0.36207251902022441, -0.35980779805902036,
        -0.34008169759348295, -0.31370917574586765, -0.28598242272118063,
        -0.25946830843787472, -0.23530062867051652, -0.21387162615066085,
        -0.19520070424434344, -0.17912981277068271, -0.16542589883381514,
        -0.17231854247407627, -0.18807704684013762, -0.20691473224301835,
        -0.22592480686594191, -0.24372602611924402, -0.2597366283376018,
        -0.27378604748060459, -0.28590812875515, -0.29623178127894995,
        -0.30492385269998995, -0.29842787737620707, -0.28559333203258475,
        -0.27060828769542744, -0.25556899707364483, -0.24146458853487918,
        -0.22870489469533431, -0.21740263169064145, -0.20752357839921304,
        -0.21099829352289828, -0.21985119155252364, -0.23056737321003043,
        -0.24138297521870652, -0.25146162737327821, -0.26045282571312867,
        -0.26825573493007415, -0.27489341177631565, -0.28044631650298041,
        -0.28501760164516093, -0.28180450294738335, -0.27563717530088494,
        -0.26841943644631128, -0.26111012219886687, -0.25416698566796775,
        -0.24778488850863314, -0.24202327204009055, -0.23687408578270708,
        -0.2350188725112107, -0.23397701330474183, -0.23333254415549073,
        -0.23286583171467456, -0.23246285523871324, -0.2320661158233534,
        -0.23164815069574846, -0.23119728435044609, -0.23836087610774576,
        -0.24936536208759796, -0.26131091430377684, -0.27278094494866789,
        -0.28313932666171915, -0.29215460567915269, -0.29979967342095043,
        -0.30614556244938024, -0.311305685324029, -0.31540705158826804,
        -0.30629846978475661, -0.29062494019247709, -0.272861144625892,
        -0.25523563162806556, -0.23878998737939588, -0.22394591897188598,
        -0.21080812149773287, -0.19932531034468004, -0.18937517641942742,
        -0.18080860286402556, -0.18964849110330528, -0.20665373028719625,
        -0.22624196540193625, -0.24563699178138218, -0.26354516705059172,
        -0.2794466499350079, -0.29321686796761048, -0.30492529208150643,
        -0.31472932335167059, -0.29751930463344356, -0.267961099047861,
        -0.23460654429085195, -0.20170017642343469, -0.17121166226415635,
        -0.14392412807623803, -0.12001535099810513, -0.099366645330825759,
        -0.081725678104928479, -0.066791071782532532, -0.054255261271195551,
        -0.043825190121810013, -0.0352313513051139, -0.028230795844438834,
        -0.05602534963833098, -0.09889533954860294, -0.14587814969231824,
        -0.19157515525537674, -0.23352198023364329, -0.27078066465929718,
        -0.30318824719120979, -0.3309577956589308, -0.35446846766739104,
        -0.37415675105207868, -0.35489906085035061, -0.31818249314313823,
        -0.2756950053052919, -0.23327631543173327, -0.19367256957284526,
        -0.1580122292498542, -0.12659479586022768, -0.099310442866282725,
        -0.07586158580872987, -0.055878349770237173, -0.075834575989998168,
        -0.11367704598289434, -0.15725148750096232, -0.20050482525612676,
        -0.24060891029967951, -0.27641982621671229, -0.30765480449006988,
        -0.33445454113333423, -0.35715229595301384, -0.3374418940364009,
        -0.29871965547428675, -0.253667380735903, -0.20862373892856628,
        -0.16657185348585016, -0.12874001073739452, -0.095457106924368526,
        -0.066607792160917834, -0.041872801629577773, -0.020854209598499394,
        -0.0031392167564695812, 0.011668730216470002, -0.014379416518463771,
        -0.058272863811643774, -0.10751884238782806, -0.15592535268586316,
        -0.20062772524508274, -0.2404961735175733, -0.27528535537273036,
        -0.2642041349966473, -0.23192067259315488, -0.19191254222971946,
        -0.15097231909058217, -0.11235013227511262, -0.0774380647594253,
        -0.046670927940287904, -0.020006063433356685, 0.0028228188063585159,
        0.022172906735978357, 0.03842428659317805, 0.051946390714804627,
        0.063082636885210944, 0.039073822103630064, -0.00012794750093724446,
        -0.043809151365599139, -0.086664509814253055, -0.12624435743308293,
        -0.16158756894364434, -0.19249150560206618, -0.18434862543296607,
        -0.15807932910364056, -0.12514637129053363, -0.091331544929259559,
        -0.059405783634717456, -0.030560370884304609, -0.005172356917402616,
        0.016787698413023876, 0.035539973525210856, 0.051382533390915,
        0.036471902073170304, 0.0079484925293180735, -0.025034949464480438,
        -0.057909045908493141, -0.088528571982597934, -0.11601558649457466,
        -0.14014121419259798, -0.1609967605541181, -0.15260474509278385,
        -0.1310240177302219, -0.10475065176958336, -0.078056373019181974,
        -0.052975395385941246, -0.030369325890940189, -0.010496567226085147,
        0.0066844792164081849, 0.021355093678439109, 0.033752488715357319,
        0.044126980878682276, 0.05272093001704356, 0.059759166571865342,
        0.065445399823556072, 0.069961665865300171, 0.073469252538936547,
        0.076110278237715046, 0.0780094975818323, 0.079276118372529431,
        0.080005526414560268, 0.080280873755907048, 0.080174516363100912,
        0.0797493025268862, 0.079059720517578438, 0.078152917012178622,
        0.077069598645118711, 0.075844828783198787, 0.074508730870611176,
        0.073087108734118431, 0.071601993236313319, 0.070072123692826088,
        0.068513371562329214, 0.066939113089530669, 0.065360556833373246,
        0.063787031342268125, 0.062226237639898874, 0.060684470652559434,
        0.059166813235682451, 0.057677306036999679, 0.05621909606096117,
        0.0547945664684152, 0.053405449852453511, 0.052023978354588107,
        0.051424127575854454, 0.051147721895194391, 0.050963069848195389,
        0.050758047885354665, 0.050483117118827525, 0.050120969226831916,
        0.049248389957583169, 0.047457514191568607, 0.045302976262145613,
        0.043067904796572555, 0.040891437406243895, 0.038836854084942127,
        0.036927970156531459, 0.03516853675826704, 0.033552538263767848,
        0.0320696142408285, 0.030707873608101711, 0.038799949498563684,
        0.051664893082058239, 0.0657844396020514, 0.079433596542974855,
        0.091831642763333332, 0.10268806334734211, 0.11196042087143071,
        0.11972593147137604, 0.12611398534219947, 0.12215864004662423,
        0.11263738197124525, 0.1010609347286784, 0.0892039504461806,
        0.077920756558999, 0.067582379379070065, 0.058310232043172538,
        0.050100632486829673, 0.042890740200189015, 0.036593097575771227,
        0.041389933597428021, 0.051569370239951395, 0.063487126666875018,
        0.07532932382398641, 0.086249132494819511, 0.095904519192205911,
        0.10421138503282697, 0.11121233908809409, 0.1039464870504696,
        0.08941222438214888, 0.072420580184494848, 0.055379111508624991,
        0.03942407418900077, 0.02502670112993265, 0.012317115668220439,
        0.0012566603273008478, -0.0082710909894443581, -0.01641287506419661,
        -0.023321544495485406, -0.029144238055950608, -0.019743930853516591,
        -0.0028131755529504738, 0.016450637275692084, 0.035466399536615373,
        0.05303466667977768, 0.068676752119425075, 0.082281848590633047,
        0.093919489984964438, 0.088719270800022745, 0.074586986085333554,
        0.057211270773339873, 0.039457996291407178 } ;

      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromFile_PWORK.PrevTimePtr
        = (void *) &tuData[0];
    }

    /* Start for FromWorkspace: '<S86>/FromWs' */
    {
      static real_T pTimeValues0[] = { 0.0, 5.0, 5.0, 10.0, 10.0, 15.0, 15.0,
        20.0, 20.0, 25.0, 25.0, 30.0, 30.0, 35.0, 35.0, 40.0, 40.0, 45.0, 45.0,
        50.0, 50.0, 55.0, 55.0, 60.0, 60.0, 65.0, 65.0, 70.0, 70.0, 75.0, 75.0,
        80.0, 80.0, 85.0, 85.0, 90.0, 90.0, 95.0, 95.0, 100.0 } ;

      static real_T pDataValues0[] = { 0.0, 0.0, 0.5, 0.5, 0.0, 0.0, -0.5, -0.5,
        0.0, 0.0, 1.0, 1.0, 0.0, 0.0, -1.0, -1.0, -0.0, -0.0, 1.5, 1.5, 0.0, 0.0,
        -1.5, -1.5, 0.0, 0.0, 2.0, 2.0, -0.0, -0.0, -2.0, -2.0, -0.05, -0.05,
        0.25, 0.25, -0.0, -0.0, -0.25, -0.25, 0.5, 0.5, 0.5, 0.5, 0.3, 0.3, 0.3,
        0.3, 0.3, 0.3, 0.3, 0.3, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7,
        0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7,
        0.7, 0.7, 0.7, 0.7, 0.7, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
        0.625, 0.625, 0.75, 0.75, 0.875, 0.875, 1.0, 0.5, 0.375, 0.375, 0.25,
        0.25, 0.125, 0.125, 0.0, 0.0, 0.0625, 0.0625, 0.125, 0.125, 0.1875,
        0.1875, 0.25, 0.25, 0.3125, 0.3125, 0.375, 0.375, 0.4375, 0.4375, 0.5,
        0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, -4.0, -4.0,
        -4.0, -4.0, -4.0, -4.0, -4.0, -4.0, -4.0, -3.5, -3.5, -3.0, -3.0, -2.5,
        -2.5, -2.0, -2.0, -1.5, -1.5, -1.0, -1.0, -0.5, -0.5, 0.0, 0.0, 0.5, 0.5,
        1.0, 1.0, 1.5, 1.5, 2.0, 2.0, 2.5, 2.5, 3.0, 3.0, 3.5, 3.5, 4.0 } ;

      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_PWORK.TimePtr
        = static_cast<void *>(pTimeValues0);
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_PWORK.DataPtr
        = static_cast<void *>(pDataValues0);
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromWs_IWORK.PrevIndex
        = 0;
    }

    /* Start for RateTransition generated from: '<S10>/Switch1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitch1Inport1
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitch1Inport1_InitialC;

    /* Start for RateTransition generated from: '<S75>/Sum' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SollgrevorRegler =
      D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSumInport2_InitialCondi;

    /* Start for S-Function (sg_IO291_di_isol_s): '<S7>/Isolated digital input ' */
    /* Level2 S-Function Block: '<S7>/Isolated digital input ' (sg_IO291_di_isol_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition: '<S78>/RT' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_i =
      D_20231120_Modell_Inbetrieb_cal->RT_InitialCondition;

    /* Start for RateTransition generated from: '<S78>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport2 =
      D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport2_InitialCo;

    /* Start for InitialCondition: '<S78>/IC1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d =
      D_20231120_Modell_Inbetrieb_cal->IC1_Value_a;

    /* Start for InitialCondition: '<S78>/IC1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_n
      = (rtMinusInf);

    /* Start for InitialCondition: '<S10>/IC2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_n
      = (rtMinusInf);

    /* Start for InitialCondition: '<S10>/IC3' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
      = (rtMinusInf);

    /* Start for S-Function (sg_IO191_da_s): '<S6>/Analog output ' */
    /* Level2 S-Function Block: '<S6>/Analog output ' (sg_IO191_da_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for Constant: '<S5>/Constant8' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Br_Licht_On =
      D_20231120_Modell_Inbetrieb_cal->Constant8_Value;

    /* Start for Constant: '<S6>/Constant' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant =
      D_20231120_Modell_Inbetrieb_cal->Constant_Value_hc;

    /* Start for S-Function (sg_IO191_do_s): '<S6>/Digital output ' */
    /* Level2 S-Function Block: '<S6>/Digital output ' (sg_IO191_do_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_setup_s): '<S7>/Setup ' */
    /* Level2 S-Function Block: '<S7>/Setup ' (sg_IO291_setup_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition generated from: '<S1>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_iu
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_Initia_jx;

    /* Start for S-Function (sg_fpga_di_sf_a2): '<S8>/Digital input' */
    /* Level2 S-Function Block: '<S8>/Digital input' (sg_fpga_di_sf_a2) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for InitialCondition: '<S16>/IC1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
      = (rtMinusInf);

    /* Start for InitialCondition: '<S16>/IC2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
      = (rtMinusInf);

    /* Start for Constant: '<S5>/Constant13' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Reverse =
      D_20231120_Modell_Inbetrieb_cal->Constant13_Value;

    /* Start for DiscretePulseGenerator: '<S49>/Pulse Generator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter = 0;

    /* Start for S-Function (sg_IO291_do_fet_s): '<S7>/FET digital output ' */
    /* Level2 S-Function Block: '<S7>/FET digital output ' (sg_IO291_do_fet_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [10];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_di_ttl_s): '<S7>/LVTTL digital input ' */
    /* Level2 S-Function Block: '<S7>/LVTTL digital input ' (sg_IO291_di_ttl_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [11];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_do_ttl_s): '<S7>/LVTTL digital output ' */
    /* Level2 S-Function Block: '<S7>/LVTTL digital output ' (sg_IO291_do_ttl_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [12];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO602_IO691_setup_s): '<S9>/CAN Setup ' */
    /* Level2 S-Function Block: '<S9>/CAN Setup ' (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [13];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition generated from: '<S4>/Lenkradwinkel' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelOutport1
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtLenkradwinkelOutport1_I;

    /* Start for RateTransition generated from: '<S4>/Lenkradwinkelgeschwindigkeit' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtLenkradwinkelgeschwindi
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtLenkradwinkelgeschwindi;

    /* Start for RateTransition generated from: '<S4>/Derivative' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel =
      D_20231120_Modell_Inbetrieb_cal->TmpRTBAtDerivativeInport1_Initi;

    /* Start for RateTransition generated from: '<S4>/Fahrzeuggeschwindigkeit' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtFahrzeuggeschwindigkeit
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtFahrzeuggeschwindigkeit;

    /* Start for InitialCondition: '<S4>/IC2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_ny
      = (rtMinusInf);

    /* Start for RateTransition generated from: '<S79>/Derivative' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtDerivativeInport1
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtDerivativeInport1_Ini_j;

    /* Start for RateTransition generated from: '<S79>/MATLAB Function1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtMATLABFunction1Inport2
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtMATLABFunction1Inport2_;

    /* Start for RateTransition generated from: '<S12>/Transfer Fcn1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtTransferFcn1Inport1_Ini;

    /* Start for RateTransition generated from: '<S12>/Transfer Fcn' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1
      = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtTransferFcnInport1_Init;

    /* Start for S-Function (slrealtimeUDPReceive): '<S11>/From Jetson' */
    {
      try {
        uint8_t *tempAddr = nullptr;
        uint8_t *tempInterface = nullptr;
        slrealtime::ip::udp::Socket *udpSock = (slrealtime::ip::udp::Socket *)
          slrealtime::ip::SocketFactory::createSocket(slrealtime::ip::SocketType::
          UDP, "10.42.0.10",5500U);
        if (tempAddr)
          delete tempAddr;
        if (tempInterface)
          delete tempInterface;
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_IWORK
          [0] = 48;
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
          [0] = reinterpret_cast<void*>(udpSock);
        char *buffer = (char *)calloc(65507,sizeof(char));
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
          [1] = (void*)buffer;
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }

    /* Start for S-Function (slrealtimeUDPSend): '<S2>/UDP Send' */
    {
      try {
        slrealtime::ip::udp::Socket *udpSock = (slrealtime::ip::udp::Socket *)
          slrealtime::ip::SocketFactory::createSocket(slrealtime::ip::SocketType::
          UDP,"192.168.9.10",25000U);
        uint8_t *remoteAddress = (uint8_t *)
          D_20231120_Modell_Inbetrieb_cal->UDPSend_toAddress;
        uint16_t *remotePort = (uint16_t *)
          &D_20231120_Modell_Inbetrieb_cal->UDPSend_toPort;
        udpSock->setRemoteEndpoint(remoteAddress, remotePort[0]);
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK[0] =
          24;
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK[1] =
          25000U;
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_PWORK =
          reinterpret_cast<void*>(udpSock);
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }
  }

  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE
    = UNINITIALIZED_ZCSIG;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE_p
    = UNINITIALIZED_ZCSIG;
  D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.TriggeredSubsystem_Trig_ZCE
    = POS_ZCSIG;

  {
    packLaneMarkerBus_D_20231120__T *b_obj;

    /* InitializeConditions for RateTransition generated from: '<S3>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_InitialCo;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx
      = 1;

    /* InitializeConditions for S-Function (sfix_udelay): '<S42>/Tapped Delay1' */
    for (int32_T i = 0; i < 199; i++) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[i] =
        D_20231120_Modell_Inbetrieb_cal->TappedDelay1_vinit;
    }

    /* End of InitializeConditions for S-Function (sfix_udelay): '<S42>/Tapped Delay1' */

    /* InitializeConditions for TransferFcn: '<S12>/Transfer Fcn' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn_CSTATE =
      0.0;

    /* InitializeConditions for RateTransition generated from: '<S10>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_e
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_Initial_j;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g
      = 1;

    /* InitializeConditions for TransferFcn: '<S12>/Transfer Fcn1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn1_CSTATE =
      0.0;

    /* InitializeConditions for RateTransition generated from: '<S10>/Index Vector1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtIndexVector1Inport3_Ini;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_WrB
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtIndexVector1Inport3_RdB
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S10>/Switch1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitch1Inport1_InitialC;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_WrBufIdx
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitch1Inport1_RdBufIdx
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S75>/Sum' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSumInport2_InitialCondi;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_WrBufIdx
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport2_RdBufIdx
      = 1;

    /* InitializeConditions for Integrator: '<S49>/Integrator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE =
      D_20231120_Modell_Inbetrieb_cal->Integrator_IC;

    /* InitializeConditions for S-Function (sfix_udelay): '<S60>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[0] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S61>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[0] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for S-Function (sfix_udelay): '<S60>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S61>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for S-Function (sfix_udelay): '<S60>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S61>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for S-Function (sfix_udelay): '<S60>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S61>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for DiscreteIntegrator: '<S53>/Discrete-Time Integrator2' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE
      = D_20231120_Modell_Inbetrieb_cal->DiscreteTimeIntegrator2_IC;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
      = 2;

    /* InitializeConditions for UnitDelay: '<S48>/Unit Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_e =
      D_20231120_Modell_Inbetrieb_cal->UnitDelay_InitialCondition_j;

    /* InitializeConditions for Memory: '<S48>/Memory' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput =
      D_20231120_Modell_Inbetrieb_cal->Memory_InitialCondition;

    /* InitializeConditions for Integrator: '<S119>/Integrator' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE_k =
      D_20231120_Modell_Inbetrieb_cal->PIDController_InitialConditionF;

    /* InitializeConditions for RateTransition: '<S78>/RT' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_Buf[0] =
      D_20231120_Modell_Inbetrieb_cal->RT_InitialCondition;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx = 1;

    /* InitializeConditions for RateTransition generated from: '<S78>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport2_InitialCo;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_WrBufIdx
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport2_RdBufIdx
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S1>/Switch' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_eu
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_Initia_jx;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufI_gp
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufI_gy
      = 1;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[0] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S15>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[0] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S15>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S15>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S15>/Tapped Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for UnitDelay: '<S16>/Unit Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_c =
      D_20231120_Modell_Inbetrieb_cal->UnitDelay_InitialCondition_p;

    /* InitializeConditions for UnitDelay: '<S26>/Unit Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay1_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->UnitDelay1_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S26>/Unit Delay' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->UnitDelay_InitialCondition;

    /* InitializeConditions for Delay: '<S17>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->Delay1_InitialCondition;

    /* InitializeConditions for Delay: '<S18>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_o =
      D_20231120_Modell_Inbetrieb_cal->Delay1_InitialCondition_i;

    /* InitializeConditions for UnitDelay: '<S30>/Delay Input1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->DetectIncrease_vinit;

    /* InitializeConditions for UnitDelay: '<S32>/Delay Input1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_b =
      D_20231120_Modell_Inbetrieb_cal->DetectIncrease_vinit_h;

    /* InitializeConditions for Memory: '<S36>/Memory' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_o
      = D_20231120_Modell_Inbetrieb_cal->EdgeDetector_ic;

    /* InitializeConditions for RateTransition generated from: '<S4>/Lenkradwinkel' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_B
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtLenkradwinkelOutport1_I;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_W
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelOutport1_R
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S4>/Lenkradwinkelgeschwindigkeit' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwindi
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtLenkradwinkelgeschwindi;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_k
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtLenkradwinkelgeschwin_p
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S4>/Derivative' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtDerivativeInport1_Initi;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrBuf
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdBuf
      = 1;

    /* InitializeConditions for Derivative: '<S4>/Derivative' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA = (rtInf);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB = (rtInf);

    /* InitializeConditions for RateTransition generated from: '<S4>/Fahrzeuggeschwindigkeit' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_k
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtFahrzeuggeschwindigkeit;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigke_b
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtFahrzeuggeschwindigkeit
      = 1;

    /* InitializeConditions for Delay: '<S50>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_p =
      D_20231120_Modell_Inbetrieb_cal->Delay1_InitialCondition_e;

    /* InitializeConditions for UnitDelay: '<S57>/Delay Input1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_j =
      D_20231120_Modell_Inbetrieb_cal->DetectIncrease_vinit_e;

    /* InitializeConditions for S-Function (sfix_udelay): '<S54>/Tapped Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[0] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[1] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[2] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[3] =
      D_20231120_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;

    /* InitializeConditions for Memory: '<S48>/Memory1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory1_PreviousInput
      = D_20231120_Modell_Inbetrieb_cal->Memory1_InitialCondition;

    /* InitializeConditions for Memory: '<S55>/Memory' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_d
      = D_20231120_Modell_Inbetrieb_cal->SRFlipFlop_initial_condition;

    /* InitializeConditions for RateTransition generated from: '<S79>/Derivative' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_Buf_a
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtDerivativeInport1_Ini_j;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_WrB_j
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtDerivativeInport1_RdB_e
      = 1;

    /* InitializeConditions for Derivative: '<S79>/Derivative' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampA_a = (rtInf);
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TimeStampB_g = (rtInf);

    /* InitializeConditions for RateTransition generated from: '<S79>/MATLAB Function1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport2_
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtMATLABFunction1Inport2_;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_m
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtMATLABFunction1Inport_p
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S12>/Transfer Fcn1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtTransferFcn1Inport1_Ini;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S12>/Transfer Fcn' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_Buf
      [0] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtTransferFcnInport1_Init;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S2>/Byte Packing' */
    for (int32_T i = 0; i < 24; i++) {
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_Buf
        [i] = D_20231120_Modell_Inbetrieb_cal->TmpRTBAtBytePackingOutport1_Ini;
    }

    struct_AzXAydn5whPkCj5deW4WYB expl_temp;
    real_T Camera_NumColumns;
    real_T Camera_NumRows;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
      = 1;

    /* End of InitializeConditions for RateTransition generated from: '<S2>/Byte Packing' */

    /* InitializeConditions for RateTransition: '<S11>/Rate Transition1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[0]
      = D_20231120_Modell_Inbetrieb_cal->RateTransition1_InitialConditio;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
      = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
      = 1;

    /* InitializeConditions for RateTransition generated from: '<Root>/S-Function Builder' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_Buf[0] =
      D_20231120_Modell_Inbetrieb_cal->Odometer_InitialCondition;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx = 1;

    /* InitializeConditions for RateTransition generated from: '<Root>/S-Function Builder' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_Buf[0] =
      D_20231120_Modell_Inbetrieb_cal->SoC_InitialCondition;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx = 1;

    /* InitializeConditions for Delay generated from: '<S137>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->Delay1_4_InitialCondition;

    /* InitializeConditions for Delay generated from: '<S137>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->Delay1_3_InitialCondition;

    /* InitializeConditions for Delay generated from: '<S137>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->Delay1_2_InitialCondition;

    /* InitializeConditions for Delay generated from: '<S137>/Delay1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE =
      D_20231120_Modell_Inbetrieb_cal->Delay1_1_InitialCondition;

    /* Start for S-Function (sg_IO602_IO691_read_s): '<S68>/CAN Read1' */
    /* Level2 S-Function Block: '<S68>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack' */

    /*-----------S-Function Block: <S68>/CAN Unpack -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack1' */

    /*-----------S-Function Block: <S68>/CAN Unpack1 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack2' */

    /*-----------S-Function Block: <S68>/CAN Unpack2 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack3' */

    /*-----------S-Function Block: <S68>/CAN Unpack3 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack4' */

    /*-----------S-Function Block: <S68>/CAN Unpack4 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack5' */

    /*-----------S-Function Block: <S68>/CAN Unpack5 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack6' */

    /*-----------S-Function Block: <S68>/CAN Unpack6 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack7' */

    /*-----------S-Function Block: <S68>/CAN Unpack7 -----------------*/

    /* Start for S-Function (scanunpack): '<S68>/CAN Unpack8' */

    /*-----------S-Function Block: <S68>/CAN Unpack8 -----------------*/

    /* SystemInitialize for Gain: '<S68>/Gain' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ChargeRequest =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.ChargeRequest;

    /* SystemInitialize for Gain: '<S68>/Gain1' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IBatt =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.IBatt;

    /* SystemInitialize for Gain: '<S68>/Gain2' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL15 =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.V_KL15;

    /* SystemInitialize for Gain: '<S68>/Gain3' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL30 =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.V_KL30;

    /* SystemInitialize for Gain: '<S68>/Gain4' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BMSStatus =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.BMSStatus;

    /* SystemInitialize for Gain: '<S68>/Gain5' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.InverterStatus =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.InverterStatus;

    /* SystemInitialize for Gain: '<S68>/Gain6' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorSpeed =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.eMotorSpeed;

    /* SystemInitialize for Gain: '<S68>/Gain7' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorTorque =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.eMotorTorque;

    /* SystemInitialize for Gain: '<S68>/Gain8' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Distance =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Distance;

    /* SystemInitialize for Gain: '<S68>/Gain9' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceTotal =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.DistanceTotal;

    /* SystemInitialize for Gain: '<S68>/Gain10' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Range =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Range;

    /* SystemInitialize for Gain: '<S68>/Gain11' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.CarSpeed;

    /* SystemInitialize for Gain: '<S68>/Gain12' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.SoC;

    /* SystemInitialize for Gain: '<S68>/Gain13' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BrakePedal =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.BrakePedal;

    /* SystemInitialize for Gain: '<S68>/Gain14' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DriveMode =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.DriveMode;

    /* SystemInitialize for Gain: '<S68>/Gain15' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceToral_24Bit =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.DistanceToral_24Bit;

    /* SystemInitialize for Gain: '<S68>/Gain16' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VehicleSpeedFromABS =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.VehicleSpeedFromABS;

    /* SystemInitialize for Gain: '<S68>/Gain17' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FL =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_FL;

    /* SystemInitialize for Gain: '<S68>/Gain18' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FR =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_FR;

    /* SystemInitialize for Gain: '<S68>/Gain19' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RL =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_RL;

    /* SystemInitialize for Gain: '<S68>/Gain20' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RR =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_RR;

    /* SystemInitialize for Gain: '<S68>/Gain21' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Handbremse =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Handbremse;

    /* SystemInitialize for Gain: '<S68>/Gain22' incorporates:
     *  Outport: '<S68>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0.Odometer;

    /* End of SystemInitialize for SubSystem: '<S9>/CAN Read Loop - Port 1' */
    /* Start for S-Function (sg_IO602_IO691_read_s): '<S69>/CAN Read1' */
    /* Level2 S-Function Block: '<S69>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (scanunpack): '<S69>/CAN Unpack' */

    /*-----------S-Function Block: <S69>/CAN Unpack -----------------*/

    /* Start for S-Function (scanunpack): '<S69>/CAN Unpack1' */

    /*-----------S-Function Block: <S69>/CAN Unpack1 -----------------*/

    /* Start for S-Function (scanunpack): '<S69>/CAN Unpack2' */

    /*-----------S-Function Block: <S69>/CAN Unpack2 -----------------*/

    /* Start for S-Function (scanunpack): '<S69>/CAN Unpack4' */

    /*-----------S-Function Block: <S69>/CAN Unpack4 -----------------*/

    /* Start for S-Function (scanunpack): '<S69>/CAN Unpack5' */

    /*-----------S-Function Block: <S69>/CAN Unpack5 -----------------*/

    /* SystemInitialize for Gain: '<S69>/Gain' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkradwinkel_m =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Lenkradwinkel;

    /* SystemInitialize for Product: '<S70>/Divide' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_b =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Lenkwinkel;

    /* SystemInitialize for Gain: '<S69>/Gain1' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AY =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.AY;

    /* SystemInitialize for Gain: '<S69>/Gain2' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierrate =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Gierrate;

    /* SystemInitialize for Gain: '<S69>/Gain3' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AX =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.AX;

    /* SystemInitialize for Gain: '<S69>/Gain4' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierbeschleunigung =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Gierbeschleunigung;

    /* SystemInitialize for SignalConversion generated from: '<S69>/Bus Creator2' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.isvalid = 0.0;

    /* SystemInitialize for SignalConversion generated from: '<S69>/Bus Creator2' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.radardatalength1788 =
      0.0;

    /* SystemInitialize for SignalConversion generated from: '<S69>/Bus Creator2' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Punkt =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Radar.Radar_Punkt;

    /* SystemInitialize for SignalConversion generated from: '<S69>/Bus Creator2' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Mode =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Radar.Radar_Mode;

    /* SystemInitialize for Gain: '<S69>/Gain5' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLA =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HLA;

    /* SystemInitialize for Gain: '<S69>/Gain6' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLM =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HLM;

    /* SystemInitialize for Gain: '<S69>/Gain7' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRA =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HRA;

    /* SystemInitialize for Gain: '<S69>/Gain8' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRM =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HRM;

    /* SystemInitialize for Gain: '<S69>/Gain9' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLA =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VLA;

    /* SystemInitialize for Gain: '<S69>/Gain10' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLM =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VLM;

    /* SystemInitialize for Gain: '<S69>/Gain11' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRA =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VRA;

    /* SystemInitialize for Gain: '<S69>/Gain12' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRM =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VRM;

    /* SystemInitialize for Gain: '<S69>/Gain13' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.RC_Fahrpedal;

    /* SystemInitialize for Gain: '<S69>/Gain14' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.RC_Lenkung;

    /* SystemInitialize for SignalConversion generated from: '<S69>/Bus Creator' incorporates:
     *  Outport: '<S69>/CAN_Out'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_2 =
      D_20231120_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Radar_2;

    /* End of SystemInitialize for SubSystem: '<S9>/CAN Read Loop - Port 3' */

    /* SystemInitialize for Triggered SubSystem: '<S37>/Triggered Subsystem' */
    /* SystemInitialize for SignalConversion generated from: '<S40>/In1' incorporates:
     *  Outport: '<S40>/Out1'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.In1 =
      D_20231120_Modell_Inbetrieb_cal->Out1_Y0;

    /* End of SystemInitialize for SubSystem: '<S37>/Triggered Subsystem' */

    /* SystemInitialize for Enabled SubSystem: '<S36>/NEGATIVE Edge' */
    /* SystemInitialize for RelationalOperator: '<S38>/Relational Operator1' incorporates:
     *  Outport: '<S38>/OUT'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_c =
      D_20231120_Modell_Inbetrieb_cal->OUT_Y0;

    /* End of SystemInitialize for SubSystem: '<S36>/NEGATIVE Edge' */

    /* SystemInitialize for Enabled SubSystem: '<S36>/POSITIVE Edge' */
    /* SystemInitialize for RelationalOperator: '<S39>/Relational Operator1' incorporates:
     *  Outport: '<S39>/OUT'
     */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_g =
      D_20231120_Modell_Inbetrieb_cal->OUT_Y0_l;

    /* End of SystemInitialize for SubSystem: '<S36>/POSITIVE Edge' */

    /* SystemInitialize for State Transition Table: '<S28>/State Transition Table' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.sfEvent =
      D_20231120_Modell_In_CALL_EVENT;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_active_c4_D_20231120_Modell_
      = 0U;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20231120_Modell_Inbetri
      = D_20231120_M_IN_NO_ACTIVE_CHILD;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable = 0.0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 0.0;

    /* SystemInitialize for Enabled SubSystem: '<S81>/Enabled Subsystem' */
    D_202_EnabledSubsystem_Init
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.EnabledSubsystem,
       &D_20231120_Modell_Inbetrieb_cal->D_20231120_EnabledSubsystem_cal);

    /* End of SystemInitialize for SubSystem: '<S81>/Enabled Subsystem' */

    /* SystemInitialize for Enabled SubSystem: '<S81>/Enabled Subsystem1' */
    D_202_EnabledSubsystem_Init
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.EnabledSubsystem1,
       &D_20231120_Modell_Inbetrieb_cal->D_2023112_EnabledSubsystem1_cal);

    /* End of SystemInitialize for SubSystem: '<S81>/Enabled Subsystem1' */

    /* SystemInitialize for Merge generated from: '<S137>/Merge1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20231120_Modell_Inbetrieb_cal->Merge1_1_InitialOutput;

    /* SystemInitialize for Merge generated from: '<S137>/Merge1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20231120_Modell_Inbetrieb_cal->Merge1_2_InitialOutput;

    /* SystemInitialize for Merge generated from: '<S137>/Merge1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20231120_Modell_Inbetrieb_cal->Merge1_3_InitialOutput;

    /* SystemInitialize for Merge generated from: '<S137>/Merge1' */
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20231120_Modell_Inbetrieb_cal->Merge1_4_InitialOutput;

    /* SystemInitialize for Atomic SubSystem: '<S138>/Path Following Control System' */
    PathFollowingControlSy_Init
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.PathFollowingControlSystem_i,
       &D_20231120_Modell_Inbetrieb_cal->PathFollowingControlSystem_cal);

    /* End of SystemInitialize for SubSystem: '<S138>/Path Following Control System' */

    /* Start for MATLABSystem: '<S11>/PackLaneBus' */
    expl_temp = *get_camera();
    Camera_NumColumns = expl_temp.NumColumns;
    Camera_NumRows = expl_temp.NumRows;
    b_obj = &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;
    b_obj->isInitialized = 0;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.objisempty = true;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns
      = Camera_NumColumns;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows =
      Camera_NumRows;
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [0] = expl_temp.FieldOfView[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [1] = expl_temp.FieldOfView[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [0] = expl_temp.ImageSize[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [1] = expl_temp.ImageSize[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [0] = expl_temp.PrincipalPoint[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [1] = expl_temp.PrincipalPoint[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [0] = expl_temp.FocalLength[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [1] = expl_temp.FocalLength[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0]
      = expl_temp.Position[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1]
      = expl_temp.Position[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2]
      = expl_temp.Position[2];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [0] = expl_temp.PositionSim3d[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [1] = expl_temp.PositionSim3d[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [2] = expl_temp.PositionSim3d[2];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0]
      = expl_temp.Rotation[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1]
      = expl_temp.Rotation[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2]
      = expl_temp.Rotation[2];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [0] = expl_temp.DetectionRanges[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [1] = expl_temp.DetectionRanges[1];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [0] = expl_temp.LaneDetectionRanges[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [1] = expl_temp.LaneDetectionRanges[1];
    std::memcpy
      (&D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
       [0], &expl_temp.MeasurementNoise[0], 9U * sizeof(real_T));
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [0] = expl_temp.MinObjectImageSize[0];
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [1] = expl_temp.MinObjectImageSize[1];
    b_obj = &D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;
    b_obj->isInitialized = 1;
  }
}

/* Model terminate function */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_terminate(void)
{
  /* Terminate for S-Function (sg_IO191_setup_s): '<S6>/Setup ' */
  /* Level2 S-Function Block: '<S6>/Setup ' (sg_IO191_setup_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_ad_s): '<S6>/Analog input ' */
  /* Level2 S-Function Block: '<S6>/Analog input ' (sg_IO191_ad_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_di_s): '<S6>/Digital input ' */
  /* Level2 S-Function Block: '<S6>/Digital input ' (sg_IO191_di_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (slrealtimeUDPReceive): '<S2>/UDP Receive1' */
  {
    slrealtime::ip::SocketFactory::releaseSocket("192.168.9.10",25001U);
    char *buffer = (char *)
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK[1];
    if (buffer)
      free(buffer);
  }

  /* Terminate for S-Function (sg_IO291_di_isol_s): '<S7>/Isolated digital input ' */
  /* Level2 S-Function Block: '<S7>/Isolated digital input ' (sg_IO291_di_isol_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_da_s): '<S6>/Analog output ' */
  /* Level2 S-Function Block: '<S6>/Analog output ' (sg_IO191_da_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_do_s): '<S6>/Digital output ' */
  /* Level2 S-Function Block: '<S6>/Digital output ' (sg_IO191_do_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_setup_s): '<S7>/Setup ' */
  /* Level2 S-Function Block: '<S7>/Setup ' (sg_IO291_setup_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_fpga_di_sf_a2): '<S8>/Digital input' */
  /* Level2 S-Function Block: '<S8>/Digital input' (sg_fpga_di_sf_a2) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_do_fet_s): '<S7>/FET digital output ' */
  /* Level2 S-Function Block: '<S7>/FET digital output ' (sg_IO291_do_fet_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[10];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_di_ttl_s): '<S7>/LVTTL digital input ' */
  /* Level2 S-Function Block: '<S7>/LVTTL digital input ' (sg_IO291_di_ttl_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[11];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_do_ttl_s): '<S7>/LVTTL digital output ' */
  /* Level2 S-Function Block: '<S7>/LVTTL digital output ' (sg_IO291_do_ttl_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[12];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO602_IO691_setup_s): '<S9>/CAN Setup ' */
  /* Level2 S-Function Block: '<S9>/CAN Setup ' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[13];
    sfcnTerminate(rts);
  }

  /* Terminate for Iterator SubSystem: '<S9>/CAN Read Loop - Port 1' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S68>/CAN Read1' */
  /* Level2 S-Function Block: '<S68>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/CAN Read Loop - Port 1' */

  /* Terminate for Iterator SubSystem: '<S9>/CAN Read Loop - Port 3' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S69>/CAN Read1' */
  /* Level2 S-Function Block: '<S69>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts =
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S9>/CAN Read Loop - Port 3' */

  /* Terminate for S-Function (slrealtimeUDPReceive): '<S11>/From Jetson' */
  {
    slrealtime::ip::SocketFactory::releaseSocket("10.42.0.10",5500U);
    char *buffer = (char *)
      D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK[1];
    if (buffer)
      free(buffer);
  }

  /* Terminate for S-Function (slrealtimeUDPSend): '<S2>/UDP Send' */
  {
    slrealtime::ip::SocketFactory::releaseSocket("192.168.9.10",25000U);
  }

  /* user code (Terminate function Trailer) */
  {
    volatile io3xx_pull *ptrIO31x_pull;
    volatile io3xx_2x *ptrio3xx_2x;
    uint16_t moduleArchitecture;
    sg_fpga_io3xxModuleIdT moduleId;

    // Get module IDs (PIC info)
    sg_fpga_IO3xxGetModuleId(39750, &moduleId);
    moduleArchitecture = moduleId.moduleArchitecture;
    SG_PRINTF(DEBUG, "moduleArchitecture %d\n",moduleArchitecture);
    if (moduleArchitecture == TEWS_TXMC) {
      // Get pointer to io31x_pull
      ptrIO31x_pull = (io3xx_pull *)((uintptr_t)io3xxGetAddressSgLib(
        (int32_t)1, SG_FPGA_IO3XX_BAR2) + IO3xx_PULL_BASE);

      // Disable pull resistors
      ptrIO31x_pull->enable = 0x0;     // disable
    }

    // Pull down and disable DIOs
    if ((1 == 2) || (1 == 3)) {
      ptrio3xx_2x = (io3xx_2x *)(
        (uintptr_t)io3xxGetAddressSgLib((int32_t)1, SG_FPGA_IO3XX_BAR2) +
        IO3xx_2x_BASE);
      ptrio3xx_2x->pull = 0xffffffff;  // pull down
      ptrio3xx_2x->dir = 0x0;          // input
      ptrio3xx_2x->update = 0x1;
      sg_wait_s(SG_FPGA_WAIT_TIME_100us);
      ptrio3xx_2x->update = 0x0;
      sg_wait_s(SG_FPGA_WAIT_TIME_1ms);

#if DEBUGGING

      // For debugging output port register of IO-Expander
      sg_wait_s(SG_FPGA_WAIT_TIME_100ms);
      SG_PRINTF(INFO, "last configuration from mdl start\n");
      SG_PRINTF(INFO, "rxData of Expander1: 0x%X\n",
                ptrio3xx_2x->rxDataExpander1);
      SG_PRINTF(INFO, "rxData of Expander2: 0x%X\n",
                ptrio3xx_2x->rxDataExpander2);
      SG_PRINTF(INFO, "rxData of Expander3: 0x%X\n",
                ptrio3xx_2x->rxDataExpander3);
      SG_PRINTF(INFO, "rxData of Expander4: 0x%X\n",
                ptrio3xx_2x->rxDataExpander4);

#endif

    } else if (1 == 4) {
      IO3xx_24_terminate(1);
    }
  }
}

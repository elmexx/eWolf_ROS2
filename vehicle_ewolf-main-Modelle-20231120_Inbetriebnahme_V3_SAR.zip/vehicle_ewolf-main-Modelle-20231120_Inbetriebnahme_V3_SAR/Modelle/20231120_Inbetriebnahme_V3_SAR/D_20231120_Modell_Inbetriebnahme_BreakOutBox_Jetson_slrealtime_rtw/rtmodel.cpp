/*
 *  rtmodel.cpp:
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
 * Model version              : 4.141
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C++ source code generated on : Fri May 24 11:08:49 2024
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtmodel.h"

/* Use this function only if you need to maintain compatibility with an existing static main program. */
void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step(int_T tid)
{
  switch (tid) {
   case 0 :
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step0();
    break;

   case 1 :
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step2();
    break;

   case 2 :
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step3();
    break;

   case 3 :
    D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step4();
    break;

   default :
    /* do nothing */
    break;
  }
}

#ifndef _RTE_D__________MODELL_INBETRIEBNAHME_BREAKOUTBOX_JETSON_PARAMETERS_H
#define _RTE_D__________MODELL_INBETRIEBNAHME_BREAKOUTBOX_JETSON_PARAMETERS_H
#include "rtwtypes.h"
#include "SegmentInfo.hpp"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"

struct RTE_Param_Service_T {
  struct_AzXAydn5whPkCj5deW4WYB camera;
  real_T Ts;
  real_T default_spacing;
  real_T max_ac;
  real_T max_steer;
  real_T min_ac;
  real_T min_steer;
};

extern RTE_Param_Service_T RTE_Param_Service;
extern RTE_Param_Service_T *RTE_Param_Service_ptr;
struct_AzXAydn5whPkCj5deW4WYB* get_camera(void);
real_T* get_Ts(void);
real_T* get_default_spacing(void);
real_T* get_max_ac(void);
real_T* get_max_steer(void);
real_T* get_min_ac(void);
real_T* get_min_steer(void);
namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif

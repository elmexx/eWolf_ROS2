/*
 *  rtmodel.h:
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
 * Model version              : 4.141
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C++ source code generated on : Fri May 24 11:08:49 2024
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"
#define GRTINTERFACE                   0

/* Model wrapper function */
/* Use this function only if you need to maintain compatibility with an existing static main program. */
extern void D_20231120_Modell_Inbetriebnahme_BreakOutBox_Jetson_step(int_T tid);

#endif                                 /* RTW_HEADER_rtmodel_h_ */

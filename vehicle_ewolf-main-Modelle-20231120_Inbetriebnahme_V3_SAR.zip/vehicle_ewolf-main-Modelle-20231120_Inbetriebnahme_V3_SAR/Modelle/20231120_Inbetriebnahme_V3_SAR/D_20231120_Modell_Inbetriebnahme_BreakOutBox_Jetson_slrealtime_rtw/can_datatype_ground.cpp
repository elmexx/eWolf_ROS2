#include "can_message.h"

CAN_DATATYPE CAN_DATATYPE_GROUND = { 0, 0, 0, 0, 0, 0.0, { 0, 0, 0, 0, 0, 0, 0,
    0 } };

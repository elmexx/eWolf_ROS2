# -*- coding: utf-8 -*-

import argparse
import logging
import os
import cv2

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torchvision import transforms
from pykalman import KalmanFilter
import matplotlib.pyplot as plt

from unet import UNet
from utils.data_vis import plot_img_and_mask
from utils.dataset import BasicDataset

import parameter
import image2bev
import lane_parameter
import lanecluster

# from torch2trt import torch2trt
# from torch2trt import TRTModule

DT = 0.2

import numpy as np
from global_settings import get_params
from reference_path import ReferencePath
from trajectory import Trajectory, LateralCurve, LongitudinalCurve
from planner_util import (
    transform_state_cartesian_to_frenet,
    transform_obstacles_frenet_to_cartesian,
    check_trajectories,
    ideal_tracking,
)
from frenet_vizualization import visualize
import operator

def step(state: dict, reference_path: ReferencePath, params: dict) -> tuple:
    """Generation of a trajectory

    :param state: current state of vehicle in frénet coordinates
    :type: dict
    :param reference_path: reference path
    :type: ReferencePath
    :param params: dictionary containing all parameters
    :type: dict
    :return: optimal trajectory, i.e. trajectory with lowest cost
    :rtype: Trajectory
    :return: dictionary containing all generated trajectories of this time step
    :rtype: dict"""

    # lists of curves and trajectories
    longitudinal_curves = []
    lateral_curves = []
    trajectories = []

    # loop over several end times
    for t_end in np.linspace(
        start=params["discretization"]["t_min"],
        stop=params["discretization"]["t_max"],
        num=params["discretization"]["num_t"],
    ):

        # sample time
        t_array = np.linspace(
            start=0, stop=t_end, num=params["discretization"]["sampling_points"]
        )

        # loop over several longitudinal end velocities
        for s_dot_end in np.linspace(
            start=params["discretization"]["s_dot_min"],
            stop=params["discretization"]["s_dot_max"],
            num=params["discretization"]["num_s_dot"],
        ):

            # calculate longitudinal curve
            longitudinal_curve = LongitudinalCurve(
                s_start=state["s"],
                s_dot_start=state["s_dot"],
                s_ddot_start=state["s_ddot"],
                s_dot_end=s_dot_end,
                s_ddot_end=0,
                t_array=t_array,
            )

            # add longitudinal curve to longitudinal curves list
            longitudinal_curves.append(longitudinal_curve)

        # loop over several lateral end positions
        for d_end in np.linspace(
            start=params["discretization"]["d_min"],
            stop=params["discretization"]["d_max"],
            num=params["discretization"]["num_d"],
        ):

            # calculate lateral curve
            lateral_curve = LateralCurve(
                d_start=state["d"],
                d_dot_start=state["d_dot"],
                d_ddot_start=state["d_ddot"],
                d_end=d_end,
                d_dot_end=0,
                d_ddot_end=0,
                t_array=t_array,
            )

            # add lateral curve to lateral curves list
            lateral_curves.append(lateral_curve)

        # combine set of longitudinal and lateral curves
        for longitudinal_curve in longitudinal_curves:
            for lateral_curve in lateral_curves:

                # calculate trajectory
                trajectory = Trajectory(
                    longitudinal_curve=longitudinal_curve,
                    lateral_curve=lateral_curve,
                    t_array=t_array,
                    cost_coefficients=params["cost_coefficients"],
                    s_dot_desired=params["discretization"]["s_dot_desired"],
                )

                # transform trajectory from frenét to cartesian coordinate system
                trajectory.transform_frenet_to_cartesian(reference_path=reference_path)

                # add trajectory to trajectories list
                trajectories.append(trajectory)

    # sort trajectories according to the cost associated with each trajectory
    trajectories = sorted(trajectories, key=operator.attrgetter("cost"))

    # check trajectories for validity and sort into valid and invalid
    trajectories = check_trajectories(trajectories=trajectories, parameters=params)

    # extract best trajectory (valid trajectory with lowest cost)
    optimal_trajectory = trajectories["valid"][0]

    return optimal_trajectory, trajectories

def predict_img(net,
                full_img,
                device,
                scale_factor=1,
                out_threshold=0.5):
    # net.eval()

    img = torch.from_numpy(BasicDataset.preprocess(full_img, scale_factor))

    img = img.unsqueeze(0)
    img = img.to(device=device, dtype=torch.float32)

    with torch.no_grad():
        output = net(img)

        if net.n_classes > 1:
            probs = F.softmax(output, dim=1)
        else:
            probs = torch.sigmoid(output)
            
        # probs = torch.sigmoid(output)
        probs = probs.squeeze(0)
        
        tf = transforms.Compose(
            [
                transforms.ToPILImage(),
                transforms.Resize(full_img.size[1]),
                transforms.ToTensor()
            ]
        )

        probs = tf(probs.cpu())
        full_mask = probs.squeeze().cpu().numpy()

    return full_mask > out_threshold


def get_args():
    parser = argparse.ArgumentParser(description='Predict masks from input images',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--model', '-m', default='MODEL.pth',
                        metavar='FILE',
                        help="Specify the file in which the model is stored")
    parser.add_argument('--input', '-i',
                        help='filenames of input images', required=True)

    parser.add_argument('--output', '-o', 
                        help='Filenames of ouput images')
    parser.add_argument('--viz', '-v', action='store_true',
                        help="Visualize the images as they are processed",
                        default=False)
    parser.add_argument('--no-save', '-n', action='store_true',
                        help="Do not save the output masks",
                        default=False)
    parser.add_argument('--mask-threshold', '-t', type=float,
                        help="Minimum probability value to consider a mask pixel white",
                        default=0.5)
    parser.add_argument('--scale', '-s', type=float,
                        help="Scale factor for the input images",
                        default=0.5)

    return parser.parse_args()


def get_output_filenames(args):
    in_files = args.input
    out_files = []

    if not args.output:
        for f in in_files:
            pathsplit = os.path.splitext(f)
            out_files.append("{}_OUT{}".format(pathsplit[0], pathsplit[1]))
    elif len(in_files) != len(args.output):
        logging.error("Input files and output files are not of the same length")
        raise SystemExit()
    else:
        out_files = args.output

    return out_files


def mask_to_image(mask):
    return Image.fromarray((mask * 255).astype(np.uint8))

def get_waypoints(lane_params):
    way_points = lane_fit_params['waypoints']
    way_points = np.fliplr(way_points)
    return way_points


if __name__ == "__main__":

    in_files = 'GRMN0119.MP4'
    model_path = './checkpoints/torch1.6model/CP_epoch8.pth'
    trt_model_path = 'lanedetection_trt.pth'
    cap = cv2.VideoCapture(in_files)
    # out_files = get_output_filenames(args)

    h = parameter.imgh
    w = parameter.imgw

        #########################################
    # Camera Pose
    CameraPose = image2bev._DictObjHolder({
            "Pitch": parameter.pitch,
            "Yaw": parameter.yaw,
            "Roll": parameter.roll,
            "Height": parameter.height,
            })

    # IntrinsicMatrix
    mtx = parameter.mtx
    dist = parameter.dist
    IntrinsicMatrix = np.transpose(mtx)

    # Out Image View
    OutImageView = image2bev._DictObjHolder({
            "distAheadOfSensor": parameter.distAheadOfSensor,
            "spaceToLeftSide": parameter.spaceToLeftSide,
            "spaceToRightSide": parameter.spaceToRightSide,
            "bottomOffset": parameter.bottomOffset,
            })

    OutImageSize = np.array([np.nan, np.int_(w/2)])  # image H, image W

    net = UNet(n_channels=3, n_classes=1)

    logging.info("Loading model {}".format(model_path))

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'Using device {device}')
    net.to(device=device)
    net.load_state_dict(torch.load(model_path, map_location=device))
    net.eval()
    # model_trt = TRTModule()

    # model_trt.load_state_dict(torch.load(trt_model_path))

    # logging.info("Model loaded !")
   
    #
    # Lane Kalmanfilter
    #
    
    L_init_lane_parameter = np.array([8.59772640e-07,  2.72346164e-02,  2.04014669e+02])
    R_init_lane_parameter = np.array([6.64430504e-06, -1.32049055e-02,  6.38566362e+02])


    L_KF_init_parameter = np.array([L_init_lane_parameter[0],0,
                                    L_init_lane_parameter[1],0,
                                    L_init_lane_parameter[2],0])
    R_KF_init_parameter = np.array([R_init_lane_parameter[0],0,
                                    R_init_lane_parameter[1],0,
                                    R_init_lane_parameter[2],0])
    transition_matrix = np.eye(6)
    transition_matrix[0,1] = DT
    transition_matrix[2,3] = DT
    transition_matrix[4,5] = DT
    
    observation_matrix = np.zeros((3,6))
    observation_matrix[0,0] = 1
    observation_matrix[1,2] = 1
    observation_matrix[2,4] = 1
    
    state_covariance = 1*np.eye(6)
    observation_covariance = 25*np.eye(3)
    C_stateleft = L_KF_init_parameter
    C_stateright = R_KF_init_parameter
    P_stateleft = state_covariance
    P_stateright = state_covariance
    
    L_kflane = KalmanFilter(transition_matrices = transition_matrix,
                          observation_matrices = observation_matrix,
                          transition_covariance  = state_covariance,
                          observation_covariance = observation_covariance,
                          initial_state_mean = L_KF_init_parameter)
    R_kflane = KalmanFilter(transition_matrices = transition_matrix,
                          observation_matrices = observation_matrix,
                          transition_covariance  = state_covariance,
                          observation_covariance = observation_covariance,
                          initial_state_mean = R_KF_init_parameter)


    # for i, fn in enumerate(in_files):
    #     logging.info("\nPredicting image {} ...".format(fn))

    #     img = Image.open(fn)

    #     mask = predict_img(net=net,
    #                        full_img=img,
    #                        scale_factor=args.scale,
    #                        out_threshold=args.mask_threshold,
    #                        device=device)

    #     if not args.no_save:
    #         out_fn = out_files[i]
    #         result = mask_to_image(mask)
    #         result.save(out_files[i])

    #         logging.info("Mask saved to {}".format(out_files[i]))

    #     if args.viz:
    #         logging.info("Visualizing results for image {}, close to continue ...".format(fn))
    #         plot_img_and_mask(img, mask)
    
    ## Trajectory Planning 
    params = get_params()
    # number of steps
    step_counter = 0
    
    # dictionary to store all trajectories of every time step for the visualization
    trajectories_over_time = dict()
    optimal_trajectories = dict()
    params["xy_obstacles"] = []
    # get initial cartesian state from parameter file
    initial_cartesian_state = params["initial_state"]
                
    # maximum progress s per step
    max_s_progress_per_step = params["discretization"]["t_max"] * params["limits"]["v_max"]  
    
    initial_xy_waypoints = np.array([[0,0],
                                     [10,0],
                                     [20,0],
                                     [30,0]])
    # initial_reference_path = ReferencePath(xy_waypoints = initial_xy_waypoints)
    # transform initial state from cartesian to frenét coordinate system
    # frenet_state = transform_state_cartesian_to_frenet(
    #     cartesian_state=initial_cartesian_state, reference_path=initial_reference_path
    # )
    xy_waypoints = []
    start_waypoint = [0,0]
    xt_1 = 0
    yt_1 = 0
    global_x_point = 0
    global_y_point = 0
    global_x_points = []
    global_y_points = []
    counter = 0
    rec_waypoints = []
    w_frame = 512
    h_frame = 256
    # fourcc = cv2.VideoWriter_fourcc(*'MPEG')
    # writer = cv2.VideoWriter('binarylane.avi',fourcc, 30, (w_frame,h_frame))
            
    while(cap.isOpened()):
        ret, frame = cap.read()
        if ret==True:
            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # img = cv2.undistort(img, mtx, dist, None, mtx)
            img_pil = Image.fromarray(img)
            mask = predict_img(net=net,                                            
                               full_img=img_pil,
                               scale_factor=1,
                               out_threshold=0.2,
                               device=device)
            # result = mask_to_image(mask)
                # plot_img_and_mask(img, mask)
            
            binaryimg = (mask*255).astype(np.uint8)
            binaryimg = cv2.resize(binaryimg, (w, h))
            binaryimg_256 = cv2.resize(binaryimg,(512,256))
            
            lanemask, lane_coords = lanecluster.lane_mask_coords(binaryimg_256)
            
            fit_params = []
            for i in range(len(lane_coords)):
                nonzero_y = lane_coords[i][:,0]
                nonzero_x = lane_coords[i][:,1]        
                fit_param = np.polyfit(nonzero_y, nonzero_x, 2)
                fit_params.append(fit_param)
            
            line_img = np.zeros_like(binaryimg_256).astype(np.uint8)
            plot_y = np.linspace(150, binaryimg_256.shape[0]-1, binaryimg_256.shape[0])
            p_xs = []
            p_ys = []
            
            for fit_param in fit_params:
                fit_x = fit_param[0] * plot_y ** 2 + fit_param[1] * plot_y  + fit_param[2]
                idx_fitx = (np.int_(fit_x)>=0) & (np.int_(fit_x)<=binaryimg_256.shape[1]-1)
                p_y = np.int_(plot_y)[idx_fitx]
                p_x = np.int_(fit_x)[idx_fitx]
                p_ys.extend(p_y)
                p_xs.extend(p_x)
            
            line_pts = (p_ys, p_xs)
            line_img[line_pts] = 255
            src_xy = np.argwhere(line_img != 0)
            src_xy = np.flip(src_xy[:,0:2],1)
            points_xy = [tuple(x) for x in src_xy]
            lane_image = np.zeros_like(binaryimg_256).astype(np.uint8)
            for points in points_xy:
                lane_image = cv2.circle(lane_image,points,3,255,-1)
            g_b = np.zeros_like(lane_image).astype(np.uint8)
            add_img = cv2.merge((lane_image,g_b, g_b))
            out_image_new = cv2.addWeighted(cv2.resize(frame,(512,256)),1,add_img,1,0.0)
            # plt.imshow(line_img)
            
            # To-do:
            # delect small lane_coords (set min_len(lane_coords))
            # or merge near lane_coords
            
            # Bird's Eye View Image
            birdseyeviewimage, unwarp_matrix, birdseyeview = lane_parameter.bev_perspective(img, IntrinsicMatrix, CameraPose, OutImageView, OutImageSize)
            
            # lane parameter in vehicle coordination
            lane_fit_params = lane_parameter.lanefit(binaryimg,IntrinsicMatrix,CameraPose, OutImageView, OutImageSize)
            ego_right_lane = lane_fit_params['ego_right_lane']
            ego_left_lane = lane_fit_params['ego_left_lane']
            # waypoints = lane_fit_params['waypoints']
            # waypoints = get_waypoints(lane_fit_params)
            # print(waypoints)
            # Tracking Lane with Kalman Filter
            if ego_left_lane is not None:
                (C_stateleft, P_stateleft) = L_kflane.filter_update(filtered_state_mean = C_stateleft,
                                                                  filtered_state_covariance = P_stateleft,
                                                                  observation = ego_left_lane)
                
                ego_left_lane = np.array([C_stateleft[0], C_stateleft[2], C_stateleft[4]])
            else:
                measureleft = np.array([C_stateleft[0], C_stateleft[2], C_stateleft[4]])
                (C_stateleft, P_stateleft) = L_kflane.filter_update(filtered_state_mean = C_stateleft,
                                                                  filtered_state_covariance = P_stateleft,
                                                                  observation = measureleft)
                ego_left_lane = np.array([C_stateleft[0], C_stateleft[2], C_stateleft[4]])
            if ego_right_lane is not None:
                (C_stateright, P_stateright) = R_kflane.filter_update(filtered_state_mean = C_stateright,
                                                                      filtered_state_covariance = P_stateright,
                                                                      observation = ego_right_lane)
                
                ego_right_lane = np.array([C_stateright[0], C_stateright[2], C_stateright[4]])
            else:
                measureright = np.array([C_stateright[0], C_stateright[2], C_stateright[4]])
                (C_stateright, P_stateright) = R_kflane.filter_update(filtered_state_mean = C_stateright,
                                                                      filtered_state_covariance = P_stateright,
                                                                      observation = measureright)
                ego_right_lane = np.array([C_stateright[0], C_stateright[2], C_stateright[4]])
        
            mask_img = lane_parameter.drawlane(binaryimg, birdseyeviewimage, unwarp_matrix, ego_right_lane, ego_left_lane)
            
            g_b = np.zeros_like(mask_img).astype(np.uint8)
            add_img = cv2.merge((mask_img,g_b, g_b))
            out_image = cv2.addWeighted(frame,1,add_img,1,0.0)
            
            mittel_lane = (ego_right_lane + ego_left_lane) / 2
            mittel_mask_img = lane_parameter.drawmittellane(binaryimg, birdseyeviewimage, unwarp_matrix, mittel_lane)
            add_img1 = cv2.merge((g_b, g_b,mittel_mask_img))
            out_image = cv2.addWeighted(out_image,1,add_img1,1,0.0)
                        
            #print('waypoints: ', waypoints)
    
            # result = (mask*255).astype(np.uint8)
            
            # result_resize = cv2.resize(result,(512,256))
            # g_r = np.zeros_like(result_resize).astype(np.uint8)
            
            # add_img = cv2.merge((result_resize,g_r,g_r))
            # img_resize = cv2.resize(img,(512,256))
            
            # out_image = cv2.addWeighted(img_resize,1,add_img,1,0.0)
            # out_img = cv2.cvtColor(out_image, cv2.COLOR_RGB2BGR)
            
            # cv2.namedWindow('img',cv2.WINDOW_AUTOSIZE)
            # cv2.imshow('img', img_resize)
            cv2.namedWindow('result',cv2.WINDOW_AUTOSIZE)
            cv2.imshow('result', out_image_new)
            cv2.namedWindow('binaryimg',cv2.WINDOW_AUTOSIZE)
            cv2.imshow('binaryimg', cv2.resize(binaryimg,(512,256)))
            cv2.namedWindow('lanemask',cv2.WINDOW_AUTOSIZE)
            cv2.imshow('lanemask', lanemask)
            cv2.namedWindow('birdeyeview',cv2.WINDOW_AUTOSIZE)
            cv2.imshow('birdeyeview', birdseyeviewimage)
            # if cv2.waitKey(1) & 0xFF == ord('q'):
            #     break
            # writer.write(cv2.resize(binaryimg_256,(512,256)))
            waypoints = get_waypoints(lane_fit_params)+[global_x_point,0]
            rec_waypoints.append(waypoints)
            # print(get_waypoints(lane_fit_params))
            
            # reference_path = ReferencePath(xy_waypoints=waypoints)
            # frenet_state = transform_state_cartesian_to_frenet(
            #         cartesian_state=initial_cartesian_state, reference_path=reference_path
            #     )
            # main loop
            # while frenet_state["s"] < reference_path.s_rp[-1] - max_s_progress_per_step:
            
            #     # do one planning step
            #     optimal_trajectory, trajectories = step(
            #         state=frenet_state, reference_path=reference_path, params=params
            #     )
            
            #     # project along optimal trajectory according to calculation time (ideal tracking)
            #     frenet_state = ideal_tracking(
            #         trajectory=optimal_trajectory, time=params["discretization"]["fixed_calc_time"]
            #     )
            
            #     # store trajectories of this time step in dictionary containing trajectories of all time steps for visualization
            #     trajectories_over_time[step_counter] = trajectories
            #     # print(trajectories_over_time[step_counter]["valid"][0].xy[1,:])
                
            #     optimal_trajectory_step = {"valid": optimal_trajectory, "invalid": []}
            
            #     # print current progress every 20 steps
            #     # if not step_counter % 20:
            #     #     progress = min(
            #     #         100
            #     #         * frenet_state["s"]
            #     #         / (reference_path.s_rp[-1] - max_s_progress_per_step),
            #     #         100,
            #     #     )
            #     #     print(f"Current progress {int(progress)} %")
            
            #     step_counter += 1
            # optimal_trajectories[counter] = optimal_trajectory_step
            # counter = counter +1
            # if counter > 100:
            #     break
                
            # vehicle_state = {"x": trajectories_over_time[0]["valid"][0].xy[1,0],
            #      "y": trajectories_over_time[0]["valid"][0].xy[1,1],
            #      "theta": trajectories_over_time[0]["valid"][0].theta[1],
            #      "kappa": trajectories_over_time[0]["valid"][0].kappa[1],
            #      "v": trajectories_over_time[0]["valid"][0].v[1],
            #      "a": trajectories_over_time[0]["valid"][0].a[1]}
            # global_x_point = vehicle_state["x"] + xt_1
            # global_y_point = vehicle_state["y"] # + yt_1
            # xt_1 = global_x_point
            # yt_1 = global_y_point
            # global_x_points.append(global_x_point)
            # global_y_points.append(global_y_point)
            # frenet_state = transform_state_cartesian_to_frenet(
            #         cartesian_state=vehicle_state, reference_path=reference_path
            #     )
            # print(frenet_state["s"])
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    cv2.destroyAllWindows()
    # writer.release()
    # visualize trajectories of all steps
    # global_referencepath = ReferencePath(xy_waypoints=np.column_stack([global_x_points,global_y_points]))
    
    # xxyy_waypoints=np.vstack([np.column_stack([global_x_points,global_y_points]),waypoints+[0.01,0]])
    # global_referencepath = ReferencePath(xy_waypoints=xxyy_waypoints)
    # visualize(
    #     trajectories_over_time=optimal_trajectories,
    #     reference_path=global_referencepath,
    #     params=params,
    # )

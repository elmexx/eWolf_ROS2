# -*- coding: utf-8 -*-

from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
from scipy.interpolate import splev, splrep, splprep
from scipy.interpolate import CubicSpline

x = [0,2,3,6,7,8]
y = [1,2,-1,3,5,10]

### cublic spline
cubic_spline = CubicSpline(x=x, y=y)
y1 = cubic_spline(x, 0)
dy1 = cubic_spline(x, 1)
ddy1 = cubic_spline(x, 2)
dddy1 = cubic_spline(x, 3)

### splrep
spl = splrep(x, y)
y2 = splev(x, spl, der = 0)
dy2 = splev(x, spl, der = 1)
ddy2 = splev(x, spl, der = 2)
dddy2 = splev(x, spl, der = 3)


### splprep
tck, u = splprep([x,y])
# u = np.linspace(0,1,1000)
y3 = splev(u, tck, der = 0)
dy3 = splev(u, tck, der = 1)
ddy3 = splev(u, tck, der = 2)
dddy3 = splev(u, tck, der = 3)

xp, yp = intplt.splev(u_new, tck, der=1)
xpp, ypp = intplt.splev(u_new, tck, der=2)




    v[0] = 0

    v[i] = v[i-1] + distance(x[i], x[i-1])

    u[i] = v[i] / v[M-1]

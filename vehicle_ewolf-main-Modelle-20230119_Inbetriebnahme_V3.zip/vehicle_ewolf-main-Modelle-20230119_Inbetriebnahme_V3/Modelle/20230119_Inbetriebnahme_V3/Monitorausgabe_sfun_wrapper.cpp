
/*
 * Include Files
 *
 */
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#define SIMPLIFIED_RTWTYPES_COMPATIBILITY
#include "rtwtypes.h"
#undef SIMPLIFIED_RTWTYPES_COMPATIBILITY
#endif



/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */
#include "simstruc.h"
#include <stdio.h>
#include <cmath>
#ifdef SIMULINK_REAL_TIME
#include "slrt_log.hpp"
#endif
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */
#define u_width 1
#define u_1_width 1
#define y_width 1

/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */
/* extern double func(double a); */
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output function
 *
 */
void Monitorausgabe_sfun_Outputs_wrapper(const real_T *u0,
			const real_T *u1,
			real_T *y0)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */
// Create custom message
static char Odometermsg[100];
static char SoCmsg[100];
sprintf(Odometermsg,"Aktueller Kilometerstand: %f km \n",round(*u0));
sprintf(SoCmsg,"Aktueller SoC: %f % \n",round(*u1));
// Use macros for platform dependent code
#ifdef SIMULINK_REAL_TIME
slrealtime::log_info(Odometermsg);
slrealtime::log_info(SoCmsg);
#else
ssPrintf(Odometermsg);
ssPrintf(SoCmsg);
#endif

// Generic platform independent code
*y0 = *u0;
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}



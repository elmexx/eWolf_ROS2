# eWolf Simulink Modell

## Prerequisites:
Software:
* MATLAB 2022B
* Speedgoat:
    * Speedgoat I/O Blockset Version 9.6.0.1 (R2022b)
        Build number: 30476
        Build date:   14-Apr-2023 09:06:54
    * Installed I/O Configuration Packages:
        - IO397 Configuration Package   Version: 5.0
    Access to new Speedgoat software with login in \\ffs4.fkfs.de\AM_Projekte\FMECH.21.03_HANNES_INTERN_MO_AEb\Hardware\Speedgoat\_Info&Zugangsdaten_Webseite.txt

* MATLAB Toolbox: 
    * Simulink Real-Time Target Support Package
    * Automated Driving Toolbox
    * Computer Vision Toolbox
    * Model Predictive Control Toolbox
    * Simulink
    * Sensor Fusion and Tracking Toolbox
    * Simscape Electrical



## Troubleshooting

- Simulink complie error: <font color=red> "std exception 'class mwboost::exception_detail::clone_impl<class fl::filesystem::pathnotfound>': 'fl:filesystem:pathnotfound' was caught."</font>
    
    -> delete below folder and file, then complie again.
    ```
    ├───D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_slrealtime_rtw
    │───slprj
    │   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.mldatx
    │   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.slxc
    ```


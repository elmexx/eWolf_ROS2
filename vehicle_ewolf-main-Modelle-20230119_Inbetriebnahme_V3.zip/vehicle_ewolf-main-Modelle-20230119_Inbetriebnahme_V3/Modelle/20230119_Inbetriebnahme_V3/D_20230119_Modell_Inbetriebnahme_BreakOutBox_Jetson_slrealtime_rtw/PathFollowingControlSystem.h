/*
 * Code generation for system system '<S120>/Path Following Control System'
 * For more details, see corresponding source file PathFollowingControlSystem.c
 *
 */

#ifndef RTW_HEADER_PathFollowingControlSystem_h_
#define RTW_HEADER_PathFollowingControlSystem_h_
#include <logsrv.h>
#include <cstring>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "verify/verifyIntrf.h"
#include "slrealtime/libsrc/IP/udp.hpp"
#include "slrealtime/libsrc/IP/ip.hpp"
#include "slrealtime/libsrc/IP/socketFactory.hpp"
#include "sg_fpga_io30x_setup_util.h"
#include "sg_fpga_io31x_io32x_setup_util.h"
#include "sg_fpga_io33x_setup_util.h"
#include "sg_fpga_io39x_setup_util.h"
#include "sg_common.h"
#include "sg_printf.h"
#include "Monitorausgabe_sfun_cgen_wrapper.h"
#include "sf_runtime/slTestResult.h"
#include "sf_runtime/slTestTypes.h"
#include "PathFollowingControlSystem_cal.h"

extern "C"
{

#include "rt_nonfinite.h"

}

#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"

/* Block signals for system '<S129>/DataTypeConversion_Vx' */
struct B_DataTypeConversion_Vx_D_202_T {
  real_T y;                            /* '<S129>/DataTypeConversion_Vx' */
};

/* Block signals for system '<S129>/DataTypeConversion_amax' */
struct B_DataTypeConversion_amax_D_2_T {
  real_T y;                            /* '<S129>/DataTypeConversion_amax' */
};

/* Block signals for system '<S120>/Path Following Control System' */
struct B_PathFollowingControlSystem__T {
  real_T b_Hv[2520];
  real_T Su[2400];
  real_T Cm[630];
  real_T b_Sx[600];
  real_T Product[21];                  /* '<S129>/Product' */
  real_T Floor;                        /* '<S150>/Floor' */
  real_T Floor1;                       /* '<S150>/Floor1' */
  real_T LastPcov[100];                /* '<S150>/LastPcov' */
  real_T MathFunction[3];              /* '<S150>/Math Function' */
  real_T MathFunction1[2];             /* '<S150>/Math Function1' */
  real_T MathFunction2[2];             /* '<S150>/Math Function2' */
  real_T umin_scale4[2];               /* '<S150>/umin_scale4' */
  real_T Reshape[2];                   /* '<S150>/Reshape' */
  real_T ymin_scale1[3];               /* '<S150>/ymin_scale1' */
  real_T Reshape1[3];                  /* '<S150>/Reshape1' */
  real_T ymin_scale2;                  /* '<S150>/ymin_scale2' */
  real_T Reshape2;                     /* '<S150>/Reshape2' */
  real_T Reshape3[3];                  /* '<S150>/Reshape3' */
  real_T Reshape4[2];                  /* '<S150>/Reshape4' */
  real_T Reshape5[2];                  /* '<S150>/Reshape5' */
  real_T extmv_scale[2];               /* '<S150>/ext.mv_scale' */
  real_T last_mv[2];                   /* '<S150>/last_mv' */
  real_T last_x[10];                   /* '<S150>/last_x' */
  real_T uref_scale[2];                /* '<S150>/uref_scale' */
  real_T utau;                         /* '<S185>/Divide' */
  real_T a1;                           /* '<S185>/Unary Minus' */
  real_T An[4];                        /* '<S185>/Matrix Concatenate' */
  real_T Sum;                          /* '<S184>/Sum' */
  real_T Gain2;                        /* '<S184>/Gain2' */
  real_T a1_a;                         /* '<S184>/Divide2' */
  real_T Product_f;                    /* '<S184>/Product' */
  real_T Product1;                     /* '<S184>/Product1' */
  real_T Sum1;                         /* '<S184>/Sum1' */
  real_T Gain3;                        /* '<S184>/Gain3' */
  real_T a3;                           /* '<S184>/Divide4' */
  real_T Divide3;                      /* '<S184>/Divide3' */
  real_T a2;                           /* '<S184>/Sum2' */
  real_T Divide6;                      /* '<S184>/Divide6' */
  real_T Divide7;                      /* '<S184>/Divide7' */
  real_T Sum3;                         /* '<S184>/Sum3' */
  real_T Gain4;                        /* '<S184>/Gain4' */
  real_T a4;                           /* '<S184>/Divide5' */
  real_T Am[4];                        /* '<S184>/Matrix Concatenate' */
  real_T MatrixConcatenate[16];        /* '<S183>/Matrix Concatenate' */
  real_T Divide;                       /* '<S184>/Divide' */
  real_T b1;                           /* '<S184>/Gain' */
  real_T Divide1;                      /* '<S184>/Divide1' */
  real_T b2;                           /* '<S184>/Gain1' */
  real_T MatrixConcatenate1[8];        /* '<S183>/Matrix Concatenate1' */
<<<<<<< .mine
  real_T MatrixConcatenate2[12];       /* '<S183>/Matrix Concatenate2' */
  real_T u_scale[2];                   /* '<S150>/u_scale' */
  real_T useq_scale[42];               /* '<S150>/useq_scale' */
  real_T useq_scale1[63];              /* '<S150>/useq_scale1' */
  real_T ym_zero[3];                   /* '<S150>/ym_zero' */
||||||| .r78
=======
  real_T MatrixConcatenate2[12];       /* '<S183>/Matrix Concatenate2' */
  real_T u_scale[2];                   /* '<S150>/u_scale' */
  real_T useq_scale[62];               /* '<S150>/useq_scale' */
  real_T useq_scale1[93];              /* '<S150>/useq_scale1' */
  real_T ym_zero[3];                   /* '<S150>/ym_zero' */
>>>>>>> .r84
  real_T Relativedistanceground;       /* '<S128>/Relative distance ground' */
  real_T Relativevelocityground;       /* '<S128>/Relative velocity ground' */
  real_T Timegapground;                /* '<S128>/Time gap ground' */
  real_T VehicledynamicsmatrixAground;
                                 /* '<S128>/Vehicle dynamics matrix A ground' */
  real_T VehicledynamicsmatrixBground;
                                 /* '<S128>/Vehicle dynamics matrix B ground' */
  real_T VehicledynamicsmatrixCground;
                                 /* '<S128>/Vehicle dynamics matrix C ground' */
  real_T A[81];                        /* '<S180>/Adaptive Model' */
  real_T B[27];                        /* '<S180>/Adaptive Model' */
  real_T C[27];                        /* '<S180>/Adaptive Model' */
  real_T D[9];                         /* '<S180>/Adaptive Model' */
  real_T TmpSignalConversionAtSFunctionI[3];/* '<S178>/FixedHorizonOptimizer' */
  real_T TmpSignalConversionAtSFunctio_e[3];/* '<S178>/FixedHorizonOptimizer' */
  real_T TmpSignalConversionAtSFunctio_g[2];/* '<S178>/FixedHorizonOptimizer' */
  real_T TmpSignalConversionAtSFunctio_h[2];/* '<S178>/FixedHorizonOptimizer' */
  real_T xk1[10];                      /* '<S178>/FixedHorizonOptimizer' */
  real_T u[2];                         /* '<S178>/FixedHorizonOptimizer' */
  real_T cost;                         /* '<S178>/FixedHorizonOptimizer' */
  real_T useq[42];                     /* '<S178>/FixedHorizonOptimizer' */
  real_T xseq[210];                    /* '<S178>/FixedHorizonOptimizer' */
  real_T yseq[63];                     /* '<S178>/FixedHorizonOptimizer' */
  real_T status;                       /* '<S178>/FixedHorizonOptimizer' */
  real_T xest[10];                     /* '<S178>/FixedHorizonOptimizer' */
  real_T Pk1[100];                     /* '<S178>/FixedHorizonOptimizer' */
  real_T y;                            /* '<S129>/DataTypeConversion_vset' */
  real_T y_b;                          /* '<S129>/DataTypeConversion_optsgn' */
  real_T y_f[2];                       /* '<S129>/DataTypeConversion_extmv' */
  real_T y_g[21];                      /* '<S129>/CurvatureConversion' */
  boolean_T min_relop;                 /* '<S133>/min_relop' */
  boolean_T Memory[8];                 /* '<S150>/Memory' */
  boolean_T iAout[8];                  /* '<S178>/FixedHorizonOptimizer' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_tlag;/* '<S128>/DataTypeConversion_tlag' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_spacing;/* '<S128>/DataTypeConversion_spacing' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_Ts;/* '<S128>/DataTypeConversion_Ts' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_umin;/* '<S129>/DataTypeConversion_umin' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_umax;/* '<S129>/DataTypeConversion_umax' */
  B_DataTypeConversion_Vx_D_202_T sf_DataTypeConversion_e2;/* '<S129>/DataTypeConversion_e2' */
  B_DataTypeConversion_Vx_D_202_T sf_DataTypeConversion_e1;/* '<S129>/DataTypeConversion_e1' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_amin;/* '<S129>/DataTypeConversion_amin' */
  B_DataTypeConversion_amax_D_2_T sf_DataTypeConversion_amax;/* '<S129>/DataTypeConversion_amax' */
  B_DataTypeConversion_Vx_D_202_T sf_DataTypeConversion_Vx;/* '<S129>/DataTypeConversion_Vx' */
};

/* Block states (default storage) for system '<S120>/Path Following Control System' */
struct DW_PathFollowingControlSystem_T {
  slTestBlkInfo_t Assertion_sltestBlkInfo;/* '<S133>/Assertion' */
  real_T last_mv_DSTATE[2];            /* '<S150>/last_mv' */
  real_T Assertion_sltestLastResultTime;/* '<S133>/Assertion' */
  real_T LastPcov_PreviousInput[100];  /* '<S150>/LastPcov' */
  real_T last_x_PreviousInput[10];     /* '<S150>/last_x' */
  int32_T Assertion_sltestFinalResult; /* '<S133>/Assertion' */
  int32_T Assertion_sltestCurrentResult;/* '<S133>/Assertion' */
  boolean_T Memory_PreviousInput[8];   /* '<S150>/Memory' */
};

extern void D_202_DataTypeConversion_Vx(real_T rtu_u,
  B_DataTypeConversion_Vx_D_202_T *localB);
extern void D_2_DataTypeConversion_amax(real_T rtu_u,
  B_DataTypeConversion_amax_D_2_T *localB);
extern void PathFollowingControlSy_Init(DW_PathFollowingControlSystem_T *localDW,
  PathFollowingControlSy_cal_type *D_20230119_Mo_PageSwitching_arg);
extern void PathFollowingControlSystem
  (RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T * const
<<<<<<< .mine
   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, real32_T
   rtu_Setvelocity, real_T rtu_Longitudinalvelocity, const real_T rtu_Curvature
   [21], real_T rtu_Lateraldeviation, real_T rtu_Relativeyawangle, real_T
   rtp_MinAcceleration, real_T rtp_MinSteering, real_T rtp_MaxAcceleration,
   real_T rtp_MaxSteering, real_T rtp_DefaultSpacing,
||||||| .r78
   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, real_T
   rtu_Longitudinalvelocity, const real_T rtu_Curvature[31], real_T
   rtu_Lateraldeviation, real_T rtu_Relativeyawangle, real_T rtp_DefaultSpacing,
=======
   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, real32_T
   rtu_Setvelocity, real_T rtu_Longitudinalvelocity, const real_T rtu_Curvature
   [31], real_T rtu_Lateraldeviation, real_T rtu_Relativeyawangle, real_T
   rtp_MinAcceleration, real_T rtp_MinSteering, real_T rtp_MaxAcceleration,
   real_T rtp_MaxSteering, real_T rtp_DefaultSpacing,
>>>>>>> .r84
   B_PathFollowingControlSystem__T *localB, DW_PathFollowingControlSystem_T
   *localDW, PathFollowingControlSy_cal_type *D_20230119_Mo_PageSwitching_arg);
extern void PathFollowingControlSy_Term(DW_PathFollowingControlSystem_T *localDW);

#endif                            /* RTW_HEADER_PathFollowingControlSystem_h_ */

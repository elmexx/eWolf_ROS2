#include "rte_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_parameters.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal.h"

RTE_Param_Service_T RTE_Param_Service = {
  {
    848.0,
    480.0,

    { 100.0, 45.0 },

    { 480.0, 848.0 },

    { 425.0031, 228.2753 },

    { 633.0128, 635.3088 },

    { 1.175, 0.4, 1.6 },

    { -0.17500000000000004, 0.4, 1.6 },

    { 0.0, 3.0, 0.0 },

    { 3.0, 40.0 },

    { 1.0, 30.0 },

    { 6.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

    { 10.0, 10.0 }
  },
  0.001,
  10.0,
  2.0,
  0.26,
  -3.0,
  -0.26
};

RTE_Param_Service_T *RTE_Param_Service_ptr = &RTE_Param_Service;
struct_AzXAydn5whPkCj5deW4WYB* get_camera(void)
{
  return &RTE_Param_Service_ptr->camera;
}

real_T* get_Ts(void)
{
  return &RTE_Param_Service_ptr->Ts;
}

real_T* get_default_spacing(void)
{
  return &RTE_Param_Service_ptr->default_spacing;
}

real_T* get_max_ac(void)
{
  return &RTE_Param_Service_ptr->max_ac;
}

real_T* get_max_steer(void)
{
  return &RTE_Param_Service_ptr->max_steer;
}

real_T* get_min_ac(void)
{
  return &RTE_Param_Service_ptr->min_ac;
}

real_T* get_min_steer(void)
{
  return &RTE_Param_Service_ptr->min_steer;
}

extern D_20230119_Modell_Inbe_cal_type D_20230119_Modell_Inbe_cal_impl;
extern RTE_Param_Service_T RTE_Param_Service;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    { (void*)&RTE_Param_Service, (void**)&RTE_Param_Service_ptr, sizeof
      (RTE_Param_Service_T), 2 },

    { (void*)&D_20230119_Modell_Inbe_cal_impl, (void**)
      &D_20230119_Modell_Inbetrieb_cal, sizeof(D_20230119_Modell_Inbe_cal_type),
      2 }
  };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime

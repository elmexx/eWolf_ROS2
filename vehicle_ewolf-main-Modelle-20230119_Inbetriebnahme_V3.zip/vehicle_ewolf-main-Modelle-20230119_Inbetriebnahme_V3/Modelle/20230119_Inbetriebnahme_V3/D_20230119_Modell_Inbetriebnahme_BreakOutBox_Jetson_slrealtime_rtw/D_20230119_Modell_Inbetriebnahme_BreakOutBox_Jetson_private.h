/*
 * D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
<<<<<<< .mine
 * Model version              : 4.38
||||||| .r78
 * Model version              : 4.24
=======
 * Model version              : 4.33
>>>>>>> .r84
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
<<<<<<< .mine
 * C++ source code generated on : Thu Oct  5 15:53:28 2023
||||||| .r78
 * C++ source code generated on : Thu May 11 16:00:17 2023
=======
 * C++ source code generated on : Fri Oct 13 13:42:54 2023
>>>>>>> .r84
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_private_h_
#define RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

#ifdef __cplusplus
#define SFB_EXTERN_C                   extern "C"
#else
#define SFB_EXTERN_C                   extern
#endif

SFB_EXTERN_C void Monitorausgabe_sfun_Start_wrapper(void);
SFB_EXTERN_C void Monitorausgabe_sfun_Outputs_wrapper(const real_T *u0,
  const real_T *u1,
  real_T *y0);
SFB_EXTERN_C void Monitorausgabe_sfun_Terminate_wrapper(void);

#undef SFB_EXTERN_C

extern real_T rt_powd_snf(real_T u0, real_T u1);
extern real_T rt_roundd_snf(real_T u);
extern real_T rt_hypotd_snf(real_T u0, real_T u1);
extern void* slrtRegisterSignalToLoggingService(uintptr_t sigAddr);
extern real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);
extern uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T
  maxIndex);
extern uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex);
extern int32_T div_nde_s32_floor(int32_T numerator, int32_T denominator);
extern "C" void sg_IO602_IO691_read_s(SimStruct *rts);
extern "C" void sg_IO191_setup_s(SimStruct *rts);
extern "C" void sg_IO191_ad_s(SimStruct *rts);
extern "C" void sg_IO191_di_s(SimStruct *rts);
extern "C" void sg_IO191_da_s(SimStruct *rts);
extern "C" void sg_IO291_di_isol_s(SimStruct *rts);
extern "C" void sg_IO191_do_s(SimStruct *rts);
extern "C" void sg_IO291_setup_s(SimStruct *rts);
extern "C" void sg_fpga_di_sf_a2(SimStruct *rts);
extern "C" void sg_IO291_do_fet_s(SimStruct *rts);
extern "C" void sg_IO291_di_ttl_s(SimStruct *rts);
extern "C" void sg_IO291_do_ttl_s(SimStruct *rts);
extern "C" void sg_IO602_IO691_setup_s(SimStruct *rts);

/* private model entry point functions */
extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_derivatives(void);

#endif
/* RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_private_h_ */

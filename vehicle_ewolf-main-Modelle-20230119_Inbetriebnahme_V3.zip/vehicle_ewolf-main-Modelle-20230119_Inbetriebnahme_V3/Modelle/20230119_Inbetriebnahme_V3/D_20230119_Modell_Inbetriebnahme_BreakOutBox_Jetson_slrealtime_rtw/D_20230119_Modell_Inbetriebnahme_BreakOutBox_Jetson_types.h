/*
 * D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
<<<<<<< .mine
 * Model version              : 4.38
||||||| .r78
 * Model version              : 4.24
=======
 * Model version              : 4.33
>>>>>>> .r84
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
<<<<<<< .mine
 * C++ source code generated on : Thu Oct  5 15:53:28 2023
||||||| .r78
 * C++ source code generated on : Thu May 11 16:00:17 2023
=======
 * C++ source code generated on : Fri Oct 13 13:42:54 2023
>>>>>>> .r84
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types_h_
#define RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_LaneBoundaryType_
#define DEFINED_TYPEDEF_FOR_LaneBoundaryType_

typedef uint8_T LaneBoundaryType;

/* enum LaneBoundaryType */
const LaneBoundaryType Unmarked = 0U;  /* Default value */
const LaneBoundaryType Solid = 1U;
const LaneBoundaryType Dashed = 2U;
const LaneBoundaryType BottsDots = 4U;
const LaneBoundaryType DoubleSolid = 5U;
const LaneBoundaryType DoubleDashed = 6U;
const LaneBoundaryType SolidDashed = 7U;
const LaneBoundaryType DashedSolid = 8U;

#endif

#ifndef DEFINED_TYPEDEF_FOR_LaneSensorBoundaries_
#define DEFINED_TYPEDEF_FOR_LaneSensorBoundaries_

struct LaneSensorBoundaries
{
  real32_T Curvature;
  real32_T CurvatureDerivative;
  real32_T HeadingAngle;
  real32_T LateralOffset;
  real32_T Strength;
  real32_T XExtent[2];
  LaneBoundaryType BoundaryType;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_LaneSensor_
#define DEFINED_TYPEDEF_FOR_LaneSensor_

struct LaneSensor
{
  LaneSensorBoundaries Left;
  LaneSensorBoundaries Right;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_AzXAydn5whPkCj5deW4WYB_
#define DEFINED_TYPEDEF_FOR_struct_AzXAydn5whPkCj5deW4WYB_

struct struct_AzXAydn5whPkCj5deW4WYB
{
  real_T NumColumns;
  real_T NumRows;
  real_T FieldOfView[2];
  real_T ImageSize[2];
  real_T PrincipalPoint[2];
  real_T FocalLength[2];
  real_T Position[3];
  real_T PositionSim3d[3];
  real_T Rotation[3];
  real_T DetectionRanges[2];
  real_T LaneDetectionRanges[2];
  real_T MeasurementNoise[9];
  real_T MinObjectImageSize[2];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_WTmPWsEMvOzNnnAVv5fQNC_
#define DEFINED_TYPEDEF_FOR_struct_WTmPWsEMvOzNnnAVv5fQNC_

struct struct_WTmPWsEMvOzNnnAVv5fQNC
{
  int32_T MaxIterations;
  real_T ConstraintTolerance;
  boolean_T UseWarmStart;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_WHjMt45Sk148iktWsfFxl_
#define DEFINED_TYPEDEF_FOR_struct_WHjMt45Sk148iktWsfFxl_

struct struct_WHjMt45Sk148iktWsfFxl
{
  int32_T MaxIterations;
  real_T ConstraintTolerance;
  real_T OptimalityTolerance;
  real_T ComplementarityTolerance;
  real_T StepTolerance;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_lnQ9KXdSZFplhcBp5LBCc_
#define DEFINED_TYPEDEF_FOR_struct_lnQ9KXdSZFplhcBp5LBCc_

struct struct_lnQ9KXdSZFplhcBp5LBCc
{
  int32_T MaxIterations;
  real_T ConstraintTolerance;
  real_T DiscreteConstraintTolerance;
  boolean_T RoundingAtRootNode;
  int32_T MaxPendingNodes;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_6wJYULTF6Ls8uk5VTDhG3G_
#define DEFINED_TYPEDEF_FOR_struct_6wJYULTF6Ls8uk5VTDhG3G_

struct struct_6wJYULTF6Ls8uk5VTDhG3G
{
  real_T ChargeRequest;
  real_T IBatt;
  real_T V_KL15;
  real_T V_KL30;
  real_T BMSStatus;
  real_T InverterStatus;
  real_T eMotorSpeed;
  real_T eMotorTorque;
  real_T Distance;
  real_T DistanceTotal;
  real_T Range;
  real_T CarSpeed;
  real_T SoC;
  real_T BrakePedal;
  real_T DriveMode;
  real_T DistanceToral_24Bit;
  real_T VehicleSpeedFromABS;
  real_T Wheel_Speed_FL;
  real_T Wheel_Speed_FR;
  real_T Wheel_Speed_RL;
  real_T Wheel_Speed_RR;
  real_T Handbremse;
  real_T Odometer;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_3QeBbRGmMBlls8ZmvcXLBG_
#define DEFINED_TYPEDEF_FOR_struct_3QeBbRGmMBlls8ZmvcXLBG_

struct struct_3QeBbRGmMBlls8ZmvcXLBG
{
  real_T is_valid;
  real_T radar_data__length_1788_;
  real_T Radar_Punkt;
  real_T Radar_Mode;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_CA5BEJ8kcqjuIApNTQMFuG_
#define DEFINED_TYPEDEF_FOR_struct_CA5BEJ8kcqjuIApNTQMFuG_

struct struct_CA5BEJ8kcqjuIApNTQMFuG
{
  real_T USS_Sensor_HLA;
  real_T USS_Sensor_HLM;
  real_T USS_Sensor_HRA;
  real_T USS_Sensor_HRM;
  real_T USS_Sensor_VLA;
  real_T USS_Sensor_VLM;
  real_T USS_Sensor_VRA;
  real_T USS_Sensor_VRM;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_rKekCg9AiyxZtQuGjKAj5D_
#define DEFINED_TYPEDEF_FOR_struct_rKekCg9AiyxZtQuGjKAj5D_

struct struct_rKekCg9AiyxZtQuGjKAj5D
{
  real_T Lenkwinkel;
  real_T AY;
  real_T Gierrate;
  real_T AX;
  real_T Gierbeschleunigung;
  struct_3QeBbRGmMBlls8ZmvcXLBG Radar;
  struct_CA5BEJ8kcqjuIApNTQMFuG USS;
  real_T RC_Fahrpedal;
  real_T RC_Lenkung;
  real_T Radar_2;
};

#endif

#ifndef struct_packLaneMarkerBus_D_20230119__T
#define struct_packLaneMarkerBus_D_20230119__T

struct packLaneMarkerBus_D_20230119__T
{
  int32_T isInitialized;
  struct_AzXAydn5whPkCj5deW4WYB Camera;
};

#endif                              /* struct_packLaneMarkerBus_D_20230119__T */

#ifndef struct_c_driving_internal_parabolicL_T
#define struct_c_driving_internal_parabolicL_T

struct c_driving_internal_parabolicL_T
{
  LaneBoundaryType BoundaryType;
  real_T Strength;
  real_T XExtent[2];
  real_T Parameters[3];
};

#endif                              /* struct_c_driving_internal_parabolicL_T */

/* Forward declaration for rtModel */
typedef struct tag_RTM_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T;

#endif
   /* RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types_h_ */

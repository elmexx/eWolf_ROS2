/*
 * D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
<<<<<<< .mine
 * Model version              : 4.38
||||||| .r78
 * Model version              : 4.24
=======
 * Model version              : 4.33
>>>>>>> .r84
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
<<<<<<< .mine
 * C++ source code generated on : Thu Oct  5 15:53:28 2023
||||||| .r78
 * C++ source code generated on : Thu May 11 16:00:17 2023
=======
 * C++ source code generated on : Fri Oct 13 13:42:54 2023
>>>>>>> .r84
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"
#include "rtwtypes.h"
#include "crl_mutex.hpp"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal.h"
#include "PathFollowingControlSystem.h"
#include "rte_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_parameters.h"
#include <cstring>
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_private.h"
#include <cmath>

extern "C"
{

#include "rt_nonfinite.h"

}

#include <stddef.h>
#include "zero_crossing_types.h"

/* Named constants for State Transition Table: '<S27>/State Transition Table' */
const uint8_T D_20230119_M_IN_NO_ACTIVE_CHILD = 0U;
const int32_T D_20230119_Modell_In_CALL_EVENT = -1;
const uint32_T D_20230119_Modell__IN_state_0_0 = 1U;
const uint32_T D_20230119_Modell__IN_state_0_1 = 2U;
const uint32_T D_20230119_Modell__IN_state_1_0 = 3U;
const uint32_T D_20230119_Modell__IN_state_1_1 = 4U;

/* Block signals (default storage) */
B_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B;

/* Continuous states */
X_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X;

/* Block states (default storage) */
DW_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX;

/* Real-time model */
RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M_ =
  RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T();
RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *const
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M =
  &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M_;

/* Forward declaration for local functions */
static void D_202_packLaneBoundaryDetection(const
  c_driving_internal_parabolicL_T boundary_Data_data[], real32_T
  *detection_Curvature, real32_T *detection_CurvatureDerivative, real32_T
  *detection_HeadingAngle, real32_T *detection_LateralOffset, real32_T
  *detection_Strength, real32_T detection_XExtent[2], LaneBoundaryType
  *detection_BoundaryType);
real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  real_T yL_0d0;
  uint32_T iLeft;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    uint32_T bpIdx;
    uint32_T iRght;

    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1U] - yL_0d0) * frac + yL_0d0;
}

uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T maxIndex)
{
  uint32_T bpIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Interpolation method: 'Use nearest'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp[0U]) {
    bpIndex = 0U;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d(u, bp, maxIndex >> 1U, maxIndex);
    if ((bpIndex < maxIndex) && (bp[bpIndex + 1U] - u <= u - bp[bpIndex])) {
      bpIndex++;
    }
  } else {
    bpIndex = maxIndex;
  }

  return bpIndex;
}

uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex)
{
  uint32_T bpIdx;
  uint32_T bpIndex;
  uint32_T iRght;

  /* Binary Search */
  bpIdx = startIndex;
  bpIndex = 0U;
  iRght = maxIndex;
  while (iRght - bpIndex > 1U) {
    if (u < bp[bpIdx]) {
      iRght = bpIdx;
    } else {
      bpIndex = bpIdx;
    }

    bpIdx = (iRght + bpIndex) >> 1U;
  }

  return bpIndex;
}

int32_T div_nde_s32_floor(int32_T numerator, int32_T denominator)
{
  return (((numerator < 0) != (denominator < 0)) && (numerator % denominator !=
           0) ? -1 : 0) + numerator / denominator;
}

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = static_cast<ODE1_IntgData *>(rtsiGetSolverData(si));
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

static void D_202_packLaneBoundaryDetection(const
  c_driving_internal_parabolicL_T boundary_Data_data[], real32_T
  *detection_Curvature, real32_T *detection_CurvatureDerivative, real32_T
  *detection_HeadingAngle, real32_T *detection_LateralOffset, real32_T
  *detection_Strength, real32_T detection_XExtent[2], LaneBoundaryType
  *detection_BoundaryType)
{
  c_driving_internal_parabolicL_T b_this_Data_data;
  real_T s_idx_0;
  real_T s_idx_1;
  real_T s_idx_2;
  int32_T n;

  /*  Parameters of parabolicLaneBoundary object = [A B C] */
  /*   corresponds to the three coefficients of a second-degree */
  /*   polynomial equation: */
  /*                 y = Ax^2 + Bx + C */
  /*  Comparing this equation with lane model using 2nd order */
  /*  polynomial approximation: */
  /*   y = (curvature/2)*(x^2) + (headingAngle)*x + lateralOffset */
  /*  */
  /*  This leads to the following relationship */
  /*    curvature           = 2 * A = 2 * Parameters(1)  (unit: 1/m) */
  /*    headingAngle        = B     = Parameters(2)      (unit: radians) */
  /*    lateralOffset       = C     = Parameters(3)      (unit: meters) */
  /*  */
  /*  Default lane of zero strength */
  *detection_Curvature = 0.0F;
  *detection_CurvatureDerivative = 0.0F;
  *detection_HeadingAngle = 0.0F;
  *detection_LateralOffset = 0.0F;
  *detection_Strength = 0.0F;
  detection_XExtent[0] = 0.0F;
  detection_XExtent[1] = 0.0F;
  *detection_BoundaryType = Unmarked;
  b_this_Data_data = boundary_Data_data[0];
  s_idx_0 = b_this_Data_data.Parameters[0];
  s_idx_1 = b_this_Data_data.Parameters[1];
  s_idx_2 = b_this_Data_data.Parameters[2];
  n = 0;
  if (s_idx_0 != 0.0) {
    n = 1;
  }

  if (s_idx_1 != 0.0) {
    n++;
  }

  if (s_idx_2 != 0.0) {
    n++;
  }

  if (n != 0) {
    b_this_Data_data = boundary_Data_data[0];
    s_idx_0 = b_this_Data_data.Parameters[0];
    *detection_Curvature = static_cast<real32_T>(2.0 * s_idx_0);
    b_this_Data_data = boundary_Data_data[0];
    s_idx_1 = b_this_Data_data.Parameters[1];
    *detection_HeadingAngle = static_cast<real32_T>(s_idx_1);

    /*  Coordinate transform */
    b_this_Data_data = boundary_Data_data[0];
    s_idx_2 = b_this_Data_data.Parameters[2];
    *detection_LateralOffset = static_cast<real32_T>(s_idx_2);

    /*  Coordinate transform */
    *detection_Strength = 1.0F;
    b_this_Data_data = boundary_Data_data[0];
    s_idx_0 = b_this_Data_data.XExtent[0];
    detection_XExtent[0] = static_cast<real32_T>(s_idx_0);
    s_idx_0 = b_this_Data_data.XExtent[1];
    detection_XExtent[1] = static_cast<real32_T>(s_idx_0);
    *detection_BoundaryType = Solid;
  }
}

/* Model step function for TID0 */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step0(void) /* Sample time: [0.0s, 0.0s] */
{
  real_T tmp;
  real_T u0;
  real_T u1;
  real_T u2;
  uint32_T bpIdx;
  boolean_T zcEvent;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* set solver stop time */
    if (!(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick0
          +1)) {
      rtsiSetSolverStopTime
        (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
         ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH0
           + 1) *
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0
          * 4294967296.0));
    } else {
      rtsiSetSolverStopTime
        (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
         ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick0
           + 1) *
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0
          + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH0
          * D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0
          * 4294967296.0));
    }

    /* Update the flag to indicate when data transfers from
     *  Sample time: [0.001s, 0.0s] to Sample time: [0.005s, 0.0s]  */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
      [7] =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
       == 0);
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2)
      ++;
    if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2)
        > 4) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        = 0;
    }

    /* Update the flag to indicate when data transfers from
     *  Sample time: [0.001s, 0.0s] to Sample time: [0.1s, 0.0s]  */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
      [8] =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
       == 0);
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3)
      ++;
    if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3)
        > 99) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        = 0;
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0] =
      rtsiGetT
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);
  }

  /* Bias: '<S16>/Bias' */
  tmp = *get_Ts();

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TriggeredSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_SubsysRanBC);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* S-Function (sg_IO191_setup_s): '<S5>/Setup ' */

    /* Level2 S-Function Block: '<S5>/Setup ' (sg_IO191_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];
      sfcnOutputs(rts,0);
    }

    /* S-Function (sg_IO191_ad_s): '<S5>/Analog input ' */

    /* Level2 S-Function Block: '<S5>/Analog input ' (sg_IO191_ad_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];
      sfcnOutputs(rts,0);
    }

    /* S-Function (sg_IO191_di_s): '<S5>/Digital input ' */

    /* Level2 S-Function Block: '<S5>/Digital input ' (sg_IO191_di_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];
      sfcnOutputs(rts,0);
    }

    /* Gain: '<S5>/Gain1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH9_Bremspedal_1
      = D_20230119_Modell_Inbetrieb_cal->Gain1_Gain_b *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1;

    /* Gain: '<S5>/Gain10' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2_FP_2_G =
      D_20230119_Modell_Inbetrieb_cal->Gain10_Gain_e *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2;

    /* Gain: '<S5>/Gain11' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3_LG_1_G =
      D_20230119_Modell_Inbetrieb_cal->Gain11_Gain_g *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3;

    /* Gain: '<S5>/Gain12' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4_LG_2_G =
      D_20230119_Modell_Inbetrieb_cal->Gain12_Gain_h *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4;

    /* Gain: '<S5>/Gain2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH10_Bremspedal_2
      = D_20230119_Modell_Inbetrieb_cal->Gain2_Gain_n *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2;

    /* Gain: '<S5>/Gain3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH11_BR_Licht
      = D_20230119_Modell_Inbetrieb_cal->Gain3_Gain_m *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o3;

    /* Gain: '<S5>/Gain4' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH12_Totmann_Taster_1
      = D_20230119_Modell_Inbetrieb_cal->Gain4_Gain_c *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o4;

    /* Gain: '<S5>/Gain5' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH13_Totmann_Taster_2
      = D_20230119_Modell_Inbetrieb_cal->Gain5_Gain_c *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o5;

    /* Gain: '<S5>/Gain6' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH14_Freigabe_Taster
      = D_20230119_Modell_Inbetrieb_cal->Gain6_Gain_i *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o6;

    /* Gain: '<S5>/Gain7' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH15 =
      D_20230119_Modell_Inbetrieb_cal->Gain7_Gain_a *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o7;

    /* Gain: '<S5>/Gain8' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH16 =
      D_20230119_Modell_Inbetrieb_cal->Gain8_Gain_i *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o8;

    /* Gain: '<S5>/Gain9' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1_FP_1_G =
      D_20230119_Modell_Inbetrieb_cal->Gain9_Gain_n *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1;

    /* RateTransition generated from: '<S3>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S3>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx];

    /* S-Function (slrealtimeUDPReceive): '<S2>/UDP Receive1' */
    {
      try {
        slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
          udp::Socket*>
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK
           [0]);
        char *buffer = (char *)
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK
          [1];
        memset(buffer,0,12);
        void *dataPort =
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o1
          [0];
        int_T numBytesAvail = (int_T)(udpSock->bytesToRead());
        if (numBytesAvail > 0) {
          uint8_t* fmAddArg = (uint8_t *)
            D_20230119_Modell_Inbetrieb_cal->UDPReceive1_fmAddress;
          size_t num_bytesRcvd = (size_t)(udpSock->receive(buffer,
            ( numBytesAvail<65507 )? numBytesAvail:65507, !1,fmAddArg));
          if (num_bytesRcvd == 0) {
            D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2
              = 0;
          } else {
            D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2
              = (double)num_bytesRcvd;
            memcpy(dataPort,(void*)buffer,12);
          }
        } else {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2 =
            0;
        }
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }

    /* SignalConversion generated from: '<S41>/Vector Concatenate' incorporates:
     *  Concatenate: '<S41>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate[0] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2;

    /* S-Function (sfix_udelay): '<S41>/Tapped Delay1' incorporates:
     *  Concatenate: '<S41>/Vector Concatenate'
     */
    std::memcpy
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate
       [1],
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[0],
       199U * sizeof(real_T));

    /* Sum: '<S41>/Sum of Elements' */
    u0 = -0.0;
    for (int32_T i = 0; i < 200; i++) {
      u0 +=
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate[i];
    }

    /* Sum: '<S41>/Sum of Elements' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements = u0;

    /* Product: '<S41>/Divide' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements /
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_g;

    /* RelationalOperator: '<S43>/Compare' incorporates:
     *  Constant: '<S43>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide ==
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant_const);

    /* S-Function (slrealtimebytepacking): '<S2>/Byte Unpacking' */

    /* Byte Unpacking: <S2>/Byte Unpacking */
    (void)memcpy((uint8_T*)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ByteUnpacking
                 [0], (uint8_T*)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o1
                 [0] + 0, 12);

    /* DataTypeConversion: '<S2>/Data Type Conversion1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ByteUnpacking[1];

    /* Switch: '<S2>/Switch1' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare) {
      /* Switch: '<S2>/Switch1' incorporates:
       *  Constant: '<S2>/Constant5'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1 =
        D_20230119_Modell_Inbetrieb_cal->Constant5_Value;
    } else {
      /* Saturate: '<S2>/Saturation1' */
      u0 =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1;
      u1 = D_20230119_Modell_Inbetrieb_cal->Saturation1_LowerSat;
      u2 = D_20230119_Modell_Inbetrieb_cal->Saturation1_UpperSat;
      if (u0 > u2) {
        /* Saturate: '<S2>/Saturation1' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p = u2;
      } else if (u0 < u1) {
        /* Saturate: '<S2>/Saturation1' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p = u1;
      } else {
        /* Saturate: '<S2>/Saturation1' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p = u0;
      }

      /* End of Saturate: '<S2>/Saturation1' */

      /* Sum: '<S2>/Add' incorporates:
       *  Constant: '<S2>/Constant1'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_n =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_p -
        D_20230119_Modell_Inbetrieb_cal->Constant1_Value;

      /* Product: '<S2>/Divide' incorporates:
       *  Constant: '<S2>/Constant2'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_cy =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_n /
        D_20230119_Modell_Inbetrieb_cal->Constant2_Value;

      /* Saturate: '<S2>/Saturation2' */
      u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_cy;
      u1 = D_20230119_Modell_Inbetrieb_cal->Saturation2_LowerSat;
      u2 = D_20230119_Modell_Inbetrieb_cal->Saturation2_UpperSat;
      if (u0 > u2) {
        /* Saturate: '<S2>/Saturation2' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j = u2;
      } else if (u0 < u1) {
        /* Saturate: '<S2>/Saturation2' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j = u1;
      } else {
        /* Saturate: '<S2>/Saturation2' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j = u0;
      }

      /* End of Saturate: '<S2>/Saturation2' */

      /* Switch: '<S2>/Switch1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1 =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_j;
    }

    /* End of Switch: '<S2>/Switch1' */

    /* InitialCondition: '<S2>/IC1' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_b)
    {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_b
        = false;

      /* InitialCondition: '<S2>/IC1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1 =
        D_20230119_Modell_Inbetrieb_cal->IC1_Value;
    } else {
      /* InitialCondition: '<S2>/IC1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1 =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1;
    }

    /* End of InitialCondition: '<S2>/IC1' */
  }

  /* TransferFcn: '<S11>/Transfer Fcn' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn =
    D_20230119_Modell_Inbetrieb_cal->TransferFcn_C *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn_CSTATE;

  /* InitialCondition: '<S11>/IC' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S11>/IC' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC =
      D_20230119_Modell_Inbetrieb_cal->IC_Value;
  } else {
    /* InitialCondition: '<S11>/IC' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn;
  }

  /* End of InitialCondition: '<S11>/IC' */

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/Android_ON'
   */
  if (D_20230119_Modell_Inbetrieb_cal->Android_ON_Value >
      D_20230119_Modell_Inbetrieb_cal->Switch_Threshold) {
    /* Switch: '<Root>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1;
  } else {
    /* Switch: '<Root>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC;
  }

  /* End of Switch: '<Root>/Switch' */

  /* Switch: '<S3>/Switch' incorporates:
   *  Constant: '<Root>/Autonom_ON'
   */
  if (D_20230119_Modell_Inbetrieb_cal->Autonom_ON_Value >
      D_20230119_Modell_Inbetrieb_cal->Switch_Threshold_m) {
    /* Switch: '<S3>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1;
  } else {
    /* Switch: '<S3>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal;
  }

  /* End of Switch: '<S3>/Switch' */

  /* Saturate: '<S3>/Saturation3' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch;
  u1 = D_20230119_Modell_Inbetrieb_cal->Saturation3_LowerSat_e;
  u2 = D_20230119_Modell_Inbetrieb_cal->Saturation3_UpperSat_m;
  if (u0 > u2) {
    /* Saturate: '<S3>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3 = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S3>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3 = u1;
  } else {
    /* Saturate: '<S3>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3 = u0;
  }

  /* End of Saturate: '<S3>/Saturation3' */

  /* Lookup_n-D: '<S3>/1-D Lookup Table' incorporates:
   *  Saturate: '<S3>/Saturation3'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable_bp01Data,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable_tableData, 1U);

  /* InitialCondition: '<S3>/IC2' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S3>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2 =
      D_20230119_Modell_Inbetrieb_cal->IC2_Value;
  } else {
    /* InitialCondition: '<S3>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable;
  }

  /* End of InitialCondition: '<S3>/IC2' */

  /* Bias: '<S3>/Bias1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_1_G =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2 +
    D_20230119_Modell_Inbetrieb_cal->Bias1_Bias;

  /* Lookup_n-D: '<S3>/1-D Lookup Table1' incorporates:
   *  Saturate: '<S3>/Saturation3'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1 =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable1_bp01Data,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable1_tableData, 1U);

  /* InitialCondition: '<S3>/IC3' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S3>/IC3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3 =
      D_20230119_Modell_Inbetrieb_cal->IC3_Value;
  } else {
    /* InitialCondition: '<S3>/IC3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1;
  }

  /* End of InitialCondition: '<S3>/IC3' */

  /* Bias: '<S3>/Bias2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_2_G =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3 +
    D_20230119_Modell_Inbetrieb_cal->Bias2_Bias;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* DataTypeConversion: '<S2>/Data Type Conversion' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ByteUnpacking[0];

    /* Switch: '<S2>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare) {
      /* Switch: '<S2>/Switch' incorporates:
       *  Constant: '<S2>/Constant'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_j =
        D_20230119_Modell_Inbetrieb_cal->Constant_Value;
    } else {
      /* Saturate: '<S2>/Saturation' */
      u0 =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion;
      u1 = D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat;
      u2 = D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat;
      if (u0 > u2) {
        /* Saturate: '<S2>/Saturation' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c = u2;
      } else if (u0 < u1) {
        /* Saturate: '<S2>/Saturation' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c = u1;
      } else {
        /* Saturate: '<S2>/Saturation' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c = u0;
      }

      /* End of Saturate: '<S2>/Saturation' */

      /* Sum: '<S2>/Add1' incorporates:
       *  Constant: '<S2>/Constant3'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_c =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_c +
        D_20230119_Modell_Inbetrieb_cal->Constant3_Value_j;

      /* Product: '<S2>/Divide1' incorporates:
       *  Constant: '<S2>/Constant4'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1_o =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_c /
        D_20230119_Modell_Inbetrieb_cal->Constant4_Value;

      /* Math: '<S42>/Power' incorporates:
       *  Constant: '<S42>/Constant7'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Power = rt_powd_snf
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1_o,
         D_20230119_Modell_Inbetrieb_cal->Constant7_Value);

      /* Gain: '<S42>/Multiply' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Multiply =
        D_20230119_Modell_Inbetrieb_cal->Multiply_Gain *
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Power;

      /* Sum: '<S42>/Add2' incorporates:
       *  Constant: '<S42>/Constant6'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_h =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Multiply +
        D_20230119_Modell_Inbetrieb_cal->Constant6_Value;

      /* Saturate: '<S2>/Saturation3' */
      u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_h;
      u1 = D_20230119_Modell_Inbetrieb_cal->Saturation3_LowerSat;
      u2 = D_20230119_Modell_Inbetrieb_cal->Saturation3_UpperSat;
      if (u0 > u2) {
        /* Saturate: '<S2>/Saturation3' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m = u2;
      } else if (u0 < u1) {
        /* Saturate: '<S2>/Saturation3' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m = u1;
      } else {
        /* Saturate: '<S2>/Saturation3' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m = u0;
      }

      /* End of Saturate: '<S2>/Saturation3' */

      /* Switch: '<S2>/Switch' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_j =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_m;
    }

    /* End of Switch: '<S2>/Switch' */

    /* InitialCondition: '<S2>/IC' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime_j)
    {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime_j
        = false;

      /* InitialCondition: '<S2>/IC' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC_p =
        D_20230119_Modell_Inbetrieb_cal->IC_Value_j;
    } else {
      /* InitialCondition: '<S2>/IC' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC_p =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_j;
    }

    /* End of InitialCondition: '<S2>/IC' */
  }

  /* TransferFcn: '<S11>/Transfer Fcn1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn1 =
    D_20230119_Modell_Inbetrieb_cal->TransferFcn1_C *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn1_CSTATE;

  /* InitialCondition: '<S11>/IC1' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S11>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_h =
      D_20230119_Modell_Inbetrieb_cal->IC1_Value_g;
  } else {
    /* InitialCondition: '<S11>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_h =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TransferFcn1;
  }

  /* End of InitialCondition: '<S11>/IC1' */

  /* Switch: '<Root>/Switch1' incorporates:
   *  Constant: '<Root>/Android_ON'
   */
  if (D_20230119_Modell_Inbetrieb_cal->Android_ON_Value >
      D_20230119_Modell_Inbetrieb_cal->Switch1_Threshold) {
    /* Switch: '<Root>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC_p;
  } else {
    /* Switch: '<Root>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_h;
  }

  /* End of Switch: '<Root>/Switch1' */

<<<<<<< .mine
  /* Lookup_n-D: '<S66>/1-D Lookup Table3' incorporates:
   *  Switch: '<S9>/Switch'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3 =
    look1_binlxpw(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable3_bp01Data,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable3_tableData, 1U);

  /* Lookup_n-D: '<S66>/1-D Lookup Vorsteuerung' incorporates:
   *  Lookup_n-D: '<S66>/1-D Lookup Table3'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupVorsteuerung =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3,
     D_20230119_Modell_Inbetrieb_cal->uDLookupVorsteuerung_bp01Data,
     D_20230119_Modell_Inbetrieb_cal->uDLookupVorsteuerung_tableData, 6U);

  /* RateTransition generated from: '<S66>/Add' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S66>/Add' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_RdBufIdx];
  }

  /* End of RateTransition generated from: '<S66>/Add' */

  /* Sum: '<S66>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3 -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel;

  /* Gain: '<S66>/Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain =
    D_20230119_Modell_Inbetrieb_cal->Gain_Gain_a *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add;

  /* Gain: '<S106>/Proportional Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ProportionalGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_P *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain;

  /* Integrator: '<S101>/Integrator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE;

  /* Gain: '<S95>/Derivative Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DerivativeGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_D *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain;

  /* Integrator: '<S96>/Filter' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Filter =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Filter_CSTATE;

  /* Sum: '<S96>/SumD' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumD =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DerivativeGain -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Filter;

  /* Gain: '<S104>/Filter Coefficient' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient =
    D_20230119_Modell_Inbetrieb_cal->PIDController_N *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumD;

  /* Sum: '<S110>/Sum' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ProportionalGain +
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator) +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient;

  /* Saturate: '<S108>/Saturation' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum;
  u1 = D_20230119_Modell_Inbetrieb_cal->PIDController_LowerSaturationLi;
  u2 = D_20230119_Modell_Inbetrieb_cal->PIDController_UpperSaturationLi;
  if (u0 > u2) {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u1;
  } else {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u0;
  }

  /* End of Saturate: '<S108>/Saturation' */

  /* Sum: '<S66>/Add2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupVorsteuerung +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation;

  /* Sum: '<S66>/Add1' incorporates:
   *  Constant: '<S66>/0-Stellung'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1 =
    D_20230119_Modell_Inbetrieb_cal->uStellung_Value +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2;

  /* Saturate: '<S66>/Saturation2' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1;
  u1 = D_20230119_Modell_Inbetrieb_cal->Saturation2_LowerSat_f;
  u2 = D_20230119_Modell_Inbetrieb_cal->Saturation2_UpperSat_h;
  if (u0 > u2) {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 = u1;
  } else {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 = u0;
  }

  /* End of Saturate: '<S66>/Saturation2' */

||||||| .r78
  /* Lookup_n-D: '<S66>/1-D Lookup Table3' incorporates:
   *  Switch: '<S9>/Switch'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3 =
    look1_binlxpw(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable3_bp01Data,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable3_tableData, 1U);

  /* Lookup_n-D: '<S66>/1-D Lookup Vorsteuerung' incorporates:
   *  Lookup_n-D: '<S66>/1-D Lookup Table3'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupVorsteuerung =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3,
     D_20230119_Modell_Inbetrieb_cal->uDLookupVorsteuerung_bp01Data,
     D_20230119_Modell_Inbetrieb_cal->uDLookupVorsteuerung_tableData, 6U);

  /* RateTransition generated from: '<S66>/Add' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S66>/Add' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Lenkwinkel_RdBufIdx];
  }

  /* End of RateTransition generated from: '<S66>/Add' */

  /* Sum: '<S66>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3 -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel;

  /* Gain: '<S66>/Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain =
    D_20230119_Modell_Inbetrieb_cal->Gain_Gain_a *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add;

  /* Gain: '<S106>/Proportional Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ProportionalGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_P *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain;

  /* Integrator: '<S101>/Integrator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE;

  /* Gain: '<S95>/Derivative Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DerivativeGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_D *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain;

  /* Integrator: '<S96>/Filter' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Filter =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Filter_CSTATE;

  /* Sum: '<S96>/SumD' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumD =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DerivativeGain -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Filter;

  /* Gain: '<S104>/Filter Coefficient' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient =
    D_20230119_Modell_Inbetrieb_cal->PIDController_N *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumD;

  /* Sum: '<S110>/Sum' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ProportionalGain +
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator) +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient;

  /* Saturate: '<S108>/Saturation' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->PIDController_LowerSaturationLi;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->PIDController_UpperSaturationLi;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S108>/Saturation' */

  /* Sum: '<S66>/Add2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupVorsteuerung +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation;

  /* Sum: '<S66>/Add1' incorporates:
   *  Constant: '<S66>/0-Stellung'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1 =
    D_20230119_Modell_Inbetrieb_cal->uStellung_Value +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2;

  /* Saturate: '<S66>/Saturation2' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation2_LowerSat_f;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation2_UpperSat_h;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S66>/Saturation2' */

=======
>>>>>>> .r84
  /* Lookup_n-D: '<S9>/1-D Lookup Table' incorporates:
   *  Switch: '<Root>/Switch1'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_m =
    look1_binlxpw(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_l,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable_tableData_c, 1U);

  /* InitialCondition: '<S9>/IC2' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S9>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_e =
      D_20230119_Modell_Inbetrieb_cal->IC2_Value_d;
  } else {
    /* InitialCondition: '<S9>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_m;
  }

  /* End of InitialCondition: '<S9>/IC2' */

  /* Bias: '<S9>/Bias' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_1_G =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_e +
    D_20230119_Modell_Inbetrieb_cal->Bias_Bias;

  /* Lookup_n-D: '<S9>/1-D Lookup Table1' incorporates:
   *  Switch: '<Root>/Switch1'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1_g =
    look1_binlxpw(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkung,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable1_bp01Data_p,
                  D_20230119_Modell_Inbetrieb_cal->uDLookupTable1_tableData_g,
                  1U);

  /* InitialCondition: '<S9>/IC3' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S9>/IC3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3_j =
      D_20230119_Modell_Inbetrieb_cal->IC3_Value_a;
  } else {
    /* InitialCondition: '<S9>/IC3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3_j =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable1_g;
  }

  /* End of InitialCondition: '<S9>/IC3' */

  /* Bias: '<S9>/Bias1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_2_G =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC3_j +
    D_20230119_Modell_Inbetrieb_cal->Bias1_Bias_l;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* S-Function (sg_IO191_da_s): '<S5>/Analog output ' */

    /* Level2 S-Function Block: '<S5>/Analog output ' (sg_IO191_da_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];
      sfcnOutputs(rts,0);
    }

    /* RelationalOperator: '<S60>/Compare' incorporates:
     *  Constant: '<S60>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_n =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH12_Totmann_Taster_1
       == D_20230119_Modell_Inbetrieb_cal->CompareToConstant_const_a);

    /* RelationalOperator: '<S61>/Compare' incorporates:
     *  Constant: '<S61>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_m =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH13_Totmann_Taster_2
       == D_20230119_Modell_Inbetrieb_cal->CompareToConstant1_const);

    /* Logic: '<S45>/AND' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_n &&
       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_m);
  }

  /* Integrator: '<S45>/Integrator' */
  if (rtsiIsModeUpdateTimeStep
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
    zcEvent = (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND &&
               (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE
                != POS_ZCSIG));
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND;

    /* evaluate zero-crossings */
    if (zcEvent) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE =
        D_20230119_Modell_Inbetrieb_cal->Integrator_IC;
    }
  }

  /* Integrator: '<S45>/Integrator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE;

  /* RelationalOperator: '<S63>/Compare' incorporates:
   *  Constant: '<S63>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_p =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator <=
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant3_const);

  /* Switch: '<S45>/Switch2' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_p) {
    /* Switch: '<S45>/Switch2' incorporates:
     *  Constant: '<S45>/Constant2'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2 =
      D_20230119_Modell_Inbetrieb_cal->Constant2_Value_e;
  } else {
    /* Switch: '<S45>/Switch2' incorporates:
     *  Constant: '<S45>/Constant1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2 =
      D_20230119_Modell_Inbetrieb_cal->Constant1_Value_ns;
  }

  /* End of Switch: '<S45>/Switch2' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* SignalConversion generated from: '<S56>/Vector Concatenate' incorporates:
     *  Concatenate: '<S56>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b[0]
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1_FP_1_G;

    /* S-Function (sfix_udelay): '<S56>/Tapped Delay' incorporates:
     *  Concatenate: '<S56>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b[1]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b[2]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b[3]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b[4]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3];

    /* Sum: '<S56>/Sum of Elements' */
    u0 = -0.0;
    for (int32_T i = 0; i < 5; i++) {
      u0 +=
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_b
        [i];
    }

    /* Sum: '<S56>/Sum of Elements' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_i = u0;

    /* Product: '<S56>/Divide' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_d =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_i /
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_gx;

    /* RelationalOperator: '<S54>/Compare' incorporates:
     *  Constant: '<S54>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_pz =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_d <=
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant_const_k);

    /* SignalConversion generated from: '<S57>/Vector Concatenate' incorporates:
     *  Concatenate: '<S57>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g[0]
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2_FP_2_G;

    /* S-Function (sfix_udelay): '<S57>/Tapped Delay' incorporates:
     *  Concatenate: '<S57>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g[1]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g[2]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g[3]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g[4]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3];

    /* Sum: '<S57>/Sum of Elements' */
    u0 = -0.0;
    for (int32_T i = 0; i < 5; i++) {
      u0 +=
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_g
        [i];
    }

    /* Sum: '<S57>/Sum of Elements' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_d = u0;

    /* Product: '<S57>/Divide' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_p =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_d /
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_gf;

    /* RelationalOperator: '<S55>/Compare' incorporates:
     *  Constant: '<S55>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_h =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_p <=
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant1_const_f);

    /* Logic: '<S48>/AND' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_m =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_pz &&
       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_h);

    /* Sum: '<S49>/Subtract2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract2 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3_LG_1_G
      - D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4_LG_2_G;

    /* Abs: '<S49>/Abs2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Abs2 = std::abs
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract2);

    /* RelationalOperator: '<S58>/Compare' incorporates:
     *  Constant: '<S58>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Abs2 >
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant4_const);

    /* DataTypeConversion: '<S49>/Data Type Conversion2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j;

    /* DiscreteIntegrator: '<S49>/Discrete-Time Integrator2' */
    if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
         <= 0.0) &&
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
         == 1)) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE
        = D_20230119_Modell_Inbetrieb_cal->DiscreteTimeIntegrator2_IC;
    }

    /* DiscreteIntegrator: '<S49>/Discrete-Time Integrator2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DiscreteTimeIntegrator2
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE;

    /* RelationalOperator: '<S49>/Relational Operator2' incorporates:
     *  Constant: '<S49>/Delta_Time1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator2 =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DiscreteTimeIntegrator2
       < D_20230119_Modell_Inbetrieb_cal->Delta_Time1_Value);

    /* S-Function (sg_IO291_di_isol_s): '<S6>/Isolated digital input ' */

    /* Level2 S-Function Block: '<S6>/Isolated digital input ' (sg_IO291_di_isol_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];
      sfcnOutputs(rts,0);
    }

    /* Gain: '<S6>/Gain' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH1_NotAus_1 =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain_c *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o1;

    /* Gain: '<S6>/Gain1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH2_NotAus_2 =
      D_20230119_Modell_Inbetrieb_cal->Gain1_Gain_j *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o2;

    /* UnitDelay: '<S44>/Unit Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_e;

    /* Logic: '<S44>/Logical Operator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator =
      ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH9_Bremspedal_1
        != 0.0) ==
       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_f);

    /* Logic: '<S44>/Logical Operator1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1 =
      ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH10_Bremspedal_2
        != 0.0) ==
       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_f);

    /* Memory: '<S44>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput;
  }

  /* Logic: '<S44>/AND2' incorporates:
   *  Constant: '<S44>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2 =
    ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2 != 0.0) &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_m &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator2 &&
     (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH1_NotAus_1
      != 0.0) &&
     (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH2_NotAus_2
      != 0.0) && (D_20230119_Modell_Inbetrieb_cal->Constant_Value_go != 0.0) &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1);

  /* Logic: '<S44>/AND3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3 =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2 &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory);

  /* DataTypeConversion: '<S44>/Data Type Conversion' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3;

  /* Gain: '<S4>/Gain6' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_1_On =
    D_20230119_Modell_Inbetrieb_cal->Gain6_Gain_f *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

  /* Gain: '<S4>/Gain7' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_2_On =
    D_20230119_Modell_Inbetrieb_cal->Gain7_Gain_b *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

  /* Gain: '<S4>/Gain8' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_1_On =
    D_20230119_Modell_Inbetrieb_cal->Gain8_Gain_f *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

  /* Gain: '<S4>/Gain9' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_2_On =
    D_20230119_Modell_Inbetrieb_cal->Gain9_Gain_m *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Constant: '<S4>/Constant8' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Br_Licht_On =
      D_20230119_Modell_Inbetrieb_cal->Constant8_Value;

    /* Constant: '<S5>/Constant' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_hc;

    /* S-Function (sg_IO191_do_s): '<S5>/Digital output ' */

    /* Level2 S-Function Block: '<S5>/Digital output ' (sg_IO191_do_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];
      sfcnOutputs(rts,0);
    }

    /* S-Function (sg_IO291_setup_s): '<S6>/Setup ' */

    /* Level2 S-Function Block: '<S6>/Setup ' (sg_IO291_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];
      sfcnOutputs(rts,0);
    }

    /* Constant: '<S6>/Alive' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Alive =
      D_20230119_Modell_Inbetrieb_cal->Alive_Value;

    /* Gain: '<S6>/Gain2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH3_Brmslcht =
      D_20230119_Modell_Inbetrieb_cal->Gain2_Gain_a *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o3;
  }

  /* Gain: '<S4>/Gain5' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe =
    D_20230119_Modell_Inbetrieb_cal->Gain5_Gain_cp *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_p;

  /* RateTransition generated from: '<S1>/Switch' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g
         == 0);
    }

    /* RateTransition generated from: '<S1>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_i
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_e
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g];
  }

  /* End of RateTransition generated from: '<S1>/Switch' */

  /* Switch: '<S1>/Switch' incorporates:
   *  Constant: '<Root>/Autonom_ON'
   */
  if (D_20230119_Modell_Inbetrieb_cal->Autonom_ON_Value >
      D_20230119_Modell_Inbetrieb_cal->Switch_Threshold_o) {
    /* Switch: '<S1>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_p =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_i;
  } else {
    /* Switch: '<S1>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_p =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Fahrpedal;
  }

  /* End of Switch: '<S1>/Switch' */

  /* Saturate: '<S1>/Saturation3' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_p;
  u1 = D_20230119_Modell_Inbetrieb_cal->Saturation3_LowerSat_j;
  u2 = D_20230119_Modell_Inbetrieb_cal->Saturation3_UpperSat_i;
  if (u0 > u2) {
    /* Saturate: '<S1>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S1>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j = u1;
  } else {
    /* Saturate: '<S1>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j = u0;
  }

  /* End of Saturate: '<S1>/Saturation3' */

  /* Gain: '<S1>/Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain =
    D_20230119_Modell_Inbetrieb_cal->Gain_Gain_h *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_j;

  /* RelationalOperator: '<S22>/Compare' incorporates:
   *  Constant: '<S22>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_d =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain >
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant6_const);

  /* Lookup_n-D: '<S15>/1-D Lookup Table' incorporates:
   *  Gain: '<S1>/Gain'
   */
  bpIdx = plook_u32d_binckan
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_n, 4U);

  /* Lookup_n-D: '<S15>/1-D Lookup Table' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_j =
    D_20230119_Modell_Inbetrieb_cal->uDLookupTable_tableData_e[bpIdx];
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* S-Function (sg_fpga_di_sf_a2): '<S7>/Digital input' */

    /* Level2 S-Function Block: '<S7>/Digital input' (sg_fpga_di_sf_a2) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];
      sfcnOutputs(rts,0);
    }

    /* Gain: '<S7>/Gain' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch8_Bremsaktuator_Hall
      = D_20230119_Modell_Inbetrieb_cal->Gain_Gain_g *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1_p;

    /* SignalConversion generated from: '<S13>/Vector Concatenate' incorporates:
     *  Concatenate: '<S13>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n[0]
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch8_Bremsaktuator_Hall;

    /* S-Function (sfix_udelay): '<S13>/Tapped Delay' incorporates:
     *  Concatenate: '<S13>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n[1]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n[2]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n[3]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n[4]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3];

    /* Sum: '<S13>/Sum of Elements' */
    u0 = -0.0;
    for (int32_T i = 0; i < 5; i++) {
      u0 +=
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_n
        [i];
    }

    /* Sum: '<S13>/Sum of Elements' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_f = u0;

    /* Product: '<S13>/Divide' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_f /
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width;

    /* Rounding: '<S13>/Round' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round = rt_roundd_snf
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_l);

    /* DataTypeConversion: '<S27>/Data Type Conversion' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round;

    /* Gain: '<S7>/Gain1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch9_Bremsaktuator_Hall
      = D_20230119_Modell_Inbetrieb_cal->Gain1_Gain_c *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2_b;

    /* SignalConversion generated from: '<S14>/Vector Concatenate' incorporates:
     *  Concatenate: '<S14>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a[0]
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch9_Bremsaktuator_Hall;

    /* S-Function (sfix_udelay): '<S14>/Tapped Delay' incorporates:
     *  Concatenate: '<S14>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a[1]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a[2]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a[3]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a[4]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3];

    /* Sum: '<S14>/Sum of Elements' */
    u0 = -0.0;
    for (int32_T i = 0; i < 5; i++) {
      u0 +=
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_a
        [i];
    }

    /* Sum: '<S14>/Sum of Elements' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_g = u0;

    /* Product: '<S14>/Divide' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_g /
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_d;

    /* Rounding: '<S14>/Round' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round_m =
      rt_roundd_snf
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_e);

    /* DataTypeConversion: '<S27>/Data Type Conversion1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Round_m;

    /* State Transition Table: '<S27>/State Transition Table' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.sfEvent =
      D_20230119_Modell_In_CALL_EVENT;
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_active_c4_D_20230119_Modell_
        == 0U) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_active_c4_D_20230119_Modell_
        = 1U;
      if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
           == 0.0) &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
           == 0.0)) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
          = D_20230119_Modell__IN_state_0_0;
      } else if
          ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
            == 1.0) &&
           (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
            == 0.0)) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
          = D_20230119_Modell__IN_state_1_0;
      } else if
          ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
            == 1.0) &&
           (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
            == 1.0)) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
          = D_20230119_Modell__IN_state_1_1;
      } else {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
          = D_20230119_Modell__IN_state_0_1;
      }
    } else {
      switch
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri)
      {
       case D_20230119_Modell__IN_state_0_0:
        if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
             == 1.0) &&
            (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
             == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_0;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 0.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_1;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 0.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_0;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_1;
        }
        break;

       case D_20230119_Modell__IN_state_0_1:
        if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
             == 0.0) &&
            (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
             == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_0;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_1;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 0.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_1;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_0;
        }
        break;

       case D_20230119_Modell__IN_state_1_0:
        if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
             == 1.0) &&
            (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
             == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_1;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 0.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_0;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_0;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 0.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_1;
        }
        break;

       default:
        /* case IN_state_1_1: */
        if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
             == 0.0) &&
            (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
             == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_1;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            1.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_0;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 1.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 1.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_1_1;
        } else if
            ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_e
              == 0.0) &&
             (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_m
              == 0.0)) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable =
            0.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 2.0;
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
            = D_20230119_Modell__IN_state_0_0;
        }
        break;
      }
    }

    /* End of State Transition Table: '<S27>/State Transition Table' */

    /* RelationalOperator: '<S34>/Compare' incorporates:
     *  Constant: '<S34>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_f =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir ==
       D_20230119_Modell_Inbetrieb_cal->Constant_Value_n);

    /* UnitDelay: '<S15>/Unit Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_c =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_c;

    /* RelationalOperator: '<S19>/Compare' incorporates:
     *  Constant: '<S19>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_ig = (
      static_cast<int32_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay_c) >
      static_cast<int32_T>
      (D_20230119_Modell_Inbetrieb_cal->CompareToConstant2_const_a));
  }

  /* RelationalOperator: '<S18>/Compare' incorporates:
   *  Constant: '<S18>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_i =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain >
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant1_const_o);

  /* Logic: '<S15>/OR' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_i ||
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_ig);

  /* Switch: '<S15>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR) {
    /* Switch: '<S15>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable;
  } else {
    /* Switch: '<S15>/Switch' incorporates:
     *  Constant: '<S15>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_f =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_eq;
  }

  /* End of Switch: '<S15>/Switch' */

  /* RelationalOperator: '<S33>/Compare' incorporates:
   *  Constant: '<S33>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fa =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_f >
     D_20230119_Modell_Inbetrieb_cal->Constant_Value_a);

  /* Logic: '<S25>/AND6' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND6 =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_f &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fa);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* RelationalOperator: '<S32>/Compare' incorporates:
     *  Constant: '<S32>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_o =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir ==
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant5_const);

    /* UnitDelay: '<S25>/Unit Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay1_DSTATE;

    /* UnitDelay: '<S25>/Unit Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE;

    /* Switch: '<S25>/Switch2' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay1) {
      /* Switch: '<S25>/Switch2' incorporates:
       *  Constant: '<S25>/Constant3'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_f =
        D_20230119_Modell_Inbetrieb_cal->Constant3_Value;
    } else {
      /* Switch: '<S25>/Switch2' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_f =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnitDelay;
    }

    /* End of Switch: '<S25>/Switch2' */
  }

  /* Switch: '<S25>/Switch1' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND6) {
    /* Switch: '<S25>/Switch1' incorporates:
     *  Constant: '<S25>/Constant2'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_c =
      D_20230119_Modell_Inbetrieb_cal->Constant2_Value_l;
  } else {
    /* Logic: '<S25>/AND5' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND5 =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_o &&
       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fa);

    /* Switch: '<S25>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND5) {
      /* Switch: '<S25>/Switch' incorporates:
       *  Constant: '<S25>/Constant'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oi =
        D_20230119_Modell_Inbetrieb_cal->Constant_Value_ai;
    } else {
      /* Switch: '<S25>/Switch' incorporates:
       *  Constant: '<S25>/Constant1'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oi =
        D_20230119_Modell_Inbetrieb_cal->Constant1_Value_f;
    }

    /* End of Switch: '<S25>/Switch' */

    /* Switch: '<S25>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_c =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_oi;
  }

  /* End of Switch: '<S25>/Switch1' */

  /* Sum: '<S25>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_c +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch2_f;

  /* Sum: '<S15>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_a =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_j;

  /* RelationalOperator: '<S23>/Compare' incorporates:
   *  Constant: '<S23>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fx =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_a <=
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant7_const);

  /* Logic: '<S15>/AND7' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7 =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_d &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_fx);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Delay: '<S16>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE;

    /* RelationalOperator: '<S28>/Compare' incorporates:
     *  Constant: '<S28>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hi =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1 ==
       D_20230119_Modell_Inbetrieb_cal->Constant_Value_k);
  }

  /* Switch: '<S16>/Switch1' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hi) {
    /* Switch: '<S16>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_h =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7;
  } else {
    /* Switch: '<S16>/Switch1' incorporates:
     *  Constant: '<S16>/Constant1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_h =
      D_20230119_Modell_Inbetrieb_cal->Constant1_Value_m;
  }

  /* End of Switch: '<S16>/Switch1' */

  /* InitialCondition: '<S15>/IC1' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S15>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d =
      D_20230119_Modell_Inbetrieb_cal->IC1_Value_m;
  } else {
    /* InitialCondition: '<S15>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_h;
  }

  /* End of InitialCondition: '<S15>/IC1' */

  /* Logic: '<S1>/AND3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_1 =
    ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe !=
      0.0) && (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC1_d !=
               0.0));

  /* DataTypeConversion: '<S6>/Data Type Conversion' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_g =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_1;

  /* RelationalOperator: '<S20>/Compare' incorporates:
   *  Constant: '<S20>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_c =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_a >
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant3_const_k);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* RelationalOperator: '<S24>/Compare' incorporates:
     *  Constant: '<S24>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_co =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO291_DI_CH3_Brmslcht
       > D_20230119_Modell_Inbetrieb_cal->Constant_Value_d);

    /* Delay: '<S17>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_n =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_o;

    /* RelationalOperator: '<S30>/Compare' incorporates:
     *  Constant: '<S30>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_dk =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_n ==
       D_20230119_Modell_Inbetrieb_cal->Constant_Value_h);
  }

  /* Logic: '<S15>/AND8' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND8 =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_c &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_co);

  /* RelationalOperator: '<S21>/Compare' incorporates:
   *  Constant: '<S21>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_cr =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain <
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant4_const_k);

  /* Logic: '<S15>/AND1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1 =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_cr &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_co);

  /* Logic: '<S15>/AND2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND8 ||
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1);

  /* Switch: '<S17>/Switch1' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_dk) {
    /* Switch: '<S17>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_j =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;
  } else {
    /* Switch: '<S17>/Switch1' incorporates:
     *  Constant: '<S17>/Constant1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_j =
      D_20230119_Modell_Inbetrieb_cal->Constant1_Value_pm;
  }

  /* End of Switch: '<S17>/Switch1' */

  /* InitialCondition: '<S15>/IC2' */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c4
       == (rtMinusInf)) ||
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c4
       == D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0])) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c4
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

    /* InitialCondition: '<S15>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_ep =
      D_20230119_Modell_Inbetrieb_cal->IC2_Value_n;
  } else {
    /* InitialCondition: '<S15>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_ep =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_j;
  }

  /* End of InitialCondition: '<S15>/IC2' */

  /* Logic: '<S1>/AND4' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_2 =
    ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe !=
      0.0) && (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IC2_ep !=
               0.0));

  /* DataTypeConversion: '<S6>/Data Type Conversion1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_c =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bremsaktuator_2;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Constant: '<S4>/Constant13' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Reverse =
      D_20230119_Modell_Inbetrieb_cal->Constant13_Value;

    /* DiscretePulseGenerator: '<S45>/Pulse Generator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PulseGenerator =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter <
       D_20230119_Modell_Inbetrieb_cal->PulseGenerator_Duty) &&
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter >=
       0) ? D_20230119_Modell_Inbetrieb_cal->PulseGenerator_Amp : 0.0;

    /* DiscretePulseGenerator: '<S45>/Pulse Generator' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter >=
        D_20230119_Modell_Inbetrieb_cal->PulseGenerator_Period - 1.0) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter =
        0;
    } else {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter++;
    }
  }

  /* Switch: '<S45>/Switch1' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_p) {
    /* RelationalOperator: '<S62>/Compare' incorporates:
     *  Constant: '<S62>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hy =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator <
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant2_const);

    /* Switch: '<S45>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_hy) {
      /* Switch: '<S45>/Switch' incorporates:
       *  Constant: '<S45>/Constant'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_jr =
        D_20230119_Modell_Inbetrieb_cal->Constant_Value_ph;
    } else {
      /* Switch: '<S45>/Switch' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_jr =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PulseGenerator;
    }

    /* End of Switch: '<S45>/Switch' */

    /* Switch: '<S45>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_jr;
  } else {
    /* Switch: '<S45>/Switch1' incorporates:
     *  Constant: '<S45>/Constant1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_m =
      D_20230119_Modell_Inbetrieb_cal->Constant1_Value_ns;
  }

  /* End of Switch: '<S45>/Switch1' */

  /* Gain: '<S4>/Gain4' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LED_Totmann =
    D_20230119_Modell_Inbetrieb_cal->Gain4_Gain_i *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_m;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* S-Function (sg_IO291_do_fet_s): '<S6>/FET digital output ' */

    /* Level2 S-Function Block: '<S6>/FET digital output ' (sg_IO291_do_fet_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [10];
      sfcnOutputs(rts,0);
    }

    /* S-Function (sg_IO291_di_ttl_s): '<S6>/LVTTL digital input ' */

    /* Level2 S-Function Block: '<S6>/LVTTL digital input ' (sg_IO291_di_ttl_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [11];
      sfcnOutputs(rts,0);
    }

    /* S-Function (sg_IO291_do_ttl_s): '<S6>/LVTTL digital output ' */

    /* Level2 S-Function Block: '<S6>/LVTTL digital output ' (sg_IO291_do_ttl_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [12];
      sfcnOutputs(rts,0);
    }

    /* S-Function (sg_IO602_IO691_setup_s): '<S8>/CAN Setup ' */

    /* Level2 S-Function Block: '<S8>/CAN Setup ' (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [13];
      sfcnOutputs(rts,0);
    }

    /* Bias: '<S16>/Bias' */
    u0 = -tmp;

    /* Bias: '<S16>/Bias' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1 + u0;

    /* UnitDelay: '<S29>/Delay Input1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE;

    /* Saturate: '<S16>/Saturation' */
    u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias;
    u1 = D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat_j;
    u2 = D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat_j;
    if (u0 > u2) {
      /* Saturate: '<S16>/Saturation' */
<<<<<<< .mine
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i = u2;
    } else if (u0 < u1) {
||||||| .r78
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i =
        leftEgoParameters_idx_1;
    } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
=======
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u2;
    } else if (u0 < u1) {
>>>>>>> .r84
      /* Saturate: '<S16>/Saturation' */
<<<<<<< .mine
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i = u1;
||||||| .r78
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i =
        leftEgoParameters_idx_0;
=======
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u1;
>>>>>>> .r84
    } else {
      /* Saturate: '<S16>/Saturation' */
<<<<<<< .mine
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i = u0;
||||||| .r78
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_i =
        rightEgoParameters_idx_2;
=======
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation = u0;
>>>>>>> .r84
    }

    /* End of Saturate: '<S16>/Saturation' */
  }

  /* RelationalOperator: '<S29>/FixPt Relational Operator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator =
    (static_cast<int32_T>
     (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7) > static_cast<
     int32_T>(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1));

  /* Switch: '<S16>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator)
  {
    /* Switch: '<S16>/Switch' incorporates:
     *  Constant: '<S16>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_kc;
  } else {
    /* Switch: '<S16>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation;
  }

  /* End of Switch: '<S16>/Switch' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Bias: '<S17>/Bias' */
    u0 = -tmp;

    /* Bias: '<S17>/Bias' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_n =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_n + u0;

    /* UnitDelay: '<S31>/Delay Input1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_b;

    /* Saturate: '<S17>/Saturation' */
    u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_n;
    u1 = D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat_n;
    u2 = D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat_k;
    if (u0 > u2) {
      /* Saturate: '<S17>/Saturation' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g = u2;
    } else if (u0 < u1) {
      /* Saturate: '<S17>/Saturation' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g = u1;
    } else {
      /* Saturate: '<S17>/Saturation' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g = u0;
    }

    /* End of Saturate: '<S17>/Saturation' */
  }

  /* RelationalOperator: '<S31>/FixPt Relational Operator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_p
    = (static_cast<int32_T>
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m) >
       static_cast<int32_T>
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_e));

  /* Switch: '<S17>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_p)
  {
    /* Switch: '<S17>/Switch' incorporates:
     *  Constant: '<S17>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_g =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_f;
  } else {
    /* Switch: '<S17>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_g =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_g;
  }

  /* End of Switch: '<S17>/Switch' */

  /* Clock: '<S36>/Clock' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Clock =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];

  /* DataTypeConversion: '<S35>/Data Type Conversion2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Memory: '<S35>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_p =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_o;

    /* MultiPortSwitch: '<S35>/Multiport Switch' incorporates:
     *  Constant: '<S35>/Constant1'
     */
    switch (static_cast<int32_T>
            (D_20230119_Modell_Inbetrieb_cal->EdgeDetector_model)) {
     case 1:
      /* MultiPortSwitch: '<S35>/Multiport Switch' incorporates:
       *  Constant: '<S35>/pos. edge'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[0] =
        D_20230119_Modell_Inbetrieb_cal->posedge_Value[0];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1] =
        D_20230119_Modell_Inbetrieb_cal->posedge_Value[1];
      break;

     case 2:
      /* MultiPortSwitch: '<S35>/Multiport Switch' incorporates:
       *  Constant: '<S35>/neg. edge'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[0] =
        D_20230119_Modell_Inbetrieb_cal->negedge_Value[0];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1] =
        D_20230119_Modell_Inbetrieb_cal->negedge_Value[1];
      break;

     default:
      /* MultiPortSwitch: '<S35>/Multiport Switch' incorporates:
       *  Constant: '<S35>/either edge'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[0] =
        D_20230119_Modell_Inbetrieb_cal->eitheredge_Value[0];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1] =
        D_20230119_Modell_Inbetrieb_cal->eitheredge_Value[1];
      break;
    }

    /* End of MultiPortSwitch: '<S35>/Multiport Switch' */

    /* Outputs for Enabled SubSystem: '<S35>/POSITIVE Edge' incorporates:
     *  EnablePort: '<S38>/Enable'
     */
    if (rtsiIsModeUpdateTimeStep
        (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch
          [0] > 0.0) {
        if (!D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE)
        {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE
            = true;
        }
      } else if
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE)
      {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE
          = false;
      }
    }

    /* End of Outputs for SubSystem: '<S35>/POSITIVE Edge' */
  }

  /* Outputs for Enabled SubSystem: '<S35>/POSITIVE Edge' incorporates:
   *  EnablePort: '<S38>/Enable'
   */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_MODE)
  {
    /* RelationalOperator: '<S38>/Relational Operator1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1 =
      (static_cast<int32_T>
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_p) <
       static_cast<int32_T>
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i));
    if (rtsiIsModeUpdateTimeStep
        (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      srUpdateBC
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.POSITIVEEdge_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S35>/POSITIVE Edge' */

  /* Outputs for Enabled SubSystem: '<S35>/NEGATIVE Edge' incorporates:
   *  EnablePort: '<S37>/Enable'
   */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M) &&
      rtsiIsModeUpdateTimeStep
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.MultiportSwitch[1]
        > 0.0) {
      if (!D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE)
      {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE
          = true;
      }
    } else if
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE)
    {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE =
        false;
    }
  }

  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_MODE)
  {
    /* RelationalOperator: '<S37>/Relational Operator1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_c =
      (static_cast<int32_T>
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_p) >
       static_cast<int32_T>
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i));
    if (rtsiIsModeUpdateTimeStep
        (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      srUpdateBC
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.NEGATIVEEdge_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S35>/NEGATIVE Edge' */

  /* Logic: '<S35>/Logical Operator1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1 ||
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_c);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Outputs for Triggered SubSystem: '<S36>/Triggered Subsystem' incorporates:
     *  TriggerPort: '<S39>/Trigger'
     */
    if (rtsiIsModeUpdateTimeStep
        (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo)) {
      zcEvent =
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h
         &&
         (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.TriggeredSubsystem_Trig_ZCE
          != POS_ZCSIG));
      if (zcEvent) {
        /* SignalConversion generated from: '<S39>/In1' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.In1 =
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Clock;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TriggeredSubsystem_SubsysRanBC
          = 4;
      }

      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.TriggeredSubsystem_Trig_ZCE
        =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h;
    }

    /* End of Outputs for SubSystem: '<S36>/Triggered Subsystem' */

    /* Sum: '<S36>/Sum' incorporates:
     *  Constant: '<S36>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.In1 +
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_l;
  }

  /* RelationalOperator: '<S36>/Relational Operator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum >
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Clock);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Delay: '<S46>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_p;

    /* RelationalOperator: '<S52>/Compare' incorporates:
     *  Constant: '<S52>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j5 =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_a ==
       D_20230119_Modell_Inbetrieb_cal->Constant_Value_g);

    /* UnitDelay: '<S53>/Delay Input1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_k =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_j;

    /* SignalConversion generated from: '<S50>/Vector Concatenate' incorporates:
     *  Concatenate: '<S50>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j[0]
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH14_Freigabe_Taster;

    /* S-Function (sfix_udelay): '<S50>/Tapped Delay1' incorporates:
     *  Concatenate: '<S50>/Vector Concatenate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j[1]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
      [0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j[2]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
      [1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j[3]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
      [2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j[4]
      = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
      [3];

    /* Sum: '<S50>/Sum of Elements' */
    u0 = -0.0;
    for (int32_T i = 0; i < 5; i++) {
      u0 +=
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VectorConcatenate_j
        [i];
    }

    /* Sum: '<S50>/Sum of Elements' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_fw = u0;

    /* Product: '<S50>/Divide' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_g =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumofElements_fw /
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_m;

    /* RelationalOperator: '<S59>/Compare' incorporates:
     *  Constant: '<S59>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_g ==
       D_20230119_Modell_Inbetrieb_cal->CompareToConstant_const_j);

    /* RelationalOperator: '<S53>/FixPt Relational Operator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_c
      = (static_cast<int32_T>
         (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on) >
         static_cast<int32_T>
         (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Uk1_k));

    /* Switch: '<S46>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FixPtRelationalOperator_c)
    {
      /* Switch: '<S46>/Switch' incorporates:
       *  Constant: '<S46>/Constant'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_k =
        D_20230119_Modell_Inbetrieb_cal->Constant_Value_e;
    } else {
      /* Bias: '<S46>/Bias' */
      u0 = -tmp;

      /* Bias: '<S46>/Bias' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_nf =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Delay1_a + u0;

      /* Saturate: '<S46>/Saturation' */
      u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Bias_nf;
      u1 = D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat_o;
      u2 = D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat_a;
      if (u0 > u2) {
        /* Saturate: '<S46>/Saturation' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz = u2;
      } else if (u0 < u1) {
        /* Saturate: '<S46>/Saturation' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz = u1;
      } else {
        /* Saturate: '<S46>/Saturation' */
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz = u0;
      }

      /* End of Saturate: '<S46>/Saturation' */

      /* Switch: '<S46>/Switch' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_k =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_gz;
    }

    /* End of Switch: '<S46>/Switch' */

    /* Switch: '<S46>/Switch1' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_j5) {
      /* Switch: '<S46>/Switch1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on;
    } else {
      /* Switch: '<S46>/Switch1' incorporates:
       *  Constant: '<S46>/Constant1'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc =
        D_20230119_Modell_Inbetrieb_cal->Constant1_Value_p;
    }

    /* End of Switch: '<S46>/Switch1' */
  }

  /* Logic: '<S44>/NOT' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.NOT =
    !D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2;

  /* Logic: '<S44>/OR' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR_j =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.NOT ||
     (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc != 0.0));

  /* Logic: '<S44>/AND' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_n =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.OR_j &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Memory: '<S44>/Memory1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory1_PreviousInput;

    /* Logic: '<S44>/AND1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1_a =
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory1 &&
       (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_cc != 0.0));

    /* Memory: '<S51>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_b =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_d;
  }

  /* CombinatorialLogic: '<S51>/Logic' */
  zcEvent = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND1_a;
  bpIdx = zcEvent;
  zcEvent = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND_n;
  bpIdx = (bpIdx << 1) + zcEvent;
  zcEvent = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_b;
  bpIdx = (bpIdx << 1) + zcEvent;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[0U] =
    D_20230119_Modell_Inbetrieb_cal->Logic_table[bpIdx];
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[1U] =
    D_20230119_Modell_Inbetrieb_cal->Logic_table[bpIdx + 8U];
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    int8_T wrBufIdx;

    /* Product: '<S7>/Divide' incorporates:
     *  Constant: '<S7>/Constant1'
     *  Constant: '<S7>/Gear Ratio'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_h =
      D_20230119_Modell_Inbetrieb_cal->Constant1_Value_ga /
      D_20230119_Modell_Inbetrieb_cal->GearRatio_Value;

    /* Product: '<S7>/Divide1' incorporates:
     *  Constant: '<S7>/Constant2'
     *  Constant: '<S7>/Gear Ratio'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1 =
      D_20230119_Modell_Inbetrieb_cal->Constant2_Value_k /
      D_20230119_Modell_Inbetrieb_cal->GearRatio_Value;

    /* Gain: '<S7>/Gain4' incorporates:
     *  Constant: '<S7>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_QAD_Position =
      D_20230119_Modell_Inbetrieb_cal->Gain4_Gain_cp *
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_o;

    /* Gain: '<S7>/Gain5' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_QAD_Turns =
      D_20230119_Modell_Inbetrieb_cal->Gain5_Gain_o *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_h;

    /* Gain: '<S7>/Gain6' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_QAD_rpm =
      D_20230119_Modell_Inbetrieb_cal->Gain6_Gain_e *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide1;

    /* RateTransition generated from: '<S9>/Switch' incorporates:
     *  Constant: '<Root>/Autonom_ON'
     */
    rtw_slrealtime_mutex_lock
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_d0_SEMAPHORE);
    wrBufIdx = static_cast<int8_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_LstBufWR
       + 1);
    if (wrBufIdx == 3) {
      wrBufIdx = 0;
    }

    if (wrBufIdx ==
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_RDBuf)
    {
      wrBufIdx = static_cast<int8_T>(wrBufIdx + 1);
      if (wrBufIdx == 3) {
        wrBufIdx = 0;
      }
    }

    rtw_slrealtime_mutex_unlock
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_d0_SEMAPHORE);
    switch (wrBufIdx) {
     case 0:
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf0 =
        D_20230119_Modell_Inbetrieb_cal->Autonom_ON_Value;
      break;

     case 1:
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf1 =
        D_20230119_Modell_Inbetrieb_cal->Autonom_ON_Value;
      break;

     case 2:
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf2 =
        D_20230119_Modell_Inbetrieb_cal->Autonom_ON_Value;
      break;
    }

    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_LstBufWR =
      wrBufIdx;

    /* End of RateTransition generated from: '<S9>/Switch' */

    /* RateTransition: '<S66>/RT' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx =
        static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx == 0);
    }

    /* RateTransition: '<S66>/RT' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_i =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx];

    /* RateTransition: '<S66>/RT1' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_RdBufIdx =
        static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_RdBufIdx ==
         0);
    }

    /* RateTransition: '<S66>/RT1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_RdBufIdx];

    /* RateTransition generated from: '<S66>/Add2' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S66>/Add2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtAdd2Inport1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_RdBufIdx];

    /* RateTransition generated from: '<S110>/Sum' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S110>/Sum' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSumInport1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_RdBufIdx];
  }

  /* Integrator: '<S101>/Integrator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator_k =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE_i;

  /* RateTransition generated from: '<S96>/SumD' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S96>/SumD' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSumDInport1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_RdBufIdx];
  }

  /* End of RateTransition generated from: '<S96>/SumD' */

  /* Integrator: '<S96>/Filter' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Filter =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Filter_CSTATE;

  /* Sum: '<S96>/SumD' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumD =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSumDInport1 -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Filter;

  /* Gain: '<S104>/Filter Coefficient' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient =
    D_20230119_Modell_Inbetrieb_cal->PIDController_N *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SumD;

  /* Sum: '<S110>/Sum' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSumInport1 +
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Integrator_k) +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient;

  /* Saturate: '<S108>/Saturation' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e;
  u1 = D_20230119_Modell_Inbetrieb_cal->PIDController_LowerSaturationLi;
  u2 = D_20230119_Modell_Inbetrieb_cal->PIDController_UpperSaturationLi;
  if (u0 > u2) {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_j = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_j = u1;
  } else {
    /* Saturate: '<S108>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_j = u0;
  }

  /* End of Saturate: '<S108>/Saturation' */

  /* Sum: '<S66>/Add2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtAdd2Inport1 +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_j;
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
  }

  /* Sum: '<S66>/Add1' incorporates:
   *  Constant: '<S66>/0-Stellung'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1 =
    D_20230119_Modell_Inbetrieb_cal->uStellung_Value +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2;

  /* Gain: '<S92>/ZeroGain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ZeroGain =
    D_20230119_Modell_Inbetrieb_cal->ZeroGain_Gain *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e;

  /* DeadZone: '<S94>/DeadZone' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e >
      D_20230119_Modell_Inbetrieb_cal->PIDController_UpperSaturationLi) {
    /* DeadZone: '<S94>/DeadZone' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DeadZone =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e -
      D_20230119_Modell_Inbetrieb_cal->PIDController_UpperSaturationLi;
  } else if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e >=
             D_20230119_Modell_Inbetrieb_cal->PIDController_LowerSaturationLi) {
    /* DeadZone: '<S94>/DeadZone' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DeadZone = 0.0;
  } else {
    /* DeadZone: '<S94>/DeadZone' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DeadZone =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_e -
      D_20230119_Modell_Inbetrieb_cal->PIDController_LowerSaturationLi;
  }

  /* End of DeadZone: '<S94>/DeadZone' */

  /* RelationalOperator: '<S92>/NotEqual' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.NotEqual =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ZeroGain !=
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DeadZone);

  /* Signum: '<S92>/SignPreSat' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DeadZone;
  if (rtIsNaN(u0)) {
    /* Signum: '<S92>/SignPreSat' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreSat = (rtNaN);
  } else if (u0 < 0.0) {
    /* Signum: '<S92>/SignPreSat' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreSat = -1.0;
  } else {
    /* Signum: '<S92>/SignPreSat' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreSat = (u0 > 0.0);
  }

  /* End of Signum: '<S92>/SignPreSat' */

  /* DataTypeConversion: '<S92>/DataTypeConv1' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreSat;
  if (rtIsNaN(u0)) {
    u0 = 0.0;
  } else {
    u0 = std::fmod(u0, 256.0);
  }

  /* DataTypeConversion: '<S92>/DataTypeConv1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConv1 =
    static_cast<int8_T>(u0 < 0.0 ? static_cast<int32_T>(static_cast<int8_T>(-
    static_cast<int8_T>(static_cast<uint8_T>(-u0)))) : static_cast<int32_T>(
    static_cast<int8_T>(static_cast<uint8_T>(u0))));

  /* RateTransition generated from: '<S92>/Equal1' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_RdBufIdx
         == 0);
    }

<<<<<<< .mine
  /* Signum: '<S92>/SignPreIntegrator' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IntegralGain;
  if (rtIsNaN(u0)) {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      (rtNaN);
  } else if (u0 < 0.0) {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      -1.0;
  } else {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      (u0 > 0.0);
||||||| .r78
  /* Signum: '<S92>/SignPreIntegrator' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IntegralGain;
  if (rtIsNaN(rightEgoParameters_idx_2)) {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      (rtNaN);
  } else if (rightEgoParameters_idx_2 < 0.0) {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      -1.0;
  } else {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      (rightEgoParameters_idx_2 > 0.0);
=======
    /* RateTransition generated from: '<S92>/Equal1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtEqual1Inport2 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_RdBufIdx];
>>>>>>> .r84
  }

  /* End of RateTransition generated from: '<S92>/Equal1' */

<<<<<<< .mine
  /* DataTypeConversion: '<S92>/DataTypeConv2' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator;
  if (rtIsNaN(u0)) {
    u0 = 0.0;
  } else {
    u0 = std::fmod(u0, 256.0);
  }

  /* DataTypeConversion: '<S92>/DataTypeConv2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConv2 =
    static_cast<int8_T>(u0 < 0.0 ? static_cast<int32_T>(static_cast<int8_T>(-
    static_cast<int8_T>(static_cast<uint8_T>(-u0)))) : static_cast<int32_T>(
    static_cast<int8_T>(static_cast<uint8_T>(u0))));

||||||| .r78
  /* DataTypeConversion: '<S92>/DataTypeConv2' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator;
  if (rtIsNaN(rightEgoParameters_idx_2)) {
    rightEgoParameters_idx_2 = 0.0;
  } else {
    rightEgoParameters_idx_2 = std::fmod(rightEgoParameters_idx_2, 256.0);
  }

  /* DataTypeConversion: '<S92>/DataTypeConv2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConv2 =
    static_cast<int8_T>(rightEgoParameters_idx_2 < 0.0 ? static_cast<int32_T>(
    static_cast<int8_T>(-static_cast<int8_T>(static_cast<uint8_T>
    (-rightEgoParameters_idx_2)))) : static_cast<int32_T>(static_cast<int8_T>(
    static_cast<uint8_T>(rightEgoParameters_idx_2))));

=======
>>>>>>> .r84
  /* RelationalOperator: '<S92>/Equal1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Equal1 =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConv1 ==
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtEqual1Inport2);

  /* Logic: '<S92>/AND3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3_d =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.NotEqual &&
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Equal1);
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    /* Memory: '<S92>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_o =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_b;

    /* RateTransition generated from: '<S92>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_RdBufIdx
         == 0);
    }

    /* RateTransition generated from: '<S92>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport3 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_RdBufIdx];

    /* Switch: '<S92>/Switch' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Memory_o) {
      /* Switch: '<S92>/Switch' incorporates:
       *  Constant: '<S92>/Constant1'
       */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gi =
        D_20230119_Modell_Inbetrieb_cal->Constant1_Value_g;
    } else {
      /* Switch: '<S92>/Switch' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gi =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport3;
    }

    /* End of Switch: '<S92>/Switch' */
  }

  /* Saturate: '<S66>/Saturation2' */
  u0 = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1;
  u1 = D_20230119_Modell_Inbetrieb_cal->Saturation2_LowerSat_f;
  u2 = D_20230119_Modell_Inbetrieb_cal->Saturation2_UpperSat_h;
  if (u0 > u2) {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 = u2;
  } else if (u0 < u1) {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 = u1;
  } else {
    /* Saturate: '<S66>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2 = u0;
  }

  /* End of Saturate: '<S66>/Saturation2' */

  /* RateTransition: '<S10>/Rate Transition2' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_RdBufIdx
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_RdBufIdx
         == 0);
    }

    /* RateTransition: '<S10>/Rate Transition2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_Buf[
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_RdBufIdx];

    /* RateTransition generated from: '<S11>/Transfer Fcn1' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB
         == 0);
    }

    /* RateTransition generated from: '<S11>/Transfer Fcn1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB];

    /* RateTransition generated from: '<S11>/Transfer Fcn' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_2
        == 1) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu
        = static_cast<int8_T>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu
         == 0);
    }

    /* RateTransition generated from: '<S11>/Transfer Fcn' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1
      =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_Buf
      [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu];
  }

  /* End of RateTransition: '<S10>/Rate Transition2' */
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
    {
      /* Update for S-Function (sfix_udelay): '<S41>/Tapped Delay1' */
      for (int_T i = 0; i < 198; i++) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[i]
          =
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[i
          + 1];
      }

      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[198]
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UDPReceive1_o2;

      /* End of Update for S-Function (sfix_udelay): '<S41>/Tapped Delay1' */

      /* Update for S-Function (sfix_udelay): '<S56>/Tapped Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[0] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1_FP_1_G;

      /* Update for S-Function (sfix_udelay): '<S57>/Tapped Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[0] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2_FP_2_G;

      /* Update for DiscreteIntegrator: '<S49>/Discrete-Time Integrator2' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE
        += D_20230119_Modell_Inbetrieb_cal->DiscreteTimeIntegrator2_gainval *
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2;
      if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
          > 0.0) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = 1;
      } else if
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
           < 0.0) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = -1;
      } else if
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2
           == 0.0) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = 0;
      } else {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
          = 2;
      }

      /* End of Update for DiscreteIntegrator: '<S49>/Discrete-Time Integrator2' */

      /* Update for UnitDelay: '<S44>/Unit Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_e =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3;

      /* Update for Memory: '<S44>/Memory' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[0];

      /* Update for S-Function (sfix_udelay): '<S13>/Tapped Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[0] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch8_Bremsaktuator_Hall;

      /* Update for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[0] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3] =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO397_DI_Ch9_Bremsaktuator_Hall;

      /* Update for UnitDelay: '<S15>/Unit Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_c =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;

      /* Update for UnitDelay: '<S25>/Unit Delay1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay1_DSTATE =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LogicalOperator1_h;

      /* Update for UnitDelay: '<S25>/Unit Delay' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add;

      /* Update for Delay: '<S16>/Delay1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_o;

      /* Update for Delay: '<S17>/Delay1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_o =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_g;

      /* Update for UnitDelay: '<S29>/Delay Input1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND7;

      /* Update for UnitDelay: '<S31>/Delay Input1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_b
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND2_m;

      /* Update for Memory: '<S35>/Memory' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_o
        =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_i;

      /* Update for Delay: '<S46>/Delay1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_p =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_k;

      /* Update for UnitDelay: '<S53>/Delay Input1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_j
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_on;

      /* Update for S-Function (sfix_udelay): '<S50>/Tapped Delay1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[0]
        =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [1];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[1]
        =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [2];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[2]
        =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c
        [3];
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[3]
        =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_DI_CH14_Freigabe_Taster;

      /* Update for Memory: '<S44>/Memory1' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory1_PreviousInput
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[1];

      /* Update for Memory: '<S51>/Memory' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_d
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Logic[0];

      /* Update for Memory: '<S92>/Memory' */
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_b
        = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AND3_d;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    rt_ertODEUpdateContinuousStates
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);

    /* Update absolute time */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick0))
    {
      ++D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH0;
    }

    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0] =
      rtsiGetSolverStopTime
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);

    /* Update absolute time */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick1))
    {
      ++D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH1;
    }

    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[1] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick1 *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize1 +
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH1 *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize1 *
      4294967296.0;
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_derivatives(void)
{
  XDot_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *_rtXdot;
  _rtXdot = ((XDot_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *)
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->derivs);

  /* Derivatives for TransferFcn: '<S11>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE = D_20230119_Modell_Inbetrieb_cal->TransferFcn_A *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE +=
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1;

  /* Derivatives for TransferFcn: '<S11>/Transfer Fcn1' */
  _rtXdot->TransferFcn1_CSTATE = D_20230119_Modell_Inbetrieb_cal->TransferFcn1_A
    * D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn1_CSTATE;
  _rtXdot->TransferFcn1_CSTATE +=
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1;

  /* Derivatives for Integrator: '<S45>/Integrator' incorporates:
   *  Constant: '<S45>/Constant'
   */
  _rtXdot->Integrator_CSTATE =
    D_20230119_Modell_Inbetrieb_cal->Constant_Value_ph;

  /* Derivatives for Integrator: '<S101>/Integrator' */
  _rtXdot->Integrator_CSTATE_i =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gi;

  /* Derivatives for Integrator: '<S96>/Filter' */
  _rtXdot->Filter_CSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FilterCoefficient;
}

/* Model step function for TID2 */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step2(void) /* Sample time: [0.005s, 0.0s] */
{
<<<<<<< .mine
  real_T u0;
||||||| .r78
  int_T tid = 2;
  real_T u0;
=======
  real_T u;
>>>>>>> .r84
  real_T u1;
  real_T u2;
  int32_T s64_iter;

  /* Update the flag to indicate when data transfers from
   *  Sample time: [0.005s, 0.0s] to Sample time: [0.1s, 0.0s]  */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
    [13] =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
     == 0);
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3)
    ++;
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3)
      > 19) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      = 0;
  }

  /* Update the flag to indicate when data transfers from
   *  Sample time: [0.005s, 0.0s] to Sample time: [60.0s, 0.0s]  */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
    [14] =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
     == 0);
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4)
    ++;
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4)
      > 11999) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
      = 0;
  }

  /* Constant: '<S8>/RX Sample Time' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RXSampleTime =
    D_20230119_Modell_Inbetrieb_cal->RXSampleTime_Value;

  /* Outputs for Iterator SubSystem: '<S8>/CAN Read Loop - Port 1' incorporates:
   *  WhileIterator: '<S64>/While Iterator'
   */
  s64_iter = 1;
  do {
    /* Level2 S-Function Block: '<S64>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];
      sfcnOutputs(rts,2);
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1041 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 56
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o2
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 40
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o4
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack1' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1045 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 56
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1_k
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 40
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o2_m
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o3_h
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.01
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.01;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4_f
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack2' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1056 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1_f
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 56
             *  length                  = 32
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint32_T unpackedValue = 0;

                {
                  uint32_T tempValue = (uint32_T) (0);

                  {
                    tempValue = tempValue | (uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]) << 16);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 24);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o2_a
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3_m
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack3' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1057 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 16
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.1
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.1;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.5
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.5;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o2
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack4' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1059 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 8
             *  length                  = 1
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]) & (uint8_T)(0x1U));
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1_n
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2_n
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack5' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1024 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 56
             *  length                  = 24
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint32_T unpackedValue = 0;

                {
                  uint32_T tempValue = (uint32_T) (0);

                  {
                    tempValue = tempValue | (uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [7]);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [6]) << 8);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]) << 16);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack6' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((644 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 48
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = SIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = SIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 40
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [5]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [4]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o4
                  = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o5
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack7' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((645 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 24
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 8
             *  length                  = 16
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.005;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o2
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S64>/CAN Unpack8' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID
           != INVALID_CAN_ID) ) {
        if ((1477 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 2
             *  length                  = 1
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [0]) & (uint8_T)(0x4U)) >> 2);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 24
             *  length                  = 24
             *  desiredSignalByteLayout = BIGENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = -1937.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint32_T unpackedValue = 0;

                {
                  uint32_T tempValue = (uint32_T) (0);

                  {
                    tempValue = tempValue | (uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [3]);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [2]) << 8);
                    tempValue = tempValue | (uint32_T)((uint32_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e.Data
                       [1]) << 16);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result + -1937.0;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o2
                  = result;
              }
            }
          }
        }
      }
    }

    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ChargeRequest =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IBatt =
      D_20230119_Modell_Inbetrieb_cal->Gain1_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Range =
      D_20230119_Modell_Inbetrieb_cal->Gain10_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3_m;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed =
      D_20230119_Modell_Inbetrieb_cal->Gain11_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b =
      D_20230119_Modell_Inbetrieb_cal->Gain12_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack3_o2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BrakePedal =
      D_20230119_Modell_Inbetrieb_cal->Gain13_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1_n;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DriveMode =
      D_20230119_Modell_Inbetrieb_cal->Gain14_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2_n;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceToral_24Bit =
      D_20230119_Modell_Inbetrieb_cal->Gain15_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VehicleSpeedFromABS =
      D_20230119_Modell_Inbetrieb_cal->Gain16_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o3;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FL =
      D_20230119_Modell_Inbetrieb_cal->Gain17_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o4;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FR =
      D_20230119_Modell_Inbetrieb_cal->Gain18_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack6_o5;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RL =
      D_20230119_Modell_Inbetrieb_cal->Gain19_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL15 =
      D_20230119_Modell_Inbetrieb_cal->Gain2_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o3;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RR =
      D_20230119_Modell_Inbetrieb_cal->Gain20_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack7_o2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Handbremse =
      D_20230119_Modell_Inbetrieb_cal->Gain21_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e =
      D_20230119_Modell_Inbetrieb_cal->Gain22_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack8_o2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL30 =
      D_20230119_Modell_Inbetrieb_cal->Gain3_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack_o4;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BMSStatus =
      D_20230119_Modell_Inbetrieb_cal->Gain4_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1_k;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.InverterStatus =
      D_20230119_Modell_Inbetrieb_cal->Gain5_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o2_m;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorSpeed =
      D_20230119_Modell_Inbetrieb_cal->Gain6_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o3_h;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorTorque =
      D_20230119_Modell_Inbetrieb_cal->Gain7_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4_f;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Distance =
      D_20230119_Modell_Inbetrieb_cal->Gain8_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1_f;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceTotal =
      D_20230119_Modell_Inbetrieb_cal->Gain9_Gain *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o2_a;
    s64_iter++;
  } while (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1_f &&
           (s64_iter <= 501));

  /* End of Outputs for SubSystem: '<S8>/CAN Read Loop - Port 1' */

  /* Outputs for Iterator SubSystem: '<S8>/CAN Read Loop - Port 3' incorporates:
   *  WhileIterator: '<S65>/While Iterator'
   */
  s64_iter = 1;

  /* SignalConversion generated from: '<S65>/Bus Creator2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.isvalid = 0.0;

  /* SignalConversion generated from: '<S65>/Bus Creator2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.radardatalength1788 =
    0.0;

  /* SignalConversion generated from: '<S65>/Bus Creator2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Punkt = 0.0;

  /* SignalConversion generated from: '<S65>/Bus Creator2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Mode = 0.0;

  /* SignalConversion generated from: '<S65>/Bus Creator' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_2 = 0.0;
  do {
    /* Level2 S-Function Block: '<S65>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];
      sfcnOutputs(rts,2);
    }

    {
      /* S-Function (scanunpack): '<S65>/CAN Unpack' */
      if ((5 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((2 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 0
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = SIGNED
             *  factor                  = 0.09882
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                int16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);
                  int16_T* tempValuePtr = (int16_T*)&tempValue;

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]) << 8);
                  }

                  unpackedValue = *tempValuePtr;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = result * 0.09882;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack =
                  result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S65>/CAN Unpack1' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((304 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 32
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.0001274
             *  offset                  = -4.1768
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [4]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [5]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.0001274) + -4.1768;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 48
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 16
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 0
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.005
             *  offset                  = -163.84
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.005) + -163.84;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4
                  = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 52
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 7 ------------------
             *  startBit                = 20
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S65>/CAN Unpack2' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((305 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 32
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.0001274
             *  offset                  = -4.1768
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [4]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [5]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.0001274) + -4.1768;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 52
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 0
             *  length                  = 16
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 0.125
             *  offset                  = -4096.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint16_T unpackedValue = 0;

                {
                  uint16_T tempValue = (uint16_T) (0);

                  {
                    tempValue = tempValue | (uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                    tempValue = tempValue | (uint16_T)((uint16_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]) << 8);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                result = (result * 0.125) + -4096.0;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 20
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 48
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 16
             *  length                  = 4
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */

            /* --------------- START Unpacking signal 7 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            /*
             * Signal is not connected or connected to terminator.
             * No unpacking code generated.
             */
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S65>/CAN Unpack4' */
      if ((8 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((16 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 32
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [4]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 40
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [5]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2
                  = result;
              }
            }

            /* --------------- START Unpacking signal 2 ------------------
             *  startBit                = 56
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [7]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o3
                  = result;
              }
            }

            /* --------------- START Unpacking signal 3 ------------------
             *  startBit                = 48
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [6]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o4
                  = result;
              }
            }

            /* --------------- START Unpacking signal 4 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o5
                  = result;
              }
            }

            /* --------------- START Unpacking signal 5 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o6
                  = result;
              }
            }

            /* --------------- START Unpacking signal 6 ------------------
             *  startBit                = 24
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [3]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o7
                  = result;
              }
            }

            /* --------------- START Unpacking signal 7 ------------------
             *  startBit                = 16
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [2]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o8
                  = result;
              }
            }
          }
        }
      }
    }

    {
      /* S-Function (scanunpack): '<S65>/CAN Unpack5' */
      if ((2 ==
           D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Length)
          &&
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID
           != INVALID_CAN_ID) ) {
        if ((17 ==
             D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.ID)
            && (0U ==
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Extended)
            ) {
          {
            /* --------------- START Unpacking signal 0 ------------------
             *  startBit                = 8
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [1]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o1
                  = result;
              }
            }

            /* --------------- START Unpacking signal 1 ------------------
             *  startBit                = 0
             *  length                  = 8
             *  desiredSignalByteLayout = LITTLEENDIAN
             *  dataType                = UNSIGNED
             *  factor                  = 1.0
             *  offset                  = 0.0
             * -----------------------------------------------------------------------*/
            {
              real64_T outValue = 0;

              {
                uint8_T unpackedValue = 0;

                {
                  uint8_T tempValue = (uint8_T) (0);

                  {
                    tempValue = tempValue | (uint8_T)
                      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2.Data
                       [0]);
                  }

                  unpackedValue = tempValue;
                }

                outValue = (real64_T) (unpackedValue);
              }

              {
                real64_T result = (real64_T) outValue;
                D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o2
                  = result;
              }
            }
          }
        }
      }
    }

    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel_p =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain_i *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AY =
      D_20230119_Modell_Inbetrieb_cal->Gain1_Gain_f *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLM =
      D_20230119_Modell_Inbetrieb_cal->Gain10_Gain_l *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o6;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRA =
      D_20230119_Modell_Inbetrieb_cal->Gain11_Gain_e *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o7;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRM =
      D_20230119_Modell_Inbetrieb_cal->Gain12_Gain_f *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o8;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal =
      D_20230119_Modell_Inbetrieb_cal->Gain13_Gain_k *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung =
      D_20230119_Modell_Inbetrieb_cal->Gain14_Gain_n *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack5_o2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierrate =
      D_20230119_Modell_Inbetrieb_cal->Gain2_Gain_m *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack1_o4;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AX =
      D_20230119_Modell_Inbetrieb_cal->Gain3_Gain_p *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierbeschleunigung =
      D_20230119_Modell_Inbetrieb_cal->Gain4_Gain_n *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack2_o3;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLA =
      D_20230119_Modell_Inbetrieb_cal->Gain5_Gain_m *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLM =
      D_20230119_Modell_Inbetrieb_cal->Gain6_Gain_p *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRA =
      D_20230119_Modell_Inbetrieb_cal->Gain7_Gain_h *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o3;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRM =
      D_20230119_Modell_Inbetrieb_cal->Gain8_Gain_l *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o4;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLA =
      D_20230119_Modell_Inbetrieb_cal->Gain9_Gain_e *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANUnpack4_o5;
    s64_iter++;
  } while (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1 &&
           (s64_iter <= 501));

  /* End of Outputs for SubSystem: '<S8>/CAN Read Loop - Port 3' */
  /* SignalConversion generated from: '<S2>/Byte Packing' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
    [0] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
    [1] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
    [2] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel_p;

  /* S-Function (slrealtimebytepacking): '<S2>/Byte Packing' */

  /* Byte Packing: <S2>/Byte Packing */
  (void)memcpy((uint8_T*)
               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking
               [0] + 0, (uint8_T*)
               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtBytePackin
               [0], 24);

  /* RateTransition generated from: '<S2>/Byte Packing' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      == 1) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
      = static_cast<int8_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
       == 0);
  }

  for (s64_iter = 0; s64_iter < 24; s64_iter++) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_Buf
      [s64_iter +
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
      * 24] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking[s64_iter];
  }

  /* End of RateTransition generated from: '<S2>/Byte Packing' */

  /* RelationalOperator: '<S47>/Compare' incorporates:
   *  Constant: '<S47>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_e =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Handbremse ==
     D_20230119_Modell_Inbetrieb_cal->Constant_Value_jl);

  /* RateTransition generated from: '<S66>/Add' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      == 1) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_RdBufIdx
      = static_cast<int8_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_RdBufIdx
       == 0);
  }

  /* RateTransition generated from: '<S66>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtAddInport1 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_Buf
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_RdBufIdx];

  /* Sum: '<S66>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_b =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtAddInport1 -
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel_p;

  /* Gain: '<S66>/Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_h =
    D_20230119_Modell_Inbetrieb_cal->Gain_Gain_a *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_b;

  /* Gain: '<S98>/Integral Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IntegralGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_I *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_h;

  /* Signum: '<S92>/SignPreIntegrator' */
  u = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IntegralGain;
  if (rtIsNaN(u)) {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      (rtNaN);
  } else if (u < 0.0) {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator =
      -1.0;
  } else {
    /* Signum: '<S92>/SignPreIntegrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator = (u
      > 0.0);
  }

  /* End of Signum: '<S92>/SignPreIntegrator' */

  /* DataTypeConversion: '<S92>/DataTypeConv2' */
  u = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SignPreIntegrator;
  if (rtIsNaN(u)) {
    u = 0.0;
  } else {
    u = std::fmod(u, 256.0);
  }

  /* DataTypeConversion: '<S92>/DataTypeConv2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConv2 =
    static_cast<int8_T>(u < 0.0 ? static_cast<int32_T>(static_cast<int8_T>(-
    static_cast<int8_T>(static_cast<uint8_T>(-u)))) : static_cast<int32_T>(
    static_cast<int8_T>(static_cast<uint8_T>(u))));

  /* RateTransition generated from: '<S92>/Equal1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_Buf
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConv2;

  /* RateTransition generated from: '<S92>/Switch' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_Buf
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IntegralGain;

  /* Gain: '<S95>/Derivative Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DerivativeGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_D *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_h;

  /* RateTransition generated from: '<S96>/SumD' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_Buf[
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DerivativeGain;

  /* Gain: '<S106>/Proportional Gain' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ProportionalGain =
    D_20230119_Modell_Inbetrieb_cal->PIDController_P *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_h;

  /* RateTransition generated from: '<S110>/Sum' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ProportionalGain;

  /* RateTransition: '<S66>/RT1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_WrBufIdx =
    static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_WrBufIdx == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel_p;

  /* DataTypeConversion: '<S10>/Data Type Conversion' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Data = 0.0;

  /* RateTransition: '<S10>/Rate Transition1' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_3
      == 1) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
      = static_cast<int8_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
       == 0);
  }

  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed;

  /* End of RateTransition: '<S10>/Rate Transition1' */

  /* RateTransition: '<S10>/Rate Transition2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel_p;

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
      == 1) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx =
      static_cast<int8_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx ==
       0);
  }

  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e;

  /* End of RateTransition generated from: '<Root>/S-Function Builder' */

  /* RelationalOperator: '<S186>/Compare' incorporates:
   *  Constant: '<S186>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_nw =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal ==
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant_const_kb);

  /* Switch: '<S11>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_nw) {
    /* Switch: '<S11>/Switch' incorporates:
     *  Constant: '<S11>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_p;
  } else {
    /* Switch: '<S11>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal;
  }

  /* End of Switch: '<S11>/Switch' */

  /* Saturate: '<S11>/Saturation' */
  u = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_l;
  u1 = D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat_k;
  u2 = D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat_i;
  if (u > u2) {
    /* Saturate: '<S11>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k = u2;
  } else if (u < u1) {
    /* Saturate: '<S11>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k = u1;
  } else {
    /* Saturate: '<S11>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k = u;
  }

  /* End of Saturate: '<S11>/Saturation' */

  /* Lookup_n-D: '<S11>/1-D Lookup Table' incorporates:
   *  Saturate: '<S11>/Saturation'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_p =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_k,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable_bp01Data_b,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable_tableData_m, 2U);

  /* RelationalOperator: '<S187>/Compare' incorporates:
   *  Constant: '<S187>/Constant'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_if =
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung ==
     D_20230119_Modell_Inbetrieb_cal->CompareToConstant1_const_k);

  /* Switch: '<S11>/Switch1' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Compare_if) {
    /* Switch: '<S11>/Switch1' incorporates:
     *  Constant: '<S11>/Constant1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_l =
      D_20230119_Modell_Inbetrieb_cal->Constant1_Value_n;
  } else {
    /* Switch: '<S11>/Switch1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung;
  }

  /* End of Switch: '<S11>/Switch1' */

  /* Saturate: '<S11>/Saturation1' */
  u = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch1_l;
  u1 = D_20230119_Modell_Inbetrieb_cal->Saturation1_LowerSat_o;
  u2 = D_20230119_Modell_Inbetrieb_cal->Saturation1_UpperSat_a;
  if (u > u2) {
    /* Saturate: '<S11>/Saturation1' */
<<<<<<< .mine
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u2;
  } else if (u0 < u1) {
||||||| .r78
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_n = u2;
  } else if (u0 < u1) {
=======
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u2;
  } else if (u < u1) {
>>>>>>> .r84
    /* Saturate: '<S11>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u1;
  } else {
    /* Saturate: '<S11>/Saturation1' */
<<<<<<< .mine
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u0;
||||||| .r78
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_n = u0;
=======
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 = u;
>>>>>>> .r84
  }

  /* End of Saturate: '<S11>/Saturation1' */

  /* Product: '<S11>/Divide' incorporates:
   *  Constant: '<S11>/Constant2'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_c =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1 /
    D_20230119_Modell_Inbetrieb_cal->Constant2_Value_a;

  /* RateTransition generated from: '<S11>/Transfer Fcn1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_Buf
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Divide_c;

  /* RateTransition generated from: '<S11>/Transfer Fcn' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_Buf
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable_p;

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID2_4
      == 1) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx =
      static_cast<int8_T>
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx == 0);
  }

  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b;

  /* End of RateTransition generated from: '<Root>/S-Function Builder' */

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick2))
  {
    ++D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH2;
  }

  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick2 *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize2 +
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH2 *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize2 *
    4294967296.0;
}

/* Model step function for TID3 */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step3(void) /* Sample time: [0.1s, 0.0s] */
{
  LaneSensor tmp;
  c_driving_internal_parabolicL_T b_data;
  c_driving_internal_parabolicL_T leftEgoBoundary_Data_data;
  c_driving_internal_parabolicL_T rightEgoBoundary_Data_data;
  packLaneMarkerBus_D_20230119__T *obj;
  struct_AzXAydn5whPkCj5deW4WYB expl_temp;
  real_T x1_2[3];
  real_T x1_3[3];
  real_T x1_4[3];
  real_T x2_2[3];
  real_T x2_3[3];
  real_T x2_4[3];
  real_T x1[2];
  real_T x1_0[2];
  real_T x1_1[2];
  real_T x1_5[2];
  real_T x1_6[2];
  real_T x1_7[2];
  real_T x1_8[2];
  real_T x2[2];
  real_T x2_0[2];
  real_T x2_1[2];
  real_T x2_5[2];
  real_T x2_6[2];
  real_T x2_7[2];
  real_T x2_8[2];
  real_T leftEgoParameters_idx_0;
  real_T leftEgoParameters_idx_1;
  real_T leftEgoParameters_idx_2;
  real_T rightEgoParameters_idx_0;
  real_T rightEgoParameters_idx_1;
  real_T rightEgoParameters_idx_2;
  int32_T i;
  uint8_T msgs[48];
  uint8_T x[8];
  boolean_T out;
  boolean_T p;
  boolean_T p_0;
  static const LaneSensorBoundaries tmp_0 = { 0.0F,/* Curvature */
    0.0F,                              /* CurvatureDerivative */
    0.0F,                              /* HeadingAngle */
    0.0F,                              /* LateralOffset */
    0.0F,                              /* Strength */

<<<<<<< .mine
    { 0.0F, 0.0F },                    /* XExtent */
    0U                                 /* BoundaryType */
  };

  real_T *x1_9;
  real_T *x2_9;
  boolean_T exitg1;

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeftandRight1_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeft1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromRight1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromNone1_SubsysRanBC);

  /* RateTransition: '<S10>/Rate Transition1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
     == 0);

  /* RateTransition: '<S10>/Rate Transition1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx];

  /* Switch: '<S120>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity
      > D_20230119_Modell_Inbetrieb_cal->Switch_Threshold_c) {
    /* Switch: '<S120>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity;
  } else {
    /* Switch: '<S120>/Switch' incorporates:
     *  Constant: '<S120>/Initial Velocity'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp =
      D_20230119_Modell_Inbetrieb_cal->InitialVelocity_Value;
  }

  /* End of Switch: '<S120>/Switch' */

  /* S-Function (slrealtimeUDPReceive): '<S10>/From Jetson' */
  {
    try {
      slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
        udp::Socket*>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK[
         0]);
      char *buffer = (char *)
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
        [1];
      memset(buffer,0,48);
      void *dataPort =
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o1[0];
      int_T numBytesAvail = (int_T)(udpSock->bytesToRead());
      if (numBytesAvail > 0) {
        uint8_t* fmAddArg = (uint8_t *)
          D_20230119_Modell_Inbetrieb_cal->FromJetson_fmAddress;
        size_t num_bytesRcvd = (size_t)(udpSock->receive(buffer,( numBytesAvail<
          65507 )? numBytesAvail:65507, !1,fmAddArg));
        if (num_bytesRcvd == 0) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 =
            0;
        } else {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 =
            (double)num_bytesRcvd;
          memcpy(dataPort,(void*)buffer,48);
        }
      } else {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 = 0;
      }
    } catch (std::exception& e) {
      std::string tmp = std::string(e.what());
      static std::string eMsg = tmp;
      rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                        eMsg.c_str());
      rtmSetStopRequested(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          1);
      ;
    }
  }

  /* MATLABSystem: '<S10>/PackLaneBus' */
  expl_temp = *get_camera();
  rightEgoParameters_idx_2 = expl_temp.NumColumns;
  leftEgoParameters_idx_0 = expl_temp.NumRows;
  for (i = 0; i < 48; i++) {
    msgs[i] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o1[i];
  }

  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns;
  leftEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows;
  x1_8[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
    [0];
  x1_8[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
    [1];
  x1_7[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
    [0];
  x1_7[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
    [1];
  x1_6[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
    [0];
  x1_6[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
    [1];
  x1_5[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
    [0];
  x1_5[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
    [1];
  x1_4[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0];
  x1_4[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1];
  x1_4[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2];
  x1_3[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [0];
  x1_3[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [1];
  x1_3[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [2];
  x1_2[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0];
  x1_2[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1];
  x1_2[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2];
  x1_1[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
    [0];
  x1_1[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
    [1];
  x1_0[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
    [0];
  x1_0[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
    [1];
  x1_9 =
    &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
    [0];
  x1[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
    [0];
  x1[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
    [1];
  x2_8[0] = expl_temp.FieldOfView[0];
  x2_7[0] = expl_temp.ImageSize[0];
  x2_6[0] = expl_temp.PrincipalPoint[0];
  x2_5[0] = expl_temp.FocalLength[0];
  x2_8[1] = expl_temp.FieldOfView[1];
  x2_7[1] = expl_temp.ImageSize[1];
  x2_6[1] = expl_temp.PrincipalPoint[1];
  x2_5[1] = expl_temp.FocalLength[1];
  x2_4[0] = expl_temp.Position[0];
  x2_3[0] = expl_temp.PositionSim3d[0];
  x2_2[0] = expl_temp.Rotation[0];
  x2_4[1] = expl_temp.Position[1];
  x2_3[1] = expl_temp.PositionSim3d[1];
  x2_2[1] = expl_temp.Rotation[1];
  x2_4[2] = expl_temp.Position[2];
  x2_3[2] = expl_temp.PositionSim3d[2];
  x2_2[2] = expl_temp.Rotation[2];
  x2_1[0] = expl_temp.DetectionRanges[0];
  x2_0[0] = expl_temp.LaneDetectionRanges[0];
  x2_1[1] = expl_temp.DetectionRanges[1];
  x2_0[1] = expl_temp.LaneDetectionRanges[1];
  x2_9 = &expl_temp.MeasurementNoise[0];
  x2[0] = expl_temp.MinObjectImageSize[0];
  x2[1] = expl_temp.MinObjectImageSize[1];
  p = false;
  out = true;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 2)) {
    rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
    rightEgoParameters_idx_1 = x1[static_cast<int32_T>(rightEgoParameters_idx_0)
      - 1];
    rightEgoParameters_idx_0 = x2[static_cast<int32_T>(rightEgoParameters_idx_0)
      - 1];
    p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
    if (!p_0) {
      out = false;
      exitg1 = true;
    } else {
      i++;
    }
  }

  if (out) {
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 9)) {
      rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
      rightEgoParameters_idx_1 = x1_9[static_cast<int32_T>
        (rightEgoParameters_idx_0) - 1];
      rightEgoParameters_idx_0 = x2_9[static_cast<int32_T>
        (rightEgoParameters_idx_0) - 1];
      p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
      if (!p_0) {
        out = false;
        exitg1 = true;
      } else {
        i++;
      }
    }

    if (out) {
      i = 0;
      exitg1 = false;
      while ((!exitg1) && (i < 2)) {
        rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
        rightEgoParameters_idx_1 = x1_0[static_cast<int32_T>
          (rightEgoParameters_idx_0) - 1];
        rightEgoParameters_idx_0 = x2_0[static_cast<int32_T>
          (rightEgoParameters_idx_0) - 1];
        p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
        if (!p_0) {
          out = false;
          exitg1 = true;
        } else {
          i++;
        }
      }

      if (out) {
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i < 2)) {
          rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
          rightEgoParameters_idx_1 = x1_1[static_cast<int32_T>
            (rightEgoParameters_idx_0) - 1];
          rightEgoParameters_idx_0 = x2_1[static_cast<int32_T>
            (rightEgoParameters_idx_0) - 1];
          p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
          if (!p_0) {
            out = false;
            exitg1 = true;
          } else {
            i++;
          }
        }

        if (out) {
          i = 0;
          exitg1 = false;
          while ((!exitg1) && (i < 3)) {
            rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
            rightEgoParameters_idx_1 = x1_2[static_cast<int32_T>
              (rightEgoParameters_idx_0) - 1];
            rightEgoParameters_idx_0 = x2_2[static_cast<int32_T>
              (rightEgoParameters_idx_0) - 1];
            p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
            if (!p_0) {
              out = false;
              exitg1 = true;
            } else {
              i++;
            }
          }

          if (out) {
            i = 0;
            exitg1 = false;
            while ((!exitg1) && (i < 3)) {
              rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
              rightEgoParameters_idx_1 = x1_3[static_cast<int32_T>
                (rightEgoParameters_idx_0) - 1];
              rightEgoParameters_idx_0 = x2_3[static_cast<int32_T>
                (rightEgoParameters_idx_0) - 1];
              p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
              if (!p_0) {
                out = false;
                exitg1 = true;
              } else {
                i++;
              }
            }

            if (out) {
              i = 0;
              exitg1 = false;
              while ((!exitg1) && (i < 3)) {
                rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                rightEgoParameters_idx_1 = x1_4[static_cast<int32_T>
                  (rightEgoParameters_idx_0) - 1];
                rightEgoParameters_idx_0 = x2_4[static_cast<int32_T>
                  (rightEgoParameters_idx_0) - 1];
                p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                if (!p_0) {
                  out = false;
                  exitg1 = true;
                } else {
                  i++;
                }
              }

              if (out) {
                i = 0;
                exitg1 = false;
                while ((!exitg1) && (i < 2)) {
                  rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                  rightEgoParameters_idx_1 = x1_5[static_cast<int32_T>
                    (rightEgoParameters_idx_0) - 1];
                  rightEgoParameters_idx_0 = x2_5[static_cast<int32_T>
                    (rightEgoParameters_idx_0) - 1];
                  p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                  if (!p_0) {
                    out = false;
                    exitg1 = true;
                  } else {
                    i++;
                  }
                }

                if (out) {
                  i = 0;
                  exitg1 = false;
                  while ((!exitg1) && (i < 2)) {
                    rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                    rightEgoParameters_idx_1 = x1_6[static_cast<int32_T>
                      (rightEgoParameters_idx_0) - 1];
                    rightEgoParameters_idx_0 = x2_6[static_cast<int32_T>
                      (rightEgoParameters_idx_0) - 1];
                    p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                    if (!p_0) {
                      out = false;
                      exitg1 = true;
                    } else {
                      i++;
                    }
                  }

                  if (out) {
                    i = 0;
                    exitg1 = false;
                    while ((!exitg1) && (i < 2)) {
                      rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                      rightEgoParameters_idx_1 = x1_7[static_cast<int32_T>
                        (rightEgoParameters_idx_0) - 1];
                      rightEgoParameters_idx_0 = x2_7[static_cast<int32_T>
                        (rightEgoParameters_idx_0) - 1];
                      p_0 = (rightEgoParameters_idx_1 ==
                             rightEgoParameters_idx_0);
                      if (!p_0) {
                        out = false;
                        exitg1 = true;
                      } else {
                        i++;
                      }
                    }

                    if (out) {
                      i = 0;
                      exitg1 = false;
                      while ((!exitg1) && (i < 2)) {
                        rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                        rightEgoParameters_idx_1 = x1_8[static_cast<int32_T>
                          (rightEgoParameters_idx_0) - 1];
                        rightEgoParameters_idx_0 = x2_8[static_cast<int32_T>
                          (rightEgoParameters_idx_0) - 1];
                        p_0 = (rightEgoParameters_idx_1 ==
                               rightEgoParameters_idx_0);
                        if (!p_0) {
                          out = false;
                          exitg1 = true;
                        } else {
                          i++;
                        }
                      }

                      if (out) {
                        p_0 = (leftEgoParameters_idx_2 ==
                               leftEgoParameters_idx_0);
                        out = p_0;
                        if (out) {
                          p_0 = (leftEgoParameters_idx_1 ==
                                 rightEgoParameters_idx_2);
                          out = p_0;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (out) {
    p = true;
  }

  if (!p) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns
      = rightEgoParameters_idx_2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows =
      leftEgoParameters_idx_0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [0] = expl_temp.FieldOfView[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [1] = expl_temp.FieldOfView[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [0] = expl_temp.ImageSize[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [1] = expl_temp.ImageSize[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [0] = expl_temp.PrincipalPoint[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [1] = expl_temp.PrincipalPoint[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [0] = expl_temp.FocalLength[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [1] = expl_temp.FocalLength[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0]
      = expl_temp.Position[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1]
      = expl_temp.Position[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2]
      = expl_temp.Position[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [0] = expl_temp.PositionSim3d[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [1] = expl_temp.PositionSim3d[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [2] = expl_temp.PositionSim3d[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0]
      = expl_temp.Rotation[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1]
      = expl_temp.Rotation[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2]
      = expl_temp.Rotation[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [0] = expl_temp.DetectionRanges[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [1] = expl_temp.DetectionRanges[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [0] = expl_temp.LaneDetectionRanges[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [1] = expl_temp.LaneDetectionRanges[1];
    std::memcpy
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
       [0], &expl_temp.MeasurementNoise[0], 9U * sizeof(real_T));
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [0] = expl_temp.MinObjectImageSize[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [1] = expl_temp.MinObjectImageSize[1];
  }

  obj = &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;

  /*  Pack lane boundaries to LaneSensor bus */
  /* ------------------------------------------------------------------ */
  /*  packLaneBoundaryDetections method packs Pack detections into */
  /*  format expected by LaneFollowingDecisionLogicandControl.  */
  /*  y=Ax^2+Bx+C */
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_0 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 8];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_1 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 16];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_2 = rightEgoParameters_idx_2 + 0.2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 24];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_0 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 32];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_1 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 40];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_2 += 0.2;
  b_data.BoundaryType = Solid;
  b_data.Strength = 0.0;
  b_data.XExtent[0] = 0.0;
  b_data.XExtent[1] = (rtInf);
  b_data.Parameters[0] = leftEgoParameters_idx_0;
  b_data.Parameters[1] = leftEgoParameters_idx_1;
  b_data.Parameters[2] = leftEgoParameters_idx_2;
  leftEgoBoundary_Data_data = b_data;
  b_data.BoundaryType = Solid;
  b_data.Strength = 0.0;
  b_data.XExtent[0] = 0.0;
  b_data.XExtent[1] = (rtInf);
  b_data.Parameters[0] = rightEgoParameters_idx_0;
  b_data.Parameters[1] = rightEgoParameters_idx_1;
  b_data.Parameters[2] = rightEgoParameters_idx_2;
  rightEgoBoundary_Data_data = b_data;

  /*  Preallocate struct expected by controller */
  /*  Pack detections into struct */
  D_202_packLaneBoundaryDetection(&leftEgoBoundary_Data_data,
    &tmp.Left.Curvature, &tmp.Left.CurvatureDerivative, &tmp.Left.HeadingAngle,
    &tmp.Left.LateralOffset, &tmp.Left.Strength, tmp.Left.XExtent,
    &tmp.Left.BoundaryType);
  D_202_packLaneBoundaryDetection(&rightEgoBoundary_Data_data,
    &tmp.Right.Curvature, &tmp.Right.CurvatureDerivative,
    &tmp.Right.HeadingAngle, &tmp.Right.LateralOffset, &tmp.Right.Strength,
    tmp.Right.XExtent, &tmp.Right.BoundaryType);

  /*  Shift detections to vehicle center as required by controller */
  /*  Note: camera.PositionSim3d(1) represents the X mount location of the */
  /*        camera sensor with respect to the vehicle center */
  b_data = leftEgoBoundary_Data_data;
  x1_4[0] = b_data.Parameters[0];
  x1_4[1] = b_data.Parameters[1];
  x1_4[2] = b_data.Parameters[2];
  i = 0;
  if (x1_4[0] != 0.0) {
    i = 1;
  }

  if (x1_4[1] != 0.0) {
    i++;
  }

  if (x1_4[2] != 0.0) {
    i++;
  }

  rightEgoParameters_idx_0 = i;
  if (rightEgoParameters_idx_0 != 0.0) {
    b_data = leftEgoBoundary_Data_data;
    x1_4[0] = b_data.Parameters[0];
    x1_4[1] = b_data.Parameters[1];
    x1_4[2] = b_data.Parameters[2];
    leftEgoParameters_idx_0 = -obj->Camera.PositionSim3d[0];
    rightEgoParameters_idx_2 = x1_4[0];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[1];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[2];
    tmp.Left.LateralOffset = static_cast<real32_T>(rightEgoParameters_idx_2);

    /*  Lane to left should always have positive lateral offset */
    if (tmp.Left.LateralOffset < 0.0F) {
      tmp.Left = tmp_0;
    }
  }

  b_data = rightEgoBoundary_Data_data;
  x1_4[0] = b_data.Parameters[0];
  x1_4[1] = b_data.Parameters[1];
  x1_4[2] = b_data.Parameters[2];
  i = 0;
  if (x1_4[0] != 0.0) {
    i = 1;
  }

  if (x1_4[1] != 0.0) {
    i++;
  }

  if (x1_4[2] != 0.0) {
    i++;
  }

  rightEgoParameters_idx_0 = i;
  if (rightEgoParameters_idx_0 != 0.0) {
    b_data = rightEgoBoundary_Data_data;
    x1_4[0] = b_data.Parameters[0];
    x1_4[1] = b_data.Parameters[1];
    x1_4[2] = b_data.Parameters[2];
    leftEgoParameters_idx_0 = -obj->Camera.PositionSim3d[0];
    rightEgoParameters_idx_2 = x1_4[0];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[1];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[2];
    tmp.Right.LateralOffset = static_cast<real32_T>(rightEgoParameters_idx_2);

    /*  Lane to right should always have negative lateral offset */
    if (tmp.Right.LateralOffset > 0.0F) {
      tmp.Right = tmp_0;
    }
  }

  /* MATLABSystem: '<S10>/PackLaneBus' */
  std::memcpy(&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus,
              &tmp, sizeof(LaneSensor));

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE;

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE;

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE;

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE;

  /* MATLAB Function: '<S119>/MATLAB Function1' incorporates:
   *  MATLABSystem: '<S10>/PackLaneBus'
   */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Strength
       > 0.0F) &&
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Strength
       > 0.0F)) {
    /* Outputs for Function Call SubSystem: '<S119>/Center from Left and Right1' */
    /* Sum: '<S121>/Add' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_nc =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature;

    /* Sum: '<S121>/Add1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.CurvatureDerivative
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.CurvatureDerivative;

    /* Sum: '<S121>/Add2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

    /* Sum: '<S121>/Add3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add3 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain_ii *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_nc;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetrieb_cal->Gain1_Gain_cq *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_e;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain2'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetrieb_cal->Gain2_Gain_o *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_e;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain3'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetrieb_cal->Gain3_Gain_d *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add3;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeftandRight1_SubsysR
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from Left and Right1' */
  } else if
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Strength
       > 0.0F) {
    /* Outputs for Function Call SubSystem: '<S119>/Center from Left1' */
    /* Product: '<S122>/Product' incorporates:
     *  Constant: '<S122>/Half Lane Width Estimate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      * D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate_Value;

    /* Sum: '<S122>/Subtract' incorporates:
     *  Constant: '<S122>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_jd -
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_l;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S122>/Divide'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l;

    /* Product: '<S122>/Product1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1_k =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S122>/Divide1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.CurvatureDerivative
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1_k;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S122>/Lanes_BusSelector'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Constant: '<S122>/Half Lane Width Estimate1'
     *  Sum: '<S122>/Subtract1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset
      - D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate1_Value;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeft1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from Left1' */
  } else if
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Strength
       > 0.0F) {
    /* Outputs for Function Call SubSystem: '<S119>/Center from Right1' */
    /* Product: '<S124>/Product' incorporates:
     *  Constant: '<S124>/Half Lane Width Estimate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_g =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature
      * D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate_Value_f;

    /* Sum: '<S124>/Subtract' incorporates:
     *  Constant: '<S124>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_pa +
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_g;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S124>/Divide'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract;

    /* Product: '<S124>/Product1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S124>/Divide1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.CurvatureDerivative
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S124>/Lanes_BusSelector'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Constant: '<S124>/Half Lane Width Estimate1'
     *  Sum: '<S124>/Subtract1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset
      + D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate1_Value_h;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromRight1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from Right1' */
  } else {
    /* Outputs for Function Call SubSystem: '<S119>/Center from None1' */
    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromNone1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from None1' */
  }

  /* End of MATLAB Function: '<S119>/MATLAB Function1' */

  /* UnaryMinus: '<S127>/Unary Minus' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus_i =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a;

  /* DataTypeConversion: '<S126>/Data Type Conversion3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion3 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus_i;

  /* Saturate: '<S126>/Saturation2' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion3;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation2_LowerSat_d;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation2_UpperSat_c;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation2' */

  /* UnaryMinus: '<S127>/Unary Minus1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1_k =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m;

  /* DataTypeConversion: '<S126>/Data Type Conversion2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_a =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1_k;

  /* Saturate: '<S126>/Saturation3' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_a;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation3_LowerSat_h;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation3_UpperSat_p;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation3' */

  /* Product: '<S126>/Product' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity;
  for (i = 0; i < 21; i++) {
    /* Gain: '<S126>/Gain' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_p[i] =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain_f[i] *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product;
  }

  for (i = 0; i < 21; i++) {
    /* Sum: '<S126>/Sum' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_a[i] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i +
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_p[i];
  }

  /* UnaryMinus: '<S127>/Unary Minus3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus3 =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f;

  /* DataTypeConversion: '<S126>/Data Type Conversion1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_f =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus3;

  /* UnaryMinus: '<S126>/Unary Minus1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1 =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_f;

  /* Saturate: '<S126>/Saturation' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat_d;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat_l;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation' */

  /* UnaryMinus: '<S127>/Unary Minus2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus2 =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l;

  /* DataTypeConversion: '<S126>/Data Type Conversion' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_gl =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus2;

  /* UnaryMinus: '<S126>/Unary Minus' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_gl;

  /* Saturate: '<S126>/Saturation1' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation1_LowerSat_n;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation1_UpperSat_d;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation1' */

||||||| .r78
=======
    { 0.0F, 0.0F },                    /* XExtent */
    0U                                 /* BoundaryType */
  };

  real_T *x1_9;
  real_T *x2_9;
  boolean_T exitg1;

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeftandRight1_SubsysR);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeft1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromRight1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromNone1_SubsysRanBC);

  /* RateTransition: '<S10>/Rate Transition1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
     == 0);

  /* RateTransition: '<S10>/Rate Transition1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx];

  /* Switch: '<S120>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity
      > D_20230119_Modell_Inbetrieb_cal->Switch_Threshold_c) {
    /* Switch: '<S120>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity;
  } else {
    /* Switch: '<S120>/Switch' incorporates:
     *  Constant: '<S120>/Initial Velocity'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp =
      D_20230119_Modell_Inbetrieb_cal->InitialVelocity_Value;
  }

  /* End of Switch: '<S120>/Switch' */

  /* S-Function (slrealtimeUDPReceive): '<S10>/From Jetson' */
  {
    try {
      slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
        udp::Socket*>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK[
         0]);
      char *buffer = (char *)
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
        [1];
      memset(buffer,0,48);
      void *dataPort =
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o1[0];
      int_T numBytesAvail = (int_T)(udpSock->bytesToRead());
      if (numBytesAvail > 0) {
        uint8_t* fmAddArg = (uint8_t *)
          D_20230119_Modell_Inbetrieb_cal->FromJetson_fmAddress;
        size_t num_bytesRcvd = (size_t)(udpSock->receive(buffer,( numBytesAvail<
          65507 )? numBytesAvail:65507, !1,fmAddArg));
        if (num_bytesRcvd == 0) {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 =
            0;
        } else {
          D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 =
            (double)num_bytesRcvd;
          memcpy(dataPort,(void*)buffer,48);
        }
      } else {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o2 = 0;
      }
    } catch (std::exception& e) {
      std::string tmp = std::string(e.what());
      static std::string eMsg = tmp;
      rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                        eMsg.c_str());
      rtmSetStopRequested(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          1);
      ;
    }
  }

  /* MATLABSystem: '<S10>/PackLaneBus' */
  expl_temp = *get_camera();
  rightEgoParameters_idx_2 = expl_temp.NumColumns;
  leftEgoParameters_idx_0 = expl_temp.NumRows;
  for (i = 0; i < 48; i++) {
    msgs[i] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FromJetson_o1[i];
  }

  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns;
  leftEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows;
  x1_8[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
    [0];
  x1_8[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
    [1];
  x1_7[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
    [0];
  x1_7[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
    [1];
  x1_6[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
    [0];
  x1_6[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
    [1];
  x1_5[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
    [0];
  x1_5[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
    [1];
  x1_4[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0];
  x1_4[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1];
  x1_4[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2];
  x1_3[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [0];
  x1_3[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [1];
  x1_3[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
    [2];
  x1_2[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0];
  x1_2[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1];
  x1_2[2] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2];
  x1_1[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
    [0];
  x1_1[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
    [1];
  x1_0[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
    [0];
  x1_0[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
    [1];
  x1_9 =
    &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
    [0];
  x1[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
    [0];
  x1[1] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
    [1];
  x2_8[0] = expl_temp.FieldOfView[0];
  x2_7[0] = expl_temp.ImageSize[0];
  x2_6[0] = expl_temp.PrincipalPoint[0];
  x2_5[0] = expl_temp.FocalLength[0];
  x2_8[1] = expl_temp.FieldOfView[1];
  x2_7[1] = expl_temp.ImageSize[1];
  x2_6[1] = expl_temp.PrincipalPoint[1];
  x2_5[1] = expl_temp.FocalLength[1];
  x2_4[0] = expl_temp.Position[0];
  x2_3[0] = expl_temp.PositionSim3d[0];
  x2_2[0] = expl_temp.Rotation[0];
  x2_4[1] = expl_temp.Position[1];
  x2_3[1] = expl_temp.PositionSim3d[1];
  x2_2[1] = expl_temp.Rotation[1];
  x2_4[2] = expl_temp.Position[2];
  x2_3[2] = expl_temp.PositionSim3d[2];
  x2_2[2] = expl_temp.Rotation[2];
  x2_1[0] = expl_temp.DetectionRanges[0];
  x2_0[0] = expl_temp.LaneDetectionRanges[0];
  x2_1[1] = expl_temp.DetectionRanges[1];
  x2_0[1] = expl_temp.LaneDetectionRanges[1];
  x2_9 = &expl_temp.MeasurementNoise[0];
  x2[0] = expl_temp.MinObjectImageSize[0];
  x2[1] = expl_temp.MinObjectImageSize[1];
  p = false;
  out = true;
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 2)) {
    rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
    rightEgoParameters_idx_1 = x1[static_cast<int32_T>(rightEgoParameters_idx_0)
      - 1];
    rightEgoParameters_idx_0 = x2[static_cast<int32_T>(rightEgoParameters_idx_0)
      - 1];
    p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
    if (!p_0) {
      out = false;
      exitg1 = true;
    } else {
      i++;
    }
  }

  if (out) {
    i = 0;
    exitg1 = false;
    while ((!exitg1) && (i < 9)) {
      rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
      rightEgoParameters_idx_1 = x1_9[static_cast<int32_T>
        (rightEgoParameters_idx_0) - 1];
      rightEgoParameters_idx_0 = x2_9[static_cast<int32_T>
        (rightEgoParameters_idx_0) - 1];
      p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
      if (!p_0) {
        out = false;
        exitg1 = true;
      } else {
        i++;
      }
    }

    if (out) {
      i = 0;
      exitg1 = false;
      while ((!exitg1) && (i < 2)) {
        rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
        rightEgoParameters_idx_1 = x1_0[static_cast<int32_T>
          (rightEgoParameters_idx_0) - 1];
        rightEgoParameters_idx_0 = x2_0[static_cast<int32_T>
          (rightEgoParameters_idx_0) - 1];
        p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
        if (!p_0) {
          out = false;
          exitg1 = true;
        } else {
          i++;
        }
      }

      if (out) {
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i < 2)) {
          rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
          rightEgoParameters_idx_1 = x1_1[static_cast<int32_T>
            (rightEgoParameters_idx_0) - 1];
          rightEgoParameters_idx_0 = x2_1[static_cast<int32_T>
            (rightEgoParameters_idx_0) - 1];
          p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
          if (!p_0) {
            out = false;
            exitg1 = true;
          } else {
            i++;
          }
        }

        if (out) {
          i = 0;
          exitg1 = false;
          while ((!exitg1) && (i < 3)) {
            rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
            rightEgoParameters_idx_1 = x1_2[static_cast<int32_T>
              (rightEgoParameters_idx_0) - 1];
            rightEgoParameters_idx_0 = x2_2[static_cast<int32_T>
              (rightEgoParameters_idx_0) - 1];
            p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
            if (!p_0) {
              out = false;
              exitg1 = true;
            } else {
              i++;
            }
          }

          if (out) {
            i = 0;
            exitg1 = false;
            while ((!exitg1) && (i < 3)) {
              rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
              rightEgoParameters_idx_1 = x1_3[static_cast<int32_T>
                (rightEgoParameters_idx_0) - 1];
              rightEgoParameters_idx_0 = x2_3[static_cast<int32_T>
                (rightEgoParameters_idx_0) - 1];
              p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
              if (!p_0) {
                out = false;
                exitg1 = true;
              } else {
                i++;
              }
            }

            if (out) {
              i = 0;
              exitg1 = false;
              while ((!exitg1) && (i < 3)) {
                rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                rightEgoParameters_idx_1 = x1_4[static_cast<int32_T>
                  (rightEgoParameters_idx_0) - 1];
                rightEgoParameters_idx_0 = x2_4[static_cast<int32_T>
                  (rightEgoParameters_idx_0) - 1];
                p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                if (!p_0) {
                  out = false;
                  exitg1 = true;
                } else {
                  i++;
                }
              }

              if (out) {
                i = 0;
                exitg1 = false;
                while ((!exitg1) && (i < 2)) {
                  rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                  rightEgoParameters_idx_1 = x1_5[static_cast<int32_T>
                    (rightEgoParameters_idx_0) - 1];
                  rightEgoParameters_idx_0 = x2_5[static_cast<int32_T>
                    (rightEgoParameters_idx_0) - 1];
                  p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                  if (!p_0) {
                    out = false;
                    exitg1 = true;
                  } else {
                    i++;
                  }
                }

                if (out) {
                  i = 0;
                  exitg1 = false;
                  while ((!exitg1) && (i < 2)) {
                    rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                    rightEgoParameters_idx_1 = x1_6[static_cast<int32_T>
                      (rightEgoParameters_idx_0) - 1];
                    rightEgoParameters_idx_0 = x2_6[static_cast<int32_T>
                      (rightEgoParameters_idx_0) - 1];
                    p_0 = (rightEgoParameters_idx_1 == rightEgoParameters_idx_0);
                    if (!p_0) {
                      out = false;
                      exitg1 = true;
                    } else {
                      i++;
                    }
                  }

                  if (out) {
                    i = 0;
                    exitg1 = false;
                    while ((!exitg1) && (i < 2)) {
                      rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                      rightEgoParameters_idx_1 = x1_7[static_cast<int32_T>
                        (rightEgoParameters_idx_0) - 1];
                      rightEgoParameters_idx_0 = x2_7[static_cast<int32_T>
                        (rightEgoParameters_idx_0) - 1];
                      p_0 = (rightEgoParameters_idx_1 ==
                             rightEgoParameters_idx_0);
                      if (!p_0) {
                        out = false;
                        exitg1 = true;
                      } else {
                        i++;
                      }
                    }

                    if (out) {
                      i = 0;
                      exitg1 = false;
                      while ((!exitg1) && (i < 2)) {
                        rightEgoParameters_idx_0 = static_cast<real_T>(i) + 1.0;
                        rightEgoParameters_idx_1 = x1_8[static_cast<int32_T>
                          (rightEgoParameters_idx_0) - 1];
                        rightEgoParameters_idx_0 = x2_8[static_cast<int32_T>
                          (rightEgoParameters_idx_0) - 1];
                        p_0 = (rightEgoParameters_idx_1 ==
                               rightEgoParameters_idx_0);
                        if (!p_0) {
                          out = false;
                          exitg1 = true;
                        } else {
                          i++;
                        }
                      }

                      if (out) {
                        p_0 = (leftEgoParameters_idx_2 ==
                               leftEgoParameters_idx_0);
                        out = p_0;
                        if (out) {
                          p_0 = (leftEgoParameters_idx_1 ==
                                 rightEgoParameters_idx_2);
                          out = p_0;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (out) {
    p = true;
  }

  if (!p) {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns
      = rightEgoParameters_idx_2;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows =
      leftEgoParameters_idx_0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [0] = expl_temp.FieldOfView[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [1] = expl_temp.FieldOfView[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [0] = expl_temp.ImageSize[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [1] = expl_temp.ImageSize[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [0] = expl_temp.PrincipalPoint[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [1] = expl_temp.PrincipalPoint[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [0] = expl_temp.FocalLength[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [1] = expl_temp.FocalLength[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0]
      = expl_temp.Position[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1]
      = expl_temp.Position[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2]
      = expl_temp.Position[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [0] = expl_temp.PositionSim3d[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [1] = expl_temp.PositionSim3d[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [2] = expl_temp.PositionSim3d[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0]
      = expl_temp.Rotation[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1]
      = expl_temp.Rotation[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2]
      = expl_temp.Rotation[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [0] = expl_temp.DetectionRanges[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [1] = expl_temp.DetectionRanges[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [0] = expl_temp.LaneDetectionRanges[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [1] = expl_temp.LaneDetectionRanges[1];
    std::memcpy
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
       [0], &expl_temp.MeasurementNoise[0], 9U * sizeof(real_T));
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [0] = expl_temp.MinObjectImageSize[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [1] = expl_temp.MinObjectImageSize[1];
  }

  obj = &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;

  /*  Pack lane boundaries to LaneSensor bus */
  /* ------------------------------------------------------------------ */
  /*  packLaneBoundaryDetections method packs Pack detections into */
  /*  format expected by LaneFollowingDecisionLogicandControl.  */
  /*  y=Ax^2+Bx+C */
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_0 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 8];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_1 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 16];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  leftEgoParameters_idx_2 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 24];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_0 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 32];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  rightEgoParameters_idx_1 = rightEgoParameters_idx_2;
  for (i = 0; i < 8; i++) {
    x[i] = msgs[i + 40];
  }

  std::memcpy((void *)&rightEgoParameters_idx_2, (void *)&x[0], (uint32_T)
              ((size_t)1 * sizeof(real_T)));
  b_data.BoundaryType = Solid;
  b_data.Strength = 0.0;
  b_data.XExtent[0] = 0.0;
  b_data.XExtent[1] = (rtInf);
  b_data.Parameters[0] = leftEgoParameters_idx_0;
  b_data.Parameters[1] = leftEgoParameters_idx_1;
  b_data.Parameters[2] = leftEgoParameters_idx_2;
  leftEgoBoundary_Data_data = b_data;
  b_data.BoundaryType = Solid;
  b_data.Strength = 0.0;
  b_data.XExtent[0] = 0.0;
  b_data.XExtent[1] = (rtInf);
  b_data.Parameters[0] = rightEgoParameters_idx_0;
  b_data.Parameters[1] = rightEgoParameters_idx_1;
  b_data.Parameters[2] = rightEgoParameters_idx_2;
  rightEgoBoundary_Data_data = b_data;

  /*  Preallocate struct expected by controller */
  /*  Pack detections into struct */
  D_202_packLaneBoundaryDetection(&leftEgoBoundary_Data_data,
    &tmp.Left.Curvature, &tmp.Left.CurvatureDerivative, &tmp.Left.HeadingAngle,
    &tmp.Left.LateralOffset, &tmp.Left.Strength, tmp.Left.XExtent,
    &tmp.Left.BoundaryType);
  D_202_packLaneBoundaryDetection(&rightEgoBoundary_Data_data,
    &tmp.Right.Curvature, &tmp.Right.CurvatureDerivative,
    &tmp.Right.HeadingAngle, &tmp.Right.LateralOffset, &tmp.Right.Strength,
    tmp.Right.XExtent, &tmp.Right.BoundaryType);

  /*  Shift detections to vehicle center as required by controller */
  /*  Note: camera.PositionSim3d(1) represents the X mount location of the */
  /*        camera sensor with respect to the vehicle center */
  b_data = leftEgoBoundary_Data_data;
  x1_4[0] = b_data.Parameters[0];
  x1_4[1] = b_data.Parameters[1];
  x1_4[2] = b_data.Parameters[2];
  i = 0;
  if (x1_4[0] != 0.0) {
    i = 1;
  }

  if (x1_4[1] != 0.0) {
    i++;
  }

  if (x1_4[2] != 0.0) {
    i++;
  }

  rightEgoParameters_idx_0 = i;
  if (rightEgoParameters_idx_0 != 0.0) {
    b_data = leftEgoBoundary_Data_data;
    x1_4[0] = b_data.Parameters[0];
    x1_4[1] = b_data.Parameters[1];
    x1_4[2] = b_data.Parameters[2];
    leftEgoParameters_idx_0 = -obj->Camera.PositionSim3d[0];
    rightEgoParameters_idx_2 = x1_4[0];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[1];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[2];
    tmp.Left.LateralOffset = static_cast<real32_T>(rightEgoParameters_idx_2);

    /*  Lane to left should always have positive lateral offset */
    if (tmp.Left.LateralOffset < 0.0F) {
      tmp.Left = tmp_0;
    }
  }

  b_data = rightEgoBoundary_Data_data;
  x1_4[0] = b_data.Parameters[0];
  x1_4[1] = b_data.Parameters[1];
  x1_4[2] = b_data.Parameters[2];
  i = 0;
  if (x1_4[0] != 0.0) {
    i = 1;
  }

  if (x1_4[1] != 0.0) {
    i++;
  }

  if (x1_4[2] != 0.0) {
    i++;
  }

  rightEgoParameters_idx_0 = i;
  if (rightEgoParameters_idx_0 != 0.0) {
    b_data = rightEgoBoundary_Data_data;
    x1_4[0] = b_data.Parameters[0];
    x1_4[1] = b_data.Parameters[1];
    x1_4[2] = b_data.Parameters[2];
    leftEgoParameters_idx_0 = -obj->Camera.PositionSim3d[0];
    rightEgoParameters_idx_2 = x1_4[0];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[1];
    rightEgoParameters_idx_2 = leftEgoParameters_idx_0 *
      rightEgoParameters_idx_2 + x1_4[2];
    tmp.Right.LateralOffset = static_cast<real32_T>(rightEgoParameters_idx_2);

    /*  Lane to right should always have negative lateral offset */
    if (tmp.Right.LateralOffset > 0.0F) {
      tmp.Right = tmp_0;
    }
  }

  /* MATLABSystem: '<S10>/PackLaneBus' */
  std::memcpy(&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus,
              &tmp, sizeof(LaneSensor));

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE;

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE;

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE;

  /* Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE;

  /* MATLAB Function: '<S119>/MATLAB Function1' incorporates:
   *  MATLABSystem: '<S10>/PackLaneBus'
   */
  if ((D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Strength
       > 0.0F) &&
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Strength
       > 0.0F)) {
    /* Outputs for Function Call SubSystem: '<S119>/Center from Left and Right1' */
    /* Sum: '<S121>/Add' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_nc =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature;

    /* Sum: '<S121>/Add1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.CurvatureDerivative
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.CurvatureDerivative;

    /* Sum: '<S121>/Add2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_e =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

    /* Sum: '<S121>/Add3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add3 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset
      + D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain_ii *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add_nc;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetrieb_cal->Gain1_Gain_cq *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add1_e;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain2'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetrieb_cal->Gain2_Gain_o *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add2_e;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Gain: '<S121>/Gain3'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetrieb_cal->Gain3_Gain_d *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Add3;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeftandRight1_SubsysR
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from Left and Right1' */
  } else if
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Strength
       > 0.0F) {
    /* Outputs for Function Call SubSystem: '<S119>/Center from Left1' */
    /* Product: '<S122>/Product' incorporates:
     *  Constant: '<S122>/Half Lane Width Estimate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      * D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate_Value;

    /* Sum: '<S122>/Subtract' incorporates:
     *  Constant: '<S122>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_jd -
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_l;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S122>/Divide'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l;

    /* Product: '<S122>/Product1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1_k =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract_l;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S122>/Divide1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.CurvatureDerivative
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1_k;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S122>/Lanes_BusSelector'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Constant: '<S122>/Half Lane Width Estimate1'
     *  Sum: '<S122>/Subtract1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset
      - D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate1_Value;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromLeft1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from Left1' */
  } else if
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Strength
       > 0.0F) {
    /* Outputs for Function Call SubSystem: '<S119>/Center from Right1' */
    /* Product: '<S124>/Product' incorporates:
     *  Constant: '<S124>/Half Lane Width Estimate'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_g =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature
      * D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate_Value_f;

    /* Sum: '<S124>/Subtract' incorporates:
     *  Constant: '<S124>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_pa +
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product_g;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S124>/Divide'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract;

    /* Product: '<S124>/Product1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1 =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Subtract;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Product: '<S124>/Divide1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.CurvatureDerivative
      / D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product1;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S124>/Lanes_BusSelector'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  Constant: '<S124>/Half Lane Width Estimate1'
     *  Sum: '<S124>/Subtract1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset
      + D_20230119_Modell_Inbetrieb_cal->HalfLaneWidthEstimate1_Value_h;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromRight1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from Right1' */
  } else {
    /* Outputs for Function Call SubSystem: '<S119>/Center from None1' */
    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle;

    /* Merge generated from: '<S119>/Merge1' incorporates:
     *  SignalConversion generated from: '<S123>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CenterfromNone1_SubsysRanBC
      = 4;

    /* End of Outputs for SubSystem: '<S119>/Center from None1' */
  }

  /* End of MATLAB Function: '<S119>/MATLAB Function1' */

  /* UnaryMinus: '<S127>/Unary Minus' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus_i =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a;

  /* DataTypeConversion: '<S126>/Data Type Conversion3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion3 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus_i;

  /* Saturate: '<S126>/Saturation2' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion3;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation2_LowerSat_d;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation2_UpperSat_c;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation2' */

  /* UnaryMinus: '<S127>/Unary Minus1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1_k =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m;

  /* DataTypeConversion: '<S126>/Data Type Conversion2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_a =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1_k;

  /* Saturate: '<S126>/Saturation3' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion2_a;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation3_LowerSat_h;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation3_UpperSat_p;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation3' */

  /* Product: '<S126>/Product' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation3_b *
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Longitudinal_Velocity;
  for (i = 0; i < 31; i++) {
    /* Gain: '<S126>/Gain' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_p[i] =
      D_20230119_Modell_Inbetrieb_cal->Gain_Gain_f[i] *
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Product;
  }

  for (i = 0; i < 31; i++) {
    /* Sum: '<S126>/Sum' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_a[i] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation2_i +
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gain_p[i];
  }

  /* UnaryMinus: '<S127>/Unary Minus3' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus3 =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f;

  /* DataTypeConversion: '<S126>/Data Type Conversion1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_f =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus3;

  /* UnaryMinus: '<S126>/Unary Minus1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1 =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_f;

  /* Saturate: '<S126>/Saturation' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus1;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation_LowerSat_d;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation_UpperSat_l;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation' */

  /* UnaryMinus: '<S127>/Unary Minus2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus2 =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l;

  /* DataTypeConversion: '<S126>/Data Type Conversion' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_gl =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus2;

  /* UnaryMinus: '<S126>/Unary Minus' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus =
    -D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_gl;

  /* Saturate: '<S126>/Saturation1' */
  rightEgoParameters_idx_2 =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.UnaryMinus;
  leftEgoParameters_idx_0 =
    D_20230119_Modell_Inbetrieb_cal->Saturation1_LowerSat_n;
  leftEgoParameters_idx_1 =
    D_20230119_Modell_Inbetrieb_cal->Saturation1_UpperSat_d;
  if (rightEgoParameters_idx_2 > leftEgoParameters_idx_1) {
    /* Saturate: '<S126>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      leftEgoParameters_idx_1;
  } else if (rightEgoParameters_idx_2 < leftEgoParameters_idx_0) {
    /* Saturate: '<S126>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      leftEgoParameters_idx_0;
  } else {
    /* Saturate: '<S126>/Saturation1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l =
      rightEgoParameters_idx_2;
  }

  /* End of Saturate: '<S126>/Saturation1' */

>>>>>>> .r84
  /* Outputs for Atomic SubSystem: '<S120>/Path Following Control System' */
  /* Constant: '<S10>/Set Velocity' */
  PathFollowingControlSystem
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
     D_20230119_Modell_Inbetrieb_cal->SetVelocity_Value,
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_gp,
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Sum_a,
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation_f,
     D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Saturation1_l,
     *get_min_ac(), *get_min_steer(), *get_max_ac(), *get_max_steer(),
     *get_default_spacing(),
     &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i,
     &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.PathFollowingControlSystem_i,
     &D_20230119_Modell_Inbetrieb_cal->PathFollowingControlSystem_cal);

  /* End of Outputs for SubSystem: '<S120>/Path Following Control System' */

  /* Lookup_n-D: '<S1>/1-D Lookup Table2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2 =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
     [0], D_20230119_Modell_Inbetrieb_cal->uDLookupTable2_bp01Data_h,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable2_tableData_b, 1U);

  /* RateTransition generated from: '<S1>/Switch' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_e
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2;

  /* RateTransition generated from: '<S2>/Byte Packing' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
     == 0);
  i =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
    * 24;
  for (int32_T i_0 = 0; i_0 < 24; i_0++) {
    /* RateTransition generated from: '<S2>/Byte Packing' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtBytePackingOutport1
      [i_0] =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_Buf
      [i_0 + i];
  }

  /* S-Function (slrealtimeUDPSend): '<S2>/UDP Send' */
  {
    try {
      slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
        udp::Socket*>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_PWORK);
      uint8_t *remoteAddress = (uint8_t *)
        D_20230119_Modell_Inbetrieb_cal->UDPSend_toAddress;
      uint16_t *remotePort = (uint16_t *)
        &D_20230119_Modell_Inbetrieb_cal->UDPSend_toPort;
      udpSock->resetRemoteEndpoint(remoteAddress, remotePort);
      int dataLen =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_f;
      dataLen = (dataLen <=
                 D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK
                 [0]) ? dataLen :
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK[0];
      dataLen = (dataLen <= -1) ? 0 : dataLen;
      void *dataPort =
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtBytePackingOutport1
        [0];
      size_t numBytesSend = udpSock->send((const char*)dataPort,dataLen);
    } catch (std::exception& e) {
      std::string tmp = std::string(e.what());
      static std::string eMsg = tmp;
      rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                        eMsg.c_str());
      rtmSetStopRequested(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          1);
      ;
    }
  }

  /* Lookup_n-D: '<S3>/1-D Lookup Table2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2_i =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
     [0], D_20230119_Modell_Inbetrieb_cal->uDLookupTable2_bp01Data_l,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable2_tableData_j, 1U);

  /* RateTransition generated from: '<S3>/Switch' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf
    [D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2_i;

  /* RateTransition generated from: '<S9>/Switch' */
  rtw_slrealtime_mutex_lock
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_d0_SEMAPHORE);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_RDBuf =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_LstBufWR;
  rtw_slrealtime_mutex_unlock
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_d0_SEMAPHORE);
  switch
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_RDBuf) {
   case 0:
    /* RateTransition generated from: '<S9>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Autonom_ON =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf0;
    break;

   case 1:
    /* RateTransition generated from: '<S9>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Autonom_ON =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf1;
    break;

   case 2:
    /* RateTransition generated from: '<S9>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Autonom_ON =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf2;
    break;
  }

  /* End of RateTransition generated from: '<S9>/Switch' */

  /* Switch: '<S9>/Switch' */
  if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Autonom_ON >
      D_20230119_Modell_Inbetrieb_cal->Switch_Threshold_n) {
    /* Lookup_n-D: '<S9>/1-D Lookup Table2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2_d =
      look1_binlxpw
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
       [1], D_20230119_Modell_Inbetrieb_cal->uDLookupTable2_bp01Data,
       D_20230119_Modell_Inbetrieb_cal->uDLookupTable2_tableData, 1U);

    /* Switch: '<S9>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_lu =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable2_d;
  } else {
    /* Switch: '<S9>/Switch' incorporates:
     *  Constant: '<S9>/Constant'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_lu =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_j;
  }

  /* End of Switch: '<S9>/Switch' */

  /* Lookup_n-D: '<S66>/1-D Lookup Table3' incorporates:
   *  Switch: '<S9>/Switch'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3 =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Switch_lu,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable3_bp01Data,
     D_20230119_Modell_Inbetrieb_cal->uDLookupTable3_tableData, 1U);

  /* Lookup_n-D: '<S66>/1-D Lookup Vorsteuerung' incorporates:
   *  Lookup_n-D: '<S66>/1-D Lookup Table3'
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupVorsteuerung =
    look1_binlxpw
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3,
     D_20230119_Modell_Inbetrieb_cal->uDLookupVorsteuerung_bp01Data,
     D_20230119_Modell_Inbetrieb_cal->uDLookupVorsteuerung_tableData, 6U);

  /* RateTransition: '<S66>/RT' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx =
    static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3;

  /* RateTransition generated from: '<S66>/Add2' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_Buf[
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupVorsteuerung;

<<<<<<< .mine
  /* SignalConversion generated from: '<S10>/Bus Selector' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_p =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.Curvature;
||||||| .r78
  /* S-Function (slrealtimebytepacking): '<S10>/Byte Packing' */
=======
  /* RateTransition generated from: '<S66>/Add' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_WrBufIdx
    = static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_WrBufIdx
     == 0);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_WrBufIdx]
    = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.uDLookupTable3;
>>>>>>> .r84

<<<<<<< .mine
  /* SignalConversion generated from: '<S10>/Bus Selector' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_g =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.HeadingAngle;
||||||| .r78
  /* Byte Packing: <S10>/Byte Packing */
  (void)memcpy((uint8_T*)
               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking_j
               [0] + 0, (uint8_T*)
               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
               [1], 8);
  (void)memcpy((uint8_T*)
               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking_j
               [0] + 8, (uint8_T*)
               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PathFollowingControlSystem_i.u_scale
               [0], 8);
=======
  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f;
>>>>>>> .r84

<<<<<<< .mine
  /* SignalConversion generated from: '<S10>/Bus Selector' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_k =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Left.LateralOffset;
||||||| .r78
  /* S-Function (slrealtimeUDPSend): '<S10>/To Jetson' */
  {
    try {
      slrealtime::ip::udp::Socket *udpSock = reinterpret_cast<slrealtime::ip::
        udp::Socket*>
        (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.ToJetson_PWORK);
      uint8_t *remoteAddress = (uint8_t *)
        D_20230119_Modell_Inbetrieb_cal->ToJetson_toAddress;
      uint16_t *remotePort = (uint16_t *)
        &D_20230119_Modell_Inbetrieb_cal->ToJetson_toPort;
      udpSock->resetRemoteEndpoint(remoteAddress, remotePort);
      int dataLen =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB.Width_c;
      dataLen = (dataLen <=
                 D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.ToJetson_IWORK
                 [0]) ? dataLen :
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.ToJetson_IWORK[0];
      dataLen = (dataLen <= -1) ? 0 : dataLen;
      void *dataPort =
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BytePacking_j[0];
      size_t numBytesSend = udpSock->send((const char*)dataPort,dataLen);
    } catch (std::exception& e) {
      std::string tmp = std::string(e.what());
      static std::string eMsg = tmp;
      rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                        eMsg.c_str());
      rtmSetStopRequested(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          1);
      ;
    }
  }
=======
  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l;
>>>>>>> .r84

<<<<<<< .mine
  /* SignalConversion generated from: '<S10>/Bus Selector' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_pa =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.Curvature;

  /* SignalConversion generated from: '<S10>/Bus Selector' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_gv =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.HeadingAngle;

  /* SignalConversion generated from: '<S10>/Bus Selector' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_kn =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.PackLaneBus.Right.LateralOffset;

  /* SignalConversion generated from: '<S10>/Mux' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtTAQSigLogg
    [0] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_p;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtTAQSigLogg
    [1] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_g;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtTAQSigLogg
    [2] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_k;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtTAQSigLogg
    [3] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_pa;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtTAQSigLogg
    [4] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_gv;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpSignalConversionAtTAQSigLogg
    [5] = D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_kn;

  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f;

  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l;

  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m;

  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a;

||||||| .r78
=======
  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m;

  /* Update for Delay generated from: '<S119>/Delay1' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a;

>>>>>>> .r84
  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.1, which is the step size
   * of the task. Size of "clockTick3" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick3++;
  if (!D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick3)
  {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH3++;
  }
}

/* Model step function for TID4 */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step4(void) /* Sample time: [60.0s, 0.0s] */
{
  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx =
    static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx ==
     0);

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx];

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx =
    static_cast<int8_T>
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx == 0);

  /* RateTransition generated from: '<Root>/S-Function Builder' */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_Buf[D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx];

  /* S-Function (Monitorausgabe_sfun): '<Root>/S-Function Builder' */
  Monitorausgabe_sfun_Outputs_wrapper_cgen
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer,
     &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC,
     &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SFunctionBuilder);

  /* Update absolute time */
  /* The "clockTick4" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 60.0, which is the step size
   * of the task. Size of "clockTick4" ensures timer will not overflow during the
   * application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick4 and the high bits
   * Timing.clockTickH4. When the low bit overflows to 0, the high bits increment.
   */
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick4++;
  if (!D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTick4)
  {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.clockTickH4++;
  }
}

/* Model initialize function */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* Set task counter limit used by the static main program */
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[0] = 1;
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[1] = 1;
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[2] = 5;
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[3] = 100;
  (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
    ->Timing.TaskCounters.cLimit[4] = 60000;

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.simTimeStep);
    rtsiSetTPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &rtmGetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtsiSetStepSizePtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0);
    rtsiSetdXPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->derivs);
    rtsiSetContStatesPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       (real_T **)
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->contStates);
    rtsiSetNumContStatesPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       (&rtmGetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)));
    rtsiSetRTModelPtr
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
  }

  rtsiSetSimTimeStep
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
     MAJOR_TIME_STEP);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->intgData.f[0] =
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->odeF[0];
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->contStates =
    ((X_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *)
     &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X);
  rtsiSetSolverData
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
     static_cast<void *>
     (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->intgData));
  rtsiSetIsMinorTimeStepWithModeChange
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo, false);
  rtsiSetSolverName
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,"ode1");
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfoPtr =
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimeTaskIDArray;
    int_T i;
    for (i = 0; i < 5; i++) {
      mdlTsMap[i] = i;
    }

    /* polyspace +2 MISRA2012:D4.1 [Justified:Low] "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M points to
       static memory which is guaranteed to be non-NULL" */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimeTaskIDPtr
      = (&mdlTsMap[0]);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes =
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimesArray
       [0]);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes =
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimesArray
       [0]);

    /* task periods */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[0]
      = (0.0);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[1]
      = (0.001);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[2]
      = (0.005);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[3]
      = (0.1);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleTimes[4]
      = (60.0);

    /* task offsets */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[0]
      = (0.0);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[1]
      = (0.0);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[2]
      = (0.0);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[3]
      = (0.0);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.offsetTimes[4]
      = (0.0);
  }

  rtmSetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
             &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.tArray
             [0]);

  {
    int_T *mdlSampleHits =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHitsArray;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits
      = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.sampleHits = (
      &mdlSampleHits[0]);
  }

  rtmSetTFinal(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, -1);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize0 =
    0.001;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize1 =
    0.001;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize2 =
    0.005;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfoPtr =
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo);
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize =
    (0.001);
  rtsiSetFixedStepSize
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo, 0.001);
  rtsiSetSolverMode
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->solverInfo,
     SOLVER_MODE_MULTITASKING);

  /* block I/O */
  (void) std::memset((static_cast<void *>
                      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B)),
                     0,
                     sizeof
                     (B_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T));

  {
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2 =
      CAN_DATATYPE_GROUND;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e =
      CAN_DATATYPE_GROUND;
  }

  /* states (continuous) */
  {
    (void) std::memset(static_cast<void *>
                       (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X),
                       0,
                       sizeof
                       (X_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T));
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>
                     (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW),
                     0,
                     sizeof
                     (DW_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T));

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo =
      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.sfcnInfo;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)));
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numSampTimes =
      (5);
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numSampTimes);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [0] = &(rtmGetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [0]);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [1] = &(rtmGetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [1]);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [2] = &(rtmGetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [2]);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [3] = &(rtmGetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [3]);
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs
      [4] = &(rtmGetTPtr(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M)
              [4]);
    rtssSetTPtrPtr(sfcnInfo,
                   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart
                     (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal
                     (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetStepSizePtr(sfcnInfo,
                       &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo,
                      &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         solverInfoPtr);
  }

  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Sizes.numSFcns = (14);

  /* register each child */
  {
    (void) std::memset(static_cast<void *>
                       (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.childSFunctions
                        [0]), 0,
                       14*sizeof(SimStruct));
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions =
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.childSFunctionPtrs
       [0]);

    {
      int_T i;
      for (i = 0; i < 14; i++) {
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[i]
          =
          (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.childSFunctions
           [i]);
      }
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S64>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1_f));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2_e));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 1/CAN Read1");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->CANRead1_P1_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK_o);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK_o);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S65>/CAN Read1 (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((boolean_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((CAN_DATATYPE *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CANRead1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "CAN Read1");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 3/CAN Read1");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->CANRead1_P1_Size_n);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANRead1_PWORK);
      }

      /* registration */
      sg_IO602_IO691_read_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S5>/Setup  (sg_IO191_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [2]);
      }

      /* path info */
      ssSetModelName(rts, "Setup ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Setup ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P9_Size);
      }

      /* work vectors */
      ssSetRWork(rts, (real_T *)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_RWORK
                 [0]);
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 2);

        /* RWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_RWORK
                   [0]);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Setup_PWORK);
      }

      /* registration */
      sg_IO191_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S5>/Analog input  (sg_IO191_ad_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [3]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 4);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IO191_AI_CH4));
        }
      }

      /* path info */
      ssSetModelName(rts, "Analog input ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Analog input ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analoginput_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_IWORK
                 [0]);
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 2);

        /* IWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_IWORK
                   [0]);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analoginput_PWORK);
      }

      /* registration */
      sg_IO191_ad_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S5>/Digital input  (sg_IO191_di_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidthAsInt(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o4));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidthAsInt(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o5));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidthAsInt(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o6));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidthAsInt(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o7));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidthAsInt(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o8));
        }
      }

      /* path info */
      ssSetModelName(rts, "Digital input ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Digital input ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 4);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P4_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK);
      }

      /* registration */
      sg_IO191_di_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S5>/Analog output  (sg_IO191_da_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[5]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [5]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 4);
        ssSetPortInfoForInputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.inputPortInfo
          [0]);
        ssSetPortInfoForInputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.inputPortInfo
          [0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.inputPortUnits
          [0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_1_G);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Ausgabe_Gaspedal_FP_2_G);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidthAsInt(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_1_G);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidthAsInt(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_2_G);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidthAsInt(rts, 3, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Analog output ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Analog output ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Analogoutput_P7_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analogoutput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn5.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Analogoutput_PWORK);
      }

      /* registration */
      sg_IO191_da_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Isolated digital input  (sg_IO291_di_isol_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[6]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [6]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [6]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 3);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidthAsInt(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Isolateddigitalinput_o3));
        }
      }

      /* path info */
      ssSetModelName(rts, "Isolated digital input ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/Isolated digital input ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Isolateddigitalinput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Isolateddigitalinput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Isolateddigitalinput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Isolateddigitalinput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Isolateddigitalinput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Isolateddigitalinput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Isolateddigitalinput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn6.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Isolateddigitalinput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_di_isol_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S5>/Digital output  (sg_IO191_do_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[7]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [7]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 8);
        ssSetPortInfoForInputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortInfo
          [0]);
        ssSetPortInfoForInputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortInfo
          [0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortUnits
          [0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        ssSetInputPortUnit(rts, 4, 0);
        ssSetInputPortUnit(rts, 5, 0);
        ssSetInputPortUnit(rts, 6, 0);
        ssSetInputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);
        ssSetInputPortIsContinuousQuantity(rts, 4, 0);
        ssSetInputPortIsContinuousQuantity(rts, 5, 0);
        ssSetInputPortIsContinuousQuantity(rts, 6, 0);
        ssSetInputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_1_On);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.FP_FET_2_On);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidthAsInt(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_1_On);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidthAsInt(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LG_FET_2_On);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidthAsInt(rts, 3, 1);
        }

        /* port 4 */
        {
          ssSetInputPortRequiredContiguous(rts, 4, 1);
          ssSetInputPortSignal(rts, 4,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Br_Licht_On);
          _ssSetInputPortNumDimensions(rts, 4, 1);
          ssSetInputPortWidthAsInt(rts, 4, 1);
        }

        /* port 5 */
        {
          ssSetInputPortRequiredContiguous(rts, 5, 1);
          ssSetInputPortSignal(rts, 5,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant);
          _ssSetInputPortNumDimensions(rts, 5, 1);
          ssSetInputPortWidthAsInt(rts, 5, 1);
        }

        /* port 6 */
        {
          ssSetInputPortRequiredContiguous(rts, 6, 1);
          ssSetInputPortSignal(rts, 6,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant);
          _ssSetInputPortNumDimensions(rts, 6, 1);
          ssSetInputPortWidthAsInt(rts, 6, 1);
        }

        /* port 7 */
        {
          ssSetInputPortRequiredContiguous(rts, 7, 1);
          ssSetInputPortSignal(rts, 7,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant);
          _ssSetInputPortNumDimensions(rts, 7, 1);
          ssSetInputPortWidthAsInt(rts, 7, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Digital output ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191/Digital output ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitaloutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitaloutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitaloutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitaloutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitaloutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitaloutput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitaloutput_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn7.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitaloutput_PWORK);
      }

      /* registration */
      sg_IO191_do_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);
      _ssSetInputPortConnected(rts, 4, 1);
      _ssSetInputPortConnected(rts, 5, 1);
      _ssSetInputPortConnected(rts, 6, 1);
      _ssSetInputPortConnected(rts, 7, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
      ssSetInputPortBufferDstPort(rts, 4, -1);
      ssSetInputPortBufferDstPort(rts, 5, -1);
      ssSetInputPortBufferDstPort(rts, 6, -1);
      ssSetInputPortBufferDstPort(rts, 7, -1);
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/Setup  (sg_IO291_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[8]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [8]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [8]);
      }

      /* path info */
      ssSetModelName(rts, "Setup ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/Setup ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P1_Size_k);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P3_Size_j);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P4_Size_g);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Setup_P5_Size_e);
      }

      /* registration */
      sg_IO291_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S7>/Digital input (sg_fpga_di_sf_a2) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[9]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [9]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[9]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[9]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[9]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[9]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [9]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortInfo
          [0]);
        ssSetPortInfoForOutputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortInfo
          [0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortUnits
          [0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.outputPortCoSimAttribute
          [0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidthAsInt(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o1_p));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidthAsInt(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Digitalinput_o2_b));
        }
      }

      /* path info */
      ssSetModelName(rts, "Digital input");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO397/Digital input");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P1_Size_h);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P2_Size_g);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P3_Size_n);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P4_Size_m);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->Digitalinput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK_i
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn9.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Digitalinput_PWORK_i
                   [0]);
      }

      /* registration */
      sg_fpga_di_sf_a2(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/FET digital output  (sg_IO291_do_fet_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [10];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[10]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [10]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[10]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[10]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[10]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[10]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [10]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 5);
        ssSetPortInfoForInputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortInfo
          [0]);
        ssSetPortInfoForInputs(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortInfo
          [0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortUnits
          [0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        ssSetInputPortUnit(rts, 4, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);
        ssSetInputPortIsContinuousQuantity(rts, 4, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion_g);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidthAsInt(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DataTypeConversion1_c);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidthAsInt(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Reverse);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidthAsInt(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LED_Totmann);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidthAsInt(rts, 3, 1);
        }

        /* port 4 */
        {
          ssSetInputPortRequiredContiguous(rts, 4, 1);
          ssSetInputPortSignal(rts, 4,
                               &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Taster_Freigabe);
          _ssSetInputPortNumDimensions(rts, 4, 1);
          ssSetInputPortWidthAsInt(rts, 4, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "FET digital output ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/FET digital output ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->FETdigitaloutput_P8_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FETdigitaloutput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn10.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FETdigitaloutput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_do_fet_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);
      _ssSetInputPortConnected(rts, 4, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
      ssSetInputPortBufferDstPort(rts, 4, -1);
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/LVTTL digital input  (sg_IO291_di_ttl_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [11];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[11]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [11]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[11]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[11]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[11]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[11]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [11]);
      }

      /* path info */
      ssSetModelName(rts, "LVTTL digital input ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/LVTTL digital input ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitalinput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitalinput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitalinput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitalinput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitalinput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitalinput_P6_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitalinput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn11.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitalinput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_di_ttl_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S6>/LVTTL digital output  (sg_IO291_do_ttl_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [12];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[12]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [12]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[12]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[12]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[12]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[12]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [12]);
      }

      /* path info */
      ssSetModelName(rts, "LVTTL digital output ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS/LVTTL digital output ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.params;
        ssSetSFcnParamsCount(rts, 8);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->LVTTLdigitaloutput_P8_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitaloutput_PWORK
                 [0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn12.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.LVTTLdigitaloutput_PWORK
                   [0]);
      }

      /* registration */
      sg_IO291_do_ttl_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/<S8>/CAN Setup  (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [13];

      /* timing info */
      time_T *sfcnPeriod =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.sfcnPeriod;
      time_T *sfcnOffset =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.sfcnOffset;
      int_T *sfcnTsMap =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.sfcnTsMap;
      (void) std::memset(static_cast<void*>(sfcnPeriod), 0,
                         sizeof(time_T)*1);
      (void) std::memset(static_cast<void*>(sfcnOffset), 0,
                         sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.blkInfo2[13]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.inputOutputPortInfo2
        [13]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods2[13]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods3[13]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts,
                           &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M
                           ->NonInlinedSFcns.methods4[13]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->
                         NonInlinedSFcns.statesInfo2[13]);
        ssSetPeriodicStatesInfo(rts,
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.periodicStatesInfo
          [13]);
      }

      /* path info */
      ssSetModelName(rts, "CAN Setup ");
      ssSetPath(rts,
                "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Setup ");
      ssSetRTModel(rts,D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.params;
        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->CANSetup_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->CANSetup_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       D_20230119_Modell_Inbetrieb_cal->CANSetup_P3_Size);
      }

      /* work vectors */
      ssSetPWork(rts, (void **)
                 &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANSetup_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->NonInlinedSFcns.Sfcn13.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        ssSetNumDWorkAsInt(rts, 1);

        /* PWORK */
        ssSetDWorkWidthAsInt(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0,
                   &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.CANSetup_PWORK);
      }

      /* registration */
      sg_IO602_IO691_setup_s(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCsAsInt(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }
  }

  {
    /* user code (Start function Header) */
    {
      uint16_t moduleArchitecture;
      int32_t ErrCode;
      uint32_t *bitstream, i;
      uint8_t *fpgacode;
      char *devname;
      sg_fpga_io3xxModuleIdT moduleId;
      FILE *mcs;
      static char mcsFileName[200];
      static char msg[256];
      sg_initModelRun();

      // Determine path to bitstream file
      if (sg_getModelBaseDir(mcsFileName, sizeof(mcsFileName))) {
        sprintf(msg,
                "Could not determine location of the model on the target machine.");
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        return;
      }

      if ((strlen(mcsFileName) + strlen("/fpga/speedgoat_IO397_50k_Comms.mcs") +
           1) > sizeof(mcsFileName)) {
        sprintf(msg,
                "Path to the bitstream (model name + bitstream name) is too long.");
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        return;
      }

      strcat(mcsFileName, "/fpga/speedgoat_IO397_50k_Comms.mcs");
      SG_PRINTF(DEBUG, "Bitstream: %s\n", mcsFileName);
      if ((mcs = fopen(mcsFileName, "r")) == NULL) {
        sprintf(msg, "Bitstream file not found at %s.\n", mcsFileName);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      bitstream = (uint32_t *) malloc(2192012*sizeof(uint32_t));
      fpgacode = (uint8_t *) malloc(2192012*sizeof(uint8_t));
      for (i = 0; i<2192012; i++) {
        fscanf(mcs,"%d\n",&bitstream[i]);
        fpgacode[i] = bitstream[i];
      }

      fclose(mcs);

      // Get module IDs (PIC info)
      SG_PRINTF(INFO,"Getting module information.\n");
      ErrCode = (int32_t)sg_fpga_IO3xxGetModuleId(39750, &moduleId);
      if (ErrCode >= 0) {
        devname = moduleId.devname;
        moduleArchitecture = moduleId.moduleArchitecture;
        SG_PRINTF(DEBUG, "boardType: %d\n", 39750);
        SG_PRINTF(DEBUG, "ErrCode: %d\n", ErrCode);
        SG_PRINTF(DEBUG, "******************************************\n");
        SG_PRINTF(DEBUG, "moduleId->devname: %s\n", moduleId.devname);
        SG_PRINTF(DEBUG, "moduleId->vendorid: 0x%x\n", moduleId.vendorid);
        SG_PRINTF(DEBUG, "moduleId->subvendorid: 0x%x\n", moduleId.subvendorid);
        SG_PRINTF(DEBUG, "moduleId->deviceid: 0x%x\n", moduleId.deviceid);
        SG_PRINTF(DEBUG, "moduleId->subdeviceid: 0x%x\n", moduleId.subdeviceid);
        SG_PRINTF(DEBUG, "moduleId.moduleArchitecture: %d\n",
                  moduleId.moduleArchitecture);
      } else {
        sprintf(msg, "Setup block: board type unknown.");
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      // Support for different architectures
      SG_PRINTF(INFO,"Running board specific programming file.\n");
      switch (moduleArchitecture)
      {
       case TEWS_TPMC:
        ErrCode = IO30x_programFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (int32_t)0, (uint32_t)2192012, bitstream,
          &moduleId);
        break;

       case TEWS_TXMC:
        if (39750 == 324200) {
          ErrCode = IO324_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            (uint32_t)-517031625, &moduleId, (uint32_t)84,
            (uint32_t)0);
        } else                         // IO31x, IO32x
        {
          ErrCode = IO31x_IO32x_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (int32_t)0, (uint32_t)2192012, fpgacode,
            &moduleId, (uint32_t)84);
        }
        break;

       case ACROMAG_PMC:
        ErrCode = IO331_programmFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (uint32_t)2192012, bitstream, &moduleId);
        break;

       case ACROMAG_XMC:
        if (39750 == 332) {
          ErrCode = IO332_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (uint32_t)2192012, bitstream, (uint32_t)-517031625,
            &moduleId);
        } else                         // IO333
        {
          ErrCode = IO333_programmFPGA(devname, (int16_t)-1,
            (int16_t)-1, (int32_t)1, (int32_t)1,
            (uint32_t)2192012, bitstream, (uint32_t)-517031625,
            &moduleId);
        }
        break;

       case TEWS_MPCIE:
        ErrCode = IO39x_programmFPGA(devname, (int16_t)-1, (int16_t)-1,
          (int32_t)1, (int32_t)1,
          (uint32_t)2192012, fpgacode, (uint32_t)84, &moduleId);
        break;

       default:
        sprintf(msg, "Setup block: module architecture incorrect.");
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);

        // Free the bitstream allocation
        SG_PRINTF(ERROR,msg);
        free(bitstream);
        free(fpgacode);
        return;
      }

      // Free the bitstream allocation
      free(bitstream);
      free(fpgacode);

      // Handle any error states
      switch (ErrCode)
      {
       case NO_ERR:
        // Nothing to do.
        break;

       case BOARD_NOT_FOUND:
        sprintf(msg, "Setup block %s: Board could not be found.\n",devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case EEPROM_ERROR:
        sprintf(msg, "Setup block %s: Error updating board EEPROM.\n", devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case REPROG_ERROR:
        sprintf(msg, "Setup block %s: Error writing new bitstream to FPGA.\n",
                devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case FLASH_ERROR:
        sprintf(msg, "Setup block %s: Bitstream flash storage error.\n", devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case BIST_ERROR:
        sprintf(msg, "Setup block %s: Built in self test error.\n", devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case ICAP_RECONF_FAILED:
        sprintf(msg,
                "Setup block %s: ICAP Reconfiguration was not successful.\n",
                devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       case BOARD_TYPE_UNKNOWN:
        sprintf(msg, "Setup block %s: The board type selected is unknown.\n",
                devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;

       default:
        sprintf(msg, "Setup block %s: An unknown error occurred.\n",devname);
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          msg);
        SG_PRINTF(ERROR,msg);
        return;
      }

      if (1 == 2) {
        IO3xx_21_update(devname, 1, 0, 0, 0);
      } else if (1 == 3) {
        IO3xx_22_update(devname, 1, 0, 0, 0);
      } else if (1 == 4) {
        IO3xx_24_update(devname, 1, 0, 0, 0, 0);
      }
    }

    /* Start for S-Function (sg_IO191_setup_s): '<S5>/Setup ' */
    /* Level2 S-Function Block: '<S5>/Setup ' (sg_IO191_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO191_ad_s): '<S5>/Analog input ' */
    /* Level2 S-Function Block: '<S5>/Analog input ' (sg_IO191_ad_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO191_di_s): '<S5>/Digital input ' */
    /* Level2 S-Function Block: '<S5>/Digital input ' (sg_IO191_di_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition generated from: '<S3>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1 =
      D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_InitialCo;

    /* Start for S-Function (slrealtimeUDPReceive): '<S2>/UDP Receive1' */
    {
      try {
        uint8_t *tempAddr = nullptr;
        uint8_t *tempInterface = nullptr;
        slrealtime::ip::udp::Socket *udpSock = (slrealtime::ip::udp::Socket *)
          slrealtime::ip::SocketFactory::createSocket(slrealtime::ip::SocketType::
          UDP, "0.0.0.0",25001U);
        if (tempAddr)
          delete tempAddr;
        if (tempInterface)
          delete tempInterface;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_IWORK[
          0] = 12;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK[
          0] = reinterpret_cast<void*>(udpSock);
        char *buffer = (char *)calloc(65507,sizeof(char));
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK[
          1] = (void*)buffer;
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }

    /* Start for InitialCondition: '<S2>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_b
      = true;

    /* Start for InitialCondition: '<S11>/IC' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime =
      (rtMinusInf);

    /* Start for InitialCondition: '<S3>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime =
      (rtMinusInf);

    /* Start for InitialCondition: '<S3>/IC3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime =
      (rtMinusInf);

    /* Start for InitialCondition: '<S2>/IC' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC_FirstOutputTime_j =
      true;

    /* Start for InitialCondition: '<S11>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime =
      (rtMinusInf);

    /* Start for InitialCondition: '<S9>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c
      = (rtMinusInf);

    /* Start for InitialCondition: '<S9>/IC3' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC3_FirstOutputTime_f
      = (rtMinusInf);

    /* Start for S-Function (sg_IO191_da_s): '<S5>/Analog output ' */
    /* Level2 S-Function Block: '<S5>/Analog output ' (sg_IO191_da_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_di_isol_s): '<S6>/Isolated digital input ' */
    /* Level2 S-Function Block: '<S6>/Isolated digital input ' (sg_IO291_di_isol_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for Constant: '<S4>/Constant8' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Br_Licht_On =
      D_20230119_Modell_Inbetrieb_cal->Constant8_Value;

    /* Start for Constant: '<S5>/Constant' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Constant =
      D_20230119_Modell_Inbetrieb_cal->Constant_Value_hc;

    /* Start for S-Function (sg_IO191_do_s): '<S5>/Digital output ' */
    /* Level2 S-Function Block: '<S5>/Digital output ' (sg_IO191_do_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_setup_s): '<S6>/Setup ' */
    /* Level2 S-Function Block: '<S6>/Setup ' (sg_IO291_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for RateTransition generated from: '<S1>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSwitchInport1_i
      = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_Initial_j;

    /* Start for S-Function (sg_fpga_di_sf_a2): '<S7>/Digital input' */
    /* Level2 S-Function Block: '<S7>/Digital input' (sg_fpga_di_sf_a2) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for InitialCondition: '<S15>/IC1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC1_FirstOutputTime_d
      = (rtMinusInf);

    /* Start for InitialCondition: '<S15>/IC2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.IC2_FirstOutputTime_c4
      = (rtMinusInf);

    /* Start for Constant: '<S4>/Constant13' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Reverse =
      D_20230119_Modell_Inbetrieb_cal->Constant13_Value;

    /* Start for DiscretePulseGenerator: '<S45>/Pulse Generator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.clockTickCounter = 0;

    /* Start for S-Function (sg_IO291_do_fet_s): '<S6>/FET digital output ' */
    /* Level2 S-Function Block: '<S6>/FET digital output ' (sg_IO291_do_fet_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [10];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_di_ttl_s): '<S6>/LVTTL digital input ' */
    /* Level2 S-Function Block: '<S6>/LVTTL digital input ' (sg_IO291_di_ttl_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [11];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO291_do_ttl_s): '<S6>/LVTTL digital output ' */
    /* Level2 S-Function Block: '<S6>/LVTTL digital output ' (sg_IO291_do_ttl_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [12];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (sg_IO602_IO691_setup_s): '<S8>/CAN Setup ' */
    /* Level2 S-Function Block: '<S8>/CAN Setup ' (sg_IO602_IO691_setup_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions
        [13];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

<<<<<<< .mine
    /* Start for RateTransition generated from: '<S11>/Transfer Fcn1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1
      = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtTransferFcn1Inport1_Ini;

    /* Start for RateTransition generated from: '<S11>/Transfer Fcn' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1
      = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtTransferFcnInport1_Init;

||||||| .r78
=======
    /* Start for RateTransition generated from: '<S9>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Autonom_ON =
      D_20230119_Modell_Inbetrieb_cal->Autonom_ON_InitialCondition;

    /* Start for RateTransition generated from: '<S9>/Switch' */
    rtw_slrealtime_mutex_init
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_d0_SEMAPHORE);

    /* Start for RateTransition: '<S66>/RT' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RT_i =
      D_20230119_Modell_Inbetrieb_cal->RT_InitialCondition;

    /* Start for RateTransition generated from: '<S66>/Add2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtAdd2Inport1 =
      D_20230119_Modell_Inbetrieb_cal->TmpRTBAtAdd2Inport1_InitialCond;

    /* Start for RateTransition generated from: '<S110>/Sum' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSumInport1 =
      D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSumInport1_InitialCondi;

    /* Start for RateTransition generated from: '<S96>/SumD' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtSumDInport1 =
      D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSumDInport1_InitialCond;

    /* Start for RateTransition generated from: '<S92>/Equal1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtEqual1Inport2 =
      D_20230119_Modell_Inbetrieb_cal->TmpRTBAtEqual1Inport2_InitialCo;

    /* Start for RateTransition generated from: '<S11>/Transfer Fcn1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcn1Inport1
      = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtTransferFcn1Inport1_Ini;

    /* Start for RateTransition generated from: '<S11>/Transfer Fcn' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.TmpRTBAtTransferFcnInport1
      = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtTransferFcnInport1_Init;

>>>>>>> .r84
    /* Start for S-Function (slrealtimeUDPReceive): '<S10>/From Jetson' */
    {
      try {
        uint8_t *tempAddr = nullptr;
        uint8_t *tempInterface = nullptr;
        slrealtime::ip::udp::Socket *udpSock = (slrealtime::ip::udp::Socket *)
          slrealtime::ip::SocketFactory::createSocket(slrealtime::ip::SocketType::
          UDP, "10.42.0.10",5500U);
        if (tempAddr)
          delete tempAddr;
        if (tempInterface)
          delete tempInterface;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_IWORK
          [0] = 48;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
          [0] = reinterpret_cast<void*>(udpSock);
        char *buffer = (char *)calloc(65507,sizeof(char));
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK
          [1] = (void*)buffer;
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }

    /* Start for S-Function (slrealtimeUDPSend): '<S2>/UDP Send' */
    {
      try {
        slrealtime::ip::udp::Socket *udpSock = (slrealtime::ip::udp::Socket *)
          slrealtime::ip::SocketFactory::createSocket(slrealtime::ip::SocketType::
          UDP,"0.0.0.0",25000U);
        uint8_t *remoteAddress = (uint8_t *)
          D_20230119_Modell_Inbetrieb_cal->UDPSend_toAddress;
        uint16_t *remotePort = (uint16_t *)
          &D_20230119_Modell_Inbetrieb_cal->UDPSend_toPort;
        udpSock->setRemoteEndpoint(remoteAddress, remotePort[0]);
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK[0] =
          24;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_IWORK[1] =
          25000U;
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPSend_PWORK =
          reinterpret_cast<void*>(udpSock);
      } catch (std::exception& e) {
        std::string tmp = std::string(e.what());
        static std::string eMsg = tmp;
        rtmSetErrorStatus(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M,
                          eMsg.c_str());
        rtmSetStopRequested
          (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, 1);
        ;
      }
    }
  }

  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.Integrator_Reset_ZCE
    = UNINITIALIZED_ZCSIG;
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX.TriggeredSubsystem_Trig_ZCE
    = POS_ZCSIG;

  {
    packLaneMarkerBus_D_20230119__T *b_obj;

    /* InitializeConditions for RateTransition generated from: '<S3>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_InitialCo;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufIdx
      = 1;

    /* InitializeConditions for S-Function (sfix_udelay): '<S41>/Tapped Delay1' */
    for (int32_T i = 0; i < 199; i++) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X[i] =
        D_20230119_Modell_Inbetrieb_cal->TappedDelay1_vinit;
    }

    /* End of InitializeConditions for S-Function (sfix_udelay): '<S41>/Tapped Delay1' */

    /* InitializeConditions for TransferFcn: '<S11>/Transfer Fcn' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn_CSTATE =
      0.0;

    /* InitializeConditions for TransferFcn: '<S11>/Transfer Fcn1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.TransferFcn1_CSTATE =
      0.0;

    /* InitializeConditions for Integrator: '<S45>/Integrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE =
      D_20230119_Modell_Inbetrieb_cal->Integrator_IC;

    /* InitializeConditions for S-Function (sfix_udelay): '<S56>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[0] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S57>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[0] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for S-Function (sfix_udelay): '<S56>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[1] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S57>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[1] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for S-Function (sfix_udelay): '<S56>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[2] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S57>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[2] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for S-Function (sfix_udelay): '<S56>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X[3] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit;

    /* InitializeConditions for S-Function (sfix_udelay): '<S57>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_m[3] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_h;

    /* InitializeConditions for DiscreteIntegrator: '<S49>/Discrete-Time Integrator2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_DSTATE
      = D_20230119_Modell_Inbetrieb_cal->DiscreteTimeIntegrator2_IC;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DiscreteTimeIntegrator2_PrevRes
      = 2;

    /* InitializeConditions for UnitDelay: '<S44>/Unit Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_e =
      D_20230119_Modell_Inbetrieb_cal->UnitDelay_InitialCondition_j;

    /* InitializeConditions for Memory: '<S44>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput =
      D_20230119_Modell_Inbetrieb_cal->Memory_InitialCondition;

    /* InitializeConditions for RateTransition generated from: '<S1>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_Buf_e
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport1_Initial_j;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_WrBufId_g
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport1_RdBufId_g
      = 1;

    /* InitializeConditions for UnitDelay: '<S15>/Unit Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE_c =
      D_20230119_Modell_Inbetrieb_cal->UnitDelay_InitialCondition_p;

    /* InitializeConditions for UnitDelay: '<S25>/Unit Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay1_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->UnitDelay1_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S25>/Unit Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UnitDelay_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->UnitDelay_InitialCondition;

    /* InitializeConditions for Delay: '<S16>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->Delay1_InitialCondition;

    /* InitializeConditions for Delay: '<S17>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_o =
      D_20230119_Modell_Inbetrieb_cal->Delay1_InitialCondition_i;

    /* InitializeConditions for UnitDelay: '<S29>/Delay Input1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->DetectIncrease_vinit;

    /* InitializeConditions for UnitDelay: '<S31>/Delay Input1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_b =
      D_20230119_Modell_Inbetrieb_cal->DetectIncrease_vinit_h;

    /* InitializeConditions for Memory: '<S35>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_o
      = D_20230119_Modell_Inbetrieb_cal->EdgeDetector_ic;

    /* InitializeConditions for Delay: '<S46>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_DSTATE_p =
      D_20230119_Modell_Inbetrieb_cal->Delay1_InitialCondition_e;

    /* InitializeConditions for UnitDelay: '<S53>/Delay Input1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.DelayInput1_DSTATE_j =
      D_20230119_Modell_Inbetrieb_cal->DetectIncrease_vinit_e;

    /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[0] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[0] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S50>/Tapped Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[0] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;

    /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[1] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[1] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S50>/Tapped Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[1] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;

    /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[2] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[2] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S50>/Tapped Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[2] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;

    /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_b[3] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_hn;

    /* InitializeConditions for S-Function (sfix_udelay): '<S14>/Tapped Delay' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay_X_d[3] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay_vinit_c;

    /* InitializeConditions for S-Function (sfix_udelay): '<S50>/Tapped Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TappedDelay1_X_c[3] =
      D_20230119_Modell_Inbetrieb_cal->TappedDelay1_vinit_e;

    /* InitializeConditions for Memory: '<S44>/Memory1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory1_PreviousInput
      = D_20230119_Modell_Inbetrieb_cal->Memory1_InitialCondition;

    /* InitializeConditions for Memory: '<S51>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_d
      = D_20230119_Modell_Inbetrieb_cal->SRFlipFlop_initial_condition;

    /* InitializeConditions for RateTransition generated from: '<S9>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_Buf0 =
      D_20230119_Modell_Inbetrieb_cal->Autonom_ON_InitialCondition;

    /* InitializeConditions for RateTransition: '<S66>/RT' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_Buf[0] =
      D_20230119_Modell_Inbetrieb_cal->RT_InitialCondition;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_WrBufIdx = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT_RdBufIdx = 1;

    /* InitializeConditions for RateTransition: '<S66>/RT1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_Buf[0] =
      D_20230119_Modell_Inbetrieb_cal->RT1_InitialCondition;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_WrBufIdx = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RT1_RdBufIdx = 1;

    /* InitializeConditions for RateTransition generated from: '<S66>/Add2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtAdd2Inport1_InitialCond;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAdd2Inport1_RdBufIdx
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S110>/Sum' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSumInport1_InitialCondi;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumInport1_RdBufIdx
      = 1;

    /* InitializeConditions for Integrator: '<S101>/Integrator' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Integrator_CSTATE_i =
      D_20230119_Modell_Inbetrieb_cal->PIDController_InitialConditio_g;

    /* InitializeConditions for RateTransition generated from: '<S96>/SumD' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSumDInport1_InitialCond;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSumDInport1_RdBufIdx
      = 1;

    /* InitializeConditions for Integrator: '<S96>/Filter' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X.Filter_CSTATE =
      D_20230119_Modell_Inbetrieb_cal->PIDController_InitialConditionF;

    /* InitializeConditions for RateTransition generated from: '<S92>/Equal1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtEqual1Inport2_InitialCo;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtEqual1Inport2_RdBufIdx
      = 1;

    /* InitializeConditions for Memory: '<S92>/Memory' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Memory_PreviousInput_b
      = D_20230119_Modell_Inbetrieb_cal->Memory_InitialCondition_g;

<<<<<<< .mine
||||||| .r78
    /* InitializeConditions for RateTransition: '<S10>/Rate Transition1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[0]
      = D_20230119_Modell_Inbetrieb_cal->RateTransition1_InitialConditio;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
      = 1;

=======
    /* InitializeConditions for RateTransition generated from: '<S92>/Switch' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtSwitchInport3_InitialCo;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtSwitchInport3_RdBufIdx
      = 1;

>>>>>>> .r84
    /* InitializeConditions for RateTransition: '<S10>/Rate Transition2' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_Buf[0]
      = D_20230119_Modell_Inbetrieb_cal->RateTransition2_InitialConditio;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition2_RdBufIdx
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S11>/Transfer Fcn1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtTransferFcn1Inport1_Ini;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_WrB
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcn1Inport1_RdB
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S11>/Transfer Fcn' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtTransferFcnInport1_Init;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_WrBu
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtTransferFcnInport1_RdBu
      = 1;

    /* InitializeConditions for RateTransition generated from: '<S2>/Byte Packing' */
    for (int32_T i = 0; i < 24; i++) {
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_Buf
        [i] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtBytePackingOutport1_Ini;
    }

    struct_AzXAydn5whPkCj5deW4WYB expl_temp;
    real_T Camera_NumColumns;
    real_T Camera_NumRows;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_WrB
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtBytePackingOutport1_RdB
      = 1;

    /* End of InitializeConditions for RateTransition generated from: '<S2>/Byte Packing' */

<<<<<<< .mine
    /* InitializeConditions for RateTransition: '<S10>/Rate Transition1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[0]
      = D_20230119_Modell_Inbetrieb_cal->RateTransition1_InitialConditio;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
      = 1;

||||||| .r78
=======
    /* InitializeConditions for RateTransition generated from: '<S66>/Add' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_Buf
      [0] = D_20230119_Modell_Inbetrieb_cal->TmpRTBAtAddInport1_InitialCondi;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.TmpRTBAtAddInport1_RdBufIdx
      = 1;

    /* InitializeConditions for RateTransition: '<S10>/Rate Transition1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_Buf[0]
      = D_20230119_Modell_Inbetrieb_cal->RateTransition1_InitialConditio;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_WrBufIdx
      = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.RateTransition1_RdBufIdx
      = 1;

>>>>>>> .r84
    /* InitializeConditions for RateTransition generated from: '<Root>/S-Function Builder' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_Buf[0] =
      D_20230119_Modell_Inbetrieb_cal->Odometer_InitialCondition;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_WrBufIdx = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Odometer_RdBufIdx = 1;

    /* InitializeConditions for RateTransition generated from: '<Root>/S-Function Builder' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_Buf[0] =
      D_20230119_Modell_Inbetrieb_cal->SoC_InitialCondition;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_WrBufIdx = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.SoC_RdBufIdx = 1;

    /* InitializeConditions for Delay generated from: '<S119>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_4_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->Delay1_4_InitialCondition;

    /* InitializeConditions for Delay generated from: '<S119>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_3_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->Delay1_3_InitialCondition;

    /* InitializeConditions for Delay generated from: '<S119>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_2_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->Delay1_2_InitialCondition;

    /* InitializeConditions for Delay generated from: '<S119>/Delay1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Delay1_1_DSTATE =
      D_20230119_Modell_Inbetrieb_cal->Delay1_1_InitialCondition;

    /* Start for S-Function (sg_IO602_IO691_read_s): '<S64>/CAN Read1' */
    /* Level2 S-Function Block: '<S64>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack' */

    /*-----------S-Function Block: <S64>/CAN Unpack -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack1' */

    /*-----------S-Function Block: <S64>/CAN Unpack1 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack2' */

    /*-----------S-Function Block: <S64>/CAN Unpack2 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack3' */

    /*-----------S-Function Block: <S64>/CAN Unpack3 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack4' */

    /*-----------S-Function Block: <S64>/CAN Unpack4 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack5' */

    /*-----------S-Function Block: <S64>/CAN Unpack5 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack6' */

    /*-----------S-Function Block: <S64>/CAN Unpack6 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack7' */

    /*-----------S-Function Block: <S64>/CAN Unpack7 -----------------*/

    /* Start for S-Function (scanunpack): '<S64>/CAN Unpack8' */

    /*-----------S-Function Block: <S64>/CAN Unpack8 -----------------*/

    /* SystemInitialize for Gain: '<S64>/Gain' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.ChargeRequest =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.ChargeRequest;

    /* SystemInitialize for Gain: '<S64>/Gain1' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.IBatt =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.IBatt;

    /* SystemInitialize for Gain: '<S64>/Gain2' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL15 =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.V_KL15;

    /* SystemInitialize for Gain: '<S64>/Gain3' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.V_KL30 =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.V_KL30;

    /* SystemInitialize for Gain: '<S64>/Gain4' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BMSStatus =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.BMSStatus;

    /* SystemInitialize for Gain: '<S64>/Gain5' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.InverterStatus =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.InverterStatus;

    /* SystemInitialize for Gain: '<S64>/Gain6' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorSpeed =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.eMotorSpeed;

    /* SystemInitialize for Gain: '<S64>/Gain7' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.eMotorTorque =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.eMotorTorque;

    /* SystemInitialize for Gain: '<S64>/Gain8' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Distance =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Distance;

    /* SystemInitialize for Gain: '<S64>/Gain9' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceTotal =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.DistanceTotal;

    /* SystemInitialize for Gain: '<S64>/Gain10' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Range =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Range;

    /* SystemInitialize for Gain: '<S64>/Gain11' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CarSpeed =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.CarSpeed;

    /* SystemInitialize for Gain: '<S64>/Gain12' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.SoC_b =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.SoC;

    /* SystemInitialize for Gain: '<S64>/Gain13' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.BrakePedal =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.BrakePedal;

    /* SystemInitialize for Gain: '<S64>/Gain14' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DriveMode =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.DriveMode;

    /* SystemInitialize for Gain: '<S64>/Gain15' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.DistanceToral_24Bit =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.DistanceToral_24Bit;

    /* SystemInitialize for Gain: '<S64>/Gain16' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.VehicleSpeedFromABS =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.VehicleSpeedFromABS;

    /* SystemInitialize for Gain: '<S64>/Gain17' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FL =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_FL;

    /* SystemInitialize for Gain: '<S64>/Gain18' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_FR =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_FR;

    /* SystemInitialize for Gain: '<S64>/Gain19' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RL =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_RL;

    /* SystemInitialize for Gain: '<S64>/Gain20' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Wheel_Speed_RR =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Wheel_Speed_RR;

    /* SystemInitialize for Gain: '<S64>/Gain21' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Handbremse =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Handbremse;

    /* SystemInitialize for Gain: '<S64>/Gain22' incorporates:
     *  Outport: '<S64>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Odometer_e =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0.Odometer;

    /* End of SystemInitialize for SubSystem: '<S8>/CAN Read Loop - Port 1' */
    /* Start for S-Function (sg_IO602_IO691_read_s): '<S65>/CAN Read1' */
    /* Level2 S-Function Block: '<S65>/CAN Read1' (sg_IO602_IO691_read_s) */
    {
      SimStruct *rts =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (scanunpack): '<S65>/CAN Unpack' */

    /*-----------S-Function Block: <S65>/CAN Unpack -----------------*/

    /* Start for S-Function (scanunpack): '<S65>/CAN Unpack1' */

    /*-----------S-Function Block: <S65>/CAN Unpack1 -----------------*/

    /* Start for S-Function (scanunpack): '<S65>/CAN Unpack2' */

    /*-----------S-Function Block: <S65>/CAN Unpack2 -----------------*/

    /* Start for S-Function (scanunpack): '<S65>/CAN Unpack4' */

    /*-----------S-Function Block: <S65>/CAN Unpack4 -----------------*/

    /* Start for S-Function (scanunpack): '<S65>/CAN Unpack5' */

    /*-----------S-Function Block: <S65>/CAN Unpack5 -----------------*/

    /* SystemInitialize for Gain: '<S65>/Gain' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Lenkwinkel_p =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Lenkwinkel;

    /* SystemInitialize for Gain: '<S65>/Gain1' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AY =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.AY;

    /* SystemInitialize for Gain: '<S65>/Gain2' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierrate =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Gierrate;

    /* SystemInitialize for Gain: '<S65>/Gain3' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.AX =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.AX;

    /* SystemInitialize for Gain: '<S65>/Gain4' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Gierbeschleunigung =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Gierbeschleunigung;

    /* SystemInitialize for SignalConversion generated from: '<S65>/Bus Creator2' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.isvalid = 0.0;

    /* SystemInitialize for SignalConversion generated from: '<S65>/Bus Creator2' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.radardatalength1788 =
      0.0;

    /* SystemInitialize for SignalConversion generated from: '<S65>/Bus Creator2' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Punkt =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Radar.Radar_Punkt;

    /* SystemInitialize for SignalConversion generated from: '<S65>/Bus Creator2' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_Mode =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Radar.Radar_Mode;

    /* SystemInitialize for Gain: '<S65>/Gain5' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLA =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HLA;

    /* SystemInitialize for Gain: '<S65>/Gain6' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HLM =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HLM;

    /* SystemInitialize for Gain: '<S65>/Gain7' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRA =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HRA;

    /* SystemInitialize for Gain: '<S65>/Gain8' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_HRM =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_HRM;

    /* SystemInitialize for Gain: '<S65>/Gain9' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLA =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VLA;

    /* SystemInitialize for Gain: '<S65>/Gain10' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VLM =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VLM;

    /* SystemInitialize for Gain: '<S65>/Gain11' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRA =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VRA;

    /* SystemInitialize for Gain: '<S65>/Gain12' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.USS_Sensor_VRM =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.USS.USS_Sensor_VRM;

    /* SystemInitialize for Gain: '<S65>/Gain13' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Fahrpedal =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.RC_Fahrpedal;

    /* SystemInitialize for Gain: '<S65>/Gain14' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RC_Lenkung =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.RC_Lenkung;

    /* SystemInitialize for SignalConversion generated from: '<S65>/Bus Creator' incorporates:
     *  Outport: '<S65>/CAN_Out'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Radar_2 =
      D_20230119_Modell_Inbetrieb_cal->CAN_Out_Y0_n.Radar_2;

    /* End of SystemInitialize for SubSystem: '<S8>/CAN Read Loop - Port 3' */

    /* SystemInitialize for Triggered SubSystem: '<S36>/Triggered Subsystem' */
    /* SystemInitialize for SignalConversion generated from: '<S39>/In1' incorporates:
     *  Outport: '<S39>/Out1'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.In1 =
      D_20230119_Modell_Inbetrieb_cal->Out1_Y0;

    /* End of SystemInitialize for SubSystem: '<S36>/Triggered Subsystem' */

    /* SystemInitialize for Enabled SubSystem: '<S35>/NEGATIVE Edge' */
    /* SystemInitialize for RelationalOperator: '<S37>/Relational Operator1' incorporates:
     *  Outport: '<S37>/OUT'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1_c =
      D_20230119_Modell_Inbetrieb_cal->OUT_Y0;

    /* End of SystemInitialize for SubSystem: '<S35>/NEGATIVE Edge' */

    /* SystemInitialize for Enabled SubSystem: '<S35>/POSITIVE Edge' */
    /* SystemInitialize for RelationalOperator: '<S38>/Relational Operator1' incorporates:
     *  Outport: '<S38>/OUT'
     */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.RelationalOperator1 =
      D_20230119_Modell_Inbetrieb_cal->OUT_Y0_l;

    /* End of SystemInitialize for SubSystem: '<S35>/POSITIVE Edge' */

    /* SystemInitialize for State Transition Table: '<S27>/State Transition Table' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.sfEvent =
      D_20230119_Modell_In_CALL_EVENT;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_active_c4_D_20230119_Modell_
      = 0U;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.is_c4_D_20230119_Modell_Inbetri
      = D_20230119_M_IN_NO_ACTIVE_CHILD;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_enable = 0.0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.count_dir = 0.0;

    /* SystemInitialize for Merge generated from: '<S119>/Merge1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.Curvature_a =
      D_20230119_Modell_Inbetrieb_cal->Merge1_1_InitialOutput;

    /* SystemInitialize for Merge generated from: '<S119>/Merge1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.CurvatureDerivative_m =
      D_20230119_Modell_Inbetrieb_cal->Merge1_2_InitialOutput;

    /* SystemInitialize for Merge generated from: '<S119>/Merge1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.HeadingAngle_l =
      D_20230119_Modell_Inbetrieb_cal->Merge1_3_InitialOutput;

    /* SystemInitialize for Merge generated from: '<S119>/Merge1' */
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B.LateralOffset_f =
      D_20230119_Modell_Inbetrieb_cal->Merge1_4_InitialOutput;

    /* SystemInitialize for Atomic SubSystem: '<S120>/Path Following Control System' */
    PathFollowingControlSy_Init
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.PathFollowingControlSystem_i,
       &D_20230119_Modell_Inbetrieb_cal->PathFollowingControlSystem_cal);

    /* End of SystemInitialize for SubSystem: '<S120>/Path Following Control System' */

    /* Start for MATLABSystem: '<S10>/PackLaneBus' */
    expl_temp = *get_camera();
    Camera_NumColumns = expl_temp.NumColumns;
    Camera_NumRows = expl_temp.NumRows;
    b_obj = &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;
    b_obj->isInitialized = 0;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.objisempty = true;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumColumns
      = Camera_NumColumns;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.NumRows =
      Camera_NumRows;
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [0] = expl_temp.FieldOfView[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FieldOfView
      [1] = expl_temp.FieldOfView[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [0] = expl_temp.ImageSize[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.ImageSize
      [1] = expl_temp.ImageSize[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [0] = expl_temp.PrincipalPoint[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PrincipalPoint
      [1] = expl_temp.PrincipalPoint[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [0] = expl_temp.FocalLength[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.FocalLength
      [1] = expl_temp.FocalLength[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[0]
      = expl_temp.Position[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[1]
      = expl_temp.Position[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Position[2]
      = expl_temp.Position[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [0] = expl_temp.PositionSim3d[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [1] = expl_temp.PositionSim3d[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.PositionSim3d
      [2] = expl_temp.PositionSim3d[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[0]
      = expl_temp.Rotation[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[1]
      = expl_temp.Rotation[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.Rotation[2]
      = expl_temp.Rotation[2];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [0] = expl_temp.DetectionRanges[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.DetectionRanges
      [1] = expl_temp.DetectionRanges[1];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [0] = expl_temp.LaneDetectionRanges[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.LaneDetectionRanges
      [1] = expl_temp.LaneDetectionRanges[1];
    std::memcpy
      (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MeasurementNoise
       [0], &expl_temp.MeasurementNoise[0], 9U * sizeof(real_T));
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [0] = expl_temp.MinObjectImageSize[0];
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj.Camera.MinObjectImageSize
      [1] = expl_temp.MinObjectImageSize[1];
    b_obj = &D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.obj;
    b_obj->isInitialized = 1;
  }
}

/* Model terminate function */
void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_terminate(void)
{
  /* Terminate for S-Function (sg_IO191_setup_s): '<S5>/Setup ' */
  /* Level2 S-Function Block: '<S5>/Setup ' (sg_IO191_setup_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_ad_s): '<S5>/Analog input ' */
  /* Level2 S-Function Block: '<S5>/Analog input ' (sg_IO191_ad_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_di_s): '<S5>/Digital input ' */
  /* Level2 S-Function Block: '<S5>/Digital input ' (sg_IO191_di_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (slrealtimeUDPReceive): '<S2>/UDP Receive1' */
  {
    slrealtime::ip::SocketFactory::releaseSocket("0.0.0.0",25001U);
    char *buffer = (char *)
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.UDPReceive1_PWORK[1];
    if (buffer)
      free(buffer);
  }

  /* Terminate for S-Function (sg_IO191_da_s): '<S5>/Analog output ' */
  /* Level2 S-Function Block: '<S5>/Analog output ' (sg_IO191_da_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_di_isol_s): '<S6>/Isolated digital input ' */
  /* Level2 S-Function Block: '<S6>/Isolated digital input ' (sg_IO291_di_isol_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO191_do_s): '<S5>/Digital output ' */
  /* Level2 S-Function Block: '<S5>/Digital output ' (sg_IO191_do_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_setup_s): '<S6>/Setup ' */
  /* Level2 S-Function Block: '<S6>/Setup ' (sg_IO291_setup_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[8];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_fpga_di_sf_a2): '<S7>/Digital input' */
  /* Level2 S-Function Block: '<S7>/Digital input' (sg_fpga_di_sf_a2) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[9];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_do_fet_s): '<S6>/FET digital output ' */
  /* Level2 S-Function Block: '<S6>/FET digital output ' (sg_IO291_do_fet_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[10];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_di_ttl_s): '<S6>/LVTTL digital input ' */
  /* Level2 S-Function Block: '<S6>/LVTTL digital input ' (sg_IO291_di_ttl_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[11];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO291_do_ttl_s): '<S6>/LVTTL digital output ' */
  /* Level2 S-Function Block: '<S6>/LVTTL digital output ' (sg_IO291_do_ttl_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[12];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (sg_IO602_IO691_setup_s): '<S8>/CAN Setup ' */
  /* Level2 S-Function Block: '<S8>/CAN Setup ' (sg_IO602_IO691_setup_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[13];
    sfcnTerminate(rts);
  }

<<<<<<< .mine
||||||| .r78
  /* Terminate for S-Function (slrealtimeUDPReceive): '<S10>/From Jetson' */
  {
    slrealtime::ip::SocketFactory::releaseSocket("10.41.0.10",5500U);
    char *buffer = (char *)
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK[1];
    if (buffer)
      free(buffer);
  }

  /* Terminate for Atomic SubSystem: '<S120>/Path Following Control System' */
  PathFollowingControlSy_Term
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.PathFollowingControlSystem_i);

  /* End of Terminate for SubSystem: '<S120>/Path Following Control System' */

=======
  /* Terminate for RateTransition generated from: '<S9>/Switch' */
  rtw_slrealtime_mutex_destroy
    (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.Autonom_ON_d0_SEMAPHORE);

>>>>>>> .r84
  /* Terminate for Iterator SubSystem: '<S8>/CAN Read Loop - Port 1' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S64>/CAN Read1' */
  /* Level2 S-Function Block: '<S64>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S8>/CAN Read Loop - Port 1' */

  /* Terminate for Iterator SubSystem: '<S8>/CAN Read Loop - Port 3' */

  /* Terminate for S-Function (sg_IO602_IO691_read_s): '<S65>/CAN Read1' */
  /* Level2 S-Function Block: '<S65>/CAN Read1' (sg_IO602_IO691_read_s) */
  {
    SimStruct *rts =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S8>/CAN Read Loop - Port 3' */

  /* Terminate for S-Function (slrealtimeUDPReceive): '<S10>/From Jetson' */
  {
    slrealtime::ip::SocketFactory::releaseSocket("10.42.0.10",5500U);
    char *buffer = (char *)
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.FromJetson_PWORK[1];
    if (buffer)
      free(buffer);
  }

  /* Terminate for Atomic SubSystem: '<S120>/Path Following Control System' */
  PathFollowingControlSy_Term
    (&D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW.PathFollowingControlSystem_i);

  /* End of Terminate for SubSystem: '<S120>/Path Following Control System' */

  /* Terminate for S-Function (slrealtimeUDPSend): '<S2>/UDP Send' */
  {
<<<<<<< .mine
    slrealtime::ip::SocketFactory::releaseSocket("0.0.0.0",25000U);
||||||| .r78
    slrealtime::ip::SocketFactory::releaseSocket("10.41.0.10",5500U);
=======
    slrealtime::ip::SocketFactory::releaseSocket("192.168.9.10",25000U);
>>>>>>> .r84
  }

  /* user code (Terminate function Trailer) */
  {
    volatile io3xx_pull *ptrIO31x_pull;
    volatile io3xx_2x *ptrio3xx_2x;
    uint16_t moduleArchitecture;
    sg_fpga_io3xxModuleIdT moduleId;

    // Get module IDs (PIC info)
    sg_fpga_IO3xxGetModuleId(39750, &moduleId);
    moduleArchitecture = moduleId.moduleArchitecture;
    SG_PRINTF(DEBUG, "moduleArchitecture %d\n",moduleArchitecture);
    if (moduleArchitecture == TEWS_TXMC) {
      // Get pointer to io31x_pull
      ptrIO31x_pull = (io3xx_pull *)((uintptr_t)io3xxGetAddressSgLib(
        (int32_t)1, SG_FPGA_IO3XX_BAR2) + IO3xx_PULL_BASE);

      // Disable pull resistors
      ptrIO31x_pull->enable = 0x0;     // disable
    }

    // Pull down and disable DIOs
    if ((1 == 2) || (1 == 3)) {
      ptrio3xx_2x = (io3xx_2x *)(
        (uintptr_t)io3xxGetAddressSgLib((int32_t)1, SG_FPGA_IO3XX_BAR2) +
        IO3xx_2x_BASE);
      ptrio3xx_2x->pull = 0xffffffff;  // pull down
      ptrio3xx_2x->dir = 0x0;          // input
      ptrio3xx_2x->update = 0x1;
      sg_wait_s(SG_FPGA_WAIT_TIME_100us);
      ptrio3xx_2x->update = 0x0;
      sg_wait_s(SG_FPGA_WAIT_TIME_1ms);

#if DEBUGGING

      // For debugging output port register of IO-Expander
      sg_wait_s(SG_FPGA_WAIT_TIME_100ms);
      SG_PRINTF(INFO, "last configuration from mdl start\n");
      SG_PRINTF(INFO, "rxData of Expander1: 0x%X\n",
                ptrio3xx_2x->rxDataExpander1);
      SG_PRINTF(INFO, "rxData of Expander2: 0x%X\n",
                ptrio3xx_2x->rxDataExpander2);
      SG_PRINTF(INFO, "rxData of Expander3: 0x%X\n",
                ptrio3xx_2x->rxDataExpander3);
      SG_PRINTF(INFO, "rxData of Expander4: 0x%X\n",
                ptrio3xx_2x->rxDataExpander4);

#endif

    } else if (1 == 4) {
      IO3xx_24_terminate(1);
    }
  }
}

/*
 * D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
<<<<<<< .mine
 * Model version              : 4.38
||||||| .r78
 * Model version              : 4.24
=======
 * Model version              : 4.33
>>>>>>> .r84
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
<<<<<<< .mine
 * C++ source code generated on : Thu Oct  5 15:53:28 2023
||||||| .r78
 * C++ source code generated on : Thu May 11 16:00:17 2023
=======
 * C++ source code generated on : Fri Oct 13 13:42:54 2023
>>>>>>> .r84
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_h_
#define RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_h_
#include <logsrv.h>
#include <cstring>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "verify/verifyIntrf.h"
#include "slrealtime/libsrc/IP/udp.hpp"
#include "slrealtime/libsrc/IP/ip.hpp"
#include "slrealtime/libsrc/IP/socketFactory.hpp"
#include "sg_fpga_io30x_setup_util.h"
#include "sg_fpga_io31x_io32x_setup_util.h"
#include "sg_fpga_io33x_setup_util.h"
#include "sg_fpga_io39x_setup_util.h"
#include "sg_common.h"
#include "sg_printf.h"
#include "Monitorausgabe_sfun_cgen_wrapper.h"
#include "sf_runtime/slTestResult.h"
#include "sf_runtime/slTestTypes.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_types.h"
#include "can_message.h"
#include "PathFollowingControlSystem.h"
#include <stddef.h>

extern "C"
{

#include "rtGetInf.h"

}

extern "C"
{

#include "rt_nonfinite.h"

}

#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal.h"
#include "zero_crossing_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetSampleHitArray
#define rtmGetSampleHitArray(rtm)      ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmGetStepSize
#define rtmGetStepSize(rtm)            ((rtm)->Timing.stepSize)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
#define rtmGet_TimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmCounterLimit
#define rtmCounterLimit(rtm, idx)      ((rtm)->Timing.TaskCounters.cLimit[(idx)])
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
#define rtmStepTask(rtm, idx)          ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef rtmTaskCounter
#define rtmTaskCounter(rtm, idx)       ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#ifndef rtmGetTimeOfLastOutput
#define rtmGetTimeOfLastOutput(rtm)    ((rtm)->Timing.timeOfLastOutput)
#endif

/* Block signals (default storage) */
struct B_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  LaneSensor PackLaneBus;              /* '<S10>/PackLaneBus' */
  CAN_DATATYPE CANRead1_o2;            /* '<S65>/CAN Read1' */
  CAN_DATATYPE CANRead1_o2_e;          /* '<S64>/CAN Read1' */
  real_T IO191_AI_CH1;                 /* '<S5>/Analog input ' */
  real_T IO191_AI_CH2;                 /* '<S5>/Analog input ' */
  real_T IO191_AI_CH3;                 /* '<S5>/Analog input ' */
  real_T IO191_AI_CH4;                 /* '<S5>/Analog input ' */
  real_T Digitalinput_o1;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o2;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o3;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o4;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o5;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o6;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o7;              /* '<S5>/Digital input ' */
  real_T Digitalinput_o8;              /* '<S5>/Digital input ' */
  real_T IO191_DI_CH9_Bremspedal_1;    /* '<S5>/Gain1' */
  real_T IO191_AI_CH2_FP_2_G;          /* '<S5>/Gain10' */
  real_T IO191_AI_CH3_LG_1_G;          /* '<S5>/Gain11' */
  real_T IO191_AI_CH4_LG_2_G;          /* '<S5>/Gain12' */
  real_T IO191_DI_CH10_Bremspedal_2;   /* '<S5>/Gain2' */
  real_T IO191_DI_CH11_BR_Licht;       /* '<S5>/Gain3' */
  real_T IO191_DI_CH12_Totmann_Taster_1;/* '<S5>/Gain4' */
  real_T IO191_DI_CH13_Totmann_Taster_2;/* '<S5>/Gain5' */
  real_T IO191_DI_CH14_Freigabe_Taster;/* '<S5>/Gain6' */
  real_T IO191_DI_CH15;                /* '<S5>/Gain7' */
  real_T IO191_DI_CH16;                /* '<S5>/Gain8' */
  real_T IO191_AI_CH1_FP_1_G;          /* '<S5>/Gain9' */
  real_T TmpRTBAtSwitchInport1;        /* '<S3>/1-D Lookup Table2' */
  real_T UDPReceive1_o2;               /* '<S2>/UDP Receive1' */
  real_T VectorConcatenate[200];       /* '<S41>/Vector Concatenate' */
  real_T SumofElements;                /* '<S41>/Sum of Elements' */
  real_T Divide;                       /* '<S41>/Divide' */
  real_T DataTypeConversion1;          /* '<S2>/Data Type Conversion1' */
  real_T Switch1;                      /* '<S2>/Switch1' */
  real_T IC1;                          /* '<S2>/IC1' */
  real_T TransferFcn;                  /* '<S11>/Transfer Fcn' */
  real_T IC;                           /* '<S11>/IC' */
  real_T Fahrpedal;                    /* '<Root>/Switch' */
  real_T Switch;                       /* '<S3>/Switch' */
  real_T Saturation3;                  /* '<S3>/Saturation3' */
  real_T uDLookupTable;                /* '<S3>/1-D Lookup Table' */
  real_T IC2;                          /* '<S3>/IC2' */
  real_T Ausgabe_Gaspedal_FP_1_G;      /* '<S3>/Bias1' */
  real_T uDLookupTable1;               /* '<S3>/1-D Lookup Table1' */
  real_T IC3;                          /* '<S3>/IC3' */
  real_T Ausgabe_Gaspedal_FP_2_G;      /* '<S3>/Bias2' */
  real_T DataTypeConversion;           /* '<S2>/Data Type Conversion' */
  real_T Switch_j;                     /* '<S2>/Switch' */
  real_T IC_p;                         /* '<S2>/IC' */
  real_T TransferFcn1;                 /* '<S11>/Transfer Fcn1' */
  real_T IC1_h;                        /* '<S11>/IC1' */
  real_T Lenkung;                      /* '<Root>/Switch1' */
  real_T uDLookupTable_m;              /* '<S9>/1-D Lookup Table' */
  real_T IC2_e;                        /* '<S9>/IC2' */
  real_T LG_1_G;                       /* '<S9>/Bias' */
  real_T uDLookupTable1_g;             /* '<S9>/1-D Lookup Table1' */
  real_T IC3_j;                        /* '<S9>/IC3' */
  real_T LG_2_G;                       /* '<S9>/Bias1' */
  real_T Integrator;                   /* '<S45>/Integrator' */
  real_T Switch2;                      /* '<S45>/Switch2' */
  real_T VectorConcatenate_b[5];       /* '<S56>/Vector Concatenate' */
  real_T SumofElements_i;              /* '<S56>/Sum of Elements' */
  real_T Divide_d;                     /* '<S56>/Divide' */
  real_T VectorConcatenate_g[5];       /* '<S57>/Vector Concatenate' */
  real_T SumofElements_d;              /* '<S57>/Sum of Elements' */
  real_T Divide_p;                     /* '<S57>/Divide' */
  real_T Subtract2;                    /* '<S49>/Subtract2' */
  real_T Abs2;                         /* '<S49>/Abs2' */
  real_T DataTypeConversion2;          /* '<S49>/Data Type Conversion2' */
  real_T DiscreteTimeIntegrator2;      /* '<S49>/Discrete-Time Integrator2' */
  real_T Isolateddigitalinput_o1;      /* '<S6>/Isolated digital input ' */
  real_T Isolateddigitalinput_o2;      /* '<S6>/Isolated digital input ' */
  real_T Isolateddigitalinput_o3;      /* '<S6>/Isolated digital input ' */
  real_T IO291_DI_CH1_NotAus_1;        /* '<S6>/Gain' */
  real_T IO291_DI_CH2_NotAus_2;        /* '<S6>/Gain1' */
  real_T DataTypeConversion_p;         /* '<S44>/Data Type Conversion' */
  real_T FP_FET_1_On;                  /* '<S4>/Gain6' */
  real_T FP_FET_2_On;                  /* '<S4>/Gain7' */
  real_T LG_FET_1_On;                  /* '<S4>/Gain8' */
  real_T LG_FET_2_On;                  /* '<S4>/Gain9' */
  real_T Br_Licht_On;                  /* '<S4>/Constant8' */
  real_T Constant;                     /* '<S5>/Constant' */
  real_T Alive;                        /* '<S6>/Alive' */
  real_T IO291_DI_CH3_Brmslcht;        /* '<S6>/Gain2' */
  real_T Taster_Freigabe;              /* '<S4>/Gain5' */
  real_T TmpRTBAtSwitchInport1_i;      /* '<S1>/1-D Lookup Table2' */
  real_T Switch_p;                     /* '<S1>/Switch' */
  real_T Saturation3_j;                /* '<S1>/Saturation3' */
  real_T Gain;                         /* '<S1>/Gain' */
  real_T uDLookupTable_j;              /* '<S15>/1-D Lookup Table' */
  real_T Digitalinput_o1_p;            /* '<S7>/Digital input' */
  real_T Digitalinput_o2_b;            /* '<S7>/Digital input' */
  real_T IO397_DI_Ch8_Bremsaktuator_Hall;/* '<S7>/Gain' */
  real_T VectorConcatenate_n[5];       /* '<S13>/Vector Concatenate' */
  real_T SumofElements_f;              /* '<S13>/Sum of Elements' */
  real_T Divide_l;                     /* '<S13>/Divide' */
  real_T Round;                        /* '<S13>/Round' */
  real_T DataTypeConversion_e;         /* '<S27>/Data Type Conversion' */
  real_T IO397_DI_Ch9_Bremsaktuator_Hall;/* '<S7>/Gain1' */
  real_T VectorConcatenate_a[5];       /* '<S14>/Vector Concatenate' */
  real_T SumofElements_g;              /* '<S14>/Sum of Elements' */
  real_T Divide_e;                     /* '<S14>/Divide' */
  real_T Round_m;                      /* '<S14>/Round' */
  real_T DataTypeConversion1_m;        /* '<S27>/Data Type Conversion1' */
  real_T Switch_f;                     /* '<S15>/Switch' */
  real_T Switch1_c;                    /* '<S25>/Switch1' */
  real_T UnitDelay;                    /* '<S25>/Unit Delay' */
  real_T Switch2_f;                    /* '<S25>/Switch2' */
  real_T Add;                          /* '<S25>/Add' */
  real_T Add_a;                        /* '<S15>/Add' */
  real_T Delay1;                       /* '<S16>/Delay1' */
  real_T Switch1_h;                    /* '<S16>/Switch1' */
  real_T IC1_d;                        /* '<S15>/IC1' */
  real_T DataTypeConversion_g;         /* '<S6>/Data Type Conversion' */
  real_T Delay1_n;                     /* '<S17>/Delay1' */
  real_T Switch1_j;                    /* '<S17>/Switch1' */
  real_T IC2_ep;                       /* '<S15>/IC2' */
  real_T DataTypeConversion1_c;        /* '<S6>/Data Type Conversion1' */
  real_T USS_Reverse;                  /* '<S4>/Constant13' */
  real_T PulseGenerator;               /* '<S45>/Pulse Generator' */
  real_T Switch1_m;                    /* '<S45>/Switch1' */
  real_T LED_Totmann;                  /* '<S4>/Gain4' */
  real_T Bias;                         /* '<S16>/Bias' */
  real_T Saturation;                   /* '<S16>/Saturation' */
  real_T Switch_o;                     /* '<S16>/Switch' */
  real_T Bias_n;                       /* '<S17>/Bias' */
  real_T Saturation_g;                 /* '<S17>/Saturation' */
  real_T Switch_g;                     /* '<S17>/Switch' */
  real_T Clock;                        /* '<S36>/Clock' */
  real_T MultiportSwitch[2];           /* '<S35>/Multiport Switch' */
  real_T Sum;                          /* '<S36>/Sum' */
  real_T Delay1_a;                     /* '<S46>/Delay1' */
  real_T VectorConcatenate_j[5];       /* '<S50>/Vector Concatenate' */
  real_T SumofElements_fw;             /* '<S50>/Sum of Elements' */
  real_T Divide_g;                     /* '<S50>/Divide' */
  real_T Switch_k;                     /* '<S46>/Switch' */
  real_T Switch1_cc;                   /* '<S46>/Switch1' */
  real_T Divide_h;                     /* '<S7>/Divide' */
  real_T Divide1;                      /* '<S7>/Divide1' */
  real_T IO397_QAD_Position;           /* '<S7>/Gain4' */
  real_T IO397_QAD_Turns;              /* '<S7>/Gain5' */
  real_T IO397_QAD_rpm;                /* '<S7>/Gain6' */
  real_T RT_i;                         /* '<S66>/RT' */
  real_T RT1;                          /* '<S66>/RT1' */
  real_T TmpRTBAtAdd2Inport1;          /* '<S66>/1-D Lookup Vorsteuerung' */
  real_T TmpRTBAtSumInport1;
  real_T Integrator_k;                 /* '<S101>/Integrator' */
  real_T TmpRTBAtSumDInport1;
  real_T Filter;                       /* '<S96>/Filter' */
  real_T SumD;                         /* '<S96>/SumD' */
  real_T FilterCoefficient;            /* '<S104>/Filter Coefficient' */
  real_T Sum_e;                        /* '<S110>/Sum' */
  real_T Saturation_j;                 /* '<S108>/Saturation' */
  real_T Add2;                         /* '<S66>/Add2' */
  real_T Add1;                         /* '<S66>/Add1' */
  real_T ZeroGain;                     /* '<S92>/ZeroGain' */
  real_T DeadZone;                     /* '<S94>/DeadZone' */
  real_T SignPreSat;                   /* '<S92>/SignPreSat' */
  real_T TmpRTBAtSwitchInport3;
  real_T Switch_gi;                    /* '<S92>/Switch' */
  real_T Saturation2;                  /* '<S66>/Saturation2' */
  real_T Lenkwinkel;                   /* '<S10>/Rate Transition2' */
  real_T TmpRTBAtTransferFcn1Inport1;  /* '<S11>/Divide' */
  real_T TmpRTBAtTransferFcnInport1;   /* '<S11>/1-D Lookup Table' */
  real_T RXSampleTime;                 /* '<S8>/RX Sample Time' */
  real_T TmpSignalConversionAtBytePackin[3];
  real_T TmpRTBAtAddInport1;           /* '<S66>/1-D Lookup Table3' */
  real_T Add_b;                        /* '<S66>/Add' */
  real_T Gain_h;                       /* '<S66>/Gain' */
  real_T IntegralGain;                 /* '<S98>/Integral Gain' */
  real_T SignPreIntegrator;            /* '<S92>/SignPreIntegrator' */
  real_T DerivativeGain;               /* '<S95>/Derivative Gain' */
  real_T ProportionalGain;             /* '<S106>/Proportional Gain' */
  real_T Radar_Data;                   /* '<S10>/Data Type Conversion' */
  real_T Switch_l;                     /* '<S11>/Switch' */
  real_T Saturation_k;                 /* '<S11>/Saturation' */
  real_T uDLookupTable_p;              /* '<S11>/1-D Lookup Table' */
  real_T Switch1_l;                    /* '<S11>/Switch1' */
  real_T Saturation1;                  /* '<S11>/Saturation1' */
  real_T Divide_c;                     /* '<S11>/Divide' */
  real_T Lenkwinkel_i;                 /* '<S10>/Rate Transition2' */
  real_T TmpRTBAtTransferFcn1Inport1;  /* '<S11>/Divide' */
  real_T TmpRTBAtTransferFcnInport1;   /* '<S11>/1-D Lookup Table' */
  real_T RXSampleTime;                 /* '<S8>/RX Sample Time' */
  real_T TmpSignalConversionAtBytePackin[3];
  real_T Radar_Data;                   /* '<S10>/Data Type Conversion' */
  real_T Switch_lh;                    /* '<S11>/Switch' */
  real_T Saturation_k;                 /* '<S11>/Saturation' */
  real_T uDLookupTable_p;              /* '<S11>/1-D Lookup Table' */
  real_T Switch1_l;                    /* '<S11>/Switch1' */
  real_T Saturation1;                  /* '<S11>/Saturation1' */
  real_T Divide_c;                     /* '<S11>/Divide' */
  real_T Longitudinal_Velocity;        /* '<S10>/Rate Transition1' */
  real_T Switch_gp;                    /* '<S120>/Switch' */
  real_T FromJetson_o2;                /* '<S10>/From Jetson' */
  real_T DataTypeConversion3;          /* '<S126>/Data Type Conversion3' */
  real_T Saturation2_i;                /* '<S126>/Saturation2' */
  real_T DataTypeConversion2_a;        /* '<S126>/Data Type Conversion2' */
  real_T Saturation3_b;                /* '<S126>/Saturation3' */
  real_T Product;                      /* '<S126>/Product' */
  real_T Gain_p[21];                   /* '<S126>/Gain' */
  real_T Sum_a[21];                    /* '<S126>/Sum' */
  real_T DataTypeConversion1_f;        /* '<S126>/Data Type Conversion1' */
  real_T UnaryMinus1;                  /* '<S126>/Unary Minus1' */
  real_T Saturation_f;                 /* '<S126>/Saturation' */
  real_T DataTypeConversion_gl;        /* '<S126>/Data Type Conversion' */
  real_T UnaryMinus;                   /* '<S126>/Unary Minus' */
  real_T Saturation1_l;                /* '<S126>/Saturation1' */
  real_T uDLookupTable2;               /* '<S1>/1-D Lookup Table2' */
  real_T uDLookupTable2_i;             /* '<S3>/1-D Lookup Table2' */
  real_T Autonom_ON;
  real_T Switch_lu;                    /* '<S9>/Switch' */
  real_T uDLookupTable3;               /* '<S66>/1-D Lookup Table3' */
  real_T uDLookupVorsteuerung;         /* '<S66>/1-D Lookup Vorsteuerung' */
  real_T Odometer;
  real_T SoC;
  real_T SFunctionBuilder;             /* '<Root>/S-Function Builder' */
  real_T uDLookupTable2_d;             /* '<S9>/1-D Lookup Table2' */
  real_T CANUnpack;                    /* '<S65>/CAN Unpack' */
  real_T CANUnpack1_o1;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o2;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o3;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o4;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o5;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o6;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o7;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack1_o8;                /* '<S65>/CAN Unpack1' */
  real_T CANUnpack2_o1;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o2;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o3;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o4;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o5;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o6;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o7;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack2_o8;                /* '<S65>/CAN Unpack2' */
  real_T CANUnpack4_o1;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o2;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o3;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o4;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o5;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o6;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o7;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack4_o8;                /* '<S65>/CAN Unpack4' */
  real_T CANUnpack5_o1;                /* '<S65>/CAN Unpack5' */
  real_T CANUnpack5_o2;                /* '<S65>/CAN Unpack5' */
  real_T Lenkwinkel_p;                 /* '<S65>/Gain' */
  real_T AY;                           /* '<S65>/Gain1' */
  real_T USS_Sensor_VLM;               /* '<S65>/Gain10' */
  real_T USS_Sensor_VRA;               /* '<S65>/Gain11' */
  real_T USS_Sensor_VRM;               /* '<S65>/Gain12' */
  real_T RC_Fahrpedal;                 /* '<S65>/Gain13' */
  real_T RC_Lenkung;                   /* '<S65>/Gain14' */
  real_T Gierrate;                     /* '<S65>/Gain2' */
  real_T AX;                           /* '<S65>/Gain3' */
  real_T Gierbeschleunigung;           /* '<S65>/Gain4' */
  real_T USS_Sensor_HLA;               /* '<S65>/Gain5' */
  real_T USS_Sensor_HLM;               /* '<S65>/Gain6' */
  real_T USS_Sensor_HRA;               /* '<S65>/Gain7' */
  real_T USS_Sensor_HRM;               /* '<S65>/Gain8' */
  real_T USS_Sensor_VLA;               /* '<S65>/Gain9' */
  real_T isvalid;
  real_T radardatalength1788;
  real_T Radar_Punkt;
  real_T Radar_Mode;
  real_T Radar_2;
  real_T CANUnpack_o1;                 /* '<S64>/CAN Unpack' */
  real_T CANUnpack_o2;                 /* '<S64>/CAN Unpack' */
  real_T CANUnpack_o3;                 /* '<S64>/CAN Unpack' */
  real_T CANUnpack_o4;                 /* '<S64>/CAN Unpack' */
  real_T CANUnpack1_o1_k;              /* '<S64>/CAN Unpack1' */
  real_T CANUnpack1_o2_m;              /* '<S64>/CAN Unpack1' */
  real_T CANUnpack1_o3_h;              /* '<S64>/CAN Unpack1' */
  real_T CANUnpack1_o4_f;              /* '<S64>/CAN Unpack1' */
  real_T CANUnpack2_o1_f;              /* '<S64>/CAN Unpack2' */
  real_T CANUnpack2_o2_a;              /* '<S64>/CAN Unpack2' */
  real_T CANUnpack2_o3_m;              /* '<S64>/CAN Unpack2' */
  real_T CANUnpack3_o1;                /* '<S64>/CAN Unpack3' */
  real_T CANUnpack3_o2;                /* '<S64>/CAN Unpack3' */
  real_T CANUnpack4_o1_n;              /* '<S64>/CAN Unpack4' */
  real_T CANUnpack4_o2_n;              /* '<S64>/CAN Unpack4' */
  real_T CANUnpack5;                   /* '<S64>/CAN Unpack5' */
  real_T CANUnpack6_o1;                /* '<S64>/CAN Unpack6' */
  real_T CANUnpack6_o2;                /* '<S64>/CAN Unpack6' */
  real_T CANUnpack6_o3;                /* '<S64>/CAN Unpack6' */
  real_T CANUnpack6_o4;                /* '<S64>/CAN Unpack6' */
  real_T CANUnpack6_o5;                /* '<S64>/CAN Unpack6' */
  real_T CANUnpack7_o1;                /* '<S64>/CAN Unpack7' */
  real_T CANUnpack7_o2;                /* '<S64>/CAN Unpack7' */
  real_T CANUnpack8_o1;                /* '<S64>/CAN Unpack8' */
  real_T CANUnpack8_o2;                /* '<S64>/CAN Unpack8' */
  real_T ChargeRequest;                /* '<S64>/Gain' */
  real_T IBatt;                        /* '<S64>/Gain1' */
  real_T Range;                        /* '<S64>/Gain10' */
  real_T CarSpeed;                     /* '<S64>/Gain11' */
  real_T SoC_b;                        /* '<S64>/Gain12' */
  real_T BrakePedal;                   /* '<S64>/Gain13' */
  real_T DriveMode;                    /* '<S64>/Gain14' */
  real_T DistanceToral_24Bit;          /* '<S64>/Gain15' */
  real_T VehicleSpeedFromABS;          /* '<S64>/Gain16' */
  real_T Wheel_Speed_FL;               /* '<S64>/Gain17' */
  real_T Wheel_Speed_FR;               /* '<S64>/Gain18' */
  real_T Wheel_Speed_RL;               /* '<S64>/Gain19' */
  real_T V_KL15;                       /* '<S64>/Gain2' */
  real_T Wheel_Speed_RR;               /* '<S64>/Gain20' */
  real_T Handbremse;                   /* '<S64>/Gain21' */
  real_T Odometer_e;                   /* '<S64>/Gain22' */
  real_T V_KL30;                       /* '<S64>/Gain3' */
  real_T BMSStatus;                    /* '<S64>/Gain4' */
  real_T InverterStatus;               /* '<S64>/Gain5' */
  real_T eMotorSpeed;                  /* '<S64>/Gain6' */
  real_T eMotorTorque;                 /* '<S64>/Gain7' */
  real_T Distance;                     /* '<S64>/Gain8' */
  real_T DistanceTotal;                /* '<S64>/Gain9' */
  real_T Switch_jr;                    /* '<S45>/Switch' */
  real_T Bias_nf;                      /* '<S46>/Bias' */
  real_T Saturation_gz;                /* '<S46>/Saturation' */
  real_T Saturation_c;                 /* '<S2>/Saturation' */
  real_T Add1_c;                       /* '<S2>/Add1' */
  real_T Divide1_o;                    /* '<S2>/Divide1' */
  real_T Power;                        /* '<S42>/Power' */
  real_T Multiply;                     /* '<S42>/Multiply' */
  real_T Add2_h;                       /* '<S42>/Add2' */
  real_T Saturation3_m;                /* '<S2>/Saturation3' */
  real_T Saturation1_p;                /* '<S2>/Saturation1' */
  real_T Add_n;                        /* '<S2>/Add' */
  real_T Divide_cy;                    /* '<S2>/Divide' */
  real_T Saturation2_j;                /* '<S2>/Saturation2' */
  real_T count_enable;                 /* '<S27>/State Transition Table' */
  real_T count_dir;                    /* '<S27>/State Transition Table' */
  real_T In1;                          /* '<S39>/In1' */
  real_T Switch_oi;                    /* '<S25>/Switch' */
  real32_T ByteUnpacking[3];           /* '<S2>/Byte Unpacking' */
  real32_T LateralOffset;              /* '<S119>/Delay1' */
  real32_T HeadingAngle;               /* '<S119>/Delay1' */
  real32_T CurvatureDerivative;        /* '<S119>/Delay1' */
  real32_T Curvature;                  /* '<S119>/Delay1' */
  real32_T Curvature_a;                /* '<S119>/Merge1' */
  real32_T UnaryMinus_i;               /* '<S127>/Unary Minus' */
  real32_T CurvatureDerivative_m;      /* '<S119>/Merge1' */
  real32_T UnaryMinus1_k;              /* '<S127>/Unary Minus1' */
  real32_T LateralOffset_f;            /* '<S119>/Merge1' */
  real32_T UnaryMinus3;                /* '<S127>/Unary Minus3' */
  real32_T HeadingAngle_l;             /* '<S119>/Merge1' */
  real32_T UnaryMinus2;                /* '<S127>/Unary Minus2' */
  real32_T Curvature_p;
  real32_T HeadingAngle_g;
  real32_T LateralOffset_k;
  real32_T Curvature_pa;
  real32_T HeadingAngle_gv;
  real32_T LateralOffset_kn;
  real32_T TmpSignalConversionAtTAQSigLogg[6];
  /* '<S10>/TmpSignal ConversionAtTAQSigLogging_InsertedFor_Mux_at_outport_0Inport1' */
  real32_T Product_g;                  /* '<S124>/Product' */
  real32_T Subtract;                   /* '<S124>/Subtract' */
  real32_T Product1;                   /* '<S124>/Product1' */
  real32_T Product_l;                  /* '<S122>/Product' */
  real32_T Subtract_l;                 /* '<S122>/Subtract' */
  real32_T Product1_k;                 /* '<S122>/Product1' */
  real32_T Add_nc;                     /* '<S121>/Add' */
  real32_T Add1_e;                     /* '<S121>/Add1' */
  real32_T Add2_e;                     /* '<S121>/Add2' */
  real32_T Add3;                       /* '<S121>/Add3' */
  uint8_T UDPReceive1_o1[12];          /* '<S2>/UDP Receive1' */
  uint8_T BytePacking[24];             /* '<S2>/Byte Packing' */
  uint8_T FromJetson_o1[48];           /* '<S10>/From Jetson' */
  uint8_T TmpRTBAtBytePackingOutport1[24];/* '<S2>/Byte Packing' */
  int8_T DataTypeConv1;                /* '<S92>/DataTypeConv1' */
  int8_T TmpRTBAtEqual1Inport2;        /* '<S92>/DataTypeConv2' */
  int8_T DataTypeConv2;                /* '<S92>/DataTypeConv2' */
  boolean_T Compare;                   /* '<S43>/Compare' */
  boolean_T Compare_n;                 /* '<S60>/Compare' */
  boolean_T Compare_m;                 /* '<S61>/Compare' */
  boolean_T AND;                       /* '<S45>/AND' */
  boolean_T Compare_p;                 /* '<S63>/Compare' */
  boolean_T Compare_pz;                /* '<S54>/Compare' */
  boolean_T Compare_h;                 /* '<S55>/Compare' */
  boolean_T AND_m;                     /* '<S48>/AND' */
  boolean_T Compare_j;                 /* '<S58>/Compare' */
  boolean_T RelationalOperator2;       /* '<S49>/Relational Operator2' */
  boolean_T UnitDelay_f;               /* '<S44>/Unit Delay' */
  boolean_T LogicalOperator;           /* '<S44>/Logical Operator' */
  boolean_T LogicalOperator1;          /* '<S44>/Logical Operator1' */
  boolean_T AND2;                      /* '<S44>/AND2' */
  boolean_T Memory;                    /* '<S44>/Memory' */
  boolean_T AND3;                      /* '<S44>/AND3' */
  boolean_T Compare_d;                 /* '<S22>/Compare' */
  boolean_T Compare_f;                 /* '<S34>/Compare' */
  boolean_T Compare_i;                 /* '<S18>/Compare' */
  boolean_T UnitDelay_c;               /* '<S15>/Unit Delay' */
  boolean_T Compare_ig;                /* '<S19>/Compare' */
  boolean_T OR;                        /* '<S15>/OR' */
  boolean_T Compare_fa;                /* '<S33>/Compare' */
  boolean_T AND6;                      /* '<S25>/AND6' */
  boolean_T Compare_o;                 /* '<S32>/Compare' */
  boolean_T UnitDelay1;                /* '<S25>/Unit Delay1' */
  boolean_T Compare_fx;                /* '<S23>/Compare' */
  boolean_T AND7;                      /* '<S15>/AND7' */
  boolean_T Compare_hi;                /* '<S28>/Compare' */
  boolean_T Bremsaktuator_1;           /* '<S1>/AND3' */
  boolean_T Compare_c;                 /* '<S20>/Compare' */
  boolean_T Compare_co;                /* '<S24>/Compare' */
  boolean_T AND8;                      /* '<S15>/AND8' */
  boolean_T Compare_cr;                /* '<S21>/Compare' */
  boolean_T AND1;                      /* '<S15>/AND1' */
  boolean_T AND2_m;                    /* '<S15>/AND2' */
  boolean_T Compare_dk;                /* '<S30>/Compare' */
  boolean_T Bremsaktuator_2;           /* '<S1>/AND4' */
  boolean_T Uk1;                       /* '<S29>/Delay Input1' */
  boolean_T FixPtRelationalOperator;   /* '<S29>/FixPt Relational Operator' */
  boolean_T Uk1_e;                     /* '<S31>/Delay Input1' */
  boolean_T FixPtRelationalOperator_p; /* '<S31>/FixPt Relational Operator' */
  boolean_T DataTypeConversion2_i;     /* '<S35>/Data Type Conversion2' */
  boolean_T Memory_p;                  /* '<S35>/Memory' */
  boolean_T LogicalOperator1_h;        /* '<S35>/Logical Operator1' */
  boolean_T RelationalOperator;        /* '<S36>/Relational Operator' */
  boolean_T Compare_j5;                /* '<S52>/Compare' */
  boolean_T Uk1_k;                     /* '<S53>/Delay Input1' */
  boolean_T Compare_on;                /* '<S59>/Compare' */
  boolean_T FixPtRelationalOperator_c; /* '<S53>/FixPt Relational Operator' */
  boolean_T NOT;                       /* '<S44>/NOT' */
  boolean_T OR_j;                      /* '<S44>/OR' */
  boolean_T AND_n;                     /* '<S44>/AND' */
  boolean_T Memory1;                   /* '<S44>/Memory1' */
  boolean_T AND1_a;                    /* '<S44>/AND1' */
  boolean_T Memory_b;                  /* '<S51>/Memory' */
  boolean_T Logic[2];                  /* '<S51>/Logic' */
  boolean_T NotEqual;                  /* '<S92>/NotEqual' */
  boolean_T Equal1;                    /* '<S92>/Equal1' */
  boolean_T AND3_d;                    /* '<S92>/AND3' */
  boolean_T Memory_o;                  /* '<S92>/Memory' */
  boolean_T Compare_e;                 /* '<S47>/Compare' */
  boolean_T Compare_nw;                /* '<S186>/Compare' */
  boolean_T Compare_if;                /* '<S187>/Compare' */
  boolean_T CANRead1_o1;               /* '<S65>/CAN Read1' */
  boolean_T CANRead1_o1_f;             /* '<S64>/CAN Read1' */
  boolean_T Compare_hy;                /* '<S62>/Compare' */
  boolean_T RelationalOperator1;       /* '<S38>/Relational Operator1' */
  boolean_T RelationalOperator1_c;     /* '<S37>/Relational Operator1' */
  boolean_T AND5;                      /* '<S25>/AND5' */
  B_PathFollowingControlSystem__T PathFollowingControlSystem_i;
                                    /* '<S120>/Path Following Control System' */
};

/* Block states (default storage) for system '<Root>' */
struct DW_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  packLaneMarkerBus_D_20230119__T obj; /* '<S10>/PackLaneBus' */
  real_T TappedDelay1_X[199];          /* '<S41>/Tapped Delay1' */
  real_T TappedDelay_X[4];             /* '<S56>/Tapped Delay' */
  real_T TappedDelay_X_m[4];           /* '<S57>/Tapped Delay' */
  real_T DiscreteTimeIntegrator2_DSTATE;/* '<S49>/Discrete-Time Integrator2' */
  real_T TappedDelay_X_b[4];           /* '<S13>/Tapped Delay' */
  real_T TappedDelay_X_d[4];           /* '<S14>/Tapped Delay' */
  real_T UnitDelay_DSTATE;             /* '<S25>/Unit Delay' */
  real_T Delay1_DSTATE;                /* '<S16>/Delay1' */
  real_T Delay1_DSTATE_o;              /* '<S17>/Delay1' */
  real_T Delay1_DSTATE_p;              /* '<S46>/Delay1' */
  real_T TappedDelay1_X_c[4];          /* '<S50>/Tapped Delay1' */
  real_T TmpRTBAtSwitchInport1_Buf[2]; /* synthesized block */
  real_T IC_FirstOutputTime;           /* '<S11>/IC' */
  real_T IC2_FirstOutputTime;          /* '<S3>/IC2' */
  real_T IC3_FirstOutputTime;          /* '<S3>/IC3' */
  real_T IC1_FirstOutputTime;          /* '<S11>/IC1' */
  real_T IC2_FirstOutputTime_c;        /* '<S9>/IC2' */
  real_T IC3_FirstOutputTime_f;        /* '<S9>/IC3' */
  real_T TmpRTBAtSwitchInport1_Buf_e[2];/* synthesized block */
  real_T IC1_FirstOutputTime_d;        /* '<S15>/IC1' */
  real_T IC2_FirstOutputTime_c4;       /* '<S15>/IC2' */
  real_T Autonom_ON_Buf0;              /* synthesized block */
  real_T Autonom_ON_Buf1;              /* synthesized block */
  real_T Autonom_ON_Buf2;              /* synthesized block */
  real_T RT_Buf[2];                    /* '<S66>/RT' */
  real_T RT1_Buf[2];                   /* '<S66>/RT1' */
<<<<<<< .mine
||||||| .r78
  real_T RateTransition1_Buf[2];       /* '<S10>/Rate Transition1' */
=======
  real_T TmpRTBAtAdd2Inport1_Buf[2];   /* synthesized block */
  real_T TmpRTBAtSumInport1_Buf[2];    /* synthesized block */
  real_T TmpRTBAtSumDInport1_Buf[2];   /* synthesized block */
  real_T TmpRTBAtSwitchInport3_Buf[2]; /* synthesized block */
>>>>>>> .r84
  real_T RateTransition2_Buf[2];       /* '<S10>/Rate Transition2' */
  real_T TmpRTBAtTransferFcn1Inport1_Buf[2];/* synthesized block */
  real_T TmpRTBAtTransferFcnInport1_Buf[2];/* synthesized block */
<<<<<<< .mine
  real_T RateTransition1_Buf[2];       /* '<S10>/Rate Transition1' */
||||||| .r78
=======
  real_T TmpRTBAtAddInport1_Buf[2];    /* synthesized block */
  real_T RateTransition1_Buf[2];       /* '<S10>/Rate Transition1' */
>>>>>>> .r84
  real_T Odometer_Buf[2];              /* synthesized block */
  real_T SoC_Buf[2];                   /* synthesized block */
  real_T Setup_RWORK[2];               /* '<S5>/Setup ' */
  void *Setup_PWORK;                   /* '<S5>/Setup ' */
  void *Analoginput_PWORK;             /* '<S5>/Analog input ' */
  void *Digitalinput_PWORK;            /* '<S5>/Digital input ' */
  void* UDPReceive1_DWORK1;            /* '<S2>/UDP Receive1' */
  void *UDPReceive1_PWORK[2];          /* '<S2>/UDP Receive1' */
  void *Analogoutput_PWORK;            /* '<S5>/Analog output ' */
  void *Isolateddigitalinput_PWORK[2]; /* '<S6>/Isolated digital input ' */
  void *Digitaloutput_PWORK;           /* '<S5>/Digital output ' */
  void *Digitalinput_PWORK_i[2];       /* '<S7>/Digital input' */
  void *FETdigitaloutput_PWORK[2];     /* '<S6>/FET digital output ' */
  void *LVTTLdigitalinput_PWORK[2];    /* '<S6>/LVTTL digital input ' */
  void *LVTTLdigitaloutput_PWORK[2];   /* '<S6>/LVTTL digital output ' */
  void *CANSetup_PWORK;                /* '<S8>/CAN Setup ' */
  struct {
    void *LoggedData[4];
  } Scope2_PWORK;                      /* '<S12>/Scope2' */

  struct {
    void *LoggedData[4];
  } Scope1_PWORK;                      /* '<S15>/Scope1' */

  struct {
    void *LoggedData[2];
  } Scope_PWORK;                       /* '<S2>/Scope' */

  struct {
    void *USERIO_P_IND;
    void *PROG_SPACE_P_IND;
    void *CONFIG_REGISTER_P_IND;
    void *CONDITIONING_MODULE_IO3xx_2x_P_IND;
    void *DEVICENAME_P_IND;
  } Setup_PWORK_f;                     /* '<S7>/Setup' */

  void* Autonom_ON_d0_SEMAPHORE;       /* synthesized block */
  struct {
    void *LoggedData[2];
  } Scope_PWORK_m;                     /* '<S66>/Scope' */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_RateT;   /* synthesized block */

  struct {
    void *LoggedData[3];
  } Scope_PWORK_h;                     /* '<S12>/Scope' */

  void* FromJetson_DWORK1;             /* '<S10>/From Jetson' */
  void *FromJetson_PWORK[2];           /* '<S10>/From Jetson' */
  void* UDPSend_DWORK1;                /* '<S2>/UDP Send' */
  void *UDPSend_PWORK;                 /* '<S2>/UDP Send' */
  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_FromJ;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_Estim;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_LaneF;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_LaneF;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_Est_i;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_Lan_l;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_Lan_l;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_Est_m;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_Rat_f;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_Mux_a;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_Previ;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_Estim;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_Rat_f;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_Pre_g;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_Est_i;   /* synthesized block */
>>>>>>> .r84

  struct {
<<<<<<< .mine
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Estim;   /* synthesized block */
||||||| .r78
    void *LoggedData[3];
  } Scope_PWORK_h;                     /* '<S12>/Scope' */
=======
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Est_m;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_Est_i;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_LaneF;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_MPCCo;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
<<<<<<< .mine
  } TAQSigLogging_InsertedFor_Est_m;   /* synthesized block */
||||||| .r78
  } TAQSigLogging_InsertedFor_Lan_l;   /* synthesized block */
=======
  } TAQSigLogging_InsertedFor_MPC_a;   /* synthesized block */
>>>>>>> .r84

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Previ;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Pre_g;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Previ;   /* synthesized block */

  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_Pre_g;   /* synthesized block */

  void *CANRead1_PWORK;                /* '<S65>/CAN Read1' */
  struct {
    void *AQHandles;
  } TAQSigLogging_InsertedFor_CANUn;   /* synthesized block */

  void *CANRead1_PWORK_o;              /* '<S64>/CAN Read1' */
  real32_T Delay1_4_DSTATE;            /* '<S119>/Delay1' */
  real32_T Delay1_3_DSTATE;            /* '<S119>/Delay1' */
  real32_T Delay1_2_DSTATE;            /* '<S119>/Delay1' */
  real32_T Delay1_1_DSTATE;            /* '<S119>/Delay1' */
  int32_T clockTickCounter;            /* '<S45>/Pulse Generator' */
  int32_T sfEvent;                     /* '<S27>/State Transition Table' */
  uint32_T is_c4_D_20230119_Modell_Inbetri;/* '<S27>/State Transition Table' */
  int_T Analoginput_IWORK[2];          /* '<S5>/Analog input ' */
  int_T UDPReceive1_IWORK[3];          /* '<S2>/UDP Receive1' */
  int_T ByteUnpacking_IWORK[2];        /* '<S2>/Byte Unpacking' */
  struct {
    int_T MODULEARCHITECTURE_I_IND;
  } Setup_IWORK;                       /* '<S7>/Setup' */

  int_T BytePacking_IWORK[2];          /* '<S2>/Byte Packing' */
  int_T FromJetson_IWORK[3];           /* '<S10>/From Jetson' */
  int_T UDPSend_IWORK[2];              /* '<S2>/UDP Send' */
  int_T CANUnpack_ModeSignalID;        /* '<S65>/CAN Unpack' */
  int_T CANUnpack_StatusPortID;        /* '<S65>/CAN Unpack' */
  int_T CANUnpack1_ModeSignalID;       /* '<S65>/CAN Unpack1' */
  int_T CANUnpack1_StatusPortID;       /* '<S65>/CAN Unpack1' */
  int_T CANUnpack2_ModeSignalID;       /* '<S65>/CAN Unpack2' */
  int_T CANUnpack2_StatusPortID;       /* '<S65>/CAN Unpack2' */
  int_T CANUnpack4_ModeSignalID;       /* '<S65>/CAN Unpack4' */
  int_T CANUnpack4_StatusPortID;       /* '<S65>/CAN Unpack4' */
  int_T CANUnpack5_ModeSignalID;       /* '<S65>/CAN Unpack5' */
  int_T CANUnpack5_StatusPortID;       /* '<S65>/CAN Unpack5' */
  int_T CANUnpack_ModeSignalID_d;      /* '<S64>/CAN Unpack' */
  int_T CANUnpack_StatusPortID_j;      /* '<S64>/CAN Unpack' */
  int_T CANUnpack1_ModeSignalID_f;     /* '<S64>/CAN Unpack1' */
  int_T CANUnpack1_StatusPortID_o;     /* '<S64>/CAN Unpack1' */
  int_T CANUnpack2_ModeSignalID_i;     /* '<S64>/CAN Unpack2' */
  int_T CANUnpack2_StatusPortID_d;     /* '<S64>/CAN Unpack2' */
  int_T CANUnpack3_ModeSignalID;       /* '<S64>/CAN Unpack3' */
  int_T CANUnpack3_StatusPortID;       /* '<S64>/CAN Unpack3' */
  int_T CANUnpack4_ModeSignalID_k;     /* '<S64>/CAN Unpack4' */
  int_T CANUnpack4_StatusPortID_m;     /* '<S64>/CAN Unpack4' */
  int_T CANUnpack5_ModeSignalID_a;     /* '<S64>/CAN Unpack5' */
  int_T CANUnpack5_StatusPortID_d;     /* '<S64>/CAN Unpack5' */
  int_T CANUnpack6_ModeSignalID;       /* '<S64>/CAN Unpack6' */
  int_T CANUnpack6_StatusPortID;       /* '<S64>/CAN Unpack6' */
  int_T CANUnpack7_ModeSignalID;       /* '<S64>/CAN Unpack7' */
  int_T CANUnpack7_StatusPortID;       /* '<S64>/CAN Unpack7' */
  int_T CANUnpack8_ModeSignalID;       /* '<S64>/CAN Unpack8' */
  int_T CANUnpack8_StatusPortID;       /* '<S64>/CAN Unpack8' */
  uint16_T UDPSend_DWORK2;             /* '<S2>/UDP Send' */
  boolean_T UnitDelay_DSTATE_e;        /* '<S44>/Unit Delay' */
  boolean_T UnitDelay_DSTATE_c;        /* '<S15>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE;         /* '<S25>/Unit Delay1' */
  boolean_T DelayInput1_DSTATE;        /* '<S29>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_b;      /* '<S31>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_j;      /* '<S53>/Delay Input1' */
  int8_T TmpRTBAtSwitchInport1_RdBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_WrBufIdx;/* synthesized block */
  int8_T DiscreteTimeIntegrator2_PrevRes;/* '<S49>/Discrete-Time Integrator2' */
  int8_T TmpRTBAtSwitchInport1_RdBufId_g;/* synthesized block */
  int8_T TmpRTBAtSwitchInport1_WrBufId_g;/* synthesized block */
  int8_T Autonom_ON_LstBufWR;          /* synthesized block */
  int8_T Autonom_ON_RDBuf;             /* synthesized block */
  int8_T RT_RdBufIdx;                  /* '<S66>/RT' */
  int8_T RT_WrBufIdx;                  /* '<S66>/RT' */
  int8_T RT1_RdBufIdx;                 /* '<S66>/RT1' */
  int8_T RT1_WrBufIdx;                 /* '<S66>/RT1' */
<<<<<<< .mine
||||||| .r78
  int8_T RateTransition1_RdBufIdx;     /* '<S10>/Rate Transition1' */
  int8_T RateTransition1_WrBufIdx;     /* '<S10>/Rate Transition1' */
=======
  int8_T TmpRTBAtAdd2Inport1_RdBufIdx; /* synthesized block */
  int8_T TmpRTBAtAdd2Inport1_WrBufIdx; /* synthesized block */
  int8_T TmpRTBAtSumInport1_RdBufIdx;  /* synthesized block */
  int8_T TmpRTBAtSumInport1_WrBufIdx;  /* synthesized block */
  int8_T TmpRTBAtSumDInport1_RdBufIdx; /* synthesized block */
  int8_T TmpRTBAtSumDInport1_WrBufIdx; /* synthesized block */
  int8_T TmpRTBAtEqual1Inport2_RdBufIdx;/* synthesized block */
  int8_T TmpRTBAtEqual1Inport2_WrBufIdx;/* synthesized block */
  int8_T TmpRTBAtEqual1Inport2_Buf[2]; /* synthesized block */
  int8_T TmpRTBAtSwitchInport3_RdBufIdx;/* synthesized block */
  int8_T TmpRTBAtSwitchInport3_WrBufIdx;/* synthesized block */
>>>>>>> .r84
  int8_T RateTransition2_RdBufIdx;     /* '<S10>/Rate Transition2' */
  int8_T RateTransition2_WrBufIdx;     /* '<S10>/Rate Transition2' */
  int8_T TmpRTBAtTransferFcn1Inport1_RdB;/* synthesized block */
  int8_T TmpRTBAtTransferFcn1Inport1_WrB;/* synthesized block */
  int8_T TmpRTBAtTransferFcnInport1_RdBu;/* synthesized block */
  int8_T TmpRTBAtTransferFcnInport1_WrBu;/* synthesized block */
  int8_T TmpRTBAtBytePackingOutport1_RdB;/* synthesized block */
  int8_T TmpRTBAtBytePackingOutport1_WrB;/* synthesized block */
<<<<<<< .mine
  int8_T RateTransition1_RdBufIdx;     /* '<S10>/Rate Transition1' */
  int8_T RateTransition1_WrBufIdx;     /* '<S10>/Rate Transition1' */
||||||| .r78
=======
  int8_T TmpRTBAtAddInport1_RdBufIdx;  /* synthesized block */
  int8_T TmpRTBAtAddInport1_WrBufIdx;  /* synthesized block */
  int8_T RateTransition1_RdBufIdx;     /* '<S10>/Rate Transition1' */
  int8_T RateTransition1_WrBufIdx;     /* '<S10>/Rate Transition1' */
>>>>>>> .r84
  int8_T Odometer_RdBufIdx;            /* synthesized block */
  int8_T Odometer_WrBufIdx;            /* synthesized block */
  int8_T SoC_RdBufIdx;                 /* synthesized block */
  int8_T SoC_WrBufIdx;                 /* synthesized block */
  int8_T CenterfromNone1_SubsysRanBC;  /* '<S119>/Center from None1' */
  int8_T CenterfromRight1_SubsysRanBC; /* '<S119>/Center from Right1' */
  int8_T CenterfromLeft1_SubsysRanBC;  /* '<S119>/Center from Left1' */
  int8_T CenterfromLeftandRight1_SubsysR;
                                      /* '<S119>/Center from Left and Right1' */
  int8_T POSITIVEEdge_SubsysRanBC;     /* '<S35>/POSITIVE Edge' */
  int8_T NEGATIVEEdge_SubsysRanBC;     /* '<S35>/NEGATIVE Edge' */
  int8_T TriggeredSubsystem_SubsysRanBC;/* '<S36>/Triggered Subsystem' */
  uint8_T TmpRTBAtBytePackingOutport1_Buf[48];/* synthesized block */
  uint8_T is_active_c4_D_20230119_Modell_;/* '<S27>/State Transition Table' */
  boolean_T IC1_FirstOutputTime_b;     /* '<S2>/IC1' */
  boolean_T IC_FirstOutputTime_j;      /* '<S2>/IC' */
  boolean_T Memory_PreviousInput;      /* '<S44>/Memory' */
  boolean_T Memory_PreviousInput_o;    /* '<S35>/Memory' */
  boolean_T Memory1_PreviousInput;     /* '<S44>/Memory1' */
  boolean_T Memory_PreviousInput_d;    /* '<S51>/Memory' */
  boolean_T Memory_PreviousInput_b;    /* '<S92>/Memory' */
  boolean_T objisempty;                /* '<S10>/PackLaneBus' */
  boolean_T POSITIVEEdge_MODE;         /* '<S35>/POSITIVE Edge' */
  boolean_T NEGATIVEEdge_MODE;         /* '<S35>/NEGATIVE Edge' */
  DW_PathFollowingControlSystem_T PathFollowingControlSystem_i;
                                    /* '<S120>/Path Following Control System' */
};

/* Continuous states (default storage) */
struct X_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  real_T TransferFcn_CSTATE;           /* '<S11>/Transfer Fcn' */
  real_T TransferFcn1_CSTATE;          /* '<S11>/Transfer Fcn1' */
  real_T Integrator_CSTATE;            /* '<S45>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S101>/Integrator' */
  real_T Filter_CSTATE;                /* '<S96>/Filter' */
};

/* State derivatives (default storage) */
struct XDot_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  real_T TransferFcn_CSTATE;           /* '<S11>/Transfer Fcn' */
  real_T TransferFcn1_CSTATE;          /* '<S11>/Transfer Fcn1' */
  real_T Integrator_CSTATE;            /* '<S45>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S101>/Integrator' */
  real_T Filter_CSTATE;                /* '<S96>/Filter' */
};

/* State disabled  */
struct XDis_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  boolean_T TransferFcn_CSTATE;        /* '<S11>/Transfer Fcn' */
  boolean_T TransferFcn1_CSTATE;       /* '<S11>/Transfer Fcn1' */
  boolean_T Integrator_CSTATE;         /* '<S45>/Integrator' */
  boolean_T Integrator_CSTATE_i;       /* '<S101>/Integrator' */
  boolean_T Filter_CSTATE;             /* '<S96>/Filter' */
};

/* Zero-crossing (trigger) state */
struct PrevZCX_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  ZCSigState Integrator_Reset_ZCE;     /* '<S45>/Integrator' */
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S36>/Triggered Subsystem' */
};

/* Invariant block signals (default storage) */
struct ConstB_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  real_T Width;                        /* '<S13>/Width' */
  real_T Width_d;                      /* '<S14>/Width' */
  real_T Width_g;                      /* '<S41>/Width' */
  real_T Width_f;                      /* '<S2>/Width' */
  real_T Width_gx;                     /* '<S56>/Width' */
  real_T Width_gf;                     /* '<S57>/Width' */
  real_T Width_m;                      /* '<S50>/Width' */
};

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
struct ODE1_IntgData {
  real_T *f[1];                        /* derivatives */
};

#endif

/* Real-time Model Data Structure */
struct tag_RTM_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T {
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[5];
    SimStruct childSFunctions[14];
    SimStruct *childSFunctionPtrs[14];
    struct _ssBlkInfo2 blkInfo2[14];
    struct _ssSFcnModelMethods2 methods2[14];
    struct _ssSFcnModelMethods3 methods3[14];
    struct _ssSFcnModelMethods4 methods4[14];
    struct _ssStatesInfo2 statesInfo2[14];
    ssPeriodicStatesInfo periodicStatesInfo[14];
    struct _ssPortInfo2 inputOutputPortInfo2[14];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[1];
      mxArray *params[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[4];
      struct _ssOutPortUnit outputPortUnits[4];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[4];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn3;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      uint_T attribs[4];
      mxArray *params[4];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn4;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[4];
      struct _ssInPortUnit inputPortUnits[4];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[4];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn5;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[3];
      struct _ssOutPortUnit outputPortUnits[3];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[3];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn6;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[8];
      struct _ssInPortUnit inputPortUnits[8];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[8];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn7;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[5];
      mxArray *params[5];
    } Sfcn8;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn9;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[5];
      struct _ssInPortUnit inputPortUnits[5];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[5];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn10;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn11;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[8];
      mxArray *params[8];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn12;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      uint_T attribs[3];
      mxArray *params[3];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn13;
  } NonInlinedSFcns;

  X_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][5];
  ODE1_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    uint32_T clockTick3;
    uint32_T clockTickH3;
    uint32_T clockTick4;
    uint32_T clockTickH4;
    struct {
      uint16_T TID[5];
      uint16_T cLimit[5];
    } TaskCounters;

    struct {
      uint16_T TID1_2;
      uint16_T TID1_3;
      uint16_T TID2_3;
      uint16_T TID2_4;
    } RateInteraction;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[5];
    time_T offsetTimesArray[5];
    int_T sampleTimeTaskIDArray[5];
    int_T sampleHitArray[5];
    int_T perTaskSampleHitsArray[25];
    time_T tArray[5];
  } Timing;
};

extern CAN_DATATYPE CAN_DATATYPE_GROUND;

/* Block signals (default storage) */
#ifdef __cplusplus

extern "C"
{

#endif

  extern struct B_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_B;

#ifdef __cplusplus

}

#endif

/* Continuous states (default storage) */
extern X_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_X;

/* Block states (default storage) */
extern struct DW_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_PrevZCX;
extern const ConstB_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T
  D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_ConstB;/* constant block i/o */

#ifdef __cplusplus

extern "C"
{

#endif

  /* Model entry point functions */
  extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_initialize
    (void);
  extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step0(void);
  extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step2(void);
  extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step3(void);
  extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_step4(void);
  extern void D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_terminate(void);

#ifdef __cplusplus

}

#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C"
{

#endif

  extern RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T *const
    D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M;

#ifdef __cplusplus

}

#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson'
 * '<S1>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung'
 * '<S2>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android'
 * '<S3>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Fahrpedal Steuerung'
 * '<S4>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe'
 * '<S5>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO191'
 * '<S6>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO291-HS'
 * '<S7>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO397'
 * '<S8>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691'
 * '<S9>'   : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung'
 * '<S10>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson'
 * '<S11>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Read RC Control'
 * '<S12>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Scope'
 * '<S13>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/Moving Average'
 * '<S14>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/Moving Average1'
 * '<S15>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1'
 * '<S16>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen'
 * '<S17>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen1'
 * '<S18>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant1'
 * '<S19>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant2'
 * '<S20>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant3'
 * '<S21>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant4'
 * '<S22>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant6'
 * '<S23>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Constant7'
 * '<S24>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Compare To Zero1'
 * '<S25>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter'
 * '<S26>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector'
 * '<S27>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/QAD1'
 * '<S28>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen/Compare To Zero'
 * '<S29>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen/Detect Increase'
 * '<S30>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen1/Compare To Zero'
 * '<S31>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Anti-Relaisprellen1/Detect Increase'
 * '<S32>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter/Compare To Constant5'
 * '<S33>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter/Compare To Zero'
 * '<S34>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Counter/Compare To Zero1'
 * '<S35>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model'
 * '<S36>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/Internal dirac generator'
 * '<S37>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/NEGATIVE Edge'
 * '<S38>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/POSITIVE Edge'
 * '<S39>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/Edge Detector/Model/Internal dirac generator/Triggered Subsystem'
 * '<S40>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Bremspedal Steuerung/QAD Steuerung1/QAD1/State Transition Table'
 * '<S41>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android/Detektion_kein_Signal'
 * '<S42>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android/Kurvenanpassung'
 * '<S43>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Com Android/Detektion_kein_Signal/Compare To Constant'
 * '<S44>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe'
 * '<S45>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann'
 * '<S46>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/1s Tastersperre'
 * '<S47>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Compare To Zero'
 * '<S48>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal'
 * '<S49>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Lenkung'
 * '<S50>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/EMV Filter'
 * '<S51>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/S-R Flip-Flop'
 * '<S52>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/1s Tastersperre/Compare To Zero'
 * '<S53>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/1s Tastersperre/Detect Increase'
 * '<S54>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Compare To Constant'
 * '<S55>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Compare To Constant1'
 * '<S56>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Moving Average'
 * '<S57>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Fahrpedal/Moving Average1'
 * '<S58>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/Detektion Lenkung/Compare To Constant4'
 * '<S59>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Freigabe/EMV Filter/Compare To Constant'
 * '<S60>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant'
 * '<S61>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant1'
 * '<S62>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant2'
 * '<S63>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Freigabe/Totmann/Compare To Constant3'
 * '<S64>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 1'
 * '<S65>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/IO691/CAN Read Loop - Port 3'
 * '<S66>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler'
 * '<S67>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller'
 * '<S68>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Anti-windup'
 * '<S69>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/D Gain'
 * '<S70>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Filter'
 * '<S71>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Filter ICs'
 * '<S72>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/I Gain'
 * '<S73>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Ideal P Gain'
 * '<S74>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Ideal P Gain Fdbk'
 * '<S75>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Integrator'
 * '<S76>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Integrator ICs'
 * '<S77>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/N Copy'
 * '<S78>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/N Gain'
 * '<S79>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/P Copy'
 * '<S80>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Parallel P Gain'
 * '<S81>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Reset Signal'
 * '<S82>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Saturation'
 * '<S83>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Saturation Fdbk'
 * '<S84>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Sum'
 * '<S85>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Sum Fdbk'
 * '<S86>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tracking Mode'
 * '<S87>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tracking Mode Sum'
 * '<S88>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tsamp - Integral'
 * '<S89>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tsamp - Ngain'
 * '<S90>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/postSat Signal'
 * '<S91>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/preSat Signal'
 * '<S92>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Anti-windup/Cont. Clamping Parallel'
 * '<S93>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Anti-windup/Cont. Clamping Parallel/Dead Zone'
 * '<S94>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Anti-windup/Cont. Clamping Parallel/Dead Zone/Enabled'
 * '<S95>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/D Gain/Internal Parameters'
 * '<S96>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Filter/Cont. Filter'
 * '<S97>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Filter ICs/Internal IC - Filter'
 * '<S98>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/I Gain/Internal Parameters'
 * '<S99>'  : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Ideal P Gain/Passthrough'
 * '<S100>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S101>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Integrator/Continuous'
 * '<S102>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Integrator ICs/Internal IC'
 * '<S103>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/N Copy/Disabled'
 * '<S104>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/N Gain/Internal Parameters'
 * '<S105>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/P Copy/Disabled'
 * '<S106>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Parallel P Gain/Internal Parameters'
 * '<S107>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Reset Signal/Disabled'
 * '<S108>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Saturation/Enabled'
 * '<S109>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Saturation Fdbk/Disabled'
 * '<S110>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Sum/Sum_PID'
 * '<S111>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Sum Fdbk/Disabled'
 * '<S112>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tracking Mode/Disabled'
 * '<S113>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S114>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tsamp - Integral/Passthrough'
 * '<S115>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/Tsamp - Ngain/Passthrough'
 * '<S116>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/postSat Signal/Forward_Path'
 * '<S117>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Lenkung Steuerung/PID-Regler/PID Controller/preSat Signal/Forward_Path'
 * '<S118>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl'
 * '<S119>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1'
 * '<S120>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller'
 * '<S121>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from Left and Right1'
 * '<S122>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from Left1'
 * '<S123>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from None1'
 * '<S124>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Center from Right1'
 * '<S125>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/MATLAB Function1'
 * '<S126>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Preview Curvature'
 * '<S127>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/Estimate Lane Center1/Preview Curvature/ISO 8855 to SAE J670E'
 * '<S128>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System'
 * '<S129>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller'
 * '<S130>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/DataTypeConversion_Ts'
 * '<S131>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/DataTypeConversion_spacing'
 * '<S132>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/DataTypeConversion_tlag'
 * '<S133>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Longitudinal velocity must be positive'
 * '<S134>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers'
 * '<S135>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Models'
 * '<S136>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models'
 * '<S137>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/CurvatureConversion'
 * '<S138>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_Vx'
 * '<S139>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_amax'
 * '<S140>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_amin'
 * '<S141>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_e1'
 * '<S142>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_e2'
 * '<S143>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_extmv'
 * '<S144>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_optsgn'
 * '<S145>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_umax'
 * '<S146>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_umin'
 * '<S147>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Data Processing for MPC Controller/DataTypeConversion_vset'
 * '<S148>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller'
 * '<S149>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller'
 * '<S150>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC'
 * '<S151>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check'
 * '<S152>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check A'
 * '<S153>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check B'
 * '<S154>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check C'
 * '<S155>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check D'
 * '<S156>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check DX'
 * '<S157>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check U'
 * '<S158>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check X'
 * '<S159>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check Y'
 * '<S160>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check1'
 * '<S161>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Matrix Signal Check2'
 * '<S162>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check'
 * '<S163>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check1'
 * '<S164>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check2'
 * '<S165>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check3'
 * '<S166>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check4'
 * '<S167>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check5'
 * '<S168>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check6'
 * '<S169>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check7'
 * '<S170>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Preview Signal Check8'
 * '<S171>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Scalar Signal Check'
 * '<S172>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Scalar Signal Check1'
 * '<S173>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Scalar Signal Check2'
 * '<S174>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Vector Signal Check'
 * '<S175>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Vector Signal Check1'
 * '<S176>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/MPC Vector Signal Check6'
 * '<S177>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/moorx'
 * '<S178>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/optimizer'
 * '<S179>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Controllers/Path Following Controller/Adaptive MPC Controller/MPC/optimizer/FixedHorizonOptimizer'
 * '<S180>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Models/MPC Model'
 * '<S181>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/MPC Models/MPC Model/Adaptive Model'
 * '<S182>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model'
 * '<S183>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model/Vehicle combined dynamics'
 * '<S184>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model/Vehicle lateral dynamics'
 * '<S185>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Vehicle Models/Vehicle parametric model/Vehicle longitudinal dynamics'
 * '<S186>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Read RC Control/Compare To Constant'
 * '<S187>' : 'D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Read RC Control/Compare To Constant1'
 */
#endif   /* RTW_HEADER_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_h_ */

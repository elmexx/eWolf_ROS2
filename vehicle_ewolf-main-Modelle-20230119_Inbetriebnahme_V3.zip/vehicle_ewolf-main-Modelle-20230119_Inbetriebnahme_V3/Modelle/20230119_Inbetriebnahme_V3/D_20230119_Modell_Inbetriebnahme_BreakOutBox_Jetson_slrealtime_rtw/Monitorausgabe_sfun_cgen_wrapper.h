#ifndef _MONITORAUSGABE_SFUN_CGEN_WRAPPER_H_
#define _MONITORAUSGABE_SFUN_CGEN_WRAPPER_H_
#ifdef MATLAB_MEX_FILE
#include "tmwtypes.h"
#else
#include "rtwtypes.h"
#endif

#ifdef __cplusplus
#define SFB_EXTERN_C                   extern "C"
#else
#define SFB_EXTERN_C                   extern
#endif

SFB_EXTERN_C void Monitorausgabe_sfun_Outputs_wrapper_cgen(const real_T *u0,
  const real_T *u1,
  real_T *y0);

#undef SFB_EXTERN_C
#endif

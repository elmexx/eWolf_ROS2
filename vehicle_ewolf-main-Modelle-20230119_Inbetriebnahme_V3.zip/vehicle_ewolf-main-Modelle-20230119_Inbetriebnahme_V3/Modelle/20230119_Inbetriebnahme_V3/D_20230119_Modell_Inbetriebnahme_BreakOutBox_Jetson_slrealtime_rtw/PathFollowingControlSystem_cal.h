#ifndef RTW_HEADER_PathFollowingControlSystem_cal_h_
#define RTW_HEADER_PathFollowingControlSystem_cal_h_
#include "rtwtypes.h"

/* Storage class 'PageSwitching', for system '<S120>/Path Following Control System' */
struct PathFollowingControlSy_cal_type {
  real_T Externalcontrolsignalconstant_V[2];/* Expression: [0;0]
                                             * Referenced by: '<S128>/External control signal constant'
                                             */
  real_T E_zero_Value[2];              /* Expression: zeros(1,2)
                                        * Referenced by: '<S149>/E_zero'
                                        */
  real_T F_zero_Value[3];              /* Expression: zeros(1,3)
                                        * Referenced by: '<S149>/F_zero'
                                        */
  real_T LastPcov_InitialCondition[100];/* Expression: lastPcov
                                         * Referenced by: '<S150>/LastPcov'
                                         */
  real_T ywt_zero_Value[3];            /* Expression: zeros(3,1)
                                        * Referenced by: '<S149>/y.wt_zero'
                                        */
  real_T uwt_zero_Value[2];            /* Expression: zeros(2,1)
                                        * Referenced by: '<S149>/u.wt_zero'
                                        */
  real_T duwt_zero_Value[2];           /* Expression: zeros(2,1)
                                        * Referenced by: '<S149>/du.wt_zero'
                                        */
  real_T umin_scale4_Gain[2];      /* Expression: MVscale(:,ones(1,max(nCC,1)))'
                                    * Referenced by: '<S150>/umin_scale4'
                                    */
  real_T ymin_scale1_Gain[3];       /* Expression: Yscale(:,ones(1,max(nCC,1)))'
                                     * Referenced by: '<S150>/ymin_scale1'
                                     */
  real_T extmv_zero_Value[2];          /* Expression: zeros(2,1)
                                        * Referenced by: '<S149>/ext.mv_zero'
                                        */
  real_T extmv_scale_Gain[2];          /* Expression: RMVscale
                                        * Referenced by: '<S150>/ext.mv_scale'
                                        */
  real_T last_mv_InitialCondition[2];  /* Expression: lastu+uoff
                                        * Referenced by: '<S150>/last_mv'
                                        */
  real_T last_x_InitialCondition[10];  /* Expression: lastx+xoff
                                        * Referenced by: '<S150>/last_x'
                                        */
  real_T ymin_zero_Value[3];           /* Expression: zeros(3,1)
                                        * Referenced by: '<S149>/ymin_zero'
                                        */
  real_T ymax_zero_Value[3];           /* Expression: zeros(3,1)
                                        * Referenced by: '<S149>/ymax_zero'
                                        */
  real_T mvtarget_zero_Value[2];       /* Expression: zeros(2,1)
                                        * Referenced by: '<S149>/mv.target_zero'
                                        */
  real_T uref_scale_Gain[2];           /* Expression: RMVscale
                                        * Referenced by: '<S150>/uref_scale'
                                        */
  real_T Vectorconstant_Value[2];      /* Expression: zeros(2,1)
                                        * Referenced by: '<S185>/Vector constant'
                                        */
  real_T Matrixconstant_Value[4];      /* Expression: zeros(2)
                                        * Referenced by: '<S183>/Matrix constant'
                                        */
  real_T Vectorconstant_Value_k[2];    /* Expression: zeros(2,1)
                                        * Referenced by: '<S183>/Vector constant'
                                        */
  real_T Cnconstant_Value[2];          /* Expression: [0,1]
                                        * Referenced by: '<S185>/Cn constant'
                                        */
  real_T Matrixconstant1_Value[4];     /* Expression: zeros(2)
                                        * Referenced by: '<S183>/Matrix constant1'
                                        */
  real_T Vectorconstant1_Value[2];     /* Expression: zeros(1,2)
                                        * Referenced by: '<S183>/Vector constant1'
                                        */
  real_T CmConstant_Value[4];          /* Expression: eye(2)
                                        * Referenced by: '<S184>/Cm Constant'
                                        */
  real_T UConstant_Value[3];           /* Expression: zeros(3,1)
                                        * Referenced by: '<S180>/U Constant'
                                        */
  real_T YConstant_Value[3];           /* Expression: [InitialLongVel;0;0]
                                        * Referenced by: '<S180>/Y Constant'
                                        */
  real_T XConstant_Value[9];     /* Expression: zeros(NumEgoStates+2+3*hasLag,1)
                                  * Referenced by: '<S180>/X Constant'
                                  */
  real_T DXConstant_Value[9];    /* Expression: zeros(NumEgoStates+2+3*hasLag,1)
                                  * Referenced by: '<S180>/DX Constant'
                                  */
  real_T u_scale_Gain[2];              /* Expression: MVscale
                                        * Referenced by: '<S150>/u_scale'
                                        */
  real_T useq_scale_Gain[42];          /* Expression: MVscale(:,ones(1,p+1))'
                                        * Referenced by: '<S150>/useq_scale'
                                        */
  real_T useq_scale1_Gain[63];         /* Expression: Yscale(:,ones(1,p+1))'
                                        * Referenced by: '<S150>/useq_scale1'
                                        */
  real_T ym_zero_Value[3];             /* Expression: zeros(nym,1)
                                        * Referenced by: '<S150>/ym_zero'
                                        */
  real_T Longitudinalvelocitymustbeposit;
                              /* Mask Parameter: Longitudinalvelocitymustbeposit
                               * Referenced by: '<S133>/min_val'
                               */
  real_T Lateraldeviationreferenceconsta;/* Expression: 0
                                          * Referenced by: '<S129>/Lateral deviation reference constant'
                                          */
  real_T Relativeyawanglereferenceconsta;/* Expression: 0
                                          * Referenced by: '<S129>/Relative yaw angle reference constant '
                                          */
  real_T Enableoptimizationconstant_Valu;/* Expression: 0
                                          * Referenced by: '<S128>/Enable optimization constant'
                                          */
  real_T Sampletimeconstant_Value;     /* Expression: Ts
                                        * Referenced by: '<S128>/Sample time constant'
                                        */
  real_T Transportlagconstant_Value;   /* Expression: TransportLag
                                        * Referenced by: '<S128>/Transport lag constant'
                                        */
  real_T G_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S149>/G_zero'
                                        */
  real_T p_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S149>/p_zero'
                                        */
  real_T m_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S149>/m_zero'
                                        */
  real_T S_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S149>/S_zero'
                                        */
  real_T ymin_scale2_Gain;         /* Expression: MDscale(:,ones(1,max(nCC,1)))'
                                    * Referenced by: '<S150>/ymin_scale2'
                                    */
  real_T ecrwt_zero_Value;             /* Expression: zeros(1,1)
                                        * Referenced by: '<S149>/ecr.wt_zero'
                                        */
  real_T Scalaroneconstant_Value;      /* Expression: 1
                                        * Referenced by: '<S185>/Scalar one constant'
                                        */
  real_T Vehicleaccelerationtrackingtime;/* Expression: AccelTimeConstant
                                          * Referenced by: '<S185>/Vehicle acceleration tracking time constant'
                                          */
  real_T Vehiclereartirecorneringstiffne;/* Expression: RearTireStiffness
                                          * Referenced by: '<S184>/Vehicle rear tire cornering stiffness constant'
                                          */
  real_T Vehiclefronttirecorneringstiffn;/* Expression: FrontTireStiffness
                                          * Referenced by: '<S184>/Vehicle front tire cornering stiffness constant'
                                          */
  real_T Gain2_Gain;                   /* Expression: -2
                                        * Referenced by: '<S184>/Gain2'
                                        */
  real_T Vehiclemassconstant_Value;    /* Expression: VehicleMass
                                        * Referenced by: '<S184>/Vehicle mass constant'
                                        */
  real_T Vehiclelengthtorearconstant_Val;
                                      /* Expression: cast(LengthToRear,DataType)
                                       * Referenced by: '<S184>/Vehicle length to rear constant'
                                       */
  real_T Vehiclelengthtofrontconstant_Va;
                                     /* Expression: cast(LengthToFront,DataType)
                                      * Referenced by: '<S184>/Vehicle length to front constant'
                                      */
  real_T Gain3_Gain;                   /* Expression: -2
                                        * Referenced by: '<S184>/Gain3'
                                        */
  real_T Vehicleyawinertiaconstant_Value;/* Expression: VehicleYawInertia
                                          * Referenced by: '<S184>/Vehicle yaw inertia constant'
                                          */
  real_T Gain4_Gain;                   /* Expression: -2
                                        * Referenced by: '<S184>/Gain4'
                                        */
  real_T Scalarzeroconstant_Value;     /* Expression: 0
                                        * Referenced by: '<S185>/Scalar zero constant'
                                        */
  real_T Gain_Gain;                    /* Expression: 2
                                        * Referenced by: '<S184>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 2
                                        * Referenced by: '<S184>/Gain1'
                                        */
  real_T Relativedistanceground_Value; /* Expression: 1
                                        * Referenced by: '<S128>/Relative distance ground'
                                        */
  real_T Relativevelocityground_Value; /* Expression: 1
                                        * Referenced by: '<S128>/Relative velocity ground'
                                        */
  real_T Timegapground_Value;          /* Expression: 1
                                        * Referenced by: '<S128>/Time gap ground'
                                        */
  real_T VehicledynamicsmatrixAground_Va;/* Expression: 1
                                          * Referenced by: '<S128>/Vehicle dynamics matrix A ground'
                                          */
  real_T VehicledynamicsmatrixBground_Va;/* Expression: 1
                                          * Referenced by: '<S128>/Vehicle dynamics matrix B ground'
                                          */
  real_T VehicledynamicsmatrixCground_Va;/* Expression: 1
                                          * Referenced by: '<S128>/Vehicle dynamics matrix C ground'
                                          */
  int32_T FixedHorizonOptimizer_Ndis;  /* Expression: Ndis
                                        * Referenced by: '<S178>/FixedHorizonOptimizer'
                                        */
  uint16_T MatrixDimensionCheck_P1[200];
                                  /* Computed Parameter: MatrixDimensionCheck_P1
                                   * Referenced by: '<S151>/Matrix Dimension Check'
                                   */
  uint16_T MatrixDimensionCheck_P2[18];
                                  /* Computed Parameter: MatrixDimensionCheck_P2
                                   * Referenced by: '<S151>/Matrix Dimension Check'
                                   */
  uint16_T MatrixDimensionCheck_P1_m[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_m
                                 * Referenced by: '<S152>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_a[7];
                                /* Computed Parameter: MatrixDimensionCheck_P2_a
                                 * Referenced by: '<S152>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_b[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_b
                                 * Referenced by: '<S153>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_n[7];
                                /* Computed Parameter: MatrixDimensionCheck_P2_n
                                 * Referenced by: '<S153>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_f[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_f
                                 * Referenced by: '<S154>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_e[7];
                                /* Computed Parameter: MatrixDimensionCheck_P2_e
                                 * Referenced by: '<S154>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_g[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_g
                                 * Referenced by: '<S155>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_h[7];
                                /* Computed Parameter: MatrixDimensionCheck_P2_h
                                 * Referenced by: '<S155>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_i[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_i
                                 * Referenced by: '<S156>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_c[8];
                                /* Computed Parameter: MatrixDimensionCheck_P2_c
                                 * Referenced by: '<S156>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_e[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_e
                                 * Referenced by: '<S157>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_nu[7];
                               /* Computed Parameter: MatrixDimensionCheck_P2_nu
                                * Referenced by: '<S157>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_j[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_j
                                 * Referenced by: '<S158>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_k[7];
                                /* Computed Parameter: MatrixDimensionCheck_P2_k
                                 * Referenced by: '<S158>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_c[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_c
                                 * Referenced by: '<S159>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_l[7];
                                /* Computed Parameter: MatrixDimensionCheck_P2_l
                                 * Referenced by: '<S159>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_ef[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_ef
                                * Referenced by: '<S160>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_p[18];
                                /* Computed Parameter: MatrixDimensionCheck_P2_p
                                 * Referenced by: '<S160>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_b2[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_b2
                                * Referenced by: '<S161>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_m[18];
                                /* Computed Parameter: MatrixDimensionCheck_P2_m
                                 * Referenced by: '<S161>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_jv[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_jv
                                * Referenced by: '<S162>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_az[3];
                               /* Computed Parameter: MatrixDimensionCheck_P2_az
                                * Referenced by: '<S162>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_k[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_k
                                 * Referenced by: '<S163>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_d[2];
                                /* Computed Parameter: MatrixDimensionCheck_P2_d
                                 * Referenced by: '<S163>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P1_kb[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_kb
                                * Referenced by: '<S164>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_lp[4];
                               /* Computed Parameter: MatrixDimensionCheck_P2_lp
                                * Referenced by: '<S164>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_o[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_o
                                 * Referenced by: '<S165>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_pv[4];
                               /* Computed Parameter: MatrixDimensionCheck_P2_pv
                                * Referenced by: '<S165>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_ij[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_ij
                                * Referenced by: '<S166>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_nb[5];
                               /* Computed Parameter: MatrixDimensionCheck_P2_nb
                                * Referenced by: '<S166>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_n[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_n
                                 * Referenced by: '<S167>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_ht[4];
                               /* Computed Parameter: MatrixDimensionCheck_P2_ht
                                * Referenced by: '<S167>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_g5[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_g5
                                * Referenced by: '<S168>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_mr[4];
                               /* Computed Parameter: MatrixDimensionCheck_P2_mr
                                * Referenced by: '<S168>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_mh[200];
                               /* Computed Parameter: MatrixDimensionCheck_P1_mh
                                * Referenced by: '<S169>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P2_du[4];
                               /* Computed Parameter: MatrixDimensionCheck_P2_du
                                * Referenced by: '<S169>/Matrix Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P1_p[200];
                                /* Computed Parameter: MatrixDimensionCheck_P1_p
                                 * Referenced by: '<S170>/Matrix Dimension Check'
                                 */
  uint16_T MatrixDimensionCheck_P2_pi[4];
                               /* Computed Parameter: MatrixDimensionCheck_P2_pi
                                * Referenced by: '<S170>/Matrix Dimension Check'
                                */
  uint16_T VectorDimensionCheck_P1[200];
                                  /* Computed Parameter: VectorDimensionCheck_P1
                                   * Referenced by: '<S171>/Vector Dimension Check'
                                   */
  uint16_T VectorDimensionCheck_P2[6];
                                  /* Computed Parameter: VectorDimensionCheck_P2
                                   * Referenced by: '<S171>/Vector Dimension Check'
                                   */
  uint16_T VectorDimensionCheck_P1_n[200];
                                /* Computed Parameter: VectorDimensionCheck_P1_n
                                 * Referenced by: '<S172>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P2_h[6];
                                /* Computed Parameter: VectorDimensionCheck_P2_h
                                 * Referenced by: '<S172>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P1_h[200];
                                /* Computed Parameter: VectorDimensionCheck_P1_h
                                 * Referenced by: '<S173>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P1_nj[200];
                               /* Computed Parameter: VectorDimensionCheck_P1_nj
                                * Referenced by: '<S174>/Vector Dimension Check'
                                */
  uint16_T VectorDimensionCheck_P2_j[6];
                                /* Computed Parameter: VectorDimensionCheck_P2_j
                                 * Referenced by: '<S174>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P1_f[200];
                                /* Computed Parameter: VectorDimensionCheck_P1_f
                                 * Referenced by: '<S175>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P2_n[18];
                                /* Computed Parameter: VectorDimensionCheck_P2_n
                                 * Referenced by: '<S175>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P1_e[200];
                                /* Computed Parameter: VectorDimensionCheck_P1_e
                                 * Referenced by: '<S176>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P2_g[9];
                                /* Computed Parameter: VectorDimensionCheck_P2_g
                                 * Referenced by: '<S176>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P1_i[200];
                                /* Computed Parameter: VectorDimensionCheck_P1_i
                                 * Referenced by: '<S177>/Vector Dimension Check'
                                 */
  uint16_T VectorDimensionCheck_P2_gg[2];
                               /* Computed Parameter: VectorDimensionCheck_P2_gg
                                * Referenced by: '<S177>/Vector Dimension Check'
                                */
  uint16_T MatrixDimensionCheck_P3;    /* Expression: nrow
                                        * Referenced by: '<S151>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4;    /* Expression: ncol
                                        * Referenced by: '<S151>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5;    /* Expression: nsteps
                                        * Referenced by: '<S151>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6;    /* Expression: isltv
                                        * Referenced by: '<S151>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_m;  /* Expression: nrow
                                        * Referenced by: '<S152>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_o;  /* Expression: ncol
                                        * Referenced by: '<S152>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_g;  /* Expression: nsteps
                                        * Referenced by: '<S152>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_k;  /* Expression: isltv
                                        * Referenced by: '<S152>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_k;  /* Expression: nrow
                                        * Referenced by: '<S153>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_p;  /* Expression: ncol
                                        * Referenced by: '<S153>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_c;  /* Expression: nsteps
                                        * Referenced by: '<S153>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_p;  /* Expression: isltv
                                        * Referenced by: '<S153>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_d;  /* Expression: nrow
                                        * Referenced by: '<S154>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_f;  /* Expression: ncol
                                        * Referenced by: '<S154>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_n;  /* Expression: nsteps
                                        * Referenced by: '<S154>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_pk; /* Expression: isltv
                                        * Referenced by: '<S154>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_p;  /* Expression: nrow
                                        * Referenced by: '<S155>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_pl; /* Expression: ncol
                                        * Referenced by: '<S155>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_p;  /* Expression: nsteps
                                        * Referenced by: '<S155>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_m;  /* Expression: isltv
                                        * Referenced by: '<S155>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_c;  /* Expression: nrow
                                        * Referenced by: '<S156>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_plj;/* Expression: ncol
                                        * Referenced by: '<S156>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_gu; /* Expression: nsteps
                                        * Referenced by: '<S156>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_e;  /* Expression: isltv
                                        * Referenced by: '<S156>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_l;  /* Expression: nrow
                                        * Referenced by: '<S157>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_d;  /* Expression: ncol
                                        * Referenced by: '<S157>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_ct; /* Expression: nsteps
                                        * Referenced by: '<S157>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_c;  /* Expression: isltv
                                        * Referenced by: '<S157>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_j;  /* Expression: nrow
                                        * Referenced by: '<S158>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_fn; /* Expression: ncol
                                        * Referenced by: '<S158>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_d;  /* Expression: nsteps
                                        * Referenced by: '<S158>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_g;  /* Expression: isltv
                                        * Referenced by: '<S158>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_f;  /* Expression: nrow
                                        * Referenced by: '<S159>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_a;  /* Expression: ncol
                                        * Referenced by: '<S159>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_e;  /* Expression: nsteps
                                        * Referenced by: '<S159>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_i;  /* Expression: isltv
                                        * Referenced by: '<S159>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_dr; /* Expression: nrow
                                        * Referenced by: '<S160>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_b;  /* Expression: ncol
                                        * Referenced by: '<S160>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_i;  /* Expression: nsteps
                                        * Referenced by: '<S160>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_f;  /* Expression: isltv
                                        * Referenced by: '<S160>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_l1; /* Expression: nrow
                                        * Referenced by: '<S161>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_g;  /* Expression: ncol
                                        * Referenced by: '<S161>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P5_p4; /* Expression: nsteps
                                        * Referenced by: '<S161>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P6_h;  /* Expression: isltv
                                        * Referenced by: '<S161>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_kl; /* Expression: nrow
                                        * Referenced by: '<S162>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_f1; /* Expression: ncol
                                        * Referenced by: '<S162>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_n;  /* Expression: nrow
                                        * Referenced by: '<S163>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_bl; /* Expression: ncol
                                        * Referenced by: '<S163>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_o;  /* Expression: nrow
                                        * Referenced by: '<S164>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_n;  /* Expression: ncol
                                        * Referenced by: '<S164>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_pl; /* Expression: nrow
                                        * Referenced by: '<S165>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_m;  /* Expression: ncol
                                        * Referenced by: '<S165>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_kn; /* Expression: nrow
                                        * Referenced by: '<S166>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_nm; /* Expression: ncol
                                        * Referenced by: '<S166>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_jr; /* Expression: nrow
                                        * Referenced by: '<S167>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_l;  /* Expression: ncol
                                        * Referenced by: '<S167>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_a;  /* Expression: nrow
                                        * Referenced by: '<S168>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_mi; /* Expression: ncol
                                        * Referenced by: '<S168>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_dt; /* Expression: nrow
                                        * Referenced by: '<S169>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_gx; /* Expression: ncol
                                        * Referenced by: '<S169>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P3_h;  /* Expression: nrow
                                        * Referenced by: '<S170>/Matrix Dimension Check'
                                        */
  uint16_T MatrixDimensionCheck_P4_mb; /* Expression: ncol
                                        * Referenced by: '<S170>/Matrix Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P2_h3;
                               /* Computed Parameter: VectorDimensionCheck_P2_h3
                                * Referenced by: '<S173>/Vector Dimension Check'
                                */
  uint16_T VectorDimensionCheck_P3;    /* Expression: n
                                        * Referenced by: '<S174>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P4;    /* Expression: option
                                        * Referenced by: '<S174>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P3_i;  /* Expression: n
                                        * Referenced by: '<S175>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P4_p;  /* Expression: option
                                        * Referenced by: '<S175>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P3_e;  /* Expression: n
                                        * Referenced by: '<S176>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P4_k;  /* Expression: option
                                        * Referenced by: '<S176>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P3_f;  /* Expression: n
                                        * Referenced by: '<S177>/Vector Dimension Check'
                                        */
  uint16_T VectorDimensionCheck_P4_e;  /* Expression: option
                                        * Referenced by: '<S177>/Vector Dimension Check'
                                        */
  boolean_T Memory_InitialCondition[8];/* Expression: iA
                                        * Referenced by: '<S150>/Memory'
                                        */
};

#endif                        /* RTW_HEADER_PathFollowingControlSystem_cal_h_ */

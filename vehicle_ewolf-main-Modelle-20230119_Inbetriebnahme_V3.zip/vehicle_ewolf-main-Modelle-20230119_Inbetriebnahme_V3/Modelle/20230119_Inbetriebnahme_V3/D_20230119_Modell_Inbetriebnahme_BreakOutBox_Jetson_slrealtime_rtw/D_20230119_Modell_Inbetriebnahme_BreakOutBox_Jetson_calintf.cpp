#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_calintf.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_cal.h"

extern D_20230119_Modell_Inbe_cal_type D_20230119_Modell_Inbe_cal_impl;
namespace slrealtime
{
  /* Description of SEGMENTS */
  SegmentVector segmentInfo {
    { (void*)&D_20230119_Modell_Inbe_cal_impl, (void**)
      &D_20230119_Modell_Inbetrieb_cal, sizeof(D_20230119_Modell_Inbe_cal_type),
      2 }
  };

  SegmentVector &getSegmentVector(void)
  {
    return segmentInfo;
  }
}                                      // slrealtime

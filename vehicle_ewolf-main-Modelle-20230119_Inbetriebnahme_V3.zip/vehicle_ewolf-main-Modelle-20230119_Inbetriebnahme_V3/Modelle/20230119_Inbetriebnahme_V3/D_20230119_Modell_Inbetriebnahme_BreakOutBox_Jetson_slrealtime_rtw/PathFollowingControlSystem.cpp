/*
 * Code generation for system system '<S120>/Path Following Control System'
 *
 * Model                      : D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson
<<<<<<< .mine
 * Model version              : 4.38
||||||| .r78
 * Model version              : 4.24
=======
 * Model version              : 4.33
>>>>>>> .r84
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
<<<<<<< .mine
 * C++ source code generated on : Thu Oct  5 15:53:28 2023
||||||| .r78
 * C++ source code generated on : Thu May 11 16:00:17 2023
=======
 * C++ source code generated on : Fri Oct 13 13:42:54 2023
>>>>>>> .r84
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "rtwtypes.h"
#include "PathFollowingControlSystem.h"
#include "PathFollowingControlSystem_cal.h"
#include <cstring>
#include "rt_assert.h"
#include <cmath>
#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_private.h"

extern "C"
{

#include "rt_nonfinite.h"

}

#include "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson.h"

/* Named constants for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
const real_T D_20230119_Modell_Inbe_RMDscale = 10.0;
const int32_T D_20230119_Modell_Inbet_degrees = 5;
const int32_T D_20230119_Modell_Inbetriebn_nu = 2;
const int32_T D_20230119_Modell_Inbetriebn_ny = 3;
const int32_T D_20230119_Modell_Inbetriebna_p = 20;

/* Forward declaration for local functions */
static void D_20230_PadeApproximantOfDegree(const real_T A[81], uint8_T m,
  real_T F[81]);
static void D_20230119_Modell_In_expmNoLog2(real_T A[81], real_T F[81]);
static int32_T D_20230119_Modell_Inbetr_xpotrf(real_T b_A[25]);
static real_T D_20230119_Modell_Inbet_minimum(const real_T x[5]);
static void D_20230119_Modell_Inbe_trisolve(const real_T b_A[25], real_T b_B[25]);
static real_T D_20230119_Modell_Inbetrie_norm(const real_T x[5]);
static real_T D_20230119_Modell_Inbetri_xnrm2(int32_T n, const real_T x[25],
  int32_T ix0);
static void D_20230119_Modell_Inbetri_xgemv(int32_T b_m, int32_T n, const real_T
  b_A[25], int32_T ia0, const real_T x[25], int32_T ix0, real_T y[5]);
static void D_20230119_Modell_Inbetri_xgerc(int32_T b_m, int32_T n, real_T
  alpha1, int32_T ix0, const real_T y[5], real_T b_A[25], int32_T ia0);
static void D_20230119_Modell_In_KWIKfactor(const real_T b_Ac[40], const int32_T
  iC[8], int32_T nA, const real_T b_Linv[25], real_T b_D[25], real_T b_H[25],
  int32_T n, real_T RLinv[25], real_T *Status);
static real_T D_20230119_Modell_Inbet_maximum(const real_T x[5]);
static void D_20230119_Model_DropConstraint(int32_T kDrop, boolean_T iA[8],
  int32_T *nA, int32_T iC[8]);
static void D_20230119_Modell_Inbetr_qpkwik(const real_T b_Linv[25], const
  real_T b_Hinv[25], const real_T f[5], const real_T b_Ac[40], const real_T b[8],
  boolean_T iA[8], int32_T maxiter, real_T FeasTol, real_T x[5], real_T lambda[8],
  int32_T *status);
static void D_20230119_M_mpcblock_optimizer(const real_T rseq[60], const real_T
  vseq[42], const real_T umin[2], const real_T umax[2], int32_T switch_in, const
  real_T x[10], const real_T old_u[2], const boolean_T iA[8], const real_T
  b_Mlim[8], real_T b_Mx[80], real_T b_Mu1[16], real_T b_Mv[336], const real_T
  b_utarget[40], const real_T b_uoff[2], int32_T b_enable_value, real_T b_H[25],
  real_T b_Ac[40], const real_T b_Wy[3], const real_T b_Wdu[2], const real_T
  b_Jm[160], const real_T b_Wu[2], const real_T b_I1[80], const real_T b_A[100],
  const real_T Bu[420], const real_T Bv[420], const real_T b_C[30], const real_T
  Dv[126], const int32_T b_Mrows[8], const real_T b_RMVscale[2], real_T u[2],
  real_T useq[42], real_T *status, boolean_T iAout[8],
  B_PathFollowingControlSystem__T *localB);

/*
 * Output and update for atomic system:
 *    '<S129>/DataTypeConversion_Vx'
 *    '<S129>/DataTypeConversion_e1'
 *    '<S129>/DataTypeConversion_e2'
 */
void D_202_DataTypeConversion_Vx(real_T rtu_u, B_DataTypeConversion_Vx_D_202_T
  *localB)
{
  localB->y = rtu_u;
}

/*
 * Output and update for atomic system:
 *    '<S129>/DataTypeConversion_amax'
 *    '<S129>/DataTypeConversion_amin'
 *    '<S129>/DataTypeConversion_umax'
 *    '<S129>/DataTypeConversion_umin'
 *    '<S128>/DataTypeConversion_Ts'
 *    '<S128>/DataTypeConversion_spacing'
 *    '<S128>/DataTypeConversion_tlag'
 */
void D_2_DataTypeConversion_amax(real_T rtu_u, B_DataTypeConversion_amax_D_2_T
  *localB)
{
  localB->y = rtu_u;
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = std::abs(u0);
    tmp_0 = std::abs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = (rtNaN);
    } else {
      y = std::pow(u0, u1);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S180>/Adaptive Model' */
static void D_20230_PadeApproximantOfDegree(const real_T A[81], uint8_T m,
  real_T F[81])
{
  real_T A2[81];
  real_T A3[81];
  real_T A4[81];
  real_T A4_0[81];
  real_T V[81];
  real_T d;
  real_T s;
  int32_T b_ix;
  int32_T ix;
  int32_T iy;
  int32_T jj;
  int8_T ipiv[9];
  for (int32_T e_k = 0; e_k < 9; e_k++) {
    for (jj = 0; jj < 9; jj++) {
      A2[jj + 9 * e_k] = 0.0;
      for (iy = 0; iy < 9; iy++) {
        d = A2[9 * e_k + jj];
        d += A[9 * iy + jj] * A[9 * e_k + iy];
        A2[jj + 9 * e_k] = d;
      }
    }
  }

  if (m == 3) {
    std::memcpy(&F[0], &A2[0], 81U * sizeof(real_T));
    for (int32_T e_k = 0; e_k < 9; e_k++) {
      d = F[9 * e_k + e_k];
      d += 60.0;
      F[e_k + 9 * e_k] = d;
    }

    for (int32_T e_k = 0; e_k < 9; e_k++) {
      for (jj = 0; jj < 9; jj++) {
        A4_0[jj + 9 * e_k] = 0.0;
        for (iy = 0; iy < 9; iy++) {
          d = A4_0[9 * e_k + jj];
          d += A[9 * iy + jj] * F[9 * e_k + iy];
          A4_0[jj + 9 * e_k] = d;
        }
      }
    }

    for (int32_T e_k = 0; e_k < 81; e_k++) {
      F[e_k] = A4_0[e_k];
      V[e_k] = 12.0 * A2[e_k];
    }

    d = 120.0;
  } else {
    for (int32_T e_k = 0; e_k < 9; e_k++) {
      for (jj = 0; jj < 9; jj++) {
        A3[jj + 9 * e_k] = 0.0;
        for (iy = 0; iy < 9; iy++) {
          d = A3[9 * e_k + jj];
          d += A2[9 * iy + jj] * A2[9 * e_k + iy];
          A3[jj + 9 * e_k] = d;
        }
      }
    }

    if (m == 5) {
      for (int32_T e_k = 0; e_k < 81; e_k++) {
        F[e_k] = 420.0 * A2[e_k] + A3[e_k];
      }

      for (int32_T e_k = 0; e_k < 9; e_k++) {
        d = F[9 * e_k + e_k];
        d += 15120.0;
        F[e_k + 9 * e_k] = d;
      }

      for (int32_T e_k = 0; e_k < 9; e_k++) {
        for (jj = 0; jj < 9; jj++) {
          A4_0[jj + 9 * e_k] = 0.0;
          for (iy = 0; iy < 9; iy++) {
            d = A4_0[9 * e_k + jj];
            d += A[9 * iy + jj] * F[9 * e_k + iy];
            A4_0[jj + 9 * e_k] = d;
          }
        }
      }

      for (int32_T e_k = 0; e_k < 81; e_k++) {
        F[e_k] = A4_0[e_k];
        V[e_k] = 30.0 * A3[e_k] + 3360.0 * A2[e_k];
      }

      d = 30240.0;
    } else {
      for (int32_T e_k = 0; e_k < 9; e_k++) {
        for (jj = 0; jj < 9; jj++) {
          A4[jj + 9 * e_k] = 0.0;
          for (iy = 0; iy < 9; iy++) {
            d = A4[9 * e_k + jj];
            d += A3[9 * iy + jj] * A2[9 * e_k + iy];
            A4[jj + 9 * e_k] = d;
          }
        }
      }

      if (m == 7) {
        for (int32_T e_k = 0; e_k < 81; e_k++) {
          F[e_k] = (1512.0 * A3[e_k] + A4[e_k]) + 277200.0 * A2[e_k];
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          d = F[9 * e_k + e_k];
          d += 8.64864E+6;
          F[e_k + 9 * e_k] = d;
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          for (jj = 0; jj < 9; jj++) {
            A4_0[jj + 9 * e_k] = 0.0;
            for (iy = 0; iy < 9; iy++) {
              d = A4_0[9 * e_k + jj];
              d += A[9 * iy + jj] * F[9 * e_k + iy];
              A4_0[jj + 9 * e_k] = d;
            }
          }
        }

        for (int32_T e_k = 0; e_k < 81; e_k++) {
          F[e_k] = A4_0[e_k];
          V[e_k] = (56.0 * A4[e_k] + 25200.0 * A3[e_k]) + 1.99584E+6 * A2[e_k];
        }

        d = 1.729728E+7;
      } else if (m == 9) {
        for (int32_T e_k = 0; e_k < 9; e_k++) {
          for (jj = 0; jj < 9; jj++) {
            V[jj + 9 * e_k] = 0.0;
            for (iy = 0; iy < 9; iy++) {
              s = V[9 * e_k + jj];
              s += A4[9 * iy + jj] * A2[9 * e_k + iy];
              V[jj + 9 * e_k] = s;
            }
          }
        }

        for (int32_T e_k = 0; e_k < 81; e_k++) {
          F[e_k] = ((3960.0 * A4[e_k] + V[e_k]) + 2.16216E+6 * A3[e_k]) +
            3.027024E+8 * A2[e_k];
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          d = F[9 * e_k + e_k];
          d += 8.8216128E+9;
          F[e_k + 9 * e_k] = d;
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          for (jj = 0; jj < 9; jj++) {
            A4_0[jj + 9 * e_k] = 0.0;
            for (iy = 0; iy < 9; iy++) {
              d = A4_0[9 * e_k + jj];
              d += A[9 * iy + jj] * F[9 * e_k + iy];
              A4_0[jj + 9 * e_k] = d;
            }
          }
        }

        for (int32_T e_k = 0; e_k < 81; e_k++) {
          s = V[e_k];
          F[e_k] = A4_0[e_k];
          s = ((90.0 * s + 110880.0 * A4[e_k]) + 3.027024E+7 * A3[e_k]) +
            2.0756736E+9 * A2[e_k];
          V[e_k] = s;
        }

        d = 1.76432256E+10;
      } else {
        for (int32_T e_k = 0; e_k < 81; e_k++) {
          F[e_k] = (3.352212864E+10 * A4[e_k] + 1.05594705216E+13 * A3[e_k]) +
            1.1873537964288E+15 * A2[e_k];
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          d = F[9 * e_k + e_k];
          d += 3.238237626624E+16;
          F[e_k + 9 * e_k] = d;
        }

        for (int32_T e_k = 0; e_k < 81; e_k++) {
          V[e_k] = (16380.0 * A3[e_k] + A4[e_k]) + 4.08408E+7 * A2[e_k];
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          for (jj = 0; jj < 9; jj++) {
            d = 0.0;
            for (iy = 0; iy < 9; iy++) {
              d += A4[9 * iy + e_k] * V[9 * jj + iy];
            }

            A4_0[e_k + 9 * jj] = F[9 * jj + e_k] + d;
          }
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          for (jj = 0; jj < 9; jj++) {
            F[jj + 9 * e_k] = 0.0;
            for (iy = 0; iy < 9; iy++) {
              d = F[9 * e_k + jj];
              d += A[9 * iy + jj] * A4_0[9 * e_k + iy];
              F[jj + 9 * e_k] = d;
            }
          }
        }

        for (int32_T e_k = 0; e_k < 81; e_k++) {
          A4_0[e_k] = (182.0 * A4[e_k] + 960960.0 * A3[e_k]) + 1.32324192E+9 *
            A2[e_k];
        }

        for (int32_T e_k = 0; e_k < 9; e_k++) {
          for (jj = 0; jj < 9; jj++) {
            d = 0.0;
            for (iy = 0; iy < 9; iy++) {
              d += A4[9 * iy + e_k] * A4_0[9 * jj + iy];
            }

            V[e_k + 9 * jj] = ((A4[9 * jj + e_k] * 6.704425728E+11 + d) + A3[9 *
                               jj + e_k] * 1.29060195264E+14) + A2[9 * jj + e_k]
              * 7.7717703038976E+15;
          }
        }

        d = 6.476475253248E+16;
      }
    }
  }

  for (int32_T e_k = 0; e_k < 9; e_k++) {
    s = V[9 * e_k + e_k];
    s += d;
    V[e_k + 9 * e_k] = s;
  }

  for (int32_T e_k = 0; e_k < 81; e_k++) {
    d = F[e_k];
    s = V[e_k];
    s -= d;
    d *= 2.0;
    V[e_k] = s;
    F[e_k] = d;
  }

  for (int32_T e_k = 0; e_k < 9; e_k++) {
    ipiv[e_k] = static_cast<int8_T>(e_k + 1);
  }

  for (int32_T e_k = 0; e_k < 8; e_k++) {
    jj = e_k * 10;
    iy = 9 - e_k;
    b_ix = 0;
    ix = jj;
    d = std::abs(V[jj]);
    for (int32_T k_k = 2; k_k <= iy; k_k++) {
      s = std::abs(V[(ix + k_k) - 1]);
      if (s > d) {
        b_ix = k_k - 1;
        d = s;
      }
    }

    if (V[jj + b_ix] != 0.0) {
      if (b_ix != 0) {
        ipiv[e_k] = static_cast<int8_T>((e_k + b_ix) + 1);
        iy = e_k + b_ix;
        b_ix = e_k;
        for (ix = 0; ix < 9; ix++) {
          d = V[ix * 9 + b_ix];
          V[b_ix + ix * 9] = V[iy];
          V[iy] = d;
          iy += 9;
        }
      }

      iy = (jj - e_k) + 9;
      for (b_ix = jj + 2; b_ix <= iy; b_ix++) {
        V[b_ix - 1] /= V[jj];
      }
    }

    iy = 7 - e_k;
    b_ix = jj + 11;
    ix = jj + 9;
    for (int32_T k_k = 0; k_k <= iy; k_k++) {
      if (V[k_k * 9 + ix] != 0.0) {
        int32_T e;
        d = -V[k_k * 9 + ix];
        e = (b_ix - e_k) + 7;
        for (int32_T ijA = b_ix; ijA <= e; ijA++) {
          V[ijA - 1] += V[((jj + ijA) - b_ix) + 1] * d;
        }
      }

      b_ix += 9;
    }
  }

  for (int32_T e_k = 0; e_k < 8; e_k++) {
    int8_T ipiv_0;
    ipiv_0 = ipiv[e_k];
    if (e_k + 1 != ipiv_0) {
      jj = ipiv_0 - 1;
      for (iy = 0; iy < 9; iy++) {
        d = F[9 * iy + e_k];
        F[e_k + 9 * iy] = F[9 * iy + jj];
        F[jj + 9 * iy] = d;
      }
    }
  }

  for (int32_T e_k = 0; e_k < 9; e_k++) {
    jj = 9 * e_k;
    for (iy = 0; iy < 9; iy++) {
      b_ix = 9 * iy;
      if (F[iy + jj] != 0.0) {
        for (ix = iy + 2; ix < 10; ix++) {
          F[(ix + jj) - 1] -= V[(ix + b_ix) - 1] * F[iy + jj];
        }
      }
    }
  }

  for (int32_T e_k = 0; e_k < 9; e_k++) {
    jj = 9 * e_k;
    for (iy = 8; iy >= 0; iy--) {
      b_ix = 9 * iy;
      if (F[iy + jj] != 0.0) {
        F[iy + jj] /= V[iy + b_ix];
        ix = iy;
        for (int32_T k_k = 0; k_k < ix; k_k++) {
          F[k_k + jj] -= F[iy + jj] * V[k_k + b_ix];
        }
      }
    }
  }

  for (int32_T e_k = 0; e_k < 9; e_k++) {
    d = F[9 * e_k + e_k];
    d++;
    F[e_k + 9 * e_k] = d;
  }
}

/* Function for MATLAB Function: '<S180>/Adaptive Model' */
static void D_20230119_Modell_In_expmNoLog2(real_T A[81], real_T F[81])
{
  real_T F_0[81];
  real_T b_s;
  real_T normA;
  int32_T b_j;
  static const real_T c[5] = { 0.01495585217958292, 0.253939833006323,
    0.95041789961629319, 2.097847961257068, 5.3719203511481517 };

  static const uint8_T d[5] = { 3U, 5U, 7U, 9U, 13U };

  boolean_T exitg1;
  normA = 0.0;
  b_j = 0;
  exitg1 = false;
  while ((!exitg1) && (b_j < 9)) {
    b_s = 0.0;
    for (int32_T b_i = 0; b_i < 9; b_i++) {
      b_s += std::abs(A[9 * b_j + b_i]);
    }

    if (rtIsNaN(b_s)) {
      normA = (rtNaN);
      exitg1 = true;
    } else {
      if (b_s > normA) {
        normA = b_s;
      }

      b_j++;
    }
  }

  if (normA <= 5.3719203511481517) {
    b_j = 0;
    exitg1 = false;
    while ((!exitg1) && (b_j < 5)) {
      if (normA <= c[b_j]) {
        D_20230_PadeApproximantOfDegree(A, d[b_j], F);
        exitg1 = true;
      } else {
        b_j++;
      }
    }
  } else {
    if (rtIsInf(normA) || rtIsNaN(normA)) {
      normA = 0.0;
    } else {
      b_s = normA / 5.3719203511481517;
      normA = std::floor(std::log(b_s) / 0.69314718055994529);
      b_s *= rt_powd_snf(2.0, -normA);
      if (b_s < 0.5) {
        normA--;
        b_s *= 2.0;
      } else if (b_s >= 1.0) {
        normA++;
        b_s *= 0.5;
      }

      if (b_s == 0.5) {
        normA--;
      }
    }

    b_s = rt_powd_snf(2.0, normA);
    for (int32_T i = 0; i < 81; i++) {
      real_T A_0;
      A_0 = A[i];
      A_0 /= b_s;
      A[i] = A_0;
    }

    D_20230_PadeApproximantOfDegree(A, 13, F);
    b_j = static_cast<int32_T>(normA);
    for (int32_T b_i = 0; b_i < b_j; b_i++) {
      for (int32_T i = 0; i < 9; i++) {
        for (int32_T i_0 = 0; i_0 < 9; i_0++) {
          F_0[i + 9 * i_0] = 0.0;
          for (int32_T i_1 = 0; i_1 < 9; i_1++) {
            normA = F_0[9 * i_0 + i];
            normA += F[9 * i_1 + i] * F[9 * i_0 + i_1];
            F_0[i + 9 * i_0] = normA;
          }
        }
      }

      std::memcpy(&F[0], &F_0[0], 81U * sizeof(real_T));
    }
  }
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static int32_T D_20230119_Modell_Inbetr_xpotrf(real_T b_A[25])
{
  int32_T b_ix;
  int32_T info;
  boolean_T exitg1;
  info = 0;
  b_ix = 0;
  exitg1 = false;
  while ((!exitg1) && (b_ix < 5)) {
    real_T ssq;
    int32_T b_iy;
    int32_T idxAjj;
    int32_T jm1;
    jm1 = b_ix;
    idxAjj = b_ix * 5 + b_ix;
    ssq = 0.0;
    if (b_ix >= 1) {
      b_iy = b_ix;
      for (int32_T b_k = 0; b_k < jm1; b_k++) {
        ssq += b_A[b_k * 5 + b_ix] * b_A[b_k * 5 + b_iy];
      }
    }

    ssq = b_A[idxAjj] - ssq;
    if (ssq > 0.0) {
      ssq = std::sqrt(ssq);
      b_A[idxAjj] = ssq;
      if (b_ix + 1 < 5) {
        if (b_ix != 0) {
          b_iy = ((b_ix - 1) * 5 + b_ix) + 2;
          for (int32_T b_k = b_ix + 2; b_k <= b_iy; b_k += 5) {
            real_T c;
            int32_T d;
            int32_T iy;
            c = -b_A[div_nde_s32_floor((b_k - b_ix) - 2, 5) * 5 + b_ix];
            iy = idxAjj + 1;
            d = (b_k - b_ix) + 3;
            for (jm1 = b_k; jm1 <= d; jm1++) {
              b_A[(iy + jm1) - b_k] += b_A[jm1 - 1] * c;
            }
          }
        }

        ssq = 1.0 / ssq;
        jm1 = (idxAjj - b_ix) + 5;
        for (int32_T b_k = idxAjj + 2; b_k <= jm1; b_k++) {
          b_A[b_k - 1] *= ssq;
        }
      }

      b_ix++;
    } else {
      b_A[idxAjj] = ssq;
      info = b_ix + 1;
      exitg1 = true;
    }
  }

  return info;
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static real_T D_20230119_Modell_Inbet_minimum(const real_T x[5])
{
  real_T ex;
  int32_T idx;
  int32_T k;
  if (!rtIsNaN(x[0])) {
    idx = 1;
  } else {
    boolean_T exitg1;
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k < 6)) {
      if (!rtIsNaN(x[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  if (idx == 0) {
    ex = x[0];
  } else {
    ex = x[idx - 1];
    for (k = idx + 1; k < 6; k++) {
      if (ex > x[k - 1]) {
        ex = x[k - 1];
      }
    }
  }

  return ex;
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_Modell_Inbe_trisolve(const real_T b_A[25], real_T b_B[25])
{
  for (int32_T j = 0; j < 5; j++) {
    int32_T jBcol;
    jBcol = 5 * j;
    for (int32_T b_k = 0; b_k < 5; b_k++) {
      int32_T kAcol;
      kAcol = 5 * b_k;
      if (b_B[b_k + jBcol] != 0.0) {
        b_B[b_k + jBcol] /= b_A[b_k + kAcol];
        for (int32_T i = b_k + 2; i < 6; i++) {
          b_B[(i + jBcol) - 1] -= b_A[(i + kAcol) - 1] * b_B[b_k + jBcol];
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static real_T D_20230119_Modell_Inbetrie_norm(const real_T x[5])
{
  real_T scale;
  real_T y;
  y = 0.0;
  scale = 3.3121686421112381E-170;
  for (int32_T k = 0; k < 5; k++) {
    real_T absxk;
    absxk = std::abs(x[k]);
    if (absxk > scale) {
      real_T t;
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      real_T t;
      t = absxk / scale;
      y += t * t;
    }
  }

  return scale * std::sqrt(y);
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static real_T D_20230119_Modell_Inbetri_xnrm2(int32_T n, const real_T x[25],
  int32_T ix0)
{
  real_T y;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = std::abs(x[ix0 - 1]);
    } else {
      real_T scale;
      int32_T kend;
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (int32_T k = ix0; k <= kend; k++) {
        real_T absxk;
        absxk = std::abs(x[k - 1]);
        if (absxk > scale) {
          real_T t;
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          real_T t;
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * std::sqrt(y);
    }
  }

  return y;
}

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T a;
  real_T b;
  real_T y;
  a = std::abs(u0);
  b = std::abs(u1);
  if (a < b) {
    a /= b;
    y = std::sqrt(a * a + 1.0) * b;
  } else if (a > b) {
    b /= a;
    y = std::sqrt(b * b + 1.0) * a;
  } else if (rtIsNaN(b)) {
    y = (rtNaN);
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_Modell_Inbetri_xgemv(int32_T b_m, int32_T n, const real_T
  b_A[25], int32_T ia0, const real_T x[25], int32_T ix0, real_T y[5])
{
  if ((b_m != 0) && (n != 0)) {
    int32_T b;
    int32_T iyend;
    iyend = n;
    if (iyend - 1 >= 0) {
      std::memset(&y[0], 0, static_cast<uint32_T>(iyend) * sizeof(real_T));
    }

    b = (n - 1) * 5 + ia0;
    for (int32_T b_iy = ia0; b_iy <= b; b_iy += 5) {
      real_T c;
      int32_T d;
      int32_T ix;
      ix = ix0 - 1;
      c = 0.0;
      d = (b_iy + b_m) - 1;
      for (iyend = b_iy; iyend <= d; iyend++) {
        c += x[(ix + iyend) - b_iy] * b_A[iyend - 1];
      }

      y[div_nde_s32_floor(b_iy - ia0, 5)] = y[div_nde_s32_floor(b_iy - ia0, 5)]
        + c;
    }
  }
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_Modell_Inbetri_xgerc(int32_T b_m, int32_T n, real_T
  alpha1, int32_T ix0, const real_T y[5], real_T b_A[25], int32_T ia0)
{
  if (!(alpha1 == 0.0)) {
    int32_T jA;
    jA = ia0;
    for (int32_T j = 0; j < n; j++) {
      real_T temp;
      temp = y[j];
      if (temp != 0.0) {
        int32_T b;
        int32_T ix;
        temp *= alpha1;
        ix = ix0 - 1;
        b = b_m + jA;
        for (int32_T ijA = jA; ijA < b; ijA++) {
          b_A[ijA - 1] += b_A[(ix + ijA) - jA] * temp;
        }
      }

      jA += 5;
    }
  }
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_Modell_In_KWIKfactor(const real_T b_Ac[40], const int32_T
  iC[8], int32_T nA, const real_T b_Linv[25], real_T b_D[25], real_T b_H[25],
  int32_T n, real_T RLinv[25], real_T *Status)
{
  real_T R[25];
  real_T TL[25];
  real_T b_A[25];
  real_T tau[5];
  real_T work[5];
  real_T RLinv_0;
  int32_T b_coltop;
  int32_T b_lastv;
  int32_T coltop;
  int32_T exitg1;
  int32_T ii;
  int32_T k_i;
  int32_T knt;
  boolean_T exitg2;
  *Status = 1.0;
  std::memset(&RLinv[0], 0, 25U * sizeof(real_T));
  for (k_i = 0; k_i < nA; k_i++) {
    b_coltop = iC[k_i];
    for (b_lastv = 0; b_lastv < 5; b_lastv++) {
      RLinv[b_lastv + 5 * k_i] = 0.0;
      for (ii = 0; ii < 5; ii++) {
        RLinv_0 = RLinv[5 * k_i + b_lastv];
        RLinv_0 += b_Ac[((ii << 3) + b_coltop) - 1] * b_Linv[5 * ii + b_lastv];
        RLinv[b_lastv + 5 * k_i] = RLinv_0;
      }
    }
  }

  std::memcpy(&b_A[0], &RLinv[0], 25U * sizeof(real_T));
  for (k_i = 0; k_i < 5; k_i++) {
    tau[k_i] = 0.0;
    work[k_i] = 0.0;
  }

  for (k_i = 0; k_i < 5; k_i++) {
    ii = k_i * 5 + k_i;
    if (k_i + 1 < 5) {
      real_T xnorm;
      RLinv_0 = b_A[ii];
      b_lastv = ii + 2;
      tau[k_i] = 0.0;
      xnorm = D_20230119_Modell_Inbetri_xnrm2(4 - k_i, b_A, ii + 2);
      if (xnorm != 0.0) {
        xnorm = rt_hypotd_snf(b_A[ii], xnorm);
        if (b_A[ii] >= 0.0) {
          xnorm = -xnorm;
        }

        if (std::abs(xnorm) < 1.0020841800044864E-292) {
          knt = 0;
          do {
            knt++;
            coltop = (ii - k_i) + 5;
            for (b_coltop = b_lastv; b_coltop <= coltop; b_coltop++) {
              b_A[b_coltop - 1] *= 9.9792015476736E+291;
            }

            xnorm *= 9.9792015476736E+291;
            RLinv_0 *= 9.9792015476736E+291;
          } while ((std::abs(xnorm) < 1.0020841800044864E-292) && (knt < 20));

          xnorm = rt_hypotd_snf(RLinv_0, D_20230119_Modell_Inbetri_xnrm2(4 - k_i,
            b_A, ii + 2));
          if (RLinv_0 >= 0.0) {
            xnorm = -xnorm;
          }

          tau[k_i] = (xnorm - RLinv_0) / xnorm;
          RLinv_0 = 1.0 / (RLinv_0 - xnorm);
          coltop = (ii - k_i) + 5;
          for (b_coltop = b_lastv; b_coltop <= coltop; b_coltop++) {
            b_A[b_coltop - 1] *= RLinv_0;
          }

          for (b_lastv = 0; b_lastv < knt; b_lastv++) {
            xnorm *= 1.0020841800044864E-292;
          }

          RLinv_0 = xnorm;
        } else {
          tau[k_i] = (xnorm - b_A[ii]) / xnorm;
          RLinv_0 = 1.0 / (b_A[ii] - xnorm);
          b_coltop = (ii - k_i) + 5;
          for (knt = b_lastv; knt <= b_coltop; knt++) {
            b_A[knt - 1] *= RLinv_0;
          }

          RLinv_0 = xnorm;
        }
      }

      b_A[ii] = RLinv_0;
      xnorm = b_A[ii];
      b_A[ii] = 1.0;
      if (tau[k_i] != 0.0) {
        b_lastv = 5 - k_i;
        knt = (ii - k_i) + 4;
        while ((b_lastv > 0) && (b_A[knt] == 0.0)) {
          b_lastv--;
          knt--;
        }

        knt = 4 - k_i;
        exitg2 = false;
        while ((!exitg2) && (knt > 0)) {
          b_coltop = ((knt - 1) * 5 + ii) + 5;
          coltop = b_coltop;
          do {
            exitg1 = 0;
            if (coltop + 1 <= b_coltop + b_lastv) {
              if (b_A[coltop] != 0.0) {
                exitg1 = 1;
              } else {
                coltop++;
              }
            } else {
              knt--;
              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      } else {
        b_lastv = 0;
        knt = 0;
      }

      if (b_lastv > 0) {
        D_20230119_Modell_Inbetri_xgemv(b_lastv, knt, b_A, ii + 6, b_A, ii + 1,
          work);
        D_20230119_Modell_Inbetri_xgerc(b_lastv, knt, -tau[k_i], ii + 1, work,
          b_A, ii + 6);
      }

      b_A[ii] = xnorm;
    } else {
      tau[4] = 0.0;
    }
  }

  for (k_i = 0; k_i < 5; k_i++) {
    for (ii = 0; ii <= k_i; ii++) {
      R[ii + 5 * k_i] = b_A[5 * k_i + ii];
    }

    for (ii = k_i + 2; ii < 6; ii++) {
      R[(ii + 5 * k_i) - 1] = 0.0;
    }

    work[k_i] = 0.0;
  }

  for (k_i = 4; k_i >= 0; k_i--) {
    b_lastv = (k_i * 5 + k_i) + 6;
    if (k_i + 1 < 5) {
      b_A[b_lastv - 6] = 1.0;
      if (tau[k_i] != 0.0) {
        knt = 5 - k_i;
        b_coltop = b_lastv - k_i;
        while ((knt > 0) && (b_A[b_coltop - 2] == 0.0)) {
          knt--;
          b_coltop--;
        }

        b_coltop = 4 - k_i;
        exitg2 = false;
        while ((!exitg2) && (b_coltop > 0)) {
          coltop = (b_coltop - 1) * 5 + b_lastv;
          ii = coltop;
          do {
            exitg1 = 0;
            if (ii <= (coltop + knt) - 1) {
              if (b_A[ii - 1] != 0.0) {
                exitg1 = 1;
              } else {
                ii++;
              }
            } else {
              b_coltop--;
              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      } else {
        knt = 0;
        b_coltop = 0;
      }

      if (knt > 0) {
        D_20230119_Modell_Inbetri_xgemv(knt, b_coltop, b_A, b_lastv, b_A,
          b_lastv - 5, work);
        D_20230119_Modell_Inbetri_xgerc(knt, b_coltop, -tau[k_i], b_lastv - 5,
          work, b_A, b_lastv);
      }

      b_coltop = (b_lastv - k_i) - 1;
      for (knt = b_lastv - 4; knt <= b_coltop; knt++) {
        b_A[knt - 1] *= -tau[k_i];
      }
    }

    b_A[b_lastv - 6] = 1.0 - tau[k_i];
    b_coltop = k_i;
    for (knt = 0; knt < b_coltop; knt++) {
      b_A[(b_lastv - knt) - 7] = 0.0;
    }
  }

  k_i = 0;
  do {
    exitg1 = 0;
    if (k_i <= nA - 1) {
      ii = k_i;
      if (std::abs(R[5 * ii + ii]) < 1.0E-12) {
        *Status = -2.0;
        exitg1 = 1;
      } else {
        k_i++;
      }
    } else {
      for (k_i = 0; k_i < n; k_i++) {
        for (ii = 0; ii < n; ii++) {
          RLinv_0 = 0.0;
          for (b_lastv = 0; b_lastv < 5; b_lastv++) {
            RLinv_0 += b_Linv[5 * k_i + b_lastv] * b_A[5 * ii + b_lastv];
          }

          TL[k_i + 5 * ii] = RLinv_0;
        }
      }

      std::memset(&RLinv[0], 0, 25U * sizeof(real_T));
      for (k_i = nA; k_i >= 1; k_i--) {
        RLinv[(k_i + 5 * (k_i - 1)) - 1] = 1.0;
        for (ii = k_i; ii <= nA; ii++) {
          RLinv[(k_i + 5 * (ii - 1)) - 1] /= R[((k_i - 1) * 5 + k_i) - 1];
        }

        if (k_i > 1) {
          knt = k_i;
          for (ii = 0; ii <= knt - 2; ii++) {
            for (b_lastv = k_i; b_lastv <= nA; b_lastv++) {
              RLinv[ii + 5 * (b_lastv - 1)] -= RLinv[((b_lastv - 1) * 5 + k_i) -
                1] * R[(k_i - 1) * 5 + ii];
            }
          }
        }
      }

      for (k_i = 0; k_i < n; k_i++) {
        for (ii = k_i + 1; ii <= n; ii++) {
          b_H[k_i + 5 * (ii - 1)] = 0.0;
          for (b_lastv = nA + 1; b_lastv <= n; b_lastv++) {
            b_H[k_i + 5 * (ii - 1)] -= TL[((b_lastv - 1) * 5 + ii) - 1] * TL
              [(b_lastv - 1) * 5 + k_i];
          }

          b_H[(ii + 5 * k_i) - 1] = b_H[(ii - 1) * 5 + k_i];
        }
      }

      for (k_i = 0; k_i < nA; k_i++) {
        for (ii = 0; ii < n; ii++) {
          b_D[ii + 5 * k_i] = 0.0;
          for (b_lastv = k_i + 1; b_lastv <= nA; b_lastv++) {
            b_D[ii + 5 * k_i] += TL[(b_lastv - 1) * 5 + ii] * RLinv[(b_lastv - 1)
              * 5 + k_i];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static real_T D_20230119_Modell_Inbet_maximum(const real_T x[5])
{
  real_T ex;
  int32_T idx;
  int32_T k;
  if (!rtIsNaN(x[0])) {
    idx = 1;
  } else {
    boolean_T exitg1;
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k < 6)) {
      if (!rtIsNaN(x[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  if (idx == 0) {
    ex = x[0];
  } else {
    ex = x[idx - 1];
    for (k = idx + 1; k < 6; k++) {
      if (ex < x[k - 1]) {
        ex = x[k - 1];
      }
    }
  }

  return ex;
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_Model_DropConstraint(int32_T kDrop, boolean_T iA[8],
  int32_T *nA, int32_T iC[8])
{
  if (kDrop > 0) {
    iA[iC[kDrop - 1] - 1] = false;
    if (kDrop < *nA) {
      for (int32_T i = kDrop; i < *nA; i++) {
        iC[i - 1] = iC[i];
      }
    }

    iC[*nA - 1] = 0;
    (*nA)--;
  }
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_Modell_Inbetr_qpkwik(const real_T b_Linv[25], const
  real_T b_Hinv[25], const real_T f[5], const real_T b_Ac[40], const real_T b[8],
  boolean_T iA[8], int32_T maxiter, real_T FeasTol, real_T x[5], real_T lambda[8],
  int32_T *status)
{
  real_T RLinv[25];
  real_T U[25];
  real_T b_D[25];
  real_T b_H[25];
  real_T Opt[10];
  real_T Rhs[10];
  real_T cTol[8];
  real_T r[5];
  real_T z[5];
  real_T Xnorm0;
  real_T cMin;
  real_T rMin;
  int32_T iC[8];
  int32_T b_exponent;
  int32_T exponent;
  int32_T i;
  int32_T iSave;
  int32_T kDrop;
  int32_T nA;
  boolean_T ColdReset;
  boolean_T DualFeasible;
  boolean_T cTolComputed;
  boolean_T guard1;
  for (i = 0; i < 5; i++) {
    x[i] = 0.0;
  }

  std::memset(&lambda[0], 0, sizeof(real_T) << 3U);
  *status = 1;
  for (i = 0; i < 5; i++) {
    r[i] = 0.0;
  }

  rMin = 0.0;
  cTolComputed = false;
  for (i = 0; i < 8; i++) {
    cTol[i] = 1.0;
    iC[i] = 0;
  }

  nA = 0;
  for (i = 0; i < 8; i++) {
    if (iA[i]) {
      nA++;
      iC[nA - 1] = i + 1;
    }
  }

  guard1 = false;
  if (nA > 0) {
    int32_T exitg3;
    std::memset(&Opt[0], 0, 10U * sizeof(real_T));
    for (i = 0; i < 5; i++) {
      Rhs[i] = f[i];
      Rhs[i + 5] = 0.0;
    }

    DualFeasible = false;
    ColdReset = false;
    do {
      exitg3 = 0;
      if ((!DualFeasible) && (nA > 0) && (*status <= maxiter)) {
        D_20230119_Modell_In_KWIKfactor(b_Ac, iC, nA, b_Linv, b_D, b_H,
          D_20230119_Modell_Inbet_degrees, RLinv, &Xnorm0);
        if (Xnorm0 < 0.0) {
          if (ColdReset) {
            *status = -2;
            exitg3 = 2;
          } else {
            nA = 0;
            for (i = 0; i < 8; i++) {
              iA[i] = false;
              iC[i] = 0;
            }

            ColdReset = true;
          }
        } else {
          for (i = 0; i < nA; i++) {
            Rhs[i + 5] = b[iC[i] - 1];
            for (kDrop = i + 1; kDrop <= nA; kDrop++) {
              U[(kDrop + 5 * i) - 1] = 0.0;
              for (iSave = 0; iSave < nA; iSave++) {
                U[(kDrop + 5 * i) - 1] += RLinv[(5 * iSave + kDrop) - 1] *
                  RLinv[5 * iSave + i];
              }

              U[i + 5 * (kDrop - 1)] = U[(5 * i + kDrop) - 1];
            }
          }

          for (i = 0; i < 5; i++) {
            Xnorm0 = 0.0;
            for (iSave = 0; iSave < 5; iSave++) {
              Xnorm0 += b_H[5 * iSave + i] * Rhs[iSave];
            }

            Opt[i] = Xnorm0;
            for (kDrop = 0; kDrop < nA; kDrop++) {
              Xnorm0 = Opt[i];
              Xnorm0 += b_D[5 * kDrop + i] * Rhs[kDrop + 5];
              Opt[i] = Xnorm0;
            }
          }

          for (i = 0; i < nA; i++) {
            Xnorm0 = 0.0;
            for (iSave = 0; iSave < 5; iSave++) {
              Xnorm0 += b_D[5 * i + iSave] * Rhs[iSave];
            }

            Opt[i + 5] = Xnorm0;
            for (kDrop = 0; kDrop < nA; kDrop++) {
              Opt[i + 5] += U[5 * kDrop + i] * Rhs[kDrop + 5];
            }
          }

          Xnorm0 = -1.0E-12;
          kDrop = -1;
          for (i = 0; i < nA; i++) {
            lambda[iC[i] - 1] = Opt[i + 5];
            if ((Opt[i + 5] < Xnorm0) && (i + 1 <= nA)) {
              kDrop = i;
              Xnorm0 = Opt[i + 5];
            }
          }

          if (kDrop + 1 <= 0) {
            DualFeasible = true;
            for (i = 0; i < 5; i++) {
              x[i] = Opt[i];
            }
          } else {
            (*status)++;
            if (*status > 5) {
              nA = 0;
              for (i = 0; i < 8; i++) {
                iA[i] = false;
                iC[i] = 0;
              }

              ColdReset = true;
            } else {
              lambda[iC[kDrop] - 1] = 0.0;
              D_20230119_Model_DropConstraint(kDrop + 1, iA, &nA, iC);
            }
          }
        }
      } else {
        if (nA <= 0) {
          std::memset(&lambda[0], 0, sizeof(real_T) << 3U);
          for (i = 0; i < 5; i++) {
            Xnorm0 = 0.0;
            for (iSave = 0; iSave < 5; iSave++) {
              Xnorm0 += -b_Hinv[5 * iSave + i] * f[iSave];
            }

            x[i] = Xnorm0;
          }
        }

        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
      guard1 = true;
    }
  } else {
    for (i = 0; i < 5; i++) {
      Xnorm0 = 0.0;
      for (iSave = 0; iSave < 5; iSave++) {
        Xnorm0 += -b_Hinv[5 * iSave + i] * f[iSave];
      }

      x[i] = Xnorm0;
    }

    guard1 = true;
  }

  if (guard1) {
    boolean_T exitg2;
    Xnorm0 = D_20230119_Modell_Inbetrie_norm(x);
    exitg2 = false;
    while ((!exitg2) && (*status <= maxiter)) {
      real_T b_Ac_0;
      real_T cVal;
      real_T t;
      cMin = -FeasTol;
      i = -1;
      for (kDrop = 0; kDrop < 8; kDrop++) {
        t = cTol[kDrop];
        if (!cTolComputed) {
          for (iSave = 0; iSave < 5; iSave++) {
            cVal = b_Ac[(iSave << 3) + kDrop] * x[iSave];
            z[iSave] = std::abs(cVal);
          }

          cVal = D_20230119_Modell_Inbet_maximum(z);
          if ((!(t >= cVal)) && (!rtIsNaN(cVal))) {
            t = cVal;
          }
        }

        if (!iA[kDrop]) {
          b_Ac_0 = 0.0;
          for (iSave = 0; iSave < 5; iSave++) {
            b_Ac_0 += b_Ac[(iSave << 3) + kDrop] * x[iSave];
          }

          cVal = (b_Ac_0 - b[kDrop]) / t;
          if (cVal < cMin) {
            cMin = cVal;
            i = kDrop;
          }
        }

        cTol[kDrop] = t;
      }

      cTolComputed = true;
      if (i + 1 <= 0) {
        exitg2 = true;
      } else if (*status == maxiter) {
        *status = 0;
        exitg2 = true;
      } else {
        int32_T exitg1;
        do {
          exitg1 = 0;
          if ((i + 1 > 0) && (*status <= maxiter)) {
            boolean_T guard2;
            guard2 = false;
            if (nA == 0) {
              for (iSave = 0; iSave < 5; iSave++) {
                z[iSave] = 0.0;
                for (kDrop = 0; kDrop < 5; kDrop++) {
                  cVal = z[iSave];
                  cVal += b_Hinv[5 * kDrop + iSave] * b_Ac[(kDrop << 3) + i];
                  z[iSave] = cVal;
                }
              }

              guard2 = true;
            } else {
              D_20230119_Modell_In_KWIKfactor(b_Ac, iC, nA, b_Linv, b_D, b_H,
                D_20230119_Modell_Inbet_degrees, RLinv, &cMin);
              if (cMin <= 0.0) {
                *status = -2;
                exitg1 = 1;
              } else {
                for (iSave = 0; iSave < 25; iSave++) {
                  U[iSave] = -b_H[iSave];
                }

                for (iSave = 0; iSave < 5; iSave++) {
                  z[iSave] = 0.0;
                  for (kDrop = 0; kDrop < 5; kDrop++) {
                    cVal = z[iSave];
                    cVal += U[5 * kDrop + iSave] * b_Ac[(kDrop << 3) + i];
                    z[iSave] = cVal;
                  }
                }

                for (kDrop = 0; kDrop < nA; kDrop++) {
                  b_Ac_0 = 0.0;
                  for (iSave = 0; iSave < 5; iSave++) {
                    b_Ac_0 += b_Ac[(iSave << 3) + i] * b_D[5 * kDrop + iSave];
                  }

                  r[kDrop] = b_Ac_0;
                }

                guard2 = true;
              }
            }

            if (guard2) {
              kDrop = 0;
              cMin = 0.0;
              DualFeasible = true;
              ColdReset = true;
              if (nA > 0) {
                boolean_T exitg4;
                iSave = 0;
                exitg4 = false;
                while ((!exitg4) && (iSave <= nA - 1)) {
                  if (r[iSave] >= 1.0E-12) {
                    ColdReset = false;
                    exitg4 = true;
                  } else {
                    iSave++;
                  }
                }
              }

              ColdReset = ((nA == 0) || ColdReset);
              if (!ColdReset) {
                for (iSave = 0; iSave < nA; iSave++) {
                  t = r[iSave];
                  if (t > 1.0E-12) {
                    cVal = lambda[iC[iSave] - 1] / t;
                    if ((kDrop == 0) || (cVal < rMin)) {
                      rMin = cVal;
                      kDrop = iSave + 1;
                    }
                  }
                }

                if (kDrop > 0) {
                  cMin = rMin;
                  DualFeasible = false;
                }
              }

              cVal = 0.0;
              for (iSave = 0; iSave < 5; iSave++) {
                cVal += b_Ac[(iSave << 3) + i] * z[iSave];
              }

              if (cVal <= 0.0) {
                cVal = 0.0;
                ColdReset = true;
              } else {
                b_Ac_0 = 0.0;
                for (iSave = 0; iSave < 5; iSave++) {
                  b_Ac_0 += b_Ac[(iSave << 3) + i] * x[iSave];
                }

                cVal = (b[i] - b_Ac_0) / cVal;
                ColdReset = false;
              }

              if (DualFeasible && ColdReset) {
                *status = -1;
                exitg1 = 1;
              } else {
                if (ColdReset) {
                  t = cMin;
                } else if (DualFeasible) {
                  t = cVal;
                } else if (cMin < cVal) {
                  t = cMin;
                } else {
                  t = cVal;
                }

                for (iSave = 0; iSave < nA; iSave++) {
                  int32_T iC_0;
                  iC_0 = iC[iSave];
                  lambda[iC_0 - 1] -= t * r[iSave];
                  if ((iC_0 <= 8) && (lambda[iC_0 - 1] < 0.0)) {
                    lambda[iC_0 - 1] = 0.0;
                  }
                }

                lambda[i] += t;
                std::frexp(1.0, &exponent);
                if (std::abs(t - cMin) < 2.2204460492503131E-16) {
                  D_20230119_Model_DropConstraint(kDrop, iA, &nA, iC);
                }

                if (!ColdReset) {
                  for (iSave = 0; iSave < 5; iSave++) {
                    cMin = x[iSave];
                    cMin += t * z[iSave];
                    x[iSave] = cMin;
                  }

                  std::frexp(1.0, &b_exponent);
                  if (std::abs(t - cVal) < 2.2204460492503131E-16) {
                    if (nA == D_20230119_Modell_Inbet_degrees) {
                      *status = -1;
                      exitg1 = 1;
                    } else {
                      nA++;
                      iC[nA - 1] = i + 1;
                      kDrop = nA - 1;
                      while ((kDrop + 1 > 1) && (!(iC[kDrop] > iC[kDrop - 1])))
                      {
                        iSave = iC[kDrop];
                        iC[kDrop] = iC[kDrop - 1];
                        iC[kDrop - 1] = iSave;
                        kDrop--;
                      }

                      iA[i] = true;
                      i = -1;
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                } else {
                  (*status)++;
                }
              }
            }
          } else {
            cMin = D_20230119_Modell_Inbetrie_norm(x);
            if (std::abs(cMin - Xnorm0) > 0.001) {
              Xnorm0 = cMin;
              for (i = 0; i < 8; i++) {
                cMin = std::abs(b[i]);
                if (!(cMin >= 1.0)) {
                  cMin = 1.0;
                }

                cTol[i] = cMin;
              }

              cTolComputed = false;
            }

            exitg1 = 2;
          }
        } while (exitg1 == 0);

        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<S178>/FixedHorizonOptimizer' */
static void D_20230119_M_mpcblock_optimizer(const real_T rseq[60], const real_T
  vseq[42], const real_T umin[2], const real_T umax[2], int32_T switch_in, const
  real_T x[10], const real_T old_u[2], const boolean_T iA[8], const real_T
  b_Mlim[8], real_T b_Mx[80], real_T b_Mu1[16], real_T b_Mv[336], const real_T
  b_utarget[40], const real_T b_uoff[2], int32_T b_enable_value, real_T b_H[25],
  real_T b_Ac[40], const real_T b_Wy[3], const real_T b_Wdu[2], const real_T
  b_Jm[160], const real_T b_Wu[2], const real_T b_I1[80], const real_T b_A[100],
  const real_T Bu[420], const real_T Bv[420], const real_T b_C[30], const real_T
  Dv[126], const int32_T b_Mrows[8], const real_T b_RMVscale[2], real_T u[2],
  real_T useq[42], real_T *status, boolean_T iAout[8],
  B_PathFollowingControlSystem__T *localB)
{
  real_T WySuJm[240];
  real_T b_SuJm[240];
  real_T b_Kv[168];
  real_T I2Jm[160];
  real_T WduJm[160];
  real_T WuI2Jm[160];
  real_T CA_0[126];
  real_T Sum_0[120];
  real_T b_Su1[120];
  real_T b_Kx[40];
  real_T CA[30];
  real_T CA_1[30];
  real_T L[25];
  real_T b_Jm_0[16];
  real_T b_SuJm_0[16];
  real_T Bc[8];
  real_T b_I1_0[8];
  real_T b_Ku1[8];
  real_T Sum[6];
  real_T b_C_0[6];
  real_T varargin_1[5];
  real_T zopt[5];
  real_T umax_incr[2];
  real_T umin_incr[2];
  int32_T kidx;
  int8_T a[1600];
  int8_T b[25];
  int8_T b_B[4];
  int8_T rows[3];
  boolean_T umax_incr_flag[2];
  boolean_T umin_incr_flag[2];
  boolean_T optimization_disabled;
  static const int8_T c_A[400] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
    1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

  std::memset(&useq[0], 0, 42U * sizeof(real_T));
  *status = 1.0;
  for (int32_T i = 0; i < 8; i++) {
    iAout[i] = false;
  }

  optimization_disabled = (switch_in != b_enable_value);
  if (optimization_disabled) {
    u[0] = old_u[0] + b_uoff[0];
    u[1] = old_u[1] + b_uoff[1];
    for (int32_T i = 0; i < 21; i++) {
      useq[i] = u[0];
      useq[i + 21] = u[1];
    }
  } else {
    real_T WySuJm_0;
    real_T b_C_1;
    real_T normH;
    real_T s;
    int32_T Tries;
    int16_T ixw;
    boolean_T exitg1;
    boolean_T guard1;
    for (int32_T i = 0; i < 3; i++) {
      for (Tries = 0; Tries < 10; Tries++) {
        CA[i + 3 * Tries] = 0.0;
        for (int32_T i1 = 0; i1 < 10; i1++) {
          normH = CA[3 * Tries + i];
          normH += b_C[3 * i1 + i] * b_A[10 * Tries + i1];
          CA[i + 3 * Tries] = normH;
        }
      }

      for (Tries = 0; Tries < 2; Tries++) {
        Sum[i + 3 * Tries] = 0.0;
        b_C_0[i + 3 * Tries] = 0.0;
        for (int32_T i1 = 0; i1 < 10; i1++) {
          normH = b_C_0[3 * Tries + i];
          b_C_1 = b_C[3 * i1 + i];
          s = Sum[3 * Tries + i];
          s += Bu[10 * Tries + i1] * b_C_1;
          normH += Bv[10 * Tries + i1] * b_C_1;
          Sum[i + 3 * Tries] = s;
          b_C_0[i + 3 * Tries] = normH;
        }
      }
    }

    for (int32_T i = 0; i < 2; i++) {
      localB->b_Hv[60 * i] = b_C_0[3 * i];
      localB->b_Hv[60 * (i + 2)] = Dv[3 * i];
      localB->b_Hv[60 * i + 1] = b_C_0[3 * i + 1];
      localB->b_Hv[60 * (i + 2) + 1] = Dv[3 * i + 1];
      localB->b_Hv[60 * i + 2] = b_C_0[3 * i + 2];
      localB->b_Hv[60 * (i + 2) + 2] = Dv[3 * i + 2];
    }

    for (int32_T i = 0; i < 38; i++) {
      localB->b_Hv[60 * (i + 4)] = 0.0;
      localB->b_Hv[60 * (i + 4) + 1] = 0.0;
      localB->b_Hv[60 * (i + 4) + 2] = 0.0;
    }

    for (int32_T i = 0; i < 42; i++) {
      std::memset(&localB->b_Hv[i * 60 + 3], 0, 57U * sizeof(real_T));
    }

    for (int32_T i = 0; i < 10; i++) {
      localB->b_Sx[60 * i] = CA[3 * i];
      localB->b_Sx[60 * i + 1] = CA[3 * i + 1];
      localB->b_Sx[60 * i + 2] = CA[3 * i + 2];
      std::memset(&localB->b_Sx[i * 60 + 3], 0, 57U * sizeof(real_T));
    }

    for (int32_T i = 0; i < 2; i++) {
      b_Su1[60 * i] = Sum[3 * i];
      b_Su1[60 * i + 1] = Sum[3 * i + 1];
      b_Su1[60 * i + 2] = Sum[3 * i + 2];
    }

    for (int32_T i = 0; i < 57; i++) {
      b_Su1[i + 3] = 0.0;
      b_Su1[i + 63] = 0.0;
    }

    for (int32_T i = 0; i < 2; i++) {
      localB->Su[60 * i] = Sum[3 * i];
      localB->Su[60 * i + 1] = Sum[3 * i + 1];
      localB->Su[60 * i + 2] = Sum[3 * i + 2];
    }

    for (int32_T i = 0; i < 38; i++) {
      localB->Su[60 * (i + 2)] = 0.0;
      localB->Su[60 * (i + 2) + 1] = 0.0;
      localB->Su[60 * (i + 2) + 2] = 0.0;
    }

    for (int32_T i = 0; i < 40; i++) {
      std::memset(&localB->Su[i * 60 + 3], 0, 57U * sizeof(real_T));
    }

    for (kidx = 0; kidx < 19; kidx++) {
      int8_T kidx_0;
      kidx_0 = static_cast<int8_T>((kidx + 1) * 3 + 1);
      for (int32_T i = 0; i < 3; i++) {
        rows[i] = static_cast<int8_T>(i + kidx_0);
        for (Tries = 0; Tries < 2; Tries++) {
          s = Sum[3 * Tries + i];
          normH = 0.0;
          for (int32_T i1 = 0; i1 < 10; i1++) {
            normH += CA[3 * i1 + i] * Bu[10 * Tries + i1];
          }

          s += normH;
          Sum[i + 3 * Tries] = s;
        }
      }

      for (int32_T i = 0; i < 2; i++) {
        s = Sum[3 * i];
        b_Su1[(rows[0] + 60 * i) - 1] = s;
        Sum_0[3 * i] = s;
        s = Sum[3 * i + 1];
        b_Su1[(rows[1] + 60 * i) - 1] = s;
        Sum_0[3 * i + 1] = s;
        s = Sum[3 * i + 2];
        b_Su1[(rows[2] + 60 * i) - 1] = s;
        Sum_0[3 * i + 2] = s;
      }

      for (int32_T i = 0; i < 38; i++) {
        Sum_0[3 * (i + 2)] = localB->Su[(60 * i + rows[0]) - 4];
        Sum_0[3 * (i + 2) + 1] = localB->Su[(60 * i + rows[1]) - 4];
        Sum_0[3 * (i + 2) + 2] = localB->Su[(60 * i + rows[2]) - 4];
      }

      for (int32_T i = 0; i < 40; i++) {
        localB->Su[(rows[0] + 60 * i) - 1] = Sum_0[3 * i];
        localB->Su[(rows[1] + 60 * i) - 1] = Sum_0[3 * i + 1];
        localB->Su[(rows[2] + 60 * i) - 1] = Sum_0[3 * i + 2];
      }

      for (int32_T i = 0; i < 3; i++) {
        for (Tries = 0; Tries < 2; Tries++) {
          b_C_0[i + 3 * Tries] = 0.0;
          for (int32_T i1 = 0; i1 < 10; i1++) {
            normH = b_C_0[3 * Tries + i];
            normH += CA[3 * i1 + i] * Bv[10 * Tries + i1];
            b_C_0[i + 3 * Tries] = normH;
          }
        }
      }

      for (int32_T i = 0; i < 2; i++) {
        CA_0[3 * i] = b_C_0[3 * i];
        CA_0[3 * i + 1] = b_C_0[3 * i + 1];
        CA_0[3 * i + 2] = b_C_0[3 * i + 2];
      }

      for (int32_T i = 0; i < 40; i++) {
        CA_0[3 * (i + 2)] = localB->b_Hv[(60 * i + rows[0]) - 4];
        CA_0[3 * (i + 2) + 1] = localB->b_Hv[(60 * i + rows[1]) - 4];
        CA_0[3 * (i + 2) + 2] = localB->b_Hv[(60 * i + rows[2]) - 4];
      }

      for (int32_T i = 0; i < 42; i++) {
        localB->b_Hv[(rows[0] + 60 * i) - 1] = CA_0[3 * i];
        localB->b_Hv[(rows[1] + 60 * i) - 1] = CA_0[3 * i + 1];
        localB->b_Hv[(rows[2] + 60 * i) - 1] = CA_0[3 * i + 2];
      }

      for (int32_T i = 0; i < 3; i++) {
        for (Tries = 0; Tries < 10; Tries++) {
          CA_1[i + 3 * Tries] = 0.0;
          for (int32_T i1 = 0; i1 < 10; i1++) {
            normH = CA_1[3 * Tries + i];
            normH += CA[3 * i1 + i] * b_A[10 * Tries + i1];
            CA_1[i + 3 * Tries] = normH;
          }
        }
      }

      std::memcpy(&CA[0], &CA_1[0], 30U * sizeof(real_T));
      for (int32_T i = 0; i < 10; i++) {
        localB->b_Sx[(rows[0] + 60 * i) - 1] = CA[3 * i];
        localB->b_Sx[(rows[1] + 60 * i) - 1] = CA[3 * i + 1];
        localB->b_Sx[(rows[2] + 60 * i) - 1] = CA[3 * i + 2];
      }
    }

    for (int32_T i = 0; i < 4; i++) {
      for (Tries = 0; Tries < 60; Tries++) {
        b_SuJm[Tries + 60 * i] = 0.0;
        for (int32_T i1 = 0; i1 < 40; i1++) {
          normH = b_SuJm[60 * i + Tries];
          normH += localB->Su[60 * i1 + Tries] * b_Jm[40 * i + i1];
          b_SuJm[Tries + 60 * i] = normH;
        }
      }
    }

    if (b_Mrows[0] > 0) {
      kidx = 0;
      exitg1 = false;
      while ((!exitg1) && (kidx < 8)) {
        if (b_Mrows[kidx] <= 60) {
          Tries = b_Mrows[kidx];
          b_Ac[kidx] = -b_SuJm[Tries - 1];
          b_Ac[kidx + 8] = -b_SuJm[Tries + 59];
          b_Ac[kidx + 16] = -b_SuJm[Tries + 119];
          b_Ac[kidx + 24] = -b_SuJm[Tries + 179];
          Tries = b_Mrows[kidx];
          for (int32_T i = 0; i < 10; i++) {
            b_Mx[kidx + (i << 3)] = -localB->b_Sx[(60 * i + Tries) - 1];
          }

          Tries = b_Mrows[kidx];
          b_Mu1[kidx] = -b_Su1[Tries - 1];
          b_Mu1[kidx + 8] = -b_Su1[Tries + 59];
          Tries = b_Mrows[kidx];
          for (int32_T i = 0; i < 42; i++) {
            b_Mv[kidx + (i << 3)] = -localB->b_Hv[(60 * i + Tries) - 1];
          }

          kidx++;
        } else if (b_Mrows[kidx] <= 120) {
          Tries = b_Mrows[kidx];
          b_Ac[kidx] = b_SuJm[Tries - 61];
          b_Ac[kidx + 8] = b_SuJm[Tries - 1];
          b_Ac[kidx + 16] = b_SuJm[Tries + 59];
          b_Ac[kidx + 24] = b_SuJm[Tries + 119];
          Tries = b_Mrows[kidx];
          for (int32_T i = 0; i < 10; i++) {
            b_Mx[kidx + (i << 3)] = localB->b_Sx[(60 * i + Tries) - 61];
          }

          Tries = b_Mrows[kidx];
          b_Mu1[kidx] = b_Su1[Tries - 61];
          b_Mu1[kidx + 8] = b_Su1[Tries - 1];
          Tries = b_Mrows[kidx];
          for (int32_T i = 0; i < 42; i++) {
            b_Mv[kidx + (i << 3)] = localB->b_Hv[(60 * i + Tries) - 61];
          }

          kidx++;
        } else {
          exitg1 = true;
        }
      }
    }

    b_B[1] = 0;
    b_B[2] = 0;
    b_B[0] = 1;
    b_B[3] = 1;
    kidx = -1;
    for (Tries = 0; Tries < 20; Tries++) {
      for (int32_T i = 0; i < 2; i++) {
        for (int32_T i1 = 0; i1 < 20; i1++) {
          a[kidx + 1] = static_cast<int8_T>(c_A[20 * Tries + i1] * b_B[i << 1]);
          a[kidx + 2] = static_cast<int8_T>(c_A[20 * Tries + i1] * b_B[(i << 1)
            + 1]);
          kidx += 2;
        }
      }
    }

    for (int32_T i = 0; i < 4; i++) {
      for (Tries = 0; Tries < 40; Tries++) {
        I2Jm[Tries + 40 * i] = 0.0;
        for (int32_T i1 = 0; i1 < 40; i1++) {
          normH = I2Jm[40 * i + Tries];
          normH += static_cast<real_T>(a[40 * i1 + Tries]) * b_Jm[40 * i + i1];
          I2Jm[Tries + 40 * i] = normH;
        }
      }
    }

    ixw = 1;
    for (kidx = 0; kidx < 60; kidx++) {
      normH = b_Wy[ixw - 1];
      WySuJm[kidx] = normH * b_SuJm[kidx];
      WySuJm[kidx + 60] = b_SuJm[kidx + 60] * normH;
      WySuJm[kidx + 120] = b_SuJm[kidx + 120] * normH;
      WySuJm[kidx + 180] = b_SuJm[kidx + 180] * normH;
      ixw = static_cast<int16_T>(ixw + 1);
      if (ixw > 3) {
        ixw = 1;
      }
    }

    ixw = 1;
    for (kidx = 0; kidx < 40; kidx++) {
      normH = b_Wu[ixw - 1];
      WuI2Jm[kidx] = normH * I2Jm[kidx];
      WuI2Jm[kidx + 40] = I2Jm[kidx + 40] * normH;
      WuI2Jm[kidx + 80] = I2Jm[kidx + 80] * normH;
      WuI2Jm[kidx + 120] = I2Jm[kidx + 120] * normH;
      ixw = static_cast<int16_T>(ixw + 1);
      if (ixw > 2) {
        ixw = 1;
      }
    }

    ixw = 1;
    for (kidx = 0; kidx < 40; kidx++) {
      normH = b_Wdu[ixw - 1];
      WduJm[kidx] = normH * b_Jm[kidx];
      WduJm[kidx + 40] = b_Jm[kidx + 40] * normH;
      WduJm[kidx + 80] = b_Jm[kidx + 80] * normH;
      WduJm[kidx + 120] = b_Jm[kidx + 120] * normH;
      ixw = static_cast<int16_T>(ixw + 1);
      if (ixw > 2) {
        ixw = 1;
      }
    }

    for (int32_T i = 0; i < 4; i++) {
      for (Tries = 0; Tries < 4; Tries++) {
        b_SuJm_0[i + (Tries << 2)] = 0.0;
        for (int32_T i1 = 0; i1 < 60; i1++) {
          normH = b_SuJm_0[(Tries << 2) + i];
          normH += b_SuJm[60 * i + i1] * WySuJm[60 * Tries + i1];
          b_SuJm_0[i + (Tries << 2)] = normH;
        }

        b_Jm_0[i + (Tries << 2)] = 0.0;
        normH = 0.0;
        for (int32_T i1 = 0; i1 < 40; i1++) {
          s = b_Jm_0[(Tries << 2) + i];
          s += b_Jm[40 * i + i1] * WduJm[40 * Tries + i1];
          normH += I2Jm[40 * i + i1] * WuI2Jm[40 * Tries + i1];
          b_Jm_0[i + (Tries << 2)] = s;
        }

        b_H[i + 5 * Tries] = (b_SuJm_0[(Tries << 2) + i] + b_Jm_0[(Tries << 2) +
                              i]) + normH;
      }
    }

    for (int32_T i = 0; i < 2; i++) {
      for (Tries = 0; Tries < 4; Tries++) {
        Bc[i + (Tries << 1)] = 0.0;
        for (int32_T i1 = 0; i1 < 60; i1++) {
          normH = Bc[(Tries << 1) + i];
          normH += b_Su1[60 * i + i1] * WySuJm[60 * Tries + i1];
          Bc[i + (Tries << 1)] = normH;
        }

        b_I1_0[i + (Tries << 1)] = 0.0;
        for (int32_T i1 = 0; i1 < 40; i1++) {
          normH = b_I1_0[(Tries << 1) + i];
          normH += b_I1[40 * i + i1] * WuI2Jm[40 * Tries + i1];
          b_I1_0[i + (Tries << 1)] = normH;
        }
      }
    }

    for (int32_T i = 0; i < 8; i++) {
      b_Ku1[i] = Bc[i] + b_I1_0[i];
    }

    for (int32_T i = 0; i < 160; i++) {
      normH = WuI2Jm[i];
      normH = -normH;
      WuI2Jm[i] = normH;
    }

    for (int32_T i = 0; i < 10; i++) {
      for (Tries = 0; Tries < 4; Tries++) {
        b_Kx[i + 10 * Tries] = 0.0;
        for (int32_T i1 = 0; i1 < 60; i1++) {
          s = b_Kx[10 * Tries + i];
          s += localB->b_Sx[60 * i + i1] * WySuJm[60 * Tries + i1];
          b_Kx[i + 10 * Tries] = s;
        }
      }
    }

    for (int32_T i = 0; i < 42; i++) {
      for (Tries = 0; Tries < 4; Tries++) {
        b_Kv[i + 42 * Tries] = 0.0;
        for (int32_T i1 = 0; i1 < 60; i1++) {
          b_C_1 = b_Kv[42 * Tries + i];
          b_C_1 += localB->b_Hv[60 * i + i1] * WySuJm[60 * Tries + i1];
          b_Kv[i + 42 * Tries] = b_C_1;
        }
      }
    }

    for (int32_T i = 0; i < 240; i++) {
      WySuJm_0 = WySuJm[i];
      WySuJm_0 = -WySuJm_0;
      WySuJm[i] = WySuJm_0;
    }

    kidx = 0;
    std::memcpy(&L[0], &b_H[0], 25U * sizeof(real_T));
    Tries = D_20230119_Modell_Inbetr_xpotrf(L);
    guard1 = false;
    if (Tries == 0) {
      for (Tries = 0; Tries < 5; Tries++) {
        varargin_1[Tries] = L[5 * Tries + Tries];
      }

      if (D_20230119_Modell_Inbet_minimum(varargin_1) > 1.4901161193847656E-7) {
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      boolean_T exitg2;
      normH = 0.0;
      Tries = 0;
      exitg2 = false;
      while ((!exitg2) && (Tries < 5)) {
        s = 0.0;
        for (int32_T i = 0; i < 5; i++) {
          s += std::abs(b_H[5 * i + Tries]);
        }

        if (rtIsNaN(s)) {
          normH = (rtNaN);
          exitg2 = true;
        } else {
          if (s > normH) {
            normH = s;
          }

          Tries++;
        }
      }

      if (normH >= 1.0E+10) {
        kidx = 2;
      } else {
        Tries = 0;
        exitg1 = false;
        while ((!exitg1) && (Tries <= 4)) {
          boolean_T guard2;
          normH = rt_powd_snf(10.0, static_cast<real_T>(Tries)) *
            1.4901161193847656E-7;
          for (int32_T i = 0; i < 25; i++) {
            b[i] = 0;
          }

          for (kidx = 0; kidx < 5; kidx++) {
            b[kidx + 5 * kidx] = 1;
          }

          for (int32_T i = 0; i < 25; i++) {
            s = b_H[i];
            s += normH * static_cast<real_T>(b[i]);
            L[i] = s;
            b_H[i] = s;
          }

          kidx = D_20230119_Modell_Inbetr_xpotrf(L);
          guard2 = false;
          if (kidx == 0) {
            for (kidx = 0; kidx < 5; kidx++) {
              varargin_1[kidx] = L[5 * kidx + kidx];
            }

            if (D_20230119_Modell_Inbet_minimum(varargin_1) >
                1.4901161193847656E-7) {
              kidx = 1;
              exitg1 = true;
            } else {
              guard2 = true;
            }
          } else {
            guard2 = true;
          }

          if (guard2) {
            kidx = 3;
            Tries++;
          }
        }
      }
    }

    if (kidx > 1) {
      u[0] = old_u[0] + b_uoff[0];
      u[1] = old_u[1] + b_uoff[1];
      for (int32_T i = 0; i < 21; i++) {
        useq[i] = u[0];
        useq[i + 21] = u[1];
      }

      *status = -2.0;
    } else {
      for (int32_T i = 0; i < 25; i++) {
        b[i] = 0;
      }

      for (kidx = 0; kidx < 5; kidx++) {
        b[kidx + 5 * kidx] = 1;
      }

      for (int32_T i = 0; i < 25; i++) {
        b_H[i] = b[i];
      }

      D_20230119_Modell_Inbe_trisolve(L, b_H);
      for (int32_T i = 0; i < 8; i++) {
        normH = 0.0;
        for (Tries = 0; Tries < 10; Tries++) {
          normH += b_Mx[(Tries << 3) + i] * x[Tries];
        }

        s = b_Mlim[i] + normH;
        b_C_1 = b_Mu1[i] * old_u[0];
        b_C_1 += b_Mu1[i + 8] * old_u[1];
        normH = 0.0;
        for (Tries = 0; Tries < 42; Tries++) {
          normH += b_Mv[(Tries << 3) + i] * vseq[Tries];
        }

        Bc[i] = -((s + b_C_1) + normH);
      }

      umax_incr_flag[0] = false;
      umax_incr[0] = 0.0;
      umin_incr_flag[0] = false;
      umin_incr[0] = 0.0;
      umax_incr_flag[1] = false;
      umax_incr[1] = 0.0;
      umin_incr_flag[1] = false;
      umin_incr[1] = 0.0;
      if (b_Mrows[0] > 0) {
        kidx = 0;
        exitg1 = false;
        while ((!exitg1) && (kidx < 8)) {
          if ((b_Mrows[kidx] <= 60) || (b_Mrows[kidx] <= 120)) {
            kidx++;
          } else if (b_Mrows[kidx] <= 160) {
            Tries = (b_Mrows[kidx] - (((b_Mrows[kidx] - 121) >> 1) << 1)) - 121;
            optimization_disabled = umax_incr_flag[Tries];
            if (!umax_incr_flag[Tries]) {
              normH = -(b_RMVscale[Tries] * umax[Tries] - b_uoff[Tries]) -
                (-b_Mlim[kidx]);
              optimization_disabled = true;
            } else {
              normH = umax_incr[Tries];
            }

            umax_incr[Tries] = normH;
            umax_incr_flag[Tries] = optimization_disabled;
            Bc[kidx] += normH;
            kidx++;
          } else if (b_Mrows[kidx] <= 200) {
            Tries = (b_Mrows[kidx] - (((b_Mrows[kidx] - 161) >> 1) << 1)) - 161;
            optimization_disabled = umin_incr_flag[Tries];
            if (!umin_incr_flag[Tries]) {
              normH = (b_RMVscale[Tries] * umin[Tries] - b_uoff[Tries]) -
                (-b_Mlim[kidx]);
              optimization_disabled = true;
            } else {
              normH = umin_incr[Tries];
            }

            umin_incr[Tries] = normH;
            umin_incr_flag[Tries] = optimization_disabled;
            Bc[kidx] += normH;
            kidx++;
          } else {
            exitg1 = true;
          }
        }
      }

      for (int32_T i = 0; i < 5; i++) {
        varargin_1[i] = 0.0;
      }

      for (kidx = 0; kidx < 4; kidx++) {
        real_T b_Ku1_0;
        s = 0.0;
        for (int32_T i = 0; i < 10; i++) {
          s += b_Kx[10 * kidx + i] * x[i];
        }

        WySuJm_0 = 0.0;
        for (int32_T i = 0; i < 60; i++) {
          WySuJm_0 += WySuJm[60 * kidx + i] * rseq[i];
        }

        b_Ku1_0 = b_Ku1[kidx << 1] * old_u[0];
        b_Ku1_0 += b_Ku1[(kidx << 1) + 1] * old_u[1];
        b_C_1 = 0.0;
        for (int32_T i = 0; i < 42; i++) {
          b_C_1 += b_Kv[42 * kidx + i] * vseq[i];
        }

        normH = 0.0;
        for (int32_T i = 0; i < 40; i++) {
          normH += WuI2Jm[40 * kidx + i] * b_utarget[i];
        }

        varargin_1[kidx] = (((s + WySuJm_0) + b_Ku1_0) + b_C_1) + normH;
      }

      for (int32_T i = 0; i < 8; i++) {
        iAout[i] = iA[i];
      }

      for (int32_T i = 0; i < 5; i++) {
        for (Tries = 0; Tries < 5; Tries++) {
          L[i + 5 * Tries] = 0.0;
          for (int32_T i1 = 0; i1 < 5; i1++) {
            s = L[5 * Tries + i];
            s += b_H[5 * i + i1] * b_H[5 * Tries + i1];
            L[i + 5 * Tries] = s;
          }
        }
      }

      D_20230119_Modell_Inbetr_qpkwik(b_H, L, varargin_1, b_Ac, Bc, iAout, 120,
        1.0E-6, zopt, b_Ku1, &kidx);
      if ((kidx < 0) || (kidx == 0)) {
        for (int32_T i = 0; i < 5; i++) {
          zopt[i] = 0.0;
        }
      }

      *status = kidx;
      u[0] = (old_u[0] + zopt[0]) + b_uoff[0];
      u[1] = (old_u[1] + zopt[1]) + b_uoff[1];
    }
  }
}

/* System initialize for atomic system: '<S120>/Path Following Control System' */
void PathFollowingControlSy_Init(DW_PathFollowingControlSystem_T *localDW,
  PathFollowingControlSy_cal_type *D_20230119_Mo_PageSwitching_arg)
{
  /* Start for Assertion: '<S133>/Assertion' */
  localDW->Assertion_sltestFinalResult = slTestResult_Untested;
  slTestInitialize(&localDW->Assertion_sltestBlkInfo,
                   &localDW->Assertion_sltestCurrentResult,
                   &localDW->Assertion_sltestFinalResult,
                   &localDW->Assertion_sltestLastResultTime, 1);
  slTestRegAssessment(&localDW->Assertion_sltestBlkInfo, 0, "", 0, 0, 0,
                      "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson/Nvidia_Jetson/LaneFollowingAndControl/MPC Controller/Path Following Control System/Longitudinal velocity must be positive",
                      "", 0);

  /* InitializeConditions for Memory: '<S150>/LastPcov' */
  std::memcpy(&localDW->LastPcov_PreviousInput[0],
              &D_20230119_Mo_PageSwitching_arg->LastPcov_InitialCondition[0],
              100U * sizeof(real_T));

  /* InitializeConditions for Memory: '<S150>/Memory' */
  for (int32_T i = 0; i < 8; i++) {
    localDW->Memory_PreviousInput[i] =
      D_20230119_Mo_PageSwitching_arg->Memory_InitialCondition[i];
  }

  /* End of InitializeConditions for Memory: '<S150>/Memory' */

  /* InitializeConditions for UnitDelay: '<S150>/last_mv' */
  localDW->last_mv_DSTATE[0] =
    D_20230119_Mo_PageSwitching_arg->last_mv_InitialCondition[0];
  localDW->last_mv_DSTATE[1] =
    D_20230119_Mo_PageSwitching_arg->last_mv_InitialCondition[1];

  /* InitializeConditions for Memory: '<S150>/last_x' */
  std::memcpy(&localDW->last_x_PreviousInput[0],
              &D_20230119_Mo_PageSwitching_arg->last_x_InitialCondition[0], 10U *
              sizeof(real_T));
}

/* Output and update for atomic system: '<S120>/Path Following Control System' */
void PathFollowingControlSystem
  (RT_MODEL_D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_T * const
<<<<<<< .mine
   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, real32_T
   rtu_Setvelocity, real_T rtu_Longitudinalvelocity, const real_T rtu_Curvature
   [21], real_T rtu_Lateraldeviation, real_T rtu_Relativeyawangle, real_T
   rtp_MinAcceleration, real_T rtp_MinSteering, real_T rtp_MaxAcceleration,
   real_T rtp_MaxSteering, real_T rtp_DefaultSpacing,
||||||| .r78
   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, real_T
   rtu_Longitudinalvelocity, const real_T rtu_Curvature[31], real_T
   rtu_Lateraldeviation, real_T rtu_Relativeyawangle, real_T rtp_DefaultSpacing,
=======
   D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M, real32_T
   rtu_Setvelocity, real_T rtu_Longitudinalvelocity, const real_T rtu_Curvature
   [31], real_T rtu_Lateraldeviation, real_T rtu_Relativeyawangle, real_T
   rtp_MinAcceleration, real_T rtp_MinSteering, real_T rtp_MaxAcceleration,
   real_T rtp_MaxSteering, real_T rtp_DefaultSpacing,
>>>>>>> .r84
   B_PathFollowingControlSystem__T *localB, DW_PathFollowingControlSystem_T
   *localDW, PathFollowingControlSy_cal_type *D_20230119_Mo_PageSwitching_arg)
{
<<<<<<< .mine
  real_T Bu[420];
  real_T Bv[420];
  real_T tmp_2[336];
||||||| .r78
  real_T tmp[8];
  if (rtmIsMajorTimeStep(D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M))
  {
    int8_T wrBufIdx;

    /* RelationalOperator: '<S133>/min_relop' incorporates:
     *  Constant: '<S133>/min_val'
     */
    localB->min_relop =
      (D_20230119_Mo_PageSwitching_arg->Longitudinalvelocitymustbeposit <
       rtu_Longitudinalvelocity);

    /* Assertion: '<S133>/Assertion' */
    localDW->Assertion_sltestCurrentResult = !localB->min_relop;
    if (localDW->Assertion_sltestFinalResult <
        localDW->Assertion_sltestCurrentResult) {
      localDW->Assertion_sltestFinalResult =
        localDW->Assertion_sltestCurrentResult;
      localDW->Assertion_sltestLastResultTime =
        D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
    }

    slTestLogAssessments(&localDW->Assertion_sltestBlkInfo,
                         D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t
                         [0]);
    utAssert(localB->min_relop);

    /* End of Assertion: '<S133>/Assertion' */

    /* MATLAB Function: '<S129>/CurvatureConversion' */
    std::memcpy(&localB->y_g[0], &rtu_Curvature[0], 31U * sizeof(real_T));

    /* MATLAB Function: '<S129>/DataTypeConversion_Vx' */
    D_202_DataTypeConversion_Vx(rtu_Longitudinalvelocity,
      &localB->sf_DataTypeConversion_Vx);
    for (int32_T i = 0; i < 31; i++) {
      /* Product: '<S129>/Product' */
      localB->Product[i] = localB->y_g[i] * localB->sf_DataTypeConversion_Vx.y;
    }

    /* MATLAB Function: '<S129>/DataTypeConversion_e1' */
    D_202_DataTypeConversion_Vx(rtu_Lateraldeviation,
      &localB->sf_DataTypeConversion_e1);

    /* MATLAB Function: '<S129>/DataTypeConversion_e2' */
    D_202_DataTypeConversion_Vx(rtu_Relativeyawangle,
      &localB->sf_DataTypeConversion_e2);

    /* MATLAB Function: '<S129>/DataTypeConversion_extmv' incorporates:
     *  Constant: '<S128>/External control signal constant'
     */
    localB->y_f[0] =
      D_20230119_Mo_PageSwitching_arg->Externalcontrolsignalconstant_V[0];
    localB->y_f[1] =
      D_20230119_Mo_PageSwitching_arg->Externalcontrolsignalconstant_V[1];

    /* MATLAB Function: '<S128>/DataTypeConversion_spacing' incorporates:
     *  Constant: '<S128>/Default spacing constant'
     */
    D_2_DataTypeConversion_amax(rtp_DefaultSpacing,
      &localB->sf_DataTypeConversion_spacing);

    /* Rounding: '<S150>/Floor' incorporates:
     *  Constant: '<S149>/p_zero'
     */
    localB->Floor = std::floor(D_20230119_Mo_PageSwitching_arg->p_zero_Value);

    /* Rounding: '<S150>/Floor1' incorporates:
     *  Constant: '<S149>/m_zero'
     */
    localB->Floor1 = std::floor(D_20230119_Mo_PageSwitching_arg->m_zero_Value);

    /* RateTransition generated from: '<S178>/FixedHorizonOptimizer' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      localDW->TmpRTBAtFixedHorizonOptimizer_m = static_cast<int8_T>
        (localDW->TmpRTBAtFixedHorizonOptimizer_m == 0);
    }

    localDW->TmpRTBAtFixedHorizonOptimizerIn
      [localDW->TmpRTBAtFixedHorizonOptimizer_m * 3] =
      localB->sf_DataTypeConversion_Vx.y;
    localDW->TmpRTBAtFixedHorizonOptimizerIn
      [localDW->TmpRTBAtFixedHorizonOptimizer_m * 3 + 1] =
      localB->sf_DataTypeConversion_e1.y;
    localDW->TmpRTBAtFixedHorizonOptimizerIn
      [localDW->TmpRTBAtFixedHorizonOptimizer_m * 3 + 2] =
      localB->sf_DataTypeConversion_e2.y;

    /* End of RateTransition generated from: '<S178>/FixedHorizonOptimizer' */

    /* RateTransition generated from: '<S178>/FixedHorizonOptimizer' incorporates:
     *  Product: '<S129>/Product'
     */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      localDW->TmpRTBAtFixedHorizonOptimize_me = static_cast<int8_T>
        (localDW->TmpRTBAtFixedHorizonOptimize_me == 0);
    }

    for (int32_T i = 0; i < 31; i++) {
      localDW->TmpRTBAtFixedHorizonOptimizer_a[i +
        localDW->TmpRTBAtFixedHorizonOptimize_me * 31] = localB->Product[i];
    }

    /* End of RateTransition generated from: '<S178>/FixedHorizonOptimizer' */

    /* Constant: '<S150>/ym_zero' */
    localB->ym_zero[0] = D_20230119_Mo_PageSwitching_arg->ym_zero_Value[0];
    localB->ym_zero[1] = D_20230119_Mo_PageSwitching_arg->ym_zero_Value[1];
    localB->ym_zero[2] = D_20230119_Mo_PageSwitching_arg->ym_zero_Value[2];

    /* Product: '<S185>/Divide' incorporates:
     *  Constant: '<S185>/Scalar one constant'
     *  Constant: '<S185>/Vehicle acceleration tracking time constant'
     */
    localB->utau = D_20230119_Mo_PageSwitching_arg->Scalaroneconstant_Value /
      D_20230119_Mo_PageSwitching_arg->Vehicleaccelerationtrackingtime;

    /* UnaryMinus: '<S185>/Unary Minus' */
    localB->a1 = -localB->utau;

    /* SignalConversion generated from: '<S185>/Matrix Concatenate' incorporates:
     *  Concatenate: '<S185>/Matrix Concatenate'
     *  Constant: '<S185>/Scalar one constant'
     */
    localB->An[0] = localB->a1;
    localB->An[1] = D_20230119_Mo_PageSwitching_arg->Scalaroneconstant_Value;

    /* Constant: '<S185>/Vector constant' incorporates:
     *  Concatenate: '<S185>/Matrix Concatenate'
     */
    localB->An[2] = D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value[0];
    localB->An[3] = D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value[1];

    /* Concatenate: '<S183>/Matrix Concatenate3' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate'
     *  Concatenate: '<S185>/Matrix Concatenate'
     *  Constant: '<S183>/Matrix constant'
     */
    tmp[0] = localB->An[0];
    tmp[2] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[0];
    tmp[1] = localB->An[1];
    tmp[3] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[1];
    tmp[4] = localB->An[2];
    tmp[6] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[2];
    tmp[5] = localB->An[3];
    tmp[7] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[3];
    std::memcpy(&localB->MatrixConcatenate[0], &tmp[0], sizeof(real_T) << 3U);

    /* Sum: '<S184>/Sum' incorporates:
     *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
     *  Constant: '<S184>/Vehicle rear tire cornering stiffness constant'
     */
    localB->Sum =
      D_20230119_Mo_PageSwitching_arg->Vehiclereartirecorneringstiffne +
      D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn;

    /* Gain: '<S184>/Gain2' */
    localB->Gain2 = D_20230119_Mo_PageSwitching_arg->Gain2_Gain * localB->Sum;

    /* Product: '<S184>/Divide2' incorporates:
     *  Constant: '<S184>/Vehicle mass constant'
     */
    localB->a1_a = localB->Gain2 /
      D_20230119_Mo_PageSwitching_arg->Vehiclemassconstant_Value /
      localB->sf_DataTypeConversion_Vx.y;

    /* Product: '<S184>/Product' incorporates:
     *  Constant: '<S184>/Vehicle length to rear constant'
     *  Constant: '<S184>/Vehicle rear tire cornering stiffness constant'
     */
    localB->Product_f =
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtorearconstant_Val *
      D_20230119_Mo_PageSwitching_arg->Vehiclereartirecorneringstiffne;

    /* Product: '<S184>/Product1' incorporates:
     *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
     *  Constant: '<S184>/Vehicle length to front constant'
     */
    localB->Product1 =
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va *
      D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn;

    /* Sum: '<S184>/Sum1' */
    localB->Sum1 = localB->Product1 - localB->Product_f;

    /* Gain: '<S184>/Gain3' */
    localB->Gain3 = D_20230119_Mo_PageSwitching_arg->Gain3_Gain * localB->Sum1;

    /* Product: '<S184>/Divide4' incorporates:
     *  Constant: '<S184>/Vehicle yaw inertia constant'
     */
    localB->a3 = localB->Gain3 / localB->sf_DataTypeConversion_Vx.y /
      D_20230119_Mo_PageSwitching_arg->Vehicleyawinertiaconstant_Value;

    /* SignalConversion generated from: '<S184>/Matrix Concatenate' incorporates:
     *  Concatenate: '<S184>/Matrix Concatenate'
     */
    localB->Am[0] = localB->a1_a;
    localB->Am[1] = localB->a3;

    /* Product: '<S184>/Divide3' incorporates:
     *  Constant: '<S184>/Vehicle mass constant'
     */
    localB->Divide3 = localB->Gain3 / localB->sf_DataTypeConversion_Vx.y /
      D_20230119_Mo_PageSwitching_arg->Vehiclemassconstant_Value;

    /* Sum: '<S184>/Sum2' */
    localB->a2 = localB->Divide3 - localB->sf_DataTypeConversion_Vx.y;

    /* Product: '<S184>/Divide6' incorporates:
     *  Constant: '<S184>/Vehicle length to rear constant'
     *  Constant: '<S184>/Vehicle rear tire cornering stiffness constant'
     */
    localB->Divide6 =
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtorearconstant_Val *
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtorearconstant_Val *
      D_20230119_Mo_PageSwitching_arg->Vehiclereartirecorneringstiffne;

    /* Product: '<S184>/Divide7' incorporates:
     *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
     *  Constant: '<S184>/Vehicle length to front constant'
     */
    localB->Divide7 =
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va *
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va *
      D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn;

    /* Sum: '<S184>/Sum3' */
    localB->Sum3 = localB->Divide6 + localB->Divide7;

    /* Gain: '<S184>/Gain4' */
    localB->Gain4 = D_20230119_Mo_PageSwitching_arg->Gain4_Gain * localB->Sum3;

    /* Product: '<S184>/Divide5' incorporates:
     *  Constant: '<S184>/Vehicle yaw inertia constant'
     */
    localB->a4 = localB->Gain4 / localB->sf_DataTypeConversion_Vx.y /
      D_20230119_Mo_PageSwitching_arg->Vehicleyawinertiaconstant_Value;

    /* SignalConversion generated from: '<S184>/Matrix Concatenate' incorporates:
     *  Concatenate: '<S184>/Matrix Concatenate'
     */
    localB->Am[2] = localB->a2;
    localB->Am[3] = localB->a4;

    /* Concatenate: '<S183>/Matrix Concatenate4' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate'
     *  Concatenate: '<S184>/Matrix Concatenate'
     *  Constant: '<S183>/Matrix constant'
     */
    tmp[0] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[0];
    tmp[2] = localB->Am[0];
    tmp[1] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[1];
    tmp[3] = localB->Am[1];
    tmp[4] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[2];
    tmp[6] = localB->Am[2];
    tmp[5] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[3];
    tmp[7] = localB->Am[3];
    std::memcpy(&localB->MatrixConcatenate[8], &tmp[0], sizeof(real_T) << 3U);

    /* RateTransition generated from: '<S180>/Adaptive Model' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate'
     */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      localDW->TmpRTBAtAdaptiveModelInport3_Wr = static_cast<int8_T>
        (localDW->TmpRTBAtAdaptiveModelInport3_Wr == 0);
    }

    for (int32_T i = 0; i < 16; i++) {
      localDW->TmpRTBAtAdaptiveModelInport3_Bu[i +
        (localDW->TmpRTBAtAdaptiveModelInport3_Wr << 4)] =
        localB->MatrixConcatenate[i];
    }

    /* End of RateTransition generated from: '<S180>/Adaptive Model' */

    /* SignalConversion generated from: '<S183>/Matrix Concatenate5' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     *  Constant: '<S185>/Scalar zero constant'
     */
    localB->MatrixConcatenate1[0] = localB->utau;
    localB->MatrixConcatenate1[1] =
      D_20230119_Mo_PageSwitching_arg->Scalarzeroconstant_Value;

    /* SignalConversion generated from: '<S183>/Matrix Concatenate5' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     *  Constant: '<S183>/Vector constant'
     */
    localB->MatrixConcatenate1[2] =
      D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[0];

    /* SignalConversion generated from: '<S183>/Matrix Concatenate6' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     *  Constant: '<S183>/Vector constant'
     */
    localB->MatrixConcatenate1[4] =
      D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[0];

    /* SignalConversion generated from: '<S183>/Matrix Concatenate5' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     *  Constant: '<S183>/Vector constant'
     */
    localB->MatrixConcatenate1[3] =
      D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[1];

    /* SignalConversion generated from: '<S183>/Matrix Concatenate6' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     *  Constant: '<S183>/Vector constant'
     */
    localB->MatrixConcatenate1[5] =
      D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[1];

    /* Product: '<S184>/Divide' incorporates:
     *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
     *  Constant: '<S184>/Vehicle mass constant'
     */
    localB->Divide =
      D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn /
      D_20230119_Mo_PageSwitching_arg->Vehiclemassconstant_Value;

    /* Gain: '<S184>/Gain' */
    localB->b1 = D_20230119_Mo_PageSwitching_arg->Gain_Gain * localB->Divide;

    /* Product: '<S184>/Divide1' incorporates:
     *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
     *  Constant: '<S184>/Vehicle length to front constant'
     *  Constant: '<S184>/Vehicle yaw inertia constant'
     */
    localB->Divide1 =
      D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn *
      D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va /
      D_20230119_Mo_PageSwitching_arg->Vehicleyawinertiaconstant_Value;

    /* Gain: '<S184>/Gain1' */
    localB->b2 = D_20230119_Mo_PageSwitching_arg->Gain1_Gain * localB->Divide1;

    /* SignalConversion generated from: '<S183>/Matrix Concatenate6' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     */
    localB->MatrixConcatenate1[6] = localB->b1;
    localB->MatrixConcatenate1[7] = localB->b2;

    /* RateTransition generated from: '<S180>/Adaptive Model' incorporates:
     *  Concatenate: '<S183>/Matrix Concatenate1'
     */
    rtw_slrealtime_mutex_lock(localDW->TmpRTBAtAdaptiveModelInport4_d0);
    wrBufIdx = static_cast<int8_T>(localDW->TmpRTBAtAdaptiveModelInport4_Ls + 1);
    if (wrBufIdx == 3) {
      wrBufIdx = 0;
    }

    if (wrBufIdx == localDW->TmpRTBAtAdaptiveModelInport4_RD) {
      wrBufIdx = static_cast<int8_T>(wrBufIdx + 1);
      if (wrBufIdx == 3) {
        wrBufIdx = 0;
      }
    }

    rtw_slrealtime_mutex_unlock(localDW->TmpRTBAtAdaptiveModelInport4_d0);
    switch (wrBufIdx) {
     case 0:
      for (int32_T i = 0; i < 8; i++) {
        localDW->TmpRTBAtAdaptiveModelInport4_Bu[i] = localB->
          MatrixConcatenate1[i];
      }
      break;

     case 1:
      for (int32_T i = 0; i < 8; i++) {
        localDW->TmpRTBAtAdaptiveModelInport4__f[i] = localB->
          MatrixConcatenate1[i];
      }
      break;

     case 2:
      for (int32_T i = 0; i < 8; i++) {
        localDW->TmpRTBAtAdaptiveModelInport4__m[i] = localB->
          MatrixConcatenate1[i];
      }
      break;
    }

    localDW->TmpRTBAtAdaptiveModelInport4_Ls = wrBufIdx;

    /* End of RateTransition generated from: '<S180>/Adaptive Model' */

    /* RateTransition generated from: '<S180>/Adaptive Model' */
    if (D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.RateInteraction.TID1_3
        == 1) {
      localDW->y_WrBufIdx = static_cast<int8_T>(localDW->y_WrBufIdx == 0);
    }

    localDW->y_Buf[localDW->y_WrBufIdx] = localB->sf_DataTypeConversion_Vx.y;

    /* End of RateTransition generated from: '<S180>/Adaptive Model' */

    /* Constant: '<S128>/Relative distance ground' */
    localB->Relativedistanceground =
      D_20230119_Mo_PageSwitching_arg->Relativedistanceground_Value;

    /* Constant: '<S128>/Relative velocity ground' */
    localB->Relativevelocityground =
      D_20230119_Mo_PageSwitching_arg->Relativevelocityground_Value;

    /* Constant: '<S128>/Time gap ground' */
    localB->Timegapground = D_20230119_Mo_PageSwitching_arg->Timegapground_Value;

    /* Constant: '<S128>/Vehicle dynamics matrix A ground' */
    localB->VehicledynamicsmatrixAground =
      D_20230119_Mo_PageSwitching_arg->VehicledynamicsmatrixAground_Va;

    /* Constant: '<S128>/Vehicle dynamics matrix B ground' */
    localB->VehicledynamicsmatrixBground =
      D_20230119_Mo_PageSwitching_arg->VehicledynamicsmatrixBground_Va;

    /* Constant: '<S128>/Vehicle dynamics matrix C ground' */
    localB->VehicledynamicsmatrixCground =
      D_20230119_Mo_PageSwitching_arg->VehicledynamicsmatrixCground_Va;
  }
}

/* Output and update for atomic system: '<S120>/Path Following Control System' */
void PathFollowingControlSystemTID3(real32_T rtu_Setvelocity, real_T
  rtp_MinAcceleration, real_T rtp_MinSteering, real_T rtp_MaxAcceleration,
  real_T rtp_MaxSteering, B_PathFollowingControlSystem__T *localB,
  DW_PathFollowingControlSystem_T *localDW, PathFollowingControlSy_cal_type
  *D_20230119_Mo_PageSwitching_arg)
{
  real_T tmp_2[496];
  real_T Dv[186];
  real_T Dvm[186];
=======
  real_T tmp_2[496];
  real_T Dv[186];
  real_T Dvm[186];
>>>>>>> .r84
  real_T CovMat[169];
  real_T Dv[126];
  real_T Dvm[126];
  real_T b_A[100];
  real_T b_A_0[100];
  real_T b_A_2[100];
  real_T b_A_3[100];
  real_T b_tmp[91];
  real_T Ai[81];
  real_T b_b[81];
  real_T c_a[81];
  real_T c_a_0[81];
  real_T b_B[80];
  real_T rseq[60];
  real_T vseq[42];
  real_T b_utarget[40];
  real_T L[30];
  real_T b_A_1[30];
  real_T b_C[30];
  real_T tmp_0[30];
  real_T b[27];
  real_T b_D[24];
  real_T Bl_0[18];
  real_T Cs[18];
  real_T Cm[16];
  real_T e_a[12];
  real_T b_A_4[10];
  real_T b_xoff[10];
  real_T xk[10];
  real_T Bl[9];
  real_T Kinv[9];
  real_T f_a[8];
  real_T tmp[6];
  real_T Cm_0[3];
  real_T U[3];
  real_T Y[3];
  real_T b_uoff[2];
  real_T tmp_1[2];
  real_T tmp_3[2];
  real_T tmp_4[2];
  real_T tmp_5[2];
  real_T L_0;
  real_T a21;
  real_T b_A_5;
  real_T b_A_6;
  real_T e_a_0;
  real_T h;
  int32_T Coef;
  int32_T i;
  int32_T r2;
  int32_T r3;
  int8_T c_B[9];
  int8_T UnknownIn[7];
  static const int8_T e_a_1[12] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

  static const int8_T c[6] = { 0, 1, 0, 0, 0, 1 };

  static const int8_T d_b[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

  static const int8_T f_a_0[8] = { 0, 0, 1, 0, 0, 1, 0, -1 };

  static const int8_T d[6] = { 0, 0, 0, 0, 0, -1 };

  static const real_T c_0[100] = { 0.81873075307798071, 0.090634623461009, 0.0,
    0.0, 0.0, 0.0, 0.034278209472691633, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
    0.0, 0.63212055882855822, 0.0, 0.0, 0.0, 0.0, 0.0, 1.6435347015077881E-19,
    8.9270910208759632E-20, 0.0019000350977278488, 0.00050834736272378485, 0.0,
    0.0011846544894994438, 0.000315015746829728, 0.0, 0.0, 0.0,
    1.4147599635399686E-19, 7.6844686976343782E-20, 0.00081935781200915376,
    0.0013968059227207447, 0.0, 0.00050422613228281652, 0.00087409089659866326,
    0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.63212055882855822, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.01, 1.0, 0.0, 0.0036787944117144247, 0.63212055882855822,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.36787944117144311, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.36787944117144311, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.36787944117144311, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 1.0 };

  static const real_T d_0[80] = { 0.90634626607108215, 0.046826866964458813, 0.0,
    0.0, 0.0, 0.0, 0.012550355620640066, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.098849396405550613, 0.074825499804786519, 0.0027323729204384913,
    0.0017022819185080289, 0.0, 0.0010552103643723752, 0.00066009507604175663,
    0.0, 0.0, 0.0, 0.0, 0.0, -5.0E-5, -0.010000000000000002, 0.0,
    -1.3213417532053234E-5, -0.003678658246794678, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

  static const real_T e[30] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.033333333333333333, 0.0, 0.0, 0.0,
    1.0, 0.0, 0.0, 0.0, 5.0, 0.0, 0.0, 1.0 };

  static const int8_T f[24] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 1, 0, 0, 0, 1 };

  static const real_T g[27] = { 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0,
    0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.1, 0.1, 0.1, 0.1,
    0.1, 0.1, 0.1, 0.1, 0.1 };

  static const real_T h_0[27] = { 30.0, 1.0, 0.2, 30.0, 1.0, 0.2, 30.0, 1.0, 0.2,
    30.0, 1.0, 0.2, 30.0, 1.0, 0.2, 30.0, 1.0, 0.2, 30.0, 1.0, 0.2, 30.0, 1.0,
    0.2, 30.0, 1.0, 0.2 };

  static const real_T o[8] = { 0.4, 0.5, 0.4, 0.5, 0.6, 0.5, 0.6, 0.5 };

  static const int32_T b_Mrows[8] = { 121, 122, 123, 124, 161, 162, 163, 164 };

  static const real_T x[3] = { 0.033333333333333333, 1.0, 5.0 };

  static const real_T q[16] = { -1.0, -0.0, -1.0, -0.0, 1.0, 0.0, 1.0, 0.0, -0.0,
    -1.0, -0.0, -1.0, 0.0, 1.0, 0.0, 1.0 };

  static const real_T r[25] = { 0.013060767662165126, 0.0, 0.0027679122726721708,
    0.0, 0.0, 0.0, 0.033777098314518306, 0.0, 0.021901144248197391, 0.0,
    0.0027679122726721704, 0.0, 0.012507382976588547, 0.0, 0.0, 0.0,
    0.021901144248197391, 0.0, 0.030208594642760832, 0.0, 0.0, 0.0, 0.0, 0.0,
    100000.0 };

  static const real_T s[40] = { -1.0, -0.0, -1.0, -0.0, 1.0, 0.0, 1.0, 0.0, -0.0,
    -1.0, -0.0, -1.0, 0.0, 1.0, 0.0, 1.0, -0.0, -0.0, -1.0, -0.0, 0.0, 0.0, 1.0,
    0.0, -0.0, -0.0, -0.0, -1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0 };

  static const real_T t[3] = { 0.010000000000000002, 1.0, 0.0 };

  static const real_T u[160] = { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 };

  static const real_T w[80] = { 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0,
    1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0,
    0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0,
    0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0,
    1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0,
    0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0 };

  real_T s_0[40];
  real_T r_0[25];
  real_T Ap_idx_2;

<<<<<<< .mine
  /* RelationalOperator: '<S133>/min_relop' incorporates:
   *  Constant: '<S133>/min_val'
   */
  localB->min_relop =
    (D_20230119_Mo_PageSwitching_arg->Longitudinalvelocitymustbeposit <
     rtu_Longitudinalvelocity);

  /* Assertion: '<S133>/Assertion' */
  localDW->Assertion_sltestCurrentResult = !localB->min_relop;
  if (localDW->Assertion_sltestFinalResult <
      localDW->Assertion_sltestCurrentResult) {
    localDW->Assertion_sltestFinalResult =
      localDW->Assertion_sltestCurrentResult;
    localDW->Assertion_sltestLastResultTime =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
  }

  slTestLogAssessments(&localDW->Assertion_sltestBlkInfo,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t
                       [0]);
  utAssert(localB->min_relop);

  /* End of Assertion: '<S133>/Assertion' */

  /* MATLAB Function: '<S129>/CurvatureConversion' */
  std::memcpy(&localB->y_g[0], &rtu_Curvature[0], 21U * sizeof(real_T));

  /* MATLAB Function: '<S129>/DataTypeConversion_Vx' */
  D_202_DataTypeConversion_Vx(rtu_Longitudinalvelocity,
    &localB->sf_DataTypeConversion_Vx);
  for (i = 0; i < 21; i++) {
    /* Product: '<S129>/Product' */
    localB->Product[i] = localB->y_g[i] * localB->sf_DataTypeConversion_Vx.y;
  }

  /* MATLAB Function: '<S129>/DataTypeConversion_e1' */
  D_202_DataTypeConversion_Vx(rtu_Lateraldeviation,
    &localB->sf_DataTypeConversion_e1);

  /* MATLAB Function: '<S129>/DataTypeConversion_e2' */
  D_202_DataTypeConversion_Vx(rtu_Relativeyawangle,
    &localB->sf_DataTypeConversion_e2);

||||||| .r78
=======
  /* RelationalOperator: '<S133>/min_relop' incorporates:
   *  Constant: '<S133>/min_val'
   */
  localB->min_relop =
    (D_20230119_Mo_PageSwitching_arg->Longitudinalvelocitymustbeposit <
     rtu_Longitudinalvelocity);

  /* Assertion: '<S133>/Assertion' */
  localDW->Assertion_sltestCurrentResult = !localB->min_relop;
  if (localDW->Assertion_sltestFinalResult <
      localDW->Assertion_sltestCurrentResult) {
    localDW->Assertion_sltestFinalResult =
      localDW->Assertion_sltestCurrentResult;
    localDW->Assertion_sltestLastResultTime =
      D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t[0];
  }

  slTestLogAssessments(&localDW->Assertion_sltestBlkInfo,
                       D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson_M->Timing.t
                       [0]);
  utAssert(localB->min_relop);

  /* End of Assertion: '<S133>/Assertion' */

  /* MATLAB Function: '<S129>/CurvatureConversion' */
  std::memcpy(&localB->y_g[0], &rtu_Curvature[0], 31U * sizeof(real_T));

  /* MATLAB Function: '<S129>/DataTypeConversion_Vx' */
  D_202_DataTypeConversion_Vx(rtu_Longitudinalvelocity,
    &localB->sf_DataTypeConversion_Vx);
  for (i = 0; i < 31; i++) {
    /* Product: '<S129>/Product' */
    localB->Product[i] = localB->y_g[i] * localB->sf_DataTypeConversion_Vx.y;
  }

  /* MATLAB Function: '<S129>/DataTypeConversion_e1' */
  D_202_DataTypeConversion_Vx(rtu_Lateraldeviation,
    &localB->sf_DataTypeConversion_e1);

  /* MATLAB Function: '<S129>/DataTypeConversion_e2' */
  D_202_DataTypeConversion_Vx(rtu_Relativeyawangle,
    &localB->sf_DataTypeConversion_e2);

>>>>>>> .r84
  /* MATLAB Function: '<S129>/DataTypeConversion_vset' */
  localB->y = rtu_Setvelocity;

  /* MATLAB Function: '<S129>/DataTypeConversion_extmv' incorporates:
   *  Constant: '<S128>/External control signal constant'
   */
  localB->y_f[0] =
    D_20230119_Mo_PageSwitching_arg->Externalcontrolsignalconstant_V[0];
  localB->y_f[1] =
    D_20230119_Mo_PageSwitching_arg->Externalcontrolsignalconstant_V[1];

  /* MATLAB Function: '<S129>/DataTypeConversion_amin' incorporates:
   *  Constant: '<S128>/Minimum longitudinal acceleration constant'
   */
  D_2_DataTypeConversion_amax(rtp_MinAcceleration,
    &localB->sf_DataTypeConversion_amin);

  /* MATLAB Function: '<S129>/DataTypeConversion_umin' incorporates:
   *  Constant: '<S128>/Minimum steering angle constant'
   */
  D_2_DataTypeConversion_amax(rtp_MinSteering,
    &localB->sf_DataTypeConversion_umin);

  /* MATLAB Function: '<S129>/DataTypeConversion_amax' incorporates:
   *  Constant: '<S128>/Maximum longitudinal acceleration constant'
   */
  D_2_DataTypeConversion_amax(rtp_MaxAcceleration,
    &localB->sf_DataTypeConversion_amax);

  /* MATLAB Function: '<S129>/DataTypeConversion_umax' incorporates:
   *  Constant: '<S128>/Maximum steering angle constant'
   */
  D_2_DataTypeConversion_amax(rtp_MaxSteering,
    &localB->sf_DataTypeConversion_umax);

  /* MATLAB Function: '<S129>/DataTypeConversion_optsgn' incorporates:
   *  Constant: '<S128>/Enable optimization constant'
   */
  localB->y_b =
    ((D_20230119_Mo_PageSwitching_arg->Enableoptimizationconstant_Valu > 0.0) ||
     (D_20230119_Mo_PageSwitching_arg->Enableoptimizationconstant_Valu < 0.0));

  /* MATLAB Function: '<S128>/DataTypeConversion_Ts' incorporates:
   *  Constant: '<S128>/Sample time constant'
   */
  D_2_DataTypeConversion_amax
    (D_20230119_Mo_PageSwitching_arg->Sampletimeconstant_Value,
     &localB->sf_DataTypeConversion_Ts);

  /* MATLAB Function: '<S128>/DataTypeConversion_spacing' incorporates:
   *  Constant: '<S128>/Default spacing constant'
   */
  D_2_DataTypeConversion_amax(rtp_DefaultSpacing,
    &localB->sf_DataTypeConversion_spacing);

  /* MATLAB Function: '<S128>/DataTypeConversion_tlag' incorporates:
   *  Constant: '<S128>/Transport lag constant'
   */
  D_2_DataTypeConversion_amax
    (D_20230119_Mo_PageSwitching_arg->Transportlagconstant_Value,
     &localB->sf_DataTypeConversion_tlag);

  /* Rounding: '<S150>/Floor' incorporates:
   *  Constant: '<S149>/p_zero'
   */
  localB->Floor = std::floor(D_20230119_Mo_PageSwitching_arg->p_zero_Value);

  /* Rounding: '<S150>/Floor1' incorporates:
   *  Constant: '<S149>/m_zero'
   */
  localB->Floor1 = std::floor(D_20230119_Mo_PageSwitching_arg->m_zero_Value);

  /* Memory: '<S150>/LastPcov' */
  std::memcpy(&localB->LastPcov[0], &localDW->LastPcov_PreviousInput[0], 100U *
              sizeof(real_T));

  /* Math: '<S150>/Math Function' incorporates:
   *  Constant: '<S149>/y.wt_zero'
   */
  localB->MathFunction[0] = D_20230119_Mo_PageSwitching_arg->ywt_zero_Value[0];
  localB->MathFunction[1] = D_20230119_Mo_PageSwitching_arg->ywt_zero_Value[1];
  localB->MathFunction[2] = D_20230119_Mo_PageSwitching_arg->ywt_zero_Value[2];

  /* Math: '<S150>/Math Function1' incorporates:
   *  Constant: '<S149>/u.wt_zero'
   */
  localB->MathFunction1[0] = D_20230119_Mo_PageSwitching_arg->uwt_zero_Value[0];

  /* Math: '<S150>/Math Function2' incorporates:
   *  Constant: '<S149>/du.wt_zero'
   */
  localB->MathFunction2[0] = D_20230119_Mo_PageSwitching_arg->duwt_zero_Value[0];

  /* Math: '<S150>/Math Function1' incorporates:
   *  Constant: '<S149>/u.wt_zero'
   */
  localB->MathFunction1[1] = D_20230119_Mo_PageSwitching_arg->uwt_zero_Value[1];

  /* Math: '<S150>/Math Function2' incorporates:
   *  Constant: '<S149>/du.wt_zero'
   */
  localB->MathFunction2[1] = D_20230119_Mo_PageSwitching_arg->duwt_zero_Value[1];
  for (i = 0; i < 8; i++) {
    /* Memory: '<S150>/Memory' */
    localB->Memory[i] = localDW->Memory_PreviousInput[i];
  }

  /* Gain: '<S150>/umin_scale4' incorporates:
   *  Constant: '<S149>/E_zero'
   */
  localB->umin_scale4[0] = D_20230119_Mo_PageSwitching_arg->umin_scale4_Gain[0] *
    D_20230119_Mo_PageSwitching_arg->E_zero_Value[0];
  localB->umin_scale4[1] = D_20230119_Mo_PageSwitching_arg->umin_scale4_Gain[1] *
    D_20230119_Mo_PageSwitching_arg->E_zero_Value[1];

  /* Reshape: '<S150>/Reshape' incorporates:
   *  Gain: '<S150>/umin_scale4'
   */
  localB->Reshape[0] = localB->umin_scale4[0];
  localB->Reshape[1] = localB->umin_scale4[1];

  /* Gain: '<S150>/ymin_scale1' incorporates:
   *  Constant: '<S149>/F_zero'
   */
  localB->ymin_scale1[0] = D_20230119_Mo_PageSwitching_arg->ymin_scale1_Gain[0] *
    D_20230119_Mo_PageSwitching_arg->F_zero_Value[0];
  localB->ymin_scale1[1] = D_20230119_Mo_PageSwitching_arg->ymin_scale1_Gain[1] *
    D_20230119_Mo_PageSwitching_arg->F_zero_Value[1];
  localB->ymin_scale1[2] = D_20230119_Mo_PageSwitching_arg->ymin_scale1_Gain[2] *
    D_20230119_Mo_PageSwitching_arg->F_zero_Value[2];

  /* Gain: '<S150>/ymin_scale2' incorporates:
   *  Constant: '<S149>/S_zero'
   */
  localB->ymin_scale2 = D_20230119_Mo_PageSwitching_arg->ymin_scale2_Gain *
    D_20230119_Mo_PageSwitching_arg->S_zero_Value;

  /* Reshape: '<S150>/Reshape2' */
  localB->Reshape2 = localB->ymin_scale2;

  /* Reshape: '<S150>/Reshape1' incorporates:
   *  Gain: '<S150>/ymin_scale1'
   */
  localB->Reshape1[0] = localB->ymin_scale1[0];

  /* Reshape: '<S150>/Reshape3' incorporates:
   *  Math: '<S150>/Math Function'
   */
  localB->Reshape3[0] = localB->MathFunction[0];

  /* Reshape: '<S150>/Reshape1' incorporates:
   *  Gain: '<S150>/ymin_scale1'
   */
  localB->Reshape1[1] = localB->ymin_scale1[1];

  /* Reshape: '<S150>/Reshape3' incorporates:
   *  Math: '<S150>/Math Function'
   */
  localB->Reshape3[1] = localB->MathFunction[1];

  /* Reshape: '<S150>/Reshape1' incorporates:
   *  Gain: '<S150>/ymin_scale1'
   */
  localB->Reshape1[2] = localB->ymin_scale1[2];

  /* Reshape: '<S150>/Reshape3' incorporates:
   *  Math: '<S150>/Math Function'
   */
  localB->Reshape3[2] = localB->MathFunction[2];

  /* Reshape: '<S150>/Reshape4' incorporates:
   *  Math: '<S150>/Math Function1'
   */
  localB->Reshape4[0] = localB->MathFunction1[0];

  /* Reshape: '<S150>/Reshape5' incorporates:
   *  Math: '<S150>/Math Function2'
   */
  localB->Reshape5[0] = localB->MathFunction2[0];

  /* Gain: '<S150>/ext.mv_scale' incorporates:
   *  Constant: '<S149>/ext.mv_zero'
   */
  localB->extmv_scale[0] = D_20230119_Mo_PageSwitching_arg->extmv_scale_Gain[0] *
    D_20230119_Mo_PageSwitching_arg->extmv_zero_Value[0];

  /* UnitDelay: '<S150>/last_mv' */
  localB->last_mv[0] = localDW->last_mv_DSTATE[0];

  /* Reshape: '<S150>/Reshape4' incorporates:
   *  Math: '<S150>/Math Function1'
   */
  localB->Reshape4[1] = localB->MathFunction1[1];

  /* Reshape: '<S150>/Reshape5' incorporates:
   *  Math: '<S150>/Math Function2'
   */
  localB->Reshape5[1] = localB->MathFunction2[1];

  /* Gain: '<S150>/ext.mv_scale' incorporates:
   *  Constant: '<S149>/ext.mv_zero'
   */
  localB->extmv_scale[1] = D_20230119_Mo_PageSwitching_arg->extmv_scale_Gain[1] *
    D_20230119_Mo_PageSwitching_arg->extmv_zero_Value[1];

  /* UnitDelay: '<S150>/last_mv' */
  localB->last_mv[1] = localDW->last_mv_DSTATE[1];

  /* Memory: '<S150>/last_x' */
  std::memcpy(&localB->last_x[0], &localDW->last_x_PreviousInput[0], 10U *
              sizeof(real_T));

  /* Product: '<S185>/Divide' incorporates:
   *  Constant: '<S185>/Scalar one constant'
   *  Constant: '<S185>/Vehicle acceleration tracking time constant'
   */
  localB->utau = D_20230119_Mo_PageSwitching_arg->Scalaroneconstant_Value /
    D_20230119_Mo_PageSwitching_arg->Vehicleaccelerationtrackingtime;

  /* UnaryMinus: '<S185>/Unary Minus' */
  localB->a1 = -localB->utau;

  /* SignalConversion generated from: '<S185>/Matrix Concatenate' incorporates:
   *  Concatenate: '<S185>/Matrix Concatenate'
   *  Constant: '<S185>/Scalar one constant'
   */
  localB->An[0] = localB->a1;
  localB->An[1] = D_20230119_Mo_PageSwitching_arg->Scalaroneconstant_Value;

  /* Gain: '<S150>/uref_scale' incorporates:
   *  Constant: '<S149>/mv.target_zero'
   */
  localB->uref_scale[0] = D_20230119_Mo_PageSwitching_arg->uref_scale_Gain[0] *
    D_20230119_Mo_PageSwitching_arg->mvtarget_zero_Value[0];

  /* Constant: '<S185>/Vector constant' incorporates:
   *  Concatenate: '<S185>/Matrix Concatenate'
   */
  localB->An[2] = D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value[0];

  /* Gain: '<S150>/uref_scale' incorporates:
   *  Constant: '<S149>/mv.target_zero'
   */
  localB->uref_scale[1] = D_20230119_Mo_PageSwitching_arg->uref_scale_Gain[1] *
    D_20230119_Mo_PageSwitching_arg->mvtarget_zero_Value[1];

  /* Constant: '<S185>/Vector constant' incorporates:
   *  Concatenate: '<S185>/Matrix Concatenate'
   */
  localB->An[3] = D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value[1];

  /* Concatenate: '<S183>/Matrix Concatenate3' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate'
   *  Concatenate: '<S185>/Matrix Concatenate'
   *  Constant: '<S183>/Matrix constant'
   */
  f_a[0] = localB->An[0];
  f_a[2] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[0];
  f_a[1] = localB->An[1];
  f_a[3] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[1];
  f_a[4] = localB->An[2];
  f_a[6] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[2];
  f_a[5] = localB->An[3];
  f_a[7] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[3];
  std::memcpy(&localB->MatrixConcatenate[0], &f_a[0], sizeof(real_T) << 3U);

  /* Sum: '<S184>/Sum' incorporates:
   *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
   *  Constant: '<S184>/Vehicle rear tire cornering stiffness constant'
   */
  localB->Sum = D_20230119_Mo_PageSwitching_arg->Vehiclereartirecorneringstiffne
    + D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn;

  /* Gain: '<S184>/Gain2' */
  localB->Gain2 = D_20230119_Mo_PageSwitching_arg->Gain2_Gain * localB->Sum;

  /* Product: '<S184>/Divide2' incorporates:
   *  Constant: '<S184>/Vehicle mass constant'
   */
  localB->a1_a = localB->Gain2 /
    D_20230119_Mo_PageSwitching_arg->Vehiclemassconstant_Value /
    localB->sf_DataTypeConversion_Vx.y;

  /* Product: '<S184>/Product' incorporates:
   *  Constant: '<S184>/Vehicle length to rear constant'
   *  Constant: '<S184>/Vehicle rear tire cornering stiffness constant'
   */
  localB->Product_f =
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtorearconstant_Val *
    D_20230119_Mo_PageSwitching_arg->Vehiclereartirecorneringstiffne;

  /* Product: '<S184>/Product1' incorporates:
   *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
   *  Constant: '<S184>/Vehicle length to front constant'
   */
  localB->Product1 =
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va *
    D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn;

  /* Sum: '<S184>/Sum1' */
  localB->Sum1 = localB->Product1 - localB->Product_f;

  /* Gain: '<S184>/Gain3' */
  localB->Gain3 = D_20230119_Mo_PageSwitching_arg->Gain3_Gain * localB->Sum1;

  /* Product: '<S184>/Divide4' incorporates:
   *  Constant: '<S184>/Vehicle yaw inertia constant'
   */
  localB->a3 = localB->Gain3 / localB->sf_DataTypeConversion_Vx.y /
    D_20230119_Mo_PageSwitching_arg->Vehicleyawinertiaconstant_Value;

  /* SignalConversion generated from: '<S184>/Matrix Concatenate' incorporates:
   *  Concatenate: '<S184>/Matrix Concatenate'
   */
  localB->Am[0] = localB->a1_a;
  localB->Am[1] = localB->a3;

  /* Product: '<S184>/Divide3' incorporates:
   *  Constant: '<S184>/Vehicle mass constant'
   */
  localB->Divide3 = localB->Gain3 / localB->sf_DataTypeConversion_Vx.y /
    D_20230119_Mo_PageSwitching_arg->Vehiclemassconstant_Value;

  /* Sum: '<S184>/Sum2' */
  localB->a2 = localB->Divide3 - localB->sf_DataTypeConversion_Vx.y;

  /* Product: '<S184>/Divide6' incorporates:
   *  Constant: '<S184>/Vehicle length to rear constant'
   *  Constant: '<S184>/Vehicle rear tire cornering stiffness constant'
   */
  localB->Divide6 =
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtorearconstant_Val *
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtorearconstant_Val *
    D_20230119_Mo_PageSwitching_arg->Vehiclereartirecorneringstiffne;

  /* Product: '<S184>/Divide7' incorporates:
   *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
   *  Constant: '<S184>/Vehicle length to front constant'
   */
  localB->Divide7 =
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va *
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va *
    D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn;

  /* Sum: '<S184>/Sum3' */
  localB->Sum3 = localB->Divide6 + localB->Divide7;

  /* Gain: '<S184>/Gain4' */
  localB->Gain4 = D_20230119_Mo_PageSwitching_arg->Gain4_Gain * localB->Sum3;

  /* Product: '<S184>/Divide5' incorporates:
   *  Constant: '<S184>/Vehicle yaw inertia constant'
   */
  localB->a4 = localB->Gain4 / localB->sf_DataTypeConversion_Vx.y /
    D_20230119_Mo_PageSwitching_arg->Vehicleyawinertiaconstant_Value;

  /* SignalConversion generated from: '<S184>/Matrix Concatenate' incorporates:
   *  Concatenate: '<S184>/Matrix Concatenate'
   */
  localB->Am[2] = localB->a2;
  localB->Am[3] = localB->a4;

  /* Concatenate: '<S183>/Matrix Concatenate4' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate'
   *  Concatenate: '<S184>/Matrix Concatenate'
   *  Constant: '<S183>/Matrix constant'
   */
  f_a[0] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[0];
  f_a[2] = localB->Am[0];
  f_a[1] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[1];
  f_a[3] = localB->Am[1];
  f_a[4] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[2];
  f_a[6] = localB->Am[2];
  f_a[5] = D_20230119_Mo_PageSwitching_arg->Matrixconstant_Value[3];
  f_a[7] = localB->Am[3];
  std::memcpy(&localB->MatrixConcatenate[8], &f_a[0], sizeof(real_T) << 3U);

  /* SignalConversion generated from: '<S183>/Matrix Concatenate5' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate1'
   *  Constant: '<S185>/Scalar zero constant'
   */
  localB->MatrixConcatenate1[0] = localB->utau;
  localB->MatrixConcatenate1[1] =
    D_20230119_Mo_PageSwitching_arg->Scalarzeroconstant_Value;

  /* Product: '<S184>/Divide' incorporates:
   *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
   *  Constant: '<S184>/Vehicle mass constant'
   */
  localB->Divide =
    D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn /
    D_20230119_Mo_PageSwitching_arg->Vehiclemassconstant_Value;

  /* Gain: '<S184>/Gain' */
  localB->b1 = D_20230119_Mo_PageSwitching_arg->Gain_Gain * localB->Divide;

  /* Product: '<S184>/Divide1' incorporates:
   *  Constant: '<S184>/Vehicle front tire cornering stiffness constant'
   *  Constant: '<S184>/Vehicle length to front constant'
   *  Constant: '<S184>/Vehicle yaw inertia constant'
   */
  localB->Divide1 =
    D_20230119_Mo_PageSwitching_arg->Vehiclefronttirecorneringstiffn *
    D_20230119_Mo_PageSwitching_arg->Vehiclelengthtofrontconstant_Va /
    D_20230119_Mo_PageSwitching_arg->Vehicleyawinertiaconstant_Value;

  /* Gain: '<S184>/Gain1' */
  localB->b2 = D_20230119_Mo_PageSwitching_arg->Gain1_Gain * localB->Divide1;

  /* SignalConversion generated from: '<S183>/Matrix Concatenate6' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate1'
   */
  localB->MatrixConcatenate1[6] = localB->b1;
  localB->MatrixConcatenate1[7] = localB->b2;

  /* SignalConversion generated from: '<S183>/Matrix Concatenate5' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate1'
   *  Constant: '<S183>/Vector constant'
   */
  localB->MatrixConcatenate1[2] =
    D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[0];

  /* SignalConversion generated from: '<S183>/Matrix Concatenate6' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate1'
   *  Constant: '<S183>/Vector constant'
   */
  localB->MatrixConcatenate1[4] =
    D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[0];

  /* Concatenate: '<S183>/Matrix Concatenate7' incorporates:
   *  Constant: '<S183>/Matrix constant1'
   *  Constant: '<S185>/Cn constant'
   */
  tmp[0] = D_20230119_Mo_PageSwitching_arg->Cnconstant_Value[0];
  tmp[1] = D_20230119_Mo_PageSwitching_arg->Matrixconstant1_Value[0];
  tmp[2] = D_20230119_Mo_PageSwitching_arg->Matrixconstant1_Value[1];

  /* SignalConversion generated from: '<S183>/Matrix Concatenate5' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate1'
   *  Constant: '<S183>/Vector constant'
   */
  localB->MatrixConcatenate1[3] =
    D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[1];

  /* SignalConversion generated from: '<S183>/Matrix Concatenate6' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate1'
   *  Constant: '<S183>/Vector constant'
   */
  localB->MatrixConcatenate1[5] =
    D_20230119_Mo_PageSwitching_arg->Vectorconstant_Value_k[1];

  /* Concatenate: '<S183>/Matrix Concatenate7' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate2'
   *  Constant: '<S183>/Matrix constant1'
   *  Constant: '<S185>/Cn constant'
   */
  tmp[3] = D_20230119_Mo_PageSwitching_arg->Cnconstant_Value[1];
  tmp[4] = D_20230119_Mo_PageSwitching_arg->Matrixconstant1_Value[2];
  tmp[5] = D_20230119_Mo_PageSwitching_arg->Matrixconstant1_Value[3];
  for (r2 = 0; r2 < 6; r2++) {
    localB->MatrixConcatenate2[r2] = tmp[r2];
  }

  /* Concatenate: '<S183>/Matrix Concatenate8' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate2'
   *  Constant: '<S183>/Vector constant1'
   *  Constant: '<S184>/Cm Constant'
   */
  tmp[0] = D_20230119_Mo_PageSwitching_arg->Vectorconstant1_Value[0];
  tmp[1] = D_20230119_Mo_PageSwitching_arg->CmConstant_Value[0];
  tmp[2] = D_20230119_Mo_PageSwitching_arg->CmConstant_Value[1];
  tmp[3] = D_20230119_Mo_PageSwitching_arg->Vectorconstant1_Value[1];
  tmp[4] = D_20230119_Mo_PageSwitching_arg->CmConstant_Value[2];
  tmp[5] = D_20230119_Mo_PageSwitching_arg->CmConstant_Value[3];
  for (r2 = 0; r2 < 6; r2++) {
    localB->MatrixConcatenate2[r2 + 6] = tmp[r2];
  }

  /* End of Concatenate: '<S183>/Matrix Concatenate8' */

  /* MATLAB Function: '<S180>/Adaptive Model' incorporates:
   *  Concatenate: '<S183>/Matrix Concatenate'
   *  Concatenate: '<S183>/Matrix Concatenate1'
   *  Concatenate: '<S183>/Matrix Concatenate2'
   */
  h = localB->sf_DataTypeConversion_Ts.y;
  for (r2 = 0; r2 < 4; r2++) {
    Cm[r2 << 2] = localB->MatrixConcatenate2[3 * r2];
    Cm[(r2 << 2) + 1] = localB->MatrixConcatenate2[3 * r2 + 1];
    Cm[(r2 << 2) + 2] = localB->MatrixConcatenate2[3 * r2 + 2];
    Cm[(r2 << 2) + 3] = 0.0;
  }

  Ap_idx_2 = localB->sf_DataTypeConversion_Vx.y;
  for (r2 = 0; r2 < 4; r2++) {
    for (Coef = 0; Coef < 3; Coef++) {
      e_a[Coef + 3 * r2] = 0.0;
      e_a_0 = e_a[3 * r2 + Coef];
      e_a_0 += Cm[r2 << 2] * static_cast<real_T>(e_a_1[Coef]);
      e_a[Coef + 3 * r2] = e_a_0;
      e_a_0 = e_a[3 * r2 + Coef];
      e_a_0 += Cm[(r2 << 2) + 1] * static_cast<real_T>(e_a_1[Coef + 3]);
      e_a[Coef + 3 * r2] = e_a_0;
      e_a_0 = e_a[3 * r2 + Coef];
      e_a_0 += Cm[(r2 << 2) + 2] * static_cast<real_T>(e_a_1[Coef + 6]);
      e_a[Coef + 3 * r2] = e_a_0;
      e_a_0 = e_a[3 * r2 + Coef];
      e_a_0 += Cm[(r2 << 2) + 3] * static_cast<real_T>(e_a_1[Coef + 9]);
      e_a[Coef + 3 * r2] = e_a_0;
    }
  }

  std::memcpy(&Cs[0], &e_a[0], 12U * sizeof(real_T));
  for (r2 = 0; r2 < 6; r2++) {
    Cs[r2 + 12] = c[r2];
  }

  a21 = -1.0 / localB->sf_DataTypeConversion_tlag.y;
  e_a_0 = 1.0 / localB->sf_DataTypeConversion_tlag.y;
  for (r2 = 0; r2 < 9; r2++) {
    Bl[r2] = e_a_0 * static_cast<real_T>(d_b[r2]);
  }

  for (r2 = 0; r2 < 4; r2++) {
    for (Coef = 0; Coef < 2; Coef++) {
      f_a[Coef + (r2 << 1)] = 0.0;
      e_a_0 = f_a[(r2 << 1) + Coef];
      e_a_0 += Cm[r2 << 2] * 0.0;
      f_a[Coef + (r2 << 1)] = e_a_0;
      e_a_0 = f_a[(r2 << 1) + Coef];
      e_a_0 += Cm[(r2 << 2) + 1] * static_cast<real_T>(f_a_0[Coef + 2]);
      f_a[Coef + (r2 << 1)] = e_a_0;
      e_a_0 = f_a[(r2 << 1) + Coef];
      e_a_0 += Cm[(r2 << 2) + 2] * static_cast<real_T>(f_a_0[Coef + 4]);
      f_a[Coef + (r2 << 1)] = e_a_0;
      e_a_0 = f_a[(r2 << 1) + Coef];
      e_a_0 += Cm[(r2 << 2) + 3] * static_cast<real_T>(f_a_0[Coef + 6]);
      f_a[Coef + (r2 << 1)] = e_a_0;
    }
  }

  for (r2 = 0; r2 < 6; r2++) {
    for (Coef = 0; Coef < 3; Coef++) {
      Bl_0[Coef + 3 * r2] = 0.0;
      e_a_0 = Bl_0[3 * r2 + Coef];
      e_a_0 += Cs[3 * r2] * Bl[Coef];
      Bl_0[Coef + 3 * r2] = e_a_0;
      e_a_0 = Bl_0[3 * r2 + Coef];
      e_a_0 += Cs[3 * r2 + 1] * Bl[Coef + 3];
      Bl_0[Coef + 3 * r2] = e_a_0;
      e_a_0 = Bl_0[3 * r2 + Coef];
      e_a_0 += Cs[3 * r2 + 2] * Bl[Coef + 6];
      Bl_0[Coef + 3 * r2] = e_a_0;
    }
  }

  for (r2 = 0; r2 < 4; r2++) {
    c_a[9 * r2] = localB->MatrixConcatenate[r2 << 2];
    c_a[9 * r2 + 1] = localB->MatrixConcatenate[(r2 << 2) + 1];
    c_a[9 * r2 + 2] = localB->MatrixConcatenate[(r2 << 2) + 2];
    c_a[9 * r2 + 3] = localB->MatrixConcatenate[(r2 << 2) + 3];
  }

  for (r2 = 0; r2 < 2; r2++) {
    c_a[9 * (r2 + 4)] = 0.0;
    c_a[9 * (r2 + 4) + 1] = 0.0;
    c_a[9 * (r2 + 4) + 2] = 0.0;
    c_a[9 * (r2 + 4) + 3] = 0.0;
  }

  for (r2 = 0; r2 < 4; r2++) {
    c_a[9 * r2 + 4] = f_a[r2 << 1];
    c_a[9 * r2 + 5] = f_a[(r2 << 1) + 1];
  }

  c_a[40] = 0.0;
  c_a[41] = 0.0;
  c_a[49] = Ap_idx_2;
  c_a[50] = 0.0;
  for (r2 = 0; r2 < 6; r2++) {
    c_a[r2 + 54] = 0.0;
    c_a[r2 + 63] = 0.0;
    c_a[r2 + 72] = 0.0;
    c_a[9 * r2 + 6] = Bl_0[3 * r2];
    c_a[9 * r2 + 7] = Bl_0[3 * r2 + 1];
    c_a[9 * r2 + 8] = Bl_0[3 * r2 + 2];
  }

  for (r2 = 0; r2 < 3; r2++) {
    for (Coef = 0; Coef < 3; Coef++) {
      c_a[(Coef + 9 * (r2 + 6)) + 6] = static_cast<real_T>(d_b[3 * r2 + Coef]) *
        a21;
      Kinv[r2 + 3 * Coef] = 0.0;
      e_a_0 = Kinv[3 * Coef + r2];
      e_a_0 += Bl[r2] * 0.0;
      Kinv[r2 + 3 * Coef] = e_a_0;
      e_a_0 = Kinv[3 * Coef + r2];
      e_a_0 += Bl[r2 + 3] * 0.0;
      Kinv[r2 + 3 * Coef] = e_a_0;
      e_a_0 = Kinv[3 * Coef + r2];
      e_a_0 += Bl[r2 + 6] * 0.0;
      Kinv[r2 + 3 * Coef] = e_a_0;
    }
  }

  for (r2 = 0; r2 < 2; r2++) {
    b[9 * r2] = localB->MatrixConcatenate1[r2 << 2];
    b[9 * r2 + 1] = localB->MatrixConcatenate1[(r2 << 2) + 1];
    b[9 * r2 + 2] = localB->MatrixConcatenate1[(r2 << 2) + 2];
    b[9 * r2 + 3] = localB->MatrixConcatenate1[(r2 << 2) + 3];
  }

  b[18] = 0.0;
  b[19] = 0.0;
  b[20] = 0.0;
  b[21] = 0.0;
  for (r2 = 0; r2 < 3; r2++) {
    b[9 * r2 + 4] = 0.0;
    b[9 * r2 + 5] = d[(r2 << 1) + 1];
    b[9 * r2 + 6] = Kinv[3 * r2];
    b[9 * r2 + 7] = Kinv[3 * r2 + 1];
    b[9 * r2 + 8] = Kinv[3 * r2 + 2];
  }

  if (localB->sf_DataTypeConversion_Ts.y > 0.0) {
    for (r2 = 0; r2 < 81; r2++) {
      c_a_0[r2] = c_a[r2] * localB->sf_DataTypeConversion_Ts.y;
    }

    D_20230119_Modell_In_expmNoLog2(c_a_0, localB->A);
    h /= 4.0;
    std::memset(&Ai[0], 0, 81U * sizeof(real_T));
    for (i = 0; i < 9; i++) {
      Ai[i + 9 * i] = 1.0;
    }

    for (r2 = 0; r2 < 81; r2++) {
      e_a_0 = Ai[r2];
      e_a_0 += localB->A[r2];
      Ai[r2] = e_a_0;
    }

    Coef = 2;
    for (i = 0; i < 3; i++) {
      if (Coef == 2) {
        Coef = 4;
      } else {
        Coef = 2;
      }

      r3 = i + 1;
      for (r2 = 0; r2 < 81; r2++) {
        c_a_0[r2] = c_a[r2] * static_cast<real_T>(r3) * h;
      }

      D_20230119_Modell_In_expmNoLog2(c_a_0, b_b);
      for (r2 = 0; r2 < 81; r2++) {
        e_a_0 = Ai[r2];
        e_a_0 += static_cast<real_T>(Coef) * b_b[r2];
        Ai[r2] = e_a_0;
      }
    }

    h /= 3.0;
    for (r2 = 0; r2 < 9; r2++) {
      for (Coef = 0; Coef < 3; Coef++) {
        localB->B[r2 + 9 * Coef] = 0.0;
        for (i = 0; i < 9; i++) {
          localB->B[r2 + 9 * Coef] += Ai[9 * i + r2] * h * b[9 * Coef + i];
        }
      }
    }
  } else {
    std::memcpy(&localB->A[0], &c_a[0], 81U * sizeof(real_T));
    std::memcpy(&localB->B[0], &b[0], 27U * sizeof(real_T));
  }

  for (r2 = 0; r2 < 6; r2++) {
    for (Coef = 0; Coef < 3; Coef++) {
      Bl_0[Coef + 3 * r2] = 0.0;
      a21 = Bl_0[3 * r2 + Coef];
      a21 += Cs[3 * r2] * 0.0;
      Bl_0[Coef + 3 * r2] = a21;
      a21 = Bl_0[3 * r2 + Coef];
      a21 += Cs[3 * r2 + 1] * 0.0;
      Bl_0[Coef + 3 * r2] = a21;
      a21 = Bl_0[3 * r2 + Coef];
      a21 += Cs[3 * r2 + 2] * 0.0;
      Bl_0[Coef + 3 * r2] = a21;
    }
  }

  std::memcpy(&localB->C[0], &Bl_0[0], 18U * sizeof(real_T));
  for (r2 = 0; r2 < 9; r2++) {
    localB->C[r2 + 18] = d_b[r2];
  }

  std::memset(&localB->D[0], 0, 9U * sizeof(real_T));

  /* End of MATLAB Function: '<S180>/Adaptive Model' */

  /* SignalConversion generated from: '<S179>/ SFunction ' incorporates:
   *  MATLAB Function: '<S178>/FixedHorizonOptimizer'
   */
  localB->TmpSignalConversionAtSFunctionI[0] =
    localB->sf_DataTypeConversion_Vx.y;
  localB->TmpSignalConversionAtSFunctionI[1] =
    localB->sf_DataTypeConversion_e1.y;
  localB->TmpSignalConversionAtSFunctionI[2] =
    localB->sf_DataTypeConversion_e2.y;

  /* SignalConversion generated from: '<S179>/ SFunction ' incorporates:
   *  Constant: '<S129>/Lateral deviation reference constant'
   *  Constant: '<S129>/Relative yaw angle reference constant '
   *  MATLAB Function: '<S178>/FixedHorizonOptimizer'
   */
  localB->TmpSignalConversionAtSFunctio_e[0] = localB->y;
  localB->TmpSignalConversionAtSFunctio_e[1] =
    D_20230119_Mo_PageSwitching_arg->Lateraldeviationreferenceconsta;
  localB->TmpSignalConversionAtSFunctio_e[2] =
    D_20230119_Mo_PageSwitching_arg->Relativeyawanglereferenceconsta;

  /* SignalConversion generated from: '<S179>/ SFunction ' incorporates:
   *  MATLAB Function: '<S178>/FixedHorizonOptimizer'
   */
  localB->TmpSignalConversionAtSFunctio_g[0] =
    localB->sf_DataTypeConversion_amin.y;
  localB->TmpSignalConversionAtSFunctio_g[1] =
    localB->sf_DataTypeConversion_umin.y;

  /* SignalConversion generated from: '<S179>/ SFunction ' incorporates:
   *  MATLAB Function: '<S178>/FixedHorizonOptimizer'
   */
  localB->TmpSignalConversionAtSFunctio_h[0] =
    localB->sf_DataTypeConversion_amax.y;
  localB->TmpSignalConversionAtSFunctio_h[1] =
    localB->sf_DataTypeConversion_umax.y;

  /* MATLAB Function: '<S178>/FixedHorizonOptimizer' incorporates:
   *  Constant: '<S180>/DX Constant'
   *  Constant: '<S180>/U Constant'
   *  Constant: '<S180>/X Constant'
   *  Constant: '<S180>/Y Constant'
   *  Memory: '<S150>/LastPcov'
   *  Product: '<S129>/Product'
   */
  std::memset(&Bu[0], 0, 420U * sizeof(real_T));
  std::memset(&Bv[0], 0, 420U * sizeof(real_T));
  std::memset(&Dv[0], 0, 126U * sizeof(real_T));
  std::memset(&Dvm[0], 0, 126U * sizeof(real_T));
  std::memset(&localB->Cm[0], 0, 630U * sizeof(real_T));
  std::memcpy(&b_A[0], &c_0[0], 100U * sizeof(real_T));
  std::memcpy(&b_B[0], &d_0[0], 80U * sizeof(real_T));
  std::memcpy(&b_C[0], &e[0], 30U * sizeof(real_T));
  for (r2 = 0; r2 < 24; r2++) {
    b_D[r2] = f[r2];
  }

  for (r2 = 0; r2 < 27; r2++) {
    b[r2] = localB->B[r2] * g[r2];
  }

  for (r2 = 0; r2 < 9; r2++) {
    b_C[3 * r2] = localB->C[3 * r2] / h_0[3 * r2];
    b_C[3 * r2 + 1] = localB->C[3 * r2 + 1] / h_0[3 * r2 + 1];
    b_C[3 * r2 + 2] = localB->C[3 * r2 + 2] / h_0[3 * r2 + 2];
  }

  for (r2 = 0; r2 < 9; r2++) {
    std::memcpy(&b_A[r2 * 10], &localB->A[r2 * 9], 9U * sizeof(real_T));
  }

  for (r2 = 0; r2 < 9; r2++) {
    for (Coef = 0; Coef < 2; Coef++) {
      b_B[r2 + 10 * Coef] = b[9 * Coef + r2];
    }
  }

  std::memcpy(&b_B[20], &b[18], 9U * sizeof(real_T));
  b_D[6] = localB->D[6] / 30.0 * 0.1;
  b_D[7] = 0.1 * localB->D[7];
  b_D[8] = localB->D[8] / 0.2 * 0.1;
<<<<<<< .mine
  std::memcpy(&Bu[0], &b_B[0], 20U * sizeof(real_T));
  std::memcpy(&Bv[0], &b_B[20], 20U * sizeof(real_T));
  for (r2 = 0; r2 < 10; r2++) {
    localB->Cm[3 * r2] = b_C[3 * r2];
    localB->Cm[3 * r2 + 1] = b_C[3 * r2 + 1];
    localB->Cm[3 * r2 + 2] = b_C[3 * r2 + 2];
||||||| .r78
  std::memcpy(&localB->Bu[0], &b_B[0], 20U * sizeof(real_T));
  std::memcpy(&localB->Bv[0], &b_B[20], 20U * sizeof(real_T));
  for (r3 = 0; r3 < 10; r3++) {
    localB->Cm[3 * r3] = b_C[3 * r3];
    localB->Cm[3 * r3 + 1] = b_C[3 * r3 + 1];
    localB->Cm[3 * r3 + 2] = b_C[3 * r3 + 2];
=======
  std::memcpy(&localB->Bu[0], &b_B[0], 20U * sizeof(real_T));
  std::memcpy(&localB->Bv[0], &b_B[20], 20U * sizeof(real_T));
  for (r2 = 0; r2 < 10; r2++) {
    localB->Cm[3 * r2] = b_C[3 * r2];
    localB->Cm[3 * r2 + 1] = b_C[3 * r2 + 1];
    localB->Cm[3 * r2 + 2] = b_C[3 * r2 + 2];
>>>>>>> .r84
  }

  for (r2 = 0; r2 < 2; r2++) {
    Dvm[3 * r2] = b_D[(r2 + 2) * 3];
    Dvm[3 * r2 + 1] = b_D[(r2 + 2) * 3 + 1];
    Dvm[3 * r2 + 2] = b_D[(r2 + 2) * 3 + 2];
  }

  UnknownIn[0] = 1;
  UnknownIn[1] = 2;
  UnknownIn[2] = 3;
  UnknownIn[3] = 5;
  UnknownIn[4] = 6;
  UnknownIn[5] = 7;
  UnknownIn[6] = 8;
  for (r2 = 0; r2 < 7; r2++) {
    for (Coef = 0; Coef < 10; Coef++) {
      b_tmp[Coef + 13 * r2] = b_B[(UnknownIn[r2] - 1) * 10 + Coef];
    }

    b_tmp[13 * r2 + 10] = b_D[(UnknownIn[r2] - 1) * 3];
    b_tmp[13 * r2 + 11] = b_D[(UnknownIn[r2] - 1) * 3 + 1];
    b_tmp[13 * r2 + 12] = b_D[(UnknownIn[r2] - 1) * 3 + 2];
  }

  for (r2 = 0; r2 < 13; r2++) {
    for (Coef = 0; Coef < 13; Coef++) {
      CovMat[r2 + 13 * Coef] = 0.0;
      for (i = 0; i < 7; i++) {
        h = CovMat[13 * Coef + r2];
        h += b_tmp[13 * i + r2] * b_tmp[13 * i + Coef];
        CovMat[r2 + 13 * Coef] = h;
      }
    }
  }

  for (r2 = 0; r2 < 2; r2++) {
    Dv[3 * r2] = b_D[(r2 + 2) * 3];
    Dv[3 * r2 + 1] = b_D[(r2 + 2) * 3 + 1];
    Dv[3 * r2 + 2] = b_D[(r2 + 2) * 3 + 2];
  }

  std::memcpy(&f_a[0], &o[0], sizeof(real_T) << 3U);
  std::memset(&b_utarget[0], 0, 40U * sizeof(real_T));
  std::memset(&b_xoff[0], 0, 10U * sizeof(real_T));
  U[0] = D_20230119_Mo_PageSwitching_arg->UConstant_Value[0] / 5.0;
  Y[0] = D_20230119_Mo_PageSwitching_arg->YConstant_Value[0] / 30.0;
  U[1] = D_20230119_Mo_PageSwitching_arg->UConstant_Value[1] / 0.52;
  Y[1] = D_20230119_Mo_PageSwitching_arg->YConstant_Value[1];
  U[2] = D_20230119_Mo_PageSwitching_arg->UConstant_Value[2] / 0.1;
  Y[2] = D_20230119_Mo_PageSwitching_arg->YConstant_Value[2] / 0.2;
  b_uoff[0] = U[0];
  b_uoff[1] = U[1];
  for (i = 0; i < 8; i++) {
    h = f_a[i];
<<<<<<< .mine
    r2 = b_Mrows[i];
    if (r2 <= 160) {
      h += 0.0 - U[(r2 - (((r2 - 121) / D_20230119_Modell_Inbetriebn_nu) << 1))
        - 121];
||||||| .r78
    r3 = b_Mrows[i];
    if (r3 <= 240) {
      h += 0.0 - U[(r3 - (((r3 - 181) / D_20230119_Modell_Inbetriebn_nu) << 1))
        - 181];
=======
    r2 = b_Mrows[i];
    if (r2 <= 240) {
      h += 0.0 - U[(r2 - (((r2 - 181) / D_20230119_Modell_Inbetriebn_nu) << 1))
        - 181];
>>>>>>> .r84
    } else {
<<<<<<< .mine
      h -= 0.0 - U[(r2 - (((r2 - 161) >> 1) << 1)) - 161];
||||||| .r78
      h -= 0.0 - U[(r3 - (((r3 - 241) >> 1) << 1)) - 241];
=======
      h -= 0.0 - U[(r2 - (((r2 - 241) >> 1) << 1)) - 241];
>>>>>>> .r84
    }

    f_a[i] = h;
  }

  for (i = 0; i < 2; i++) {
    h = U[i];
<<<<<<< .mine
    for (r2 = 0; r2 < 20; r2++) {
      e_a_0 = b_utarget[(r2 << 1) + i] - h;
      b_utarget[i + (r2 << 1)] = e_a_0;
||||||| .r78
    for (r3 = 0; r3 < 30; r3++) {
      e_a_0 = b_utarget[(r3 << 1) + i] - h;
      b_utarget[i + (r3 << 1)] = e_a_0;
=======
    for (r2 = 0; r2 < 30; r2++) {
      e_a_0 = b_utarget[(r2 << 1) + i] - h;
      b_utarget[i + (r2 << 1)] = e_a_0;
>>>>>>> .r84
    }
  }

  std::memcpy(&b_xoff[0], &D_20230119_Mo_PageSwitching_arg->XConstant_Value[0],
              9U * sizeof(real_T));
  std::memcpy(&Bv[10], &D_20230119_Mo_PageSwitching_arg->DXConstant_Value[0], 9U
              * sizeof(real_T));
  std::memset(&vseq[0], 0, 42U * sizeof(real_T));
  for (i = 0; i < 21; i++) {
    vseq[(i << 1) + 1] = 1.0;
  }

  for (i = 0; i < 20; i++) {
    rseq[i * D_20230119_Modell_Inbetriebn_ny] =
      localB->TmpSignalConversionAtSFunctio_e[0] * 0.033333333333333333 - Y[0];
    rseq[i * D_20230119_Modell_Inbetriebn_ny + 1] =
      localB->TmpSignalConversionAtSFunctio_e[1] - Y[1];
    rseq[i * D_20230119_Modell_Inbetriebn_ny + 2] =
      localB->TmpSignalConversionAtSFunctio_e[2] * 5.0 - Y[2];
  }

<<<<<<< .mine
  for (i = 0; i < 21; i++) {
    vseq[i << 1] = D_20230119_Modell_Inbe_RMDscale * localB->Product[i] - U[2];
||||||| .r78
  for (i = 0; i < 31; i++) {
    vseq[i << 1] = D_20230119_Modell_Inbe_RMDscale *
      localB->TmpRTBAtFixedHorizonOptimizer_l[i] - U[2];
=======
  for (i = 0; i < 31; i++) {
    vseq[i << 1] = D_20230119_Modell_Inbe_RMDscale * localB->Product[i] - U[2];
>>>>>>> .r84
  }

  e_a_0 = vseq[0];
  Ap_idx_2 = vseq[1];
  for (r2 = 0; r2 < 9; r2++) {
    c_B[r2] = 0;
  }

  for (i = 0; i < 3; i++) {
    c_B[i + 3 * i] = 1;
    for (r2 = 0; r2 < 10; r2++) {
      L[i + 3 * r2] = 0.0;
      for (Coef = 0; Coef < 10; Coef++) {
        h = L[3 * r2 + i];
        h += localB->Cm[3 * Coef + i] * localB->LastPcov[10 * r2 + Coef];
        L[i + 3 * r2] = h;
      }
    }

    for (r2 = 0; r2 < 3; r2++) {
      a21 = 0.0;
      for (Coef = 0; Coef < 10; Coef++) {
        a21 += L[3 * Coef + i] * localB->Cm[3 * Coef + r2];
      }

      Bl[i + 3 * r2] = CovMat[((r2 + 10) * 13 + i) + 10] + a21;
    }
  }

  Coef = 0;
  r2 = 1;
  r3 = 2;
  h = std::abs(Bl[0]);
  a21 = std::abs(Bl[1]);
  if (a21 > h) {
    h = a21;
    Coef = 1;
    r2 = 0;
  }

  if (std::abs(Bl[2]) > h) {
    Coef = 2;
    r2 = 1;
    r3 = 0;
  }

  Bl[r2] /= Bl[Coef];
  Bl[r3] /= Bl[Coef];
  Bl[r2 + 3] -= Bl[Coef + 3] * Bl[r2];
  Bl[r3 + 3] -= Bl[Coef + 3] * Bl[r3];
  Bl[r2 + 6] -= Bl[Coef + 6] * Bl[r2];
  Bl[r3 + 6] -= Bl[Coef + 6] * Bl[r3];
  if (std::abs(Bl[r3 + 3]) > std::abs(Bl[r2 + 3])) {
    i = r2;
    r2 = r3;
    r3 = i;
  }

  Bl[r3 + 3] /= Bl[r2 + 3];
  Bl[r3 + 6] -= Bl[r3 + 3] * Bl[r2 + 6];
  Kinv[3 * Coef] = static_cast<real_T>(c_B[0]) / Bl[Coef];
  Kinv[3 * r2] = static_cast<real_T>(c_B[3]) - Kinv[3 * Coef] * Bl[Coef + 3];
  Kinv[3 * r3] = static_cast<real_T>(c_B[6]) - Kinv[3 * Coef] * Bl[Coef + 6];
  Kinv[3 * r2] /= Bl[r2 + 3];
  Kinv[3 * r3] -= Kinv[3 * r2] * Bl[r2 + 6];
  Kinv[3 * r3] /= Bl[r3 + 6];
  Kinv[3 * r2] -= Kinv[3 * r3] * Bl[r3 + 3];
  Kinv[3 * Coef] -= Kinv[3 * r3] * Bl[r3];
  Kinv[3 * Coef] -= Kinv[3 * r2] * Bl[r2];
  Kinv[3 * Coef + 1] = static_cast<real_T>(c_B[1]) / Bl[Coef];
  Kinv[3 * r2 + 1] = static_cast<real_T>(c_B[4]) - Kinv[3 * Coef + 1] * Bl[Coef
    + 3];
  Kinv[3 * r3 + 1] = static_cast<real_T>(c_B[7]) - Kinv[3 * Coef + 1] * Bl[Coef
    + 6];
  Kinv[3 * r2 + 1] /= Bl[r2 + 3];
  Kinv[3 * r3 + 1] -= Kinv[3 * r2 + 1] * Bl[r2 + 6];
  Kinv[3 * r3 + 1] /= Bl[r3 + 6];
  Kinv[3 * r2 + 1] -= Kinv[3 * r3 + 1] * Bl[r3 + 3];
  Kinv[3 * Coef + 1] -= Kinv[3 * r3 + 1] * Bl[r3];
  Kinv[3 * Coef + 1] -= Kinv[3 * r2 + 1] * Bl[r2];
  Kinv[3 * Coef + 2] = static_cast<real_T>(c_B[2]) / Bl[Coef];
  Kinv[3 * r2 + 2] = static_cast<real_T>(c_B[5]) - Kinv[3 * Coef + 2] * Bl[Coef
    + 3];
  Kinv[3 * r3 + 2] = static_cast<real_T>(c_B[8]) - Kinv[3 * Coef + 2] * Bl[Coef
    + 6];
  Kinv[3 * r2 + 2] /= Bl[r2 + 3];
  Kinv[3 * r3 + 2] -= Kinv[3 * r2 + 2] * Bl[r2 + 6];
  Kinv[3 * r3 + 2] /= Bl[r3 + 6];
  Kinv[3 * r2 + 2] -= Kinv[3 * r3 + 2] * Bl[r3 + 3];
  Kinv[3 * Coef + 2] -= Kinv[3 * r3 + 2] * Bl[r3];
  Kinv[3 * Coef + 2] -= Kinv[3 * r2 + 2] * Bl[r2];
  for (r2 = 0; r2 < 10; r2++) {
    for (Coef = 0; Coef < 10; Coef++) {
      b_A_0[r2 + 10 * Coef] = 0.0;
      for (i = 0; i < 10; i++) {
        a21 = b_A_0[10 * Coef + r2];
        a21 += b_A[10 * i + r2] * localB->LastPcov[10 * Coef + i];
        b_A_0[r2 + 10 * Coef] = a21;
      }
    }

    for (Coef = 0; Coef < 3; Coef++) {
      a21 = 0.0;
      for (i = 0; i < 10; i++) {
        a21 += b_A_0[10 * i + r2] * localB->Cm[3 * i + Coef];
      }

      b_A_1[r2 + 10 * Coef] = CovMat[(Coef + 10) * 13 + r2] + a21;
    }

    for (Coef = 0; Coef < 3; Coef++) {
      L[r2 + 10 * Coef] = 0.0;
      L_0 = L[10 * Coef + r2];
      L_0 += Kinv[3 * Coef] * b_A_1[r2];
      L[r2 + 10 * Coef] = L_0;
      L_0 = L[10 * Coef + r2];
      L_0 += Kinv[3 * Coef + 1] * b_A_1[r2 + 10];
      L[r2 + 10 * Coef] = L_0;
      L_0 = L[10 * Coef + r2];
      L_0 += Kinv[3 * Coef + 2] * b_A_1[r2 + 20];
      L[r2 + 10 * Coef] = L_0;
    }

<<<<<<< .mine
    a21 = Bu[r2] * 0.0;
    a21 += Bu[r2 + 10] * 0.0;
    xk[r2] = (localB->last_x[r2] - b_xoff[r2]) + a21;
||||||| .r78
    a21 = localB->Bu[r3] * 0.0;
    a21 += localB->Bu[r3 + 10] * 0.0;
    xk[r3] = (localB->last_x[r3] - b_xoff[r3]) + a21;
=======
    a21 = localB->Bu[r2] * 0.0;
    a21 += localB->Bu[r2 + 10] * 0.0;
    xk[r2] = (localB->last_x[r2] - b_xoff[r2]) + a21;
>>>>>>> .r84
  }

  for (r2 = 0; r2 < 3; r2++) {
    Cm_0[r2] = 0.0;
    for (Coef = 0; Coef < 10; Coef++) {
      h = Cm_0[r2];
      h += localB->Cm[3 * Coef + r2] * xk[Coef];
      Cm_0[r2] = h;
    }

    h = Dvm[r2] * e_a_0;
    h += Dvm[r2 + 3] * Ap_idx_2;
    U[r2] = (localB->TmpSignalConversionAtSFunctionI[r2] * x[r2] - Y[r2]) -
      (Cm_0[r2] + h);
  }

  for (r2 = 0; r2 < 10; r2++) {
    for (Coef = 0; Coef < 3; Coef++) {
      b_A_1[r2 + 10 * Coef] = 0.0;
      for (i = 0; i < 10; i++) {
        a21 = b_A_1[10 * Coef + r2];
        a21 += localB->LastPcov[10 * i + r2] * localB->Cm[3 * i + Coef];
        b_A_1[r2 + 10 * Coef] = a21;
      }
    }

    for (Coef = 0; Coef < 3; Coef++) {
      tmp_0[r2 + 10 * Coef] = 0.0;
      a21 = tmp_0[10 * Coef + r2];
      a21 += Kinv[3 * Coef] * b_A_1[r2];
      tmp_0[r2 + 10 * Coef] = a21;
      a21 = tmp_0[10 * Coef + r2];
      a21 += Kinv[3 * Coef + 1] * b_A_1[r2 + 10];
      tmp_0[r2 + 10 * Coef] = a21;
      a21 = tmp_0[10 * Coef + r2];
      a21 += Kinv[3 * Coef + 2] * b_A_1[r2 + 20];
      tmp_0[r2 + 10 * Coef] = a21;
    }
  }

  for (r2 = 0; r2 < 10; r2++) {
    a21 = tmp_0[r2] * U[0];
    a21 += tmp_0[r2 + 10] * U[1];
    a21 += tmp_0[r2 + 20] * U[2];
    localB->xest[r2] = xk[r2] + a21;
  }

  tmp_1[0] = localB->last_mv[0] - b_uoff[0];
  tmp_1[1] = localB->last_mv[1] - b_uoff[1];
  std::memset(&b_B[0], 0, 80U * sizeof(real_T));
  std::memset(&tmp_2[0], 0, 336U * sizeof(real_T));
  tmp_3[0] = 0.010000000000000002;
  tmp_4[0] = 0.0;
  tmp_5[0] = 0.2;
  tmp_3[1] = 0.010000000000000002;
  tmp_4[1] = 0.0;
  tmp_5[1] = 1.9230769230769229;
  std::memcpy(&Cm[0], &q[0], sizeof(real_T) << 4);
  std::memcpy(&r_0[0], &r[0], 25U * sizeof(real_T));
  std::memcpy(&s_0[0], &s[0], 40U * sizeof(real_T));
  D_20230119_M_mpcblock_optimizer(rseq, vseq,
    localB->TmpSignalConversionAtSFunctio_g,
    localB->TmpSignalConversionAtSFunctio_h, static_cast<int32_T>(rt_roundd_snf
    (localB->y_b)), localB->xest, tmp_1, localB->Memory, f_a, b_B, Cm, tmp_2,
    b_utarget, b_uoff, 0, r_0, s_0, t, tmp_3, u, tmp_4, w, b_A, Bu, Bv, b_C, Dv,
    b_Mrows, tmp_5, localB->u, localB->useq, &h, localB->iAout, localB);
  localB->cost = 0.0;
<<<<<<< .mine
  std::memset(&localB->yseq[0], 0, 63U * sizeof(real_T));
  std::memset(&localB->xseq[0], 0, 210U * sizeof(real_T));
  for (r2 = 0; r2 < 10; r2++) {
||||||| .r78
  std::memset(&localB->yseq[0], 0, 93U * sizeof(real_T));
  std::memset(&localB->xseq[0], 0, 310U * sizeof(real_T));
  for (r3 = 0; r3 < 10; r3++) {
=======
  std::memset(&localB->yseq[0], 0, 93U * sizeof(real_T));
  std::memset(&localB->xseq[0], 0, 310U * sizeof(real_T));
  for (r2 = 0; r2 < 10; r2++) {
>>>>>>> .r84
    for (Coef = 0; Coef < 10; Coef++) {
      b_A_0[r2 + 10 * Coef] = 0.0;
      b_A_2[r2 + 10 * Coef] = 0.0;
      for (i = 0; i < 10; i++) {
        a21 = b_A_2[10 * Coef + r2];
        b_A_6 = b_A[10 * i + r2];
        b_A_5 = b_A_0[10 * Coef + r2];
        b_A_5 += localB->LastPcov[10 * Coef + i] * b_A_6;
        a21 += localB->LastPcov[10 * Coef + i] * b_A_6;
        b_A_0[r2 + 10 * Coef] = b_A_5;
        b_A_2[r2 + 10 * Coef] = a21;
      }
    }

    for (Coef = 0; Coef < 3; Coef++) {
      a21 = 0.0;
      for (i = 0; i < 10; i++) {
        a21 += b_A_2[10 * i + r2] * localB->Cm[3 * i + Coef];
      }

      b_A_1[r2 + 10 * Coef] = CovMat[(Coef + 10) * 13 + r2] + a21;
    }

    for (Coef = 0; Coef < 10; Coef++) {
      b_A_3[r2 + 10 * Coef] = 0.0;
      for (i = 0; i < 10; i++) {
        a21 = b_A_3[10 * Coef + r2];
        a21 += b_A_0[10 * i + r2] * b_A[10 * i + Coef];
        b_A_3[r2 + 10 * Coef] = a21;
      }
    }
  }

  for (r2 = 0; r2 < 10; r2++) {
    for (Coef = 0; Coef < 10; Coef++) {
      b_A_0[r2 + 10 * Coef] = 0.0;
      a21 = b_A_0[10 * Coef + r2];
      a21 += b_A_1[r2] * L[Coef];
      b_A_0[r2 + 10 * Coef] = a21;
      a21 = b_A_0[10 * Coef + r2];
      a21 += b_A_1[r2 + 10] * L[Coef + 10];
      b_A_0[r2 + 10 * Coef] = a21;
      a21 = b_A_0[10 * Coef + r2];
      a21 += b_A_1[r2 + 20] * L[Coef + 20];
      b_A_0[r2 + 10 * Coef] = a21;
    }
  }

  for (r2 = 0; r2 < 10; r2++) {
    for (Coef = 0; Coef < 10; Coef++) {
      b_A_2[Coef + 10 * r2] = (b_A_3[10 * r2 + Coef] - b_A_0[10 * r2 + Coef]) +
        CovMat[13 * r2 + Coef];
    }
  }

  b_A_6 = localB->u[0] - b_uoff[0];
  b_A_5 = localB->u[1] - b_uoff[1];
  for (r2 = 0; r2 < 10; r2++) {
    b_A_4[r2] = 0.0;
    for (Coef = 0; Coef < 10; Coef++) {
      a21 = b_A_4[r2];
      localB->Pk1[Coef + 10 * r2] = (b_A_2[10 * r2 + Coef] + b_A_2[10 * Coef +
        r2]) * 0.5;
      a21 += b_A[10 * Coef + r2] * xk[Coef];
      b_A_4[r2] = a21;
    }

<<<<<<< .mine
    L_0 = Bu[r2] * b_A_6;
    a21 = Bv[r2] * e_a_0;
    L_0 += Bu[r2 + 10] * b_A_5;
    a21 += Bv[r2 + 10] * Ap_idx_2;
    a21 += b_A_4[r2] + L_0;
    L_0 = L[r2] * U[0];
    L_0 += L[r2 + 10] * U[1];
    L_0 += L[r2 + 20] * U[2];
    localB->xk1[r2] = (a21 + L_0) + b_xoff[r2];
||||||| .r78
    L_0 = localB->Bu[r3] * b_A_6;
    a21 = localB->Bv[r3] * e_a_0;
    L_0 += localB->Bu[r3 + 10] * b_A_5;
    a21 += localB->Bv[r3 + 10] * Ap_idx_2;
    a21 += b_A_4[r3] + L_0;
    L_0 = L[r3] * U[0];
    L_0 += L[r3 + 10] * U[1];
    L_0 += L[r3 + 20] * U[2];
    localB->xk1[r3] = (a21 + L_0) + b_xoff[r3];
=======
    L_0 = localB->Bu[r2] * b_A_6;
    a21 = localB->Bv[r2] * e_a_0;
    L_0 += localB->Bu[r2 + 10] * b_A_5;
    a21 += localB->Bv[r2 + 10] * Ap_idx_2;
    a21 += b_A_4[r2] + L_0;
    L_0 = L[r2] * U[0];
    L_0 += L[r2 + 10] * U[1];
    L_0 += L[r2 + 20] * U[2];
    localB->xk1[r2] = (a21 + L_0) + b_xoff[r2];
>>>>>>> .r84
  }

  for (r2 = 0; r2 < 10; r2++) {
    localB->xest[r2] += b_xoff[r2];
  }

  localB->status = h;

  /* Gain: '<S150>/u_scale' */
  localB->u_scale[0] = D_20230119_Mo_PageSwitching_arg->u_scale_Gain[0] *
    localB->u[0];
  localB->u_scale[1] = D_20230119_Mo_PageSwitching_arg->u_scale_Gain[1] *
    localB->u[1];
  for (i = 0; i < 42; i++) {
    /* Gain: '<S150>/useq_scale' */
    localB->useq_scale[i] = D_20230119_Mo_PageSwitching_arg->useq_scale_Gain[i] *
      localB->useq[i];
  }

  for (i = 0; i < 63; i++) {
    /* Gain: '<S150>/useq_scale1' */
    localB->useq_scale1[i] = D_20230119_Mo_PageSwitching_arg->useq_scale1_Gain[i]
      * localB->yseq[i];
  }

  /* Constant: '<S150>/ym_zero' */
  localB->ym_zero[0] = D_20230119_Mo_PageSwitching_arg->ym_zero_Value[0];
  localB->ym_zero[1] = D_20230119_Mo_PageSwitching_arg->ym_zero_Value[1];
  localB->ym_zero[2] = D_20230119_Mo_PageSwitching_arg->ym_zero_Value[2];

  /* Constant: '<S128>/Relative distance ground' */
  localB->Relativedistanceground =
    D_20230119_Mo_PageSwitching_arg->Relativedistanceground_Value;

  /* Constant: '<S128>/Relative velocity ground' */
  localB->Relativevelocityground =
    D_20230119_Mo_PageSwitching_arg->Relativevelocityground_Value;

  /* Constant: '<S128>/Time gap ground' */
  localB->Timegapground = D_20230119_Mo_PageSwitching_arg->Timegapground_Value;

  /* Constant: '<S128>/Vehicle dynamics matrix A ground' */
  localB->VehicledynamicsmatrixAground =
    D_20230119_Mo_PageSwitching_arg->VehicledynamicsmatrixAground_Va;

  /* Constant: '<S128>/Vehicle dynamics matrix B ground' */
  localB->VehicledynamicsmatrixBground =
    D_20230119_Mo_PageSwitching_arg->VehicledynamicsmatrixBground_Va;

  /* Constant: '<S128>/Vehicle dynamics matrix C ground' */
  localB->VehicledynamicsmatrixCground =
    D_20230119_Mo_PageSwitching_arg->VehicledynamicsmatrixCground_Va;

  /* Update for Memory: '<S150>/LastPcov' */
  std::memcpy(&localDW->LastPcov_PreviousInput[0], &localB->Pk1[0], 100U *
              sizeof(real_T));

  /* Update for Memory: '<S150>/Memory' */
  for (i = 0; i < 8; i++) {
    localDW->Memory_PreviousInput[i] = localB->iAout[i];
  }

  /* End of Update for Memory: '<S150>/Memory' */

  /* Update for UnitDelay: '<S150>/last_mv' */
  localDW->last_mv_DSTATE[0] = localB->u[0];
  localDW->last_mv_DSTATE[1] = localB->u[1];

  /* Update for Memory: '<S150>/last_x' */
  std::memcpy(&localDW->last_x_PreviousInput[0], &localB->xk1[0], 10U * sizeof
              (real_T));
}

/* Termination for atomic system: '<S120>/Path Following Control System' */
void PathFollowingControlSy_Term(DW_PathFollowingControlSystem_T *localDW)
{
  /* Terminate for Assertion: '<S133>/Assertion' */
  slTestTerminate(&localDW->Assertion_sltestBlkInfo);
}

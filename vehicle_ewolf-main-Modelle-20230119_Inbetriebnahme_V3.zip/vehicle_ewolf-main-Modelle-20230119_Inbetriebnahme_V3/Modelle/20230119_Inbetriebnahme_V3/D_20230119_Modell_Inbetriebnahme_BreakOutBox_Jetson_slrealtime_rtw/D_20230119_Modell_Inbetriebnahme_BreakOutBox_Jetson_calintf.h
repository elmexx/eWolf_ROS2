#ifndef D__________MODELL_INBETRIEBNAHME_BREAKOUTBOX_JETSON_CALINTF_H
#define D__________MODELL_INBETRIEBNAHME_BREAKOUTBOX_JETSON_CALINTF_H
#include "SegmentInfo.hpp"

namespace slrealtime
{
  SegmentVector &getSegmentVector(void);
}                                      // slrealtime

#endif

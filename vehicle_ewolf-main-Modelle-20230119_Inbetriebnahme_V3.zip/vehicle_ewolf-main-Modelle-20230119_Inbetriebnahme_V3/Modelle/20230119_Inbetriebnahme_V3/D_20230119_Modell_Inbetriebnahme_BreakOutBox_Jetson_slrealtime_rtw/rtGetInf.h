/*
 * rtGetInf.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "D_20230119_Modell_Inbetriebnahme_BreakOutBox_Jetson".
 *
<<<<<<< .mine
 * Model version              : 4.38
||||||| .r78
 * Model version              : 4.24
=======
 * Model version              : 4.33
>>>>>>> .r84
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
<<<<<<< .mine
 * C++ source code generated on : Thu Oct  5 15:53:28 2023
||||||| .r78
 * C++ source code generated on : Thu May 11 16:00:17 2023
=======
 * C++ source code generated on : Fri Oct 13 13:42:54 2023
>>>>>>> .r84
 *
 * Target selection: slrealtime.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rtGetInf_h_
#define RTW_HEADER_rtGetInf_h_
#include "rtwtypes.h"
#ifdef __cplusplus

extern "C"
{

#endif

  extern real_T rtGetInf(void);
  extern real32_T rtGetInfF(void);
  extern real_T rtGetMinusInf(void);
  extern real32_T rtGetMinusInfF(void);

#ifdef __cplusplus

}                                      /* extern "C" */

#endif
#endif                                 /* RTW_HEADER_rtGetInf_h_ */

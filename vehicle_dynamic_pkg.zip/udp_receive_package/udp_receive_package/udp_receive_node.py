import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
from rclpy.time import Time

import socket
import numpy as np
from time import time

HOSTIP = '10.42.0.12' # '169.254.113.10'  
PORT = 5501

class VehicleDataReceiver(Node):

    def __init__(self):
        super().__init__('vehicle_data_receiver')
        self.publisher_ = self.create_publisher(Float32MultiArray, '/udp_receive', 10)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((HOSTIP, PORT))
        self.get_logger().info(f"UDP listing on port 5501")

        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        data, _ = self.sock.recvfrom(1024)  # buffersize = 1024
        if data:
            data_np = np.frombuffer(data, dtype=np.double)
            print("Message from Client: ", data_np.astype(float))

            current_time = self.get_clock().now()
            sec = np.float32(current_time.seconds_nanoseconds()[0])
            nanosec = np.float32(current_time.seconds_nanoseconds()[1])

            data_with_time = np.append(data_np, [sec, nanosec])

            msg = Float32MultiArray()
            msg.data = data_with_time.tolist()

            self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = VehicleDataReceiver()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()




